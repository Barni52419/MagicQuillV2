const {
  SvelteComponent: C0,
  assign: k0,
  create_slot: E0,
  detach: T0,
  element: O0,
  get_all_dirty_from_scope: M0,
  get_slot_changes: P0,
  get_spread_update: A0,
  init: j0,
  insert: D0,
  safe_not_equal: L0,
  set_dynamic_element_data: Kc,
  set_style: ze,
  toggle_class: bn,
  transition_in: ld,
  transition_out: cd,
  update_slot_base: R0
} = window.__gradio__svelte__internal;
function I0(t) {
  let e, n, o;
  const u = (
    /*#slots*/
    t[18].default
  ), g = E0(
    u,
    t,
    /*$$scope*/
    t[17],
    null
  );
  let v = [
    { "data-testid": (
      /*test_id*/
      t[7]
    ) },
    { id: (
      /*elem_id*/
      t[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      t[3].join(" ") + " svelte-nl1om8"
    }
  ], x = {};
  for (let S = 0; S < v.length; S += 1)
    x = k0(x, v[S]);
  return {
    c() {
      e = O0(
        /*tag*/
        t[14]
      ), g && g.c(), Kc(
        /*tag*/
        t[14]
      )(e, x), bn(
        e,
        "hidden",
        /*visible*/
        t[10] === !1
      ), bn(
        e,
        "padded",
        /*padding*/
        t[6]
      ), bn(
        e,
        "border_focus",
        /*border_mode*/
        t[5] === "focus"
      ), bn(
        e,
        "border_contrast",
        /*border_mode*/
        t[5] === "contrast"
      ), bn(e, "hide-container", !/*explicit_call*/
      t[8] && !/*container*/
      t[9]), ze(
        e,
        "height",
        /*get_dimension*/
        t[15](
          /*height*/
          t[0]
        )
      ), ze(e, "width", typeof /*width*/
      t[1] == "number" ? `calc(min(${/*width*/
      t[1]}px, 100%))` : (
        /*get_dimension*/
        t[15](
          /*width*/
          t[1]
        )
      )), ze(
        e,
        "border-style",
        /*variant*/
        t[4]
      ), ze(
        e,
        "overflow",
        /*allow_overflow*/
        t[11] ? "visible" : "hidden"
      ), ze(
        e,
        "flex-grow",
        /*scale*/
        t[12]
      ), ze(e, "min-width", `calc(min(${/*min_width*/
      t[13]}px, 100%))`), ze(e, "border-width", "var(--block-border-width)");
    },
    m(S, E) {
      D0(S, e, E), g && g.m(e, null), o = !0;
    },
    p(S, E) {
      g && g.p && (!o || E & /*$$scope*/
      131072) && R0(
        g,
        u,
        S,
        /*$$scope*/
        S[17],
        o ? P0(
          u,
          /*$$scope*/
          S[17],
          E,
          null
        ) : M0(
          /*$$scope*/
          S[17]
        ),
        null
      ), Kc(
        /*tag*/
        S[14]
      )(e, x = A0(v, [
        (!o || E & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          S[7]
        ) },
        (!o || E & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          S[2]
        ) },
        (!o || E & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        S[3].join(" ") + " svelte-nl1om8")) && { class: n }
      ])), bn(
        e,
        "hidden",
        /*visible*/
        S[10] === !1
      ), bn(
        e,
        "padded",
        /*padding*/
        S[6]
      ), bn(
        e,
        "border_focus",
        /*border_mode*/
        S[5] === "focus"
      ), bn(
        e,
        "border_contrast",
        /*border_mode*/
        S[5] === "contrast"
      ), bn(e, "hide-container", !/*explicit_call*/
      S[8] && !/*container*/
      S[9]), E & /*height*/
      1 && ze(
        e,
        "height",
        /*get_dimension*/
        S[15](
          /*height*/
          S[0]
        )
      ), E & /*width*/
      2 && ze(e, "width", typeof /*width*/
      S[1] == "number" ? `calc(min(${/*width*/
      S[1]}px, 100%))` : (
        /*get_dimension*/
        S[15](
          /*width*/
          S[1]
        )
      )), E & /*variant*/
      16 && ze(
        e,
        "border-style",
        /*variant*/
        S[4]
      ), E & /*allow_overflow*/
      2048 && ze(
        e,
        "overflow",
        /*allow_overflow*/
        S[11] ? "visible" : "hidden"
      ), E & /*scale*/
      4096 && ze(
        e,
        "flex-grow",
        /*scale*/
        S[12]
      ), E & /*min_width*/
      8192 && ze(e, "min-width", `calc(min(${/*min_width*/
      S[13]}px, 100%))`);
    },
    i(S) {
      o || (ld(g, S), o = !0);
    },
    o(S) {
      cd(g, S), o = !1;
    },
    d(S) {
      S && T0(e), g && g.d(S);
    }
  };
}
function F0(t) {
  let e, n = (
    /*tag*/
    t[14] && I0(t)
  );
  return {
    c() {
      n && n.c();
    },
    m(o, u) {
      n && n.m(o, u), e = !0;
    },
    p(o, [u]) {
      /*tag*/
      o[14] && n.p(o, u);
    },
    i(o) {
      e || (ld(n, o), e = !0);
    },
    o(o) {
      cd(n, o), e = !1;
    },
    d(o) {
      n && n.d(o);
    }
  };
}
function B0(t, e, n) {
  let { $$slots: o = {}, $$scope: u } = e, { height: g = void 0 } = e, { width: v = void 0 } = e, { elem_id: x = "" } = e, { elem_classes: S = [] } = e, { variant: E = "solid" } = e, { border_mode: A = "base" } = e, { padding: Y = !0 } = e, { type: V = "normal" } = e, { test_id: Q = void 0 } = e, { explicit_call: tt = !1 } = e, { container: rt = !0 } = e, { visible: ut = !0 } = e, { allow_overflow: H = !0 } = e, { scale: R = null } = e, { min_width: N = 0 } = e, $ = V === "fieldset" ? "fieldset" : "div";
  const at = (it) => {
    if (it !== void 0) {
      if (typeof it == "number")
        return it + "px";
      if (typeof it == "string")
        return it;
    }
  };
  return t.$$set = (it) => {
    "height" in it && n(0, g = it.height), "width" in it && n(1, v = it.width), "elem_id" in it && n(2, x = it.elem_id), "elem_classes" in it && n(3, S = it.elem_classes), "variant" in it && n(4, E = it.variant), "border_mode" in it && n(5, A = it.border_mode), "padding" in it && n(6, Y = it.padding), "type" in it && n(16, V = it.type), "test_id" in it && n(7, Q = it.test_id), "explicit_call" in it && n(8, tt = it.explicit_call), "container" in it && n(9, rt = it.container), "visible" in it && n(10, ut = it.visible), "allow_overflow" in it && n(11, H = it.allow_overflow), "scale" in it && n(12, R = it.scale), "min_width" in it && n(13, N = it.min_width), "$$scope" in it && n(17, u = it.$$scope);
  }, [
    g,
    v,
    x,
    S,
    E,
    A,
    Y,
    Q,
    tt,
    rt,
    ut,
    H,
    R,
    N,
    $,
    at,
    V,
    u,
    o
  ];
}
class z0 extends C0 {
  constructor(e) {
    super(), j0(this, e, B0, F0, L0, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: N0,
  append: Ys,
  attr: jn,
  bubble: U0,
  create_component: W0,
  destroy_component: Y0,
  detach: ud,
  element: Vs,
  init: V0,
  insert: hd,
  listen: G0,
  mount_component: H0,
  safe_not_equal: X0,
  set_data: q0,
  set_style: Li,
  space: Z0,
  text: K0,
  toggle_class: Pe,
  transition_in: Q0,
  transition_out: J0
} = window.__gradio__svelte__internal;
function Qc(t) {
  let e, n;
  return {
    c() {
      e = Vs("span"), n = K0(
        /*label*/
        t[1]
      ), jn(e, "class", "svelte-1lrphxw");
    },
    m(o, u) {
      hd(o, e, u), Ys(e, n);
    },
    p(o, u) {
      u & /*label*/
      2 && q0(
        n,
        /*label*/
        o[1]
      );
    },
    d(o) {
      o && ud(e);
    }
  };
}
function $0(t) {
  let e, n, o, u, g, v, x, S = (
    /*show_label*/
    t[2] && Qc(t)
  );
  return u = new /*Icon*/
  t[0]({}), {
    c() {
      e = Vs("button"), S && S.c(), n = Z0(), o = Vs("div"), W0(u.$$.fragment), jn(o, "class", "svelte-1lrphxw"), Pe(
        o,
        "small",
        /*size*/
        t[4] === "small"
      ), Pe(
        o,
        "large",
        /*size*/
        t[4] === "large"
      ), Pe(
        o,
        "medium",
        /*size*/
        t[4] === "medium"
      ), e.disabled = /*disabled*/
      t[7], jn(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), jn(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), jn(
        e,
        "title",
        /*label*/
        t[1]
      ), jn(e, "class", "svelte-1lrphxw"), Pe(
        e,
        "pending",
        /*pending*/
        t[3]
      ), Pe(
        e,
        "padded",
        /*padded*/
        t[5]
      ), Pe(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), Pe(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), Li(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[12] ? (
        /*_color*/
        t[12]
      ) : "var(--block-label-text-color)"), Li(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      )), Li(
        e,
        "margin-left",
        /*offset*/
        t[11] + "px"
      );
    },
    m(E, A) {
      hd(E, e, A), S && S.m(e, null), Ys(e, n), Ys(e, o), H0(u, o, null), g = !0, v || (x = G0(
        e,
        "click",
        /*click_handler*/
        t[14]
      ), v = !0);
    },
    p(E, [A]) {
      /*show_label*/
      E[2] ? S ? S.p(E, A) : (S = Qc(E), S.c(), S.m(e, n)) : S && (S.d(1), S = null), (!g || A & /*size*/
      16) && Pe(
        o,
        "small",
        /*size*/
        E[4] === "small"
      ), (!g || A & /*size*/
      16) && Pe(
        o,
        "large",
        /*size*/
        E[4] === "large"
      ), (!g || A & /*size*/
      16) && Pe(
        o,
        "medium",
        /*size*/
        E[4] === "medium"
      ), (!g || A & /*disabled*/
      128) && (e.disabled = /*disabled*/
      E[7]), (!g || A & /*label*/
      2) && jn(
        e,
        "aria-label",
        /*label*/
        E[1]
      ), (!g || A & /*hasPopup*/
      256) && jn(
        e,
        "aria-haspopup",
        /*hasPopup*/
        E[8]
      ), (!g || A & /*label*/
      2) && jn(
        e,
        "title",
        /*label*/
        E[1]
      ), (!g || A & /*pending*/
      8) && Pe(
        e,
        "pending",
        /*pending*/
        E[3]
      ), (!g || A & /*padded*/
      32) && Pe(
        e,
        "padded",
        /*padded*/
        E[5]
      ), (!g || A & /*highlight*/
      64) && Pe(
        e,
        "highlight",
        /*highlight*/
        E[6]
      ), (!g || A & /*transparent*/
      512) && Pe(
        e,
        "transparent",
        /*transparent*/
        E[9]
      ), A & /*disabled, _color*/
      4224 && Li(e, "color", !/*disabled*/
      E[7] && /*_color*/
      E[12] ? (
        /*_color*/
        E[12]
      ) : "var(--block-label-text-color)"), A & /*disabled, background*/
      1152 && Li(e, "--bg-color", /*disabled*/
      E[7] ? "auto" : (
        /*background*/
        E[10]
      )), A & /*offset*/
      2048 && Li(
        e,
        "margin-left",
        /*offset*/
        E[11] + "px"
      );
    },
    i(E) {
      g || (Q0(u.$$.fragment, E), g = !0);
    },
    o(E) {
      J0(u.$$.fragment, E), g = !1;
    },
    d(E) {
      E && ud(e), S && S.d(), Y0(u), v = !1, x();
    }
  };
}
function tg(t, e, n) {
  let o, { Icon: u } = e, { label: g = "" } = e, { show_label: v = !1 } = e, { pending: x = !1 } = e, { size: S = "small" } = e, { padded: E = !0 } = e, { highlight: A = !1 } = e, { disabled: Y = !1 } = e, { hasPopup: V = !1 } = e, { color: Q = "var(--block-label-text-color)" } = e, { transparent: tt = !1 } = e, { background: rt = "var(--background-fill-primary)" } = e, { offset: ut = 0 } = e;
  function H(R) {
    U0.call(this, t, R);
  }
  return t.$$set = (R) => {
    "Icon" in R && n(0, u = R.Icon), "label" in R && n(1, g = R.label), "show_label" in R && n(2, v = R.show_label), "pending" in R && n(3, x = R.pending), "size" in R && n(4, S = R.size), "padded" in R && n(5, E = R.padded), "highlight" in R && n(6, A = R.highlight), "disabled" in R && n(7, Y = R.disabled), "hasPopup" in R && n(8, V = R.hasPopup), "color" in R && n(13, Q = R.color), "transparent" in R && n(9, tt = R.transparent), "background" in R && n(10, rt = R.background), "offset" in R && n(11, ut = R.offset);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    8256 && n(12, o = A ? "var(--color-accent)" : Q);
  }, [
    u,
    g,
    v,
    x,
    S,
    E,
    A,
    Y,
    V,
    tt,
    rt,
    ut,
    o,
    Q,
    H
  ];
}
class eg extends N0 {
  constructor(e) {
    super(), V0(this, e, tg, $0, X0, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      offset: 11
    });
  }
}
const {
  SvelteComponent: ng,
  append: rs,
  attr: an,
  detach: ig,
  init: rg,
  insert: ag,
  noop: as,
  safe_not_equal: og,
  set_style: xn,
  svg_element: ba
} = window.__gradio__svelte__internal;
function sg(t) {
  let e, n, o, u;
  return {
    c() {
      e = ba("svg"), n = ba("g"), o = ba("path"), u = ba("path"), an(o, "d", "M18,6L6.087,17.913"), xn(o, "fill", "none"), xn(o, "fill-rule", "nonzero"), xn(o, "stroke-width", "2px"), an(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), an(u, "d", "M4.364,4.364L19.636,19.636"), xn(u, "fill", "none"), xn(u, "fill-rule", "nonzero"), xn(u, "stroke-width", "2px"), an(e, "width", "100%"), an(e, "height", "100%"), an(e, "viewBox", "0 0 24 24"), an(e, "version", "1.1"), an(e, "xmlns", "http://www.w3.org/2000/svg"), an(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), an(e, "xml:space", "preserve"), an(e, "stroke", "currentColor"), xn(e, "fill-rule", "evenodd"), xn(e, "clip-rule", "evenodd"), xn(e, "stroke-linecap", "round"), xn(e, "stroke-linejoin", "round");
    },
    m(g, v) {
      ag(g, e, v), rs(e, n), rs(n, o), rs(e, u);
    },
    p: as,
    i: as,
    o: as,
    d(g) {
      g && ig(e);
    }
  };
}
class lg extends ng {
  constructor(e) {
    super(), rg(this, e, null, sg, og, {});
  }
}
const cg = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Jc = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
cg.reduce(
  (t, { color: e, primary: n, secondary: o }) => ({
    ...t,
    [e]: {
      primary: Jc[e][n],
      secondary: Jc[e][o]
    }
  }),
  {}
);
function Fi(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let o = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + o;
}
function Ha() {
}
const dd = typeof window < "u";
let $c = dd ? () => window.performance.now() : () => Date.now(), fd = dd ? (t) => requestAnimationFrame(t) : Ha;
const Ki = /* @__PURE__ */ new Set();
function pd(t) {
  Ki.forEach((e) => {
    e.c(t) || (Ki.delete(e), e.f());
  }), Ki.size !== 0 && fd(pd);
}
function ug(t) {
  let e;
  return Ki.size === 0 && fd(pd), { promise: new Promise((n) => {
    Ki.add(e = { c: t, f: n });
  }), abort() {
    Ki.delete(e);
  } };
}
const Ri = [];
function hg(t, e = Ha) {
  let n;
  const o = /* @__PURE__ */ new Set();
  function u(v) {
    if (S = v, ((x = t) != x ? S == S : x !== S || x && typeof x == "object" || typeof x == "function") && (t = v, n)) {
      const E = !Ri.length;
      for (const A of o) A[1](), Ri.push(A, t);
      if (E) {
        for (let A = 0; A < Ri.length; A += 2) Ri[A][0](Ri[A + 1]);
        Ri.length = 0;
      }
    }
    var x, S;
  }
  function g(v) {
    u(v(t));
  }
  return { set: u, update: g, subscribe: function(v, x = Ha) {
    const S = [v, x];
    return o.add(S), o.size === 1 && (n = e(u, g) || Ha), v(t), () => {
      o.delete(S), o.size === 0 && n && (n(), n = null);
    };
  } };
}
function tu(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Gs(t, e, n, o) {
  if (typeof n == "number" || tu(n)) {
    const u = o - n, g = (n - e) / (t.dt || 1 / 60), v = (g + (t.opts.stiffness * u - t.opts.damping * g) * t.inv_mass) * t.dt;
    return Math.abs(v) < t.opts.precision && Math.abs(u) < t.opts.precision ? o : (t.settled = !1, tu(n) ? new Date(n.getTime() + v) : n + v);
  }
  if (Array.isArray(n)) return n.map((u, g) => Gs(t, e[g], n[g], o[g]));
  if (typeof n == "object") {
    const u = {};
    for (const g in n) u[g] = Gs(t, e[g], n[g], o[g]);
    return u;
  }
  throw new Error(`Cannot spring ${typeof n} values`);
}
function eu(t, e = {}) {
  const n = hg(t), { stiffness: o = 0.15, damping: u = 0.8, precision: g = 0.01 } = e;
  let v, x, S, E = t, A = t, Y = 1, V = 0, Q = !1;
  function tt(ut, H = {}) {
    A = ut;
    const R = S = {};
    return t == null || H.hard || rt.stiffness >= 1 && rt.damping >= 1 ? (Q = !0, v = $c(), E = ut, n.set(t = A), Promise.resolve()) : (H.soft && (V = 1 / (60 * (H.soft === !0 ? 0.5 : +H.soft)), Y = 0), x || (v = $c(), Q = !1, x = ug((N) => {
      if (Q) return Q = !1, x = null, !1;
      Y = Math.min(Y + V, 1);
      const $ = { inv_mass: Y, opts: rt, settled: !0, dt: 60 * (N - v) / 1e3 }, at = Gs($, E, t, A);
      return v = N, E = t, n.set(t = at), $.settled && (x = null), !$.settled;
    })), new Promise((N) => {
      x.promise.then(() => {
        R === S && N();
      });
    }));
  }
  const rt = { set: tt, update: (ut, H) => tt(ut(A, t), H), subscribe: n.subscribe, stiffness: o, damping: u, precision: g };
  return rt;
}
const {
  SvelteComponent: dg,
  append: on,
  attr: Bt,
  component_subscribe: nu,
  detach: fg,
  element: pg,
  init: gg,
  insert: mg,
  noop: iu,
  safe_not_equal: vg,
  set_style: xa,
  svg_element: sn,
  toggle_class: ru
} = window.__gradio__svelte__internal, { onMount: yg } = window.__gradio__svelte__internal;
function bg(t) {
  let e, n, o, u, g, v, x, S, E, A, Y, V;
  return {
    c() {
      e = pg("div"), n = sn("svg"), o = sn("g"), u = sn("path"), g = sn("path"), v = sn("path"), x = sn("path"), S = sn("g"), E = sn("path"), A = sn("path"), Y = sn("path"), V = sn("path"), Bt(u, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Bt(u, "fill", "#FF7C00"), Bt(u, "fill-opacity", "0.4"), Bt(u, "class", "svelte-43sxxs"), Bt(g, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Bt(g, "fill", "#FF7C00"), Bt(g, "class", "svelte-43sxxs"), Bt(v, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Bt(v, "fill", "#FF7C00"), Bt(v, "fill-opacity", "0.4"), Bt(v, "class", "svelte-43sxxs"), Bt(x, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Bt(x, "fill", "#FF7C00"), Bt(x, "class", "svelte-43sxxs"), xa(o, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), Bt(E, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Bt(E, "fill", "#FF7C00"), Bt(E, "fill-opacity", "0.4"), Bt(E, "class", "svelte-43sxxs"), Bt(A, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Bt(A, "fill", "#FF7C00"), Bt(A, "class", "svelte-43sxxs"), Bt(Y, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Bt(Y, "fill", "#FF7C00"), Bt(Y, "fill-opacity", "0.4"), Bt(Y, "class", "svelte-43sxxs"), Bt(V, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Bt(V, "fill", "#FF7C00"), Bt(V, "class", "svelte-43sxxs"), xa(S, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), Bt(n, "viewBox", "-1200 -1200 3000 3000"), Bt(n, "fill", "none"), Bt(n, "xmlns", "http://www.w3.org/2000/svg"), Bt(n, "class", "svelte-43sxxs"), Bt(e, "class", "svelte-43sxxs"), ru(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(Q, tt) {
      mg(Q, e, tt), on(e, n), on(n, o), on(o, u), on(o, g), on(o, v), on(o, x), on(n, S), on(S, E), on(S, A), on(S, Y), on(S, V);
    },
    p(Q, [tt]) {
      tt & /*$top*/
      2 && xa(o, "transform", "translate(" + /*$top*/
      Q[1][0] + "px, " + /*$top*/
      Q[1][1] + "px)"), tt & /*$bottom*/
      4 && xa(S, "transform", "translate(" + /*$bottom*/
      Q[2][0] + "px, " + /*$bottom*/
      Q[2][1] + "px)"), tt & /*margin*/
      1 && ru(
        e,
        "margin",
        /*margin*/
        Q[0]
      );
    },
    i: iu,
    o: iu,
    d(Q) {
      Q && fg(e);
    }
  };
}
function xg(t, e, n) {
  let o, u;
  var g = this && this.__awaiter || function(Q, tt, rt, ut) {
    function H(R) {
      return R instanceof rt ? R : new rt(function(N) {
        N(R);
      });
    }
    return new (rt || (rt = Promise))(function(R, N) {
      function $(gt) {
        try {
          it(ut.next(gt));
        } catch (b) {
          N(b);
        }
      }
      function at(gt) {
        try {
          it(ut.throw(gt));
        } catch (b) {
          N(b);
        }
      }
      function it(gt) {
        gt.done ? R(gt.value) : H(gt.value).then($, at);
      }
      it((ut = ut.apply(Q, tt || [])).next());
    });
  };
  let { margin: v = !0 } = e;
  const x = eu([0, 0]);
  nu(t, x, (Q) => n(1, o = Q));
  const S = eu([0, 0]);
  nu(t, S, (Q) => n(2, u = Q));
  let E;
  function A() {
    return g(this, void 0, void 0, function* () {
      yield Promise.all([x.set([125, 140]), S.set([-125, -140])]), yield Promise.all([x.set([-125, 140]), S.set([125, -140])]), yield Promise.all([x.set([-125, 0]), S.set([125, -0])]), yield Promise.all([x.set([125, 0]), S.set([-125, 0])]);
    });
  }
  function Y() {
    return g(this, void 0, void 0, function* () {
      yield A(), E || Y();
    });
  }
  function V() {
    return g(this, void 0, void 0, function* () {
      yield Promise.all([x.set([125, 0]), S.set([-125, 0])]), Y();
    });
  }
  return yg(() => (V(), () => E = !0)), t.$$set = (Q) => {
    "margin" in Q && n(0, v = Q.margin);
  }, [v, o, u, x, S];
}
class _g extends dg {
  constructor(e) {
    super(), gg(this, e, xg, bg, vg, { margin: 0 });
  }
}
const {
  SvelteComponent: wg,
  append: vi,
  attr: pn,
  binding_callbacks: au,
  check_outros: Hs,
  create_component: gd,
  create_slot: md,
  destroy_component: vd,
  destroy_each: yd,
  detach: At,
  element: Tn,
  empty: hr,
  ensure_array_like: oo,
  get_all_dirty_from_scope: bd,
  get_slot_changes: xd,
  group_outros: Xs,
  init: Sg,
  insert: jt,
  mount_component: _d,
  noop: qs,
  safe_not_equal: Cg,
  set_data: tn,
  set_style: Zn,
  space: Qe,
  text: $t,
  toggle_class: qe,
  transition_in: fn,
  transition_out: On,
  update_slot_base: wd
} = window.__gradio__svelte__internal, { tick: kg } = window.__gradio__svelte__internal, { onDestroy: Eg } = window.__gradio__svelte__internal, { createEventDispatcher: Tg } = window.__gradio__svelte__internal, Og = (t) => ({}), ou = (t) => ({}), Mg = (t) => ({}), su = (t) => ({});
function lu(t, e, n) {
  const o = t.slice();
  return o[41] = e[n], o[43] = n, o;
}
function cu(t, e, n) {
  const o = t.slice();
  return o[41] = e[n], o;
}
function Pg(t) {
  let e, n, o, u, g = (
    /*i18n*/
    t[1]("common.error") + ""
  ), v, x, S;
  n = new eg({
    props: {
      Icon: lg,
      label: (
        /*i18n*/
        t[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    t[32]
  );
  const E = (
    /*#slots*/
    t[30].error
  ), A = md(
    E,
    t,
    /*$$scope*/
    t[29],
    ou
  );
  return {
    c() {
      e = Tn("div"), gd(n.$$.fragment), o = Qe(), u = Tn("span"), v = $t(g), x = Qe(), A && A.c(), pn(e, "class", "clear-status svelte-v0wucf"), pn(u, "class", "error svelte-v0wucf");
    },
    m(Y, V) {
      jt(Y, e, V), _d(n, e, null), jt(Y, o, V), jt(Y, u, V), vi(u, v), jt(Y, x, V), A && A.m(Y, V), S = !0;
    },
    p(Y, V) {
      const Q = {};
      V[0] & /*i18n*/
      2 && (Q.label = /*i18n*/
      Y[1]("common.clear")), n.$set(Q), (!S || V[0] & /*i18n*/
      2) && g !== (g = /*i18n*/
      Y[1]("common.error") + "") && tn(v, g), A && A.p && (!S || V[0] & /*$$scope*/
      536870912) && wd(
        A,
        E,
        Y,
        /*$$scope*/
        Y[29],
        S ? xd(
          E,
          /*$$scope*/
          Y[29],
          V,
          Og
        ) : bd(
          /*$$scope*/
          Y[29]
        ),
        ou
      );
    },
    i(Y) {
      S || (fn(n.$$.fragment, Y), fn(A, Y), S = !0);
    },
    o(Y) {
      On(n.$$.fragment, Y), On(A, Y), S = !1;
    },
    d(Y) {
      Y && (At(e), At(o), At(u), At(x)), vd(n), A && A.d(Y);
    }
  };
}
function Ag(t) {
  let e, n, o, u, g, v, x, S, E, A = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && uu(t)
  );
  function Y(N, $) {
    if (
      /*progress*/
      N[7]
    ) return Lg;
    if (
      /*queue_position*/
      N[2] !== null && /*queue_size*/
      N[3] !== void 0 && /*queue_position*/
      N[2] >= 0
    ) return Dg;
    if (
      /*queue_position*/
      N[2] === 0
    ) return jg;
  }
  let V = Y(t), Q = V && V(t), tt = (
    /*timer*/
    t[5] && fu(t)
  );
  const rt = [Bg, Fg], ut = [];
  function H(N, $) {
    return (
      /*last_progress_level*/
      N[15] != null ? 0 : (
        /*show_progress*/
        N[6] === "full" ? 1 : -1
      )
    );
  }
  ~(g = H(t)) && (v = ut[g] = rt[g](t));
  let R = !/*timer*/
  t[5] && xu(t);
  return {
    c() {
      A && A.c(), e = Qe(), n = Tn("div"), Q && Q.c(), o = Qe(), tt && tt.c(), u = Qe(), v && v.c(), x = Qe(), R && R.c(), S = hr(), pn(n, "class", "progress-text svelte-v0wucf"), qe(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), qe(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(N, $) {
      A && A.m(N, $), jt(N, e, $), jt(N, n, $), Q && Q.m(n, null), vi(n, o), tt && tt.m(n, null), jt(N, u, $), ~g && ut[g].m(N, $), jt(N, x, $), R && R.m(N, $), jt(N, S, $), E = !0;
    },
    p(N, $) {
      /*variant*/
      N[8] === "default" && /*show_eta_bar*/
      N[18] && /*show_progress*/
      N[6] === "full" ? A ? A.p(N, $) : (A = uu(N), A.c(), A.m(e.parentNode, e)) : A && (A.d(1), A = null), V === (V = Y(N)) && Q ? Q.p(N, $) : (Q && Q.d(1), Q = V && V(N), Q && (Q.c(), Q.m(n, o))), /*timer*/
      N[5] ? tt ? tt.p(N, $) : (tt = fu(N), tt.c(), tt.m(n, null)) : tt && (tt.d(1), tt = null), (!E || $[0] & /*variant*/
      256) && qe(
        n,
        "meta-text-center",
        /*variant*/
        N[8] === "center"
      ), (!E || $[0] & /*variant*/
      256) && qe(
        n,
        "meta-text",
        /*variant*/
        N[8] === "default"
      );
      let at = g;
      g = H(N), g === at ? ~g && ut[g].p(N, $) : (v && (Xs(), On(ut[at], 1, 1, () => {
        ut[at] = null;
      }), Hs()), ~g ? (v = ut[g], v ? v.p(N, $) : (v = ut[g] = rt[g](N), v.c()), fn(v, 1), v.m(x.parentNode, x)) : v = null), /*timer*/
      N[5] ? R && (Xs(), On(R, 1, 1, () => {
        R = null;
      }), Hs()) : R ? (R.p(N, $), $[0] & /*timer*/
      32 && fn(R, 1)) : (R = xu(N), R.c(), fn(R, 1), R.m(S.parentNode, S));
    },
    i(N) {
      E || (fn(v), fn(R), E = !0);
    },
    o(N) {
      On(v), On(R), E = !1;
    },
    d(N) {
      N && (At(e), At(n), At(u), At(x), At(S)), A && A.d(N), Q && Q.d(), tt && tt.d(), ~g && ut[g].d(N), R && R.d(N);
    }
  };
}
function uu(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Tn("div"), pn(e, "class", "eta-bar svelte-v0wucf"), Zn(e, "transform", n);
    },
    m(o, u) {
      jt(o, e, u);
    },
    p(o, u) {
      u[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (o[17] || 0) * 100 - 100}%)`) && Zn(e, "transform", n);
    },
    d(o) {
      o && At(e);
    }
  };
}
function jg(t) {
  let e;
  return {
    c() {
      e = $t("processing |");
    },
    m(n, o) {
      jt(n, e, o);
    },
    p: qs,
    d(n) {
      n && At(e);
    }
  };
}
function Dg(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), o, u, g, v;
  return {
    c() {
      e = $t("queue: "), o = $t(n), u = $t("/"), g = $t(
        /*queue_size*/
        t[3]
      ), v = $t(" |");
    },
    m(x, S) {
      jt(x, e, S), jt(x, o, S), jt(x, u, S), jt(x, g, S), jt(x, v, S);
    },
    p(x, S) {
      S[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      x[2] + 1 + "") && tn(o, n), S[0] & /*queue_size*/
      8 && tn(
        g,
        /*queue_size*/
        x[3]
      );
    },
    d(x) {
      x && (At(e), At(o), At(u), At(g), At(v));
    }
  };
}
function Lg(t) {
  let e, n = oo(
    /*progress*/
    t[7]
  ), o = [];
  for (let u = 0; u < n.length; u += 1)
    o[u] = du(cu(t, n, u));
  return {
    c() {
      for (let u = 0; u < o.length; u += 1)
        o[u].c();
      e = hr();
    },
    m(u, g) {
      for (let v = 0; v < o.length; v += 1)
        o[v] && o[v].m(u, g);
      jt(u, e, g);
    },
    p(u, g) {
      if (g[0] & /*progress*/
      128) {
        n = oo(
          /*progress*/
          u[7]
        );
        let v;
        for (v = 0; v < n.length; v += 1) {
          const x = cu(u, n, v);
          o[v] ? o[v].p(x, g) : (o[v] = du(x), o[v].c(), o[v].m(e.parentNode, e));
        }
        for (; v < o.length; v += 1)
          o[v].d(1);
        o.length = n.length;
      }
    },
    d(u) {
      u && At(e), yd(o, u);
    }
  };
}
function hu(t) {
  let e, n = (
    /*p*/
    t[41].unit + ""
  ), o, u, g = " ", v;
  function x(A, Y) {
    return (
      /*p*/
      A[41].length != null ? Ig : Rg
    );
  }
  let S = x(t), E = S(t);
  return {
    c() {
      E.c(), e = Qe(), o = $t(n), u = $t(" | "), v = $t(g);
    },
    m(A, Y) {
      E.m(A, Y), jt(A, e, Y), jt(A, o, Y), jt(A, u, Y), jt(A, v, Y);
    },
    p(A, Y) {
      S === (S = x(A)) && E ? E.p(A, Y) : (E.d(1), E = S(A), E && (E.c(), E.m(e.parentNode, e))), Y[0] & /*progress*/
      128 && n !== (n = /*p*/
      A[41].unit + "") && tn(o, n);
    },
    d(A) {
      A && (At(e), At(o), At(u), At(v)), E.d(A);
    }
  };
}
function Rg(t) {
  let e = Fi(
    /*p*/
    t[41].index || 0
  ) + "", n;
  return {
    c() {
      n = $t(e);
    },
    m(o, u) {
      jt(o, n, u);
    },
    p(o, u) {
      u[0] & /*progress*/
      128 && e !== (e = Fi(
        /*p*/
        o[41].index || 0
      ) + "") && tn(n, e);
    },
    d(o) {
      o && At(n);
    }
  };
}
function Ig(t) {
  let e = Fi(
    /*p*/
    t[41].index || 0
  ) + "", n, o, u = Fi(
    /*p*/
    t[41].length
  ) + "", g;
  return {
    c() {
      n = $t(e), o = $t("/"), g = $t(u);
    },
    m(v, x) {
      jt(v, n, x), jt(v, o, x), jt(v, g, x);
    },
    p(v, x) {
      x[0] & /*progress*/
      128 && e !== (e = Fi(
        /*p*/
        v[41].index || 0
      ) + "") && tn(n, e), x[0] & /*progress*/
      128 && u !== (u = Fi(
        /*p*/
        v[41].length
      ) + "") && tn(g, u);
    },
    d(v) {
      v && (At(n), At(o), At(g));
    }
  };
}
function du(t) {
  let e, n = (
    /*p*/
    t[41].index != null && hu(t)
  );
  return {
    c() {
      n && n.c(), e = hr();
    },
    m(o, u) {
      n && n.m(o, u), jt(o, e, u);
    },
    p(o, u) {
      /*p*/
      o[41].index != null ? n ? n.p(o, u) : (n = hu(o), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && At(e), n && n.d(o);
    }
  };
}
function fu(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), o, u;
  return {
    c() {
      e = $t(
        /*formatted_timer*/
        t[20]
      ), o = $t(n), u = $t("s");
    },
    m(g, v) {
      jt(g, e, v), jt(g, o, v), jt(g, u, v);
    },
    p(g, v) {
      v[0] & /*formatted_timer*/
      1048576 && tn(
        e,
        /*formatted_timer*/
        g[20]
      ), v[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      g[0] ? `/${/*formatted_eta*/
      g[19]}` : "") && tn(o, n);
    },
    d(g) {
      g && (At(e), At(o), At(u));
    }
  };
}
function Fg(t) {
  let e, n;
  return e = new _g({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      gd(e.$$.fragment);
    },
    m(o, u) {
      _d(e, o, u), n = !0;
    },
    p(o, u) {
      const g = {};
      u[0] & /*variant*/
      256 && (g.margin = /*variant*/
      o[8] === "default"), e.$set(g);
    },
    i(o) {
      n || (fn(e.$$.fragment, o), n = !0);
    },
    o(o) {
      On(e.$$.fragment, o), n = !1;
    },
    d(o) {
      vd(e, o);
    }
  };
}
function Bg(t) {
  let e, n, o, u, g, v = `${/*last_progress_level*/
  t[15] * 100}%`, x = (
    /*progress*/
    t[7] != null && pu(t)
  );
  return {
    c() {
      e = Tn("div"), n = Tn("div"), x && x.c(), o = Qe(), u = Tn("div"), g = Tn("div"), pn(n, "class", "progress-level-inner svelte-v0wucf"), pn(g, "class", "progress-bar svelte-v0wucf"), Zn(g, "width", v), pn(u, "class", "progress-bar-wrap svelte-v0wucf"), pn(e, "class", "progress-level svelte-v0wucf");
    },
    m(S, E) {
      jt(S, e, E), vi(e, n), x && x.m(n, null), vi(e, o), vi(e, u), vi(u, g), t[31](g);
    },
    p(S, E) {
      /*progress*/
      S[7] != null ? x ? x.p(S, E) : (x = pu(S), x.c(), x.m(n, null)) : x && (x.d(1), x = null), E[0] & /*last_progress_level*/
      32768 && v !== (v = `${/*last_progress_level*/
      S[15] * 100}%`) && Zn(g, "width", v);
    },
    i: qs,
    o: qs,
    d(S) {
      S && At(e), x && x.d(), t[31](null);
    }
  };
}
function pu(t) {
  let e, n = oo(
    /*progress*/
    t[7]
  ), o = [];
  for (let u = 0; u < n.length; u += 1)
    o[u] = bu(lu(t, n, u));
  return {
    c() {
      for (let u = 0; u < o.length; u += 1)
        o[u].c();
      e = hr();
    },
    m(u, g) {
      for (let v = 0; v < o.length; v += 1)
        o[v] && o[v].m(u, g);
      jt(u, e, g);
    },
    p(u, g) {
      if (g[0] & /*progress_level, progress*/
      16512) {
        n = oo(
          /*progress*/
          u[7]
        );
        let v;
        for (v = 0; v < n.length; v += 1) {
          const x = lu(u, n, v);
          o[v] ? o[v].p(x, g) : (o[v] = bu(x), o[v].c(), o[v].m(e.parentNode, e));
        }
        for (; v < o.length; v += 1)
          o[v].d(1);
        o.length = n.length;
      }
    },
    d(u) {
      u && At(e), yd(o, u);
    }
  };
}
function gu(t) {
  let e, n, o, u, g = (
    /*i*/
    t[43] !== 0 && zg()
  ), v = (
    /*p*/
    t[41].desc != null && mu(t)
  ), x = (
    /*p*/
    t[41].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[43]
    ] != null && vu()
  ), S = (
    /*progress_level*/
    t[14] != null && yu(t)
  );
  return {
    c() {
      g && g.c(), e = Qe(), v && v.c(), n = Qe(), x && x.c(), o = Qe(), S && S.c(), u = hr();
    },
    m(E, A) {
      g && g.m(E, A), jt(E, e, A), v && v.m(E, A), jt(E, n, A), x && x.m(E, A), jt(E, o, A), S && S.m(E, A), jt(E, u, A);
    },
    p(E, A) {
      /*p*/
      E[41].desc != null ? v ? v.p(E, A) : (v = mu(E), v.c(), v.m(n.parentNode, n)) : v && (v.d(1), v = null), /*p*/
      E[41].desc != null && /*progress_level*/
      E[14] && /*progress_level*/
      E[14][
        /*i*/
        E[43]
      ] != null ? x || (x = vu(), x.c(), x.m(o.parentNode, o)) : x && (x.d(1), x = null), /*progress_level*/
      E[14] != null ? S ? S.p(E, A) : (S = yu(E), S.c(), S.m(u.parentNode, u)) : S && (S.d(1), S = null);
    },
    d(E) {
      E && (At(e), At(n), At(o), At(u)), g && g.d(E), v && v.d(E), x && x.d(E), S && S.d(E);
    }
  };
}
function zg(t) {
  let e;
  return {
    c() {
      e = $t(" /");
    },
    m(n, o) {
      jt(n, e, o);
    },
    d(n) {
      n && At(e);
    }
  };
}
function mu(t) {
  let e = (
    /*p*/
    t[41].desc + ""
  ), n;
  return {
    c() {
      n = $t(e);
    },
    m(o, u) {
      jt(o, n, u);
    },
    p(o, u) {
      u[0] & /*progress*/
      128 && e !== (e = /*p*/
      o[41].desc + "") && tn(n, e);
    },
    d(o) {
      o && At(n);
    }
  };
}
function vu(t) {
  let e;
  return {
    c() {
      e = $t("-");
    },
    m(n, o) {
      jt(n, e, o);
    },
    d(n) {
      n && At(e);
    }
  };
}
function yu(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[43]
  ] || 0)).toFixed(1) + "", n, o;
  return {
    c() {
      n = $t(e), o = $t("%");
    },
    m(u, g) {
      jt(u, n, g), jt(u, o, g);
    },
    p(u, g) {
      g[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (u[14][
        /*i*/
        u[43]
      ] || 0)).toFixed(1) + "") && tn(n, e);
    },
    d(u) {
      u && (At(n), At(o));
    }
  };
}
function bu(t) {
  let e, n = (
    /*p*/
    (t[41].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[43]
    ] != null) && gu(t)
  );
  return {
    c() {
      n && n.c(), e = hr();
    },
    m(o, u) {
      n && n.m(o, u), jt(o, e, u);
    },
    p(o, u) {
      /*p*/
      o[41].desc != null || /*progress_level*/
      o[14] && /*progress_level*/
      o[14][
        /*i*/
        o[43]
      ] != null ? n ? n.p(o, u) : (n = gu(o), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && At(e), n && n.d(o);
    }
  };
}
function xu(t) {
  let e, n, o, u;
  const g = (
    /*#slots*/
    t[30]["additional-loading-text"]
  ), v = md(
    g,
    t,
    /*$$scope*/
    t[29],
    su
  );
  return {
    c() {
      e = Tn("p"), n = $t(
        /*loading_text*/
        t[9]
      ), o = Qe(), v && v.c(), pn(e, "class", "loading svelte-v0wucf");
    },
    m(x, S) {
      jt(x, e, S), vi(e, n), jt(x, o, S), v && v.m(x, S), u = !0;
    },
    p(x, S) {
      (!u || S[0] & /*loading_text*/
      512) && tn(
        n,
        /*loading_text*/
        x[9]
      ), v && v.p && (!u || S[0] & /*$$scope*/
      536870912) && wd(
        v,
        g,
        x,
        /*$$scope*/
        x[29],
        u ? xd(
          g,
          /*$$scope*/
          x[29],
          S,
          Mg
        ) : bd(
          /*$$scope*/
          x[29]
        ),
        su
      );
    },
    i(x) {
      u || (fn(v, x), u = !0);
    },
    o(x) {
      On(v, x), u = !1;
    },
    d(x) {
      x && (At(e), At(o)), v && v.d(x);
    }
  };
}
function Ng(t) {
  let e, n, o, u, g;
  const v = [Ag, Pg], x = [];
  function S(E, A) {
    return (
      /*status*/
      E[4] === "pending" ? 0 : (
        /*status*/
        E[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = S(t)) && (o = x[n] = v[n](t)), {
    c() {
      e = Tn("div"), o && o.c(), pn(e, "class", u = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-v0wucf"), qe(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden"), qe(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), qe(
        e,
        "generating",
        /*status*/
        t[4] === "generating" && /*show_progress*/
        t[6] === "full"
      ), qe(
        e,
        "border",
        /*border*/
        t[12]
      ), Zn(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), Zn(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(E, A) {
      jt(E, e, A), ~n && x[n].m(e, null), t[33](e), g = !0;
    },
    p(E, A) {
      let Y = n;
      n = S(E), n === Y ? ~n && x[n].p(E, A) : (o && (Xs(), On(x[Y], 1, 1, () => {
        x[Y] = null;
      }), Hs()), ~n ? (o = x[n], o ? o.p(E, A) : (o = x[n] = v[n](E), o.c()), fn(o, 1), o.m(e, null)) : o = null), (!g || A[0] & /*variant, show_progress*/
      320 && u !== (u = "wrap " + /*variant*/
      E[8] + " " + /*show_progress*/
      E[6] + " svelte-v0wucf")) && pn(e, "class", u), (!g || A[0] & /*variant, show_progress, status, show_progress*/
      336) && qe(e, "hide", !/*status*/
      E[4] || /*status*/
      E[4] === "complete" || /*show_progress*/
      E[6] === "hidden"), (!g || A[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && qe(
        e,
        "translucent",
        /*variant*/
        E[8] === "center" && /*status*/
        (E[4] === "pending" || /*status*/
        E[4] === "error") || /*translucent*/
        E[11] || /*show_progress*/
        E[6] === "minimal"
      ), (!g || A[0] & /*variant, show_progress, status, show_progress*/
      336) && qe(
        e,
        "generating",
        /*status*/
        E[4] === "generating" && /*show_progress*/
        E[6] === "full"
      ), (!g || A[0] & /*variant, show_progress, border*/
      4416) && qe(
        e,
        "border",
        /*border*/
        E[12]
      ), A[0] & /*absolute*/
      1024 && Zn(
        e,
        "position",
        /*absolute*/
        E[10] ? "absolute" : "static"
      ), A[0] & /*absolute*/
      1024 && Zn(
        e,
        "padding",
        /*absolute*/
        E[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(E) {
      g || (fn(o), g = !0);
    },
    o(E) {
      On(o), g = !1;
    },
    d(E) {
      E && At(e), ~n && x[n].d(), t[33](null);
    }
  };
}
var Ug = function(t, e, n, o) {
  function u(g) {
    return g instanceof n ? g : new n(function(v) {
      v(g);
    });
  }
  return new (n || (n = Promise))(function(g, v) {
    function x(A) {
      try {
        E(o.next(A));
      } catch (Y) {
        v(Y);
      }
    }
    function S(A) {
      try {
        E(o.throw(A));
      } catch (Y) {
        v(Y);
      }
    }
    function E(A) {
      A.done ? g(A.value) : u(A.value).then(x, S);
    }
    E((o = o.apply(t, e || [])).next());
  });
};
let _a = [], os = !1;
function Wg(t) {
  return Ug(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (_a.push(e), !os) os = !0;
      else return;
      yield kg(), requestAnimationFrame(() => {
        let o = [0, 0];
        for (let u = 0; u < _a.length; u++) {
          const v = _a[u].getBoundingClientRect();
          (u === 0 || v.top + window.scrollY <= o[0]) && (o[0] = v.top + window.scrollY, o[1] = u);
        }
        window.scrollTo({ top: o[0] - 20, behavior: "smooth" }), os = !1, _a = [];
      });
    }
  });
}
function Yg(t, e, n) {
  let o, { $$slots: u = {}, $$scope: g } = e;
  this && this.__awaiter;
  const v = Tg();
  let { i18n: x } = e, { eta: S = null } = e, { queue_position: E } = e, { queue_size: A } = e, { status: Y } = e, { scroll_to_output: V = !1 } = e, { timer: Q = !0 } = e, { show_progress: tt = "full" } = e, { message: rt = null } = e, { progress: ut = null } = e, { variant: H = "default" } = e, { loading_text: R = "Loading..." } = e, { absolute: N = !0 } = e, { translucent: $ = !1 } = e, { border: at = !1 } = e, { autoscroll: it } = e, gt, b = !1, Pt = 0, P = 0, nt = null, bt = null, ht = 0, l = null, a, c = null, f = !0;
  const i = () => {
    n(0, S = n(27, nt = n(19, h = null))), n(25, Pt = performance.now()), n(26, P = 0), b = !0, r();
  };
  function r() {
    requestAnimationFrame(() => {
      n(26, P = (performance.now() - Pt) / 1e3), b && r();
    });
  }
  function s() {
    n(26, P = 0), n(0, S = n(27, nt = n(19, h = null))), b && (b = !1);
  }
  Eg(() => {
    b && s();
  });
  let h = null;
  function d(y) {
    au[y ? "unshift" : "push"](() => {
      c = y, n(16, c), n(7, ut), n(14, l), n(15, a);
    });
  }
  const p = () => {
    v("clear_status");
  };
  function m(y) {
    au[y ? "unshift" : "push"](() => {
      gt = y, n(13, gt);
    });
  }
  return t.$$set = (y) => {
    "i18n" in y && n(1, x = y.i18n), "eta" in y && n(0, S = y.eta), "queue_position" in y && n(2, E = y.queue_position), "queue_size" in y && n(3, A = y.queue_size), "status" in y && n(4, Y = y.status), "scroll_to_output" in y && n(22, V = y.scroll_to_output), "timer" in y && n(5, Q = y.timer), "show_progress" in y && n(6, tt = y.show_progress), "message" in y && n(23, rt = y.message), "progress" in y && n(7, ut = y.progress), "variant" in y && n(8, H = y.variant), "loading_text" in y && n(9, R = y.loading_text), "absolute" in y && n(10, N = y.absolute), "translucent" in y && n(11, $ = y.translucent), "border" in y && n(12, at = y.border), "autoscroll" in y && n(24, it = y.autoscroll), "$$scope" in y && n(29, g = y.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (S === null && n(0, S = nt), S != null && nt !== S && (n(28, bt = (performance.now() - Pt) / 1e3 + S), n(19, h = bt.toFixed(1)), n(27, nt = S))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, ht = bt === null || bt <= 0 || !P ? null : Math.min(P / bt, 1)), t.$$.dirty[0] & /*progress*/
    128 && ut != null && n(18, f = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (ut != null ? n(14, l = ut.map((y) => {
      if (y.index != null && y.length != null)
        return y.index / y.length;
      if (y.progress != null)
        return y.progress;
    })) : n(14, l = null), l ? (n(15, a = l[l.length - 1]), c && (a === 0 ? n(16, c.style.transition = "0", c) : n(16, c.style.transition = "150ms", c))) : n(15, a = void 0)), t.$$.dirty[0] & /*status*/
    16 && (Y === "pending" ? i() : s()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && gt && V && (Y === "pending" || Y === "complete") && Wg(gt, it), t.$$.dirty[0] & /*status, message*/
    8388624, t.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, o = P.toFixed(1));
  }, [
    S,
    x,
    E,
    A,
    Y,
    Q,
    tt,
    ut,
    H,
    R,
    N,
    $,
    at,
    gt,
    l,
    a,
    c,
    ht,
    f,
    h,
    o,
    v,
    V,
    rt,
    it,
    Pt,
    P,
    nt,
    bt,
    g,
    u,
    d,
    p,
    m
  ];
}
class Vg extends wg {
  constructor(e) {
    super(), Sg(
      this,
      e,
      Yg,
      Ng,
      Cg,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.1.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.6/LICENSE */
const {
  entries: Sd,
  setPrototypeOf: _u,
  isFrozen: Gg,
  getPrototypeOf: Hg,
  getOwnPropertyDescriptor: Xg
} = Object;
let {
  freeze: Ee,
  seal: en,
  create: Cd
} = Object, {
  apply: Zs,
  construct: Ks
} = typeof Reflect < "u" && Reflect;
Ee || (Ee = function(e) {
  return e;
});
en || (en = function(e) {
  return e;
});
Zs || (Zs = function(e, n, o) {
  return e.apply(n, o);
});
Ks || (Ks = function(e, n) {
  return new e(...n);
});
const wa = Ye(Array.prototype.forEach), wu = Ye(Array.prototype.pop), yr = Ye(Array.prototype.push), Xa = Ye(String.prototype.toLowerCase), ss = Ye(String.prototype.toString), Su = Ye(String.prototype.match), br = Ye(String.prototype.replace), qg = Ye(String.prototype.indexOf), Zg = Ye(String.prototype.trim), cn = Ye(Object.prototype.hasOwnProperty), Se = Ye(RegExp.prototype.test), xr = Kg(TypeError);
function Ye(t) {
  return function(e) {
    for (var n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), u = 1; u < n; u++)
      o[u - 1] = arguments[u];
    return Zs(t, e, o);
  };
}
function Kg(t) {
  return function() {
    for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++)
      n[o] = arguments[o];
    return Ks(t, n);
  };
}
function Lt(t, e) {
  let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Xa;
  _u && _u(t, null);
  let o = e.length;
  for (; o--; ) {
    let u = e[o];
    if (typeof u == "string") {
      const g = n(u);
      g !== u && (Gg(e) || (e[o] = g), u = g);
    }
    t[u] = !0;
  }
  return t;
}
function Qg(t) {
  for (let e = 0; e < t.length; e++)
    cn(t, e) || (t[e] = null);
  return t;
}
function fi(t) {
  const e = Cd(null);
  for (const [n, o] of Sd(t))
    cn(t, n) && (Array.isArray(o) ? e[n] = Qg(o) : o && typeof o == "object" && o.constructor === Object ? e[n] = fi(o) : e[n] = o);
  return e;
}
function _r(t, e) {
  for (; t !== null; ) {
    const o = Xg(t, e);
    if (o) {
      if (o.get)
        return Ye(o.get);
      if (typeof o.value == "function")
        return Ye(o.value);
    }
    t = Hg(t);
  }
  function n() {
    return null;
  }
  return n;
}
const Cu = Ee(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), ls = Ee(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), cs = Ee(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Jg = Ee(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), us = Ee(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), $g = Ee(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), ku = Ee(["#text"]), Eu = Ee(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), hs = Ee(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Tu = Ee(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Sa = Ee(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), tm = en(/\{\{[\w\W]*|[\w\W]*\}\}/gm), em = en(/<%[\w\W]*|[\w\W]*%>/gm), nm = en(/\${[\w\W]*}/gm), im = en(/^data-[\-\w.\u00B7-\uFFFF]/), rm = en(/^aria-[\-\w]+$/), kd = en(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), am = en(/^(?:\w+script|data):/i), om = en(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Ed = en(/^html$/i), sm = en(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Ou = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: tm,
  ERB_EXPR: em,
  TMPLIT_EXPR: nm,
  DATA_ATTR: im,
  ARIA_ATTR: rm,
  IS_ALLOWED_URI: kd,
  IS_SCRIPT_OR_DATA: am,
  ATTR_WHITESPACE: om,
  DOCTYPE_NAME: Ed,
  CUSTOM_ELEMENT: sm
});
const wr = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, lm = function() {
  return typeof window > "u" ? null : window;
}, cm = function(e, n) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let o = null;
  const u = "data-tt-policy-suffix";
  n && n.hasAttribute(u) && (o = n.getAttribute(u));
  const g = "dompurify" + (o ? "#" + o : "");
  try {
    return e.createPolicy(g, {
      createHTML(v) {
        return v;
      },
      createScriptURL(v) {
        return v;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + g + " could not be created."), null;
  }
};
function Td() {
  let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : lm();
  const e = (Tt) => Td(Tt);
  if (e.version = "3.1.6", e.removed = [], !t || !t.document || t.document.nodeType !== wr.document)
    return e.isSupported = !1, e;
  let {
    document: n
  } = t;
  const o = n, u = o.currentScript, {
    DocumentFragment: g,
    HTMLTemplateElement: v,
    Node: x,
    Element: S,
    NodeFilter: E,
    NamedNodeMap: A = t.NamedNodeMap || t.MozNamedAttrMap,
    HTMLFormElement: Y,
    DOMParser: V,
    trustedTypes: Q
  } = t, tt = S.prototype, rt = _r(tt, "cloneNode"), ut = _r(tt, "remove"), H = _r(tt, "nextSibling"), R = _r(tt, "childNodes"), N = _r(tt, "parentNode");
  if (typeof v == "function") {
    const Tt = n.createElement("template");
    Tt.content && Tt.content.ownerDocument && (n = Tt.content.ownerDocument);
  }
  let $, at = "";
  const {
    implementation: it,
    createNodeIterator: gt,
    createDocumentFragment: b,
    getElementsByTagName: Pt
  } = n, {
    importNode: P
  } = o;
  let nt = {};
  e.isSupported = typeof Sd == "function" && typeof N == "function" && it && it.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: bt,
    ERB_EXPR: ht,
    TMPLIT_EXPR: l,
    DATA_ATTR: a,
    ARIA_ATTR: c,
    IS_SCRIPT_OR_DATA: f,
    ATTR_WHITESPACE: i,
    CUSTOM_ELEMENT: r
  } = Ou;
  let {
    IS_ALLOWED_URI: s
  } = Ou, h = null;
  const d = Lt({}, [...Cu, ...ls, ...cs, ...us, ...ku]);
  let p = null;
  const m = Lt({}, [...Eu, ...hs, ...Tu, ...Sa]);
  let y = Object.seal(Cd(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), _ = null, k = null, T = !0, D = !0, j = !1, w = !0, O = !1, L = !0, U = !1, W = !1, I = !1, M = !1, B = !1, Z = !1, J = !0, G = !1;
  const F = "user-content-";
  let q = !0, z = !1, X = {}, et = null;
  const ct = Lt({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let ot = null;
  const mt = Lt({}, ["audio", "video", "img", "source", "image", "track"]);
  let lt = null;
  const dt = Lt({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), ft = "http://www.w3.org/1998/Math/MathML", St = "http://www.w3.org/2000/svg", yt = "http://www.w3.org/1999/xhtml";
  let Ot = yt, Et = !1, Dt = null;
  const Zt = Lt({}, [ft, St, yt], ss);
  let Ut = null;
  const It = ["application/xhtml+xml", "text/html"], se = "text/html";
  let Nt = null, ne = null;
  const hi = n.createElement("form"), pa = function(K) {
    return K instanceof RegExp || K instanceof Function;
  }, gr = function() {
    let K = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(ne && ne === K)) {
      if ((!K || typeof K != "object") && (K = {}), K = fi(K), Ut = // eslint-disable-next-line unicorn/prefer-includes
      It.indexOf(K.PARSER_MEDIA_TYPE) === -1 ? se : K.PARSER_MEDIA_TYPE, Nt = Ut === "application/xhtml+xml" ? ss : Xa, h = cn(K, "ALLOWED_TAGS") ? Lt({}, K.ALLOWED_TAGS, Nt) : d, p = cn(K, "ALLOWED_ATTR") ? Lt({}, K.ALLOWED_ATTR, Nt) : m, Dt = cn(K, "ALLOWED_NAMESPACES") ? Lt({}, K.ALLOWED_NAMESPACES, ss) : Zt, lt = cn(K, "ADD_URI_SAFE_ATTR") ? Lt(
        fi(dt),
        // eslint-disable-line indent
        K.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        Nt
        // eslint-disable-line indent
      ) : dt, ot = cn(K, "ADD_DATA_URI_TAGS") ? Lt(
        fi(mt),
        // eslint-disable-line indent
        K.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        Nt
        // eslint-disable-line indent
      ) : mt, et = cn(K, "FORBID_CONTENTS") ? Lt({}, K.FORBID_CONTENTS, Nt) : ct, _ = cn(K, "FORBID_TAGS") ? Lt({}, K.FORBID_TAGS, Nt) : {}, k = cn(K, "FORBID_ATTR") ? Lt({}, K.FORBID_ATTR, Nt) : {}, X = cn(K, "USE_PROFILES") ? K.USE_PROFILES : !1, T = K.ALLOW_ARIA_ATTR !== !1, D = K.ALLOW_DATA_ATTR !== !1, j = K.ALLOW_UNKNOWN_PROTOCOLS || !1, w = K.ALLOW_SELF_CLOSE_IN_ATTR !== !1, O = K.SAFE_FOR_TEMPLATES || !1, L = K.SAFE_FOR_XML !== !1, U = K.WHOLE_DOCUMENT || !1, M = K.RETURN_DOM || !1, B = K.RETURN_DOM_FRAGMENT || !1, Z = K.RETURN_TRUSTED_TYPE || !1, I = K.FORCE_BODY || !1, J = K.SANITIZE_DOM !== !1, G = K.SANITIZE_NAMED_PROPS || !1, q = K.KEEP_CONTENT !== !1, z = K.IN_PLACE || !1, s = K.ALLOWED_URI_REGEXP || kd, Ot = K.NAMESPACE || yt, y = K.CUSTOM_ELEMENT_HANDLING || {}, K.CUSTOM_ELEMENT_HANDLING && pa(K.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (y.tagNameCheck = K.CUSTOM_ELEMENT_HANDLING.tagNameCheck), K.CUSTOM_ELEMENT_HANDLING && pa(K.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (y.attributeNameCheck = K.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), K.CUSTOM_ELEMENT_HANDLING && typeof K.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (y.allowCustomizedBuiltInElements = K.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), O && (D = !1), B && (M = !0), X && (h = Lt({}, ku), p = [], X.html === !0 && (Lt(h, Cu), Lt(p, Eu)), X.svg === !0 && (Lt(h, ls), Lt(p, hs), Lt(p, Sa)), X.svgFilters === !0 && (Lt(h, cs), Lt(p, hs), Lt(p, Sa)), X.mathMl === !0 && (Lt(h, us), Lt(p, Tu), Lt(p, Sa))), K.ADD_TAGS && (h === d && (h = fi(h)), Lt(h, K.ADD_TAGS, Nt)), K.ADD_ATTR && (p === m && (p = fi(p)), Lt(p, K.ADD_ATTR, Nt)), K.ADD_URI_SAFE_ATTR && Lt(lt, K.ADD_URI_SAFE_ATTR, Nt), K.FORBID_CONTENTS && (et === ct && (et = fi(et)), Lt(et, K.FORBID_CONTENTS, Nt)), q && (h["#text"] = !0), U && Lt(h, ["html", "head", "body"]), h.table && (Lt(h, ["tbody"]), delete _.tbody), K.TRUSTED_TYPES_POLICY) {
        if (typeof K.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw xr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof K.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw xr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        $ = K.TRUSTED_TYPES_POLICY, at = $.createHTML("");
      } else
        $ === void 0 && ($ = cm(Q, u)), $ !== null && typeof at == "string" && (at = $.createHTML(""));
      Ee && Ee(K), ne = K;
    }
  }, mr = Lt({}, ["mi", "mo", "mn", "ms", "mtext"]), ga = Lt({}, ["foreignobject", "annotation-xml"]), is = Lt({}, ["title", "style", "font", "a", "script"]), ma = Lt({}, [...ls, ...cs, ...Jg]), Ai = Lt({}, [...us, ...$g]), va = function(K) {
    let xt = N(K);
    (!xt || !xt.tagName) && (xt = {
      namespaceURI: Ot,
      tagName: "template"
    });
    const kt = Xa(K.tagName), Gt = Xa(xt.tagName);
    return Dt[K.namespaceURI] ? K.namespaceURI === St ? xt.namespaceURI === yt ? kt === "svg" : xt.namespaceURI === ft ? kt === "svg" && (Gt === "annotation-xml" || mr[Gt]) : !!ma[kt] : K.namespaceURI === ft ? xt.namespaceURI === yt ? kt === "math" : xt.namespaceURI === St ? kt === "math" && ga[Gt] : !!Ai[kt] : K.namespaceURI === yt ? xt.namespaceURI === St && !ga[Gt] || xt.namespaceURI === ft && !mr[Gt] ? !1 : !Ai[kt] && (is[kt] || !ma[kt]) : !!(Ut === "application/xhtml+xml" && Dt[K.namespaceURI]) : !1;
  }, Fe = function(K) {
    yr(e.removed, {
      element: K
    });
    try {
      N(K).removeChild(K);
    } catch {
      ut(K);
    }
  }, ji = function(K, xt) {
    try {
      yr(e.removed, {
        attribute: xt.getAttributeNode(K),
        from: xt
      });
    } catch {
      yr(e.removed, {
        attribute: null,
        from: xt
      });
    }
    if (xt.removeAttribute(K), K === "is" && !p[K])
      if (M || B)
        try {
          Fe(xt);
        } catch {
        }
      else
        try {
          xt.setAttribute(K, "");
        } catch {
        }
  }, _t = function(K) {
    let xt = null, kt = null;
    if (I)
      K = "<remove></remove>" + K;
    else {
      const fe = Su(K, /^[\r\n\t ]+/);
      kt = fe && fe[0];
    }
    Ut === "application/xhtml+xml" && Ot === yt && (K = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + K + "</body></html>");
    const Gt = $ ? $.createHTML(K) : K;
    if (Ot === yt)
      try {
        xt = new V().parseFromString(Gt, Ut);
      } catch {
      }
    if (!xt || !xt.documentElement) {
      xt = it.createDocument(Ot, "template", null);
      try {
        xt.documentElement.innerHTML = Et ? at : Gt;
      } catch {
      }
    }
    const ve = xt.body || xt.documentElement;
    return K && kt && ve.insertBefore(n.createTextNode(kt), ve.childNodes[0] || null), Ot === yt ? Pt.call(xt, U ? "html" : "body")[0] : U ? xt.documentElement : ve;
  }, wt = function(K) {
    return gt.call(
      K.ownerDocument || K,
      K,
      // eslint-disable-next-line no-bitwise
      E.SHOW_ELEMENT | E.SHOW_COMMENT | E.SHOW_TEXT | E.SHOW_PROCESSING_INSTRUCTION | E.SHOW_CDATA_SECTION,
      null
    );
  }, Mt = function(K) {
    return K instanceof Y && (typeof K.nodeName != "string" || typeof K.textContent != "string" || typeof K.removeChild != "function" || !(K.attributes instanceof A) || typeof K.removeAttribute != "function" || typeof K.setAttribute != "function" || typeof K.namespaceURI != "string" || typeof K.insertBefore != "function" || typeof K.hasChildNodes != "function");
  }, Ft = function(K) {
    return typeof x == "function" && K instanceof x;
  }, Wt = function(K, xt, kt) {
    nt[K] && wa(nt[K], (Gt) => {
      Gt.call(e, xt, kt, ne);
    });
  }, Be = function(K) {
    let xt = null;
    if (Wt("beforeSanitizeElements", K, null), Mt(K))
      return Fe(K), !0;
    const kt = Nt(K.nodeName);
    if (Wt("uponSanitizeElement", K, {
      tagName: kt,
      allowedTags: h
    }), K.hasChildNodes() && !Ft(K.firstElementChild) && Se(/<[/\w]/g, K.innerHTML) && Se(/<[/\w]/g, K.textContent) || K.nodeType === wr.progressingInstruction || L && K.nodeType === wr.comment && Se(/<[/\w]/g, K.data))
      return Fe(K), !0;
    if (!h[kt] || _[kt]) {
      if (!_[kt] && ya(kt) && (y.tagNameCheck instanceof RegExp && Se(y.tagNameCheck, kt) || y.tagNameCheck instanceof Function && y.tagNameCheck(kt)))
        return !1;
      if (q && !et[kt]) {
        const Gt = N(K) || K.parentNode, ve = R(K) || K.childNodes;
        if (ve && Gt) {
          const fe = ve.length;
          for (let Me = fe - 1; Me >= 0; --Me) {
            const yn = rt(ve[Me], !0);
            yn.__removalCount = (K.__removalCount || 0) + 1, Gt.insertBefore(yn, H(K));
          }
        }
      }
      return Fe(K), !0;
    }
    return K instanceof S && !va(K) || (kt === "noscript" || kt === "noembed" || kt === "noframes") && Se(/<\/no(script|embed|frames)/i, K.innerHTML) ? (Fe(K), !0) : (O && K.nodeType === wr.text && (xt = K.textContent, wa([bt, ht, l], (Gt) => {
      xt = br(xt, Gt, " ");
    }), K.textContent !== xt && (yr(e.removed, {
      element: K.cloneNode()
    }), K.textContent = xt)), Wt("afterSanitizeElements", K, null), !1);
  }, An = function(K, xt, kt) {
    if (J && (xt === "id" || xt === "name") && (kt in n || kt in hi))
      return !1;
    if (!(D && !k[xt] && Se(a, xt))) {
      if (!(T && Se(c, xt))) {
        if (!p[xt] || k[xt]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ya(K) && (y.tagNameCheck instanceof RegExp && Se(y.tagNameCheck, K) || y.tagNameCheck instanceof Function && y.tagNameCheck(K)) && (y.attributeNameCheck instanceof RegExp && Se(y.attributeNameCheck, xt) || y.attributeNameCheck instanceof Function && y.attributeNameCheck(xt)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            xt === "is" && y.allowCustomizedBuiltInElements && (y.tagNameCheck instanceof RegExp && Se(y.tagNameCheck, kt) || y.tagNameCheck instanceof Function && y.tagNameCheck(kt)))
          ) return !1;
        } else if (!lt[xt]) {
          if (!Se(s, br(kt, i, ""))) {
            if (!((xt === "src" || xt === "xlink:href" || xt === "href") && K !== "script" && qg(kt, "data:") === 0 && ot[K])) {
              if (!(j && !Se(f, br(kt, i, "")))) {
                if (kt)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ya = function(K) {
    return K !== "annotation-xml" && Su(K, r);
  }, Di = function(K) {
    Wt("beforeSanitizeAttributes", K, null);
    const {
      attributes: xt
    } = K;
    if (!xt)
      return;
    const kt = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: p
    };
    let Gt = xt.length;
    for (; Gt--; ) {
      const ve = xt[Gt], {
        name: fe,
        namespaceURI: Me,
        value: yn
      } = ve, vr = Nt(fe);
      let we = fe === "value" ? yn : Zg(yn);
      if (kt.attrName = vr, kt.attrValue = we, kt.keepAttr = !0, kt.forceKeepAttr = void 0, Wt("uponSanitizeAttribute", K, kt), we = kt.attrValue, L && Se(/((--!?|])>)|<\/(style|title)/i, we)) {
        ji(fe, K);
        continue;
      }
      if (kt.forceKeepAttr || (ji(fe, K), !kt.keepAttr))
        continue;
      if (!w && Se(/\/>/i, we)) {
        ji(fe, K);
        continue;
      }
      O && wa([bt, ht, l], (Zc) => {
        we = br(we, Zc, " ");
      });
      const qc = Nt(K.nodeName);
      if (An(qc, vr, we)) {
        if (G && (vr === "id" || vr === "name") && (ji(fe, K), we = F + we), $ && typeof Q == "object" && typeof Q.getAttributeType == "function" && !Me)
          switch (Q.getAttributeType(qc, vr)) {
            case "TrustedHTML": {
              we = $.createHTML(we);
              break;
            }
            case "TrustedScriptURL": {
              we = $.createScriptURL(we);
              break;
            }
          }
        try {
          Me ? K.setAttributeNS(Me, fe, we) : K.setAttribute(fe, we), Mt(K) ? Fe(K) : wu(e.removed);
        } catch {
        }
      }
    }
    Wt("afterSanitizeAttributes", K, null);
  }, S0 = function Tt(K) {
    let xt = null;
    const kt = wt(K);
    for (Wt("beforeSanitizeShadowDOM", K, null); xt = kt.nextNode(); )
      Wt("uponSanitizeShadowNode", xt, null), !Be(xt) && (xt.content instanceof g && Tt(xt.content), Di(xt));
    Wt("afterSanitizeShadowDOM", K, null);
  };
  return e.sanitize = function(Tt) {
    let K = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, xt = null, kt = null, Gt = null, ve = null;
    if (Et = !Tt, Et && (Tt = "<!-->"), typeof Tt != "string" && !Ft(Tt))
      if (typeof Tt.toString == "function") {
        if (Tt = Tt.toString(), typeof Tt != "string")
          throw xr("dirty is not a string, aborting");
      } else
        throw xr("toString is not a function");
    if (!e.isSupported)
      return Tt;
    if (W || gr(K), e.removed = [], typeof Tt == "string" && (z = !1), z) {
      if (Tt.nodeName) {
        const yn = Nt(Tt.nodeName);
        if (!h[yn] || _[yn])
          throw xr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Tt instanceof x)
      xt = _t("<!---->"), kt = xt.ownerDocument.importNode(Tt, !0), kt.nodeType === wr.element && kt.nodeName === "BODY" || kt.nodeName === "HTML" ? xt = kt : xt.appendChild(kt);
    else {
      if (!M && !O && !U && // eslint-disable-next-line unicorn/prefer-includes
      Tt.indexOf("<") === -1)
        return $ && Z ? $.createHTML(Tt) : Tt;
      if (xt = _t(Tt), !xt)
        return M ? null : Z ? at : "";
    }
    xt && I && Fe(xt.firstChild);
    const fe = wt(z ? Tt : xt);
    for (; Gt = fe.nextNode(); )
      Be(Gt) || (Gt.content instanceof g && S0(Gt.content), Di(Gt));
    if (z)
      return Tt;
    if (M) {
      if (B)
        for (ve = b.call(xt.ownerDocument); xt.firstChild; )
          ve.appendChild(xt.firstChild);
      else
        ve = xt;
      return (p.shadowroot || p.shadowrootmode) && (ve = P.call(o, ve, !0)), ve;
    }
    let Me = U ? xt.outerHTML : xt.innerHTML;
    return U && h["!doctype"] && xt.ownerDocument && xt.ownerDocument.doctype && xt.ownerDocument.doctype.name && Se(Ed, xt.ownerDocument.doctype.name) && (Me = "<!DOCTYPE " + xt.ownerDocument.doctype.name + `>
` + Me), O && wa([bt, ht, l], (yn) => {
      Me = br(Me, yn, " ");
    }), $ && Z ? $.createHTML(Me) : Me;
  }, e.setConfig = function() {
    let Tt = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    gr(Tt), W = !0;
  }, e.clearConfig = function() {
    ne = null, W = !1;
  }, e.isValidAttribute = function(Tt, K, xt) {
    ne || gr({});
    const kt = Nt(Tt), Gt = Nt(K);
    return An(kt, Gt, xt);
  }, e.addHook = function(Tt, K) {
    typeof K == "function" && (nt[Tt] = nt[Tt] || [], yr(nt[Tt], K));
  }, e.removeHook = function(Tt) {
    if (nt[Tt])
      return wu(nt[Tt]);
  }, e.removeHooks = function(Tt) {
    nt[Tt] && (nt[Tt] = []);
  }, e.removeAllHooks = function() {
    nt = {};
  }, e;
}
Td();
(function() {
  try {
    if (typeof document < "u") {
      var t = document.createElement("style");
      t.appendChild(document.createTextNode(":root{--toggle-color-inactive: #313131;--toggle-color-active: #0095ff;--toggle-color-active-transparent: rgba(0, 149, 255, .5);--font-color: #000;--background-color: #fff;--background-color-active: #f0f0f0;--prop-background-color: rgb(232, 232, 232);--prop-icon-background-color: rgba(212, 212, 212, .6)}[data-theme=dark]{--toggle-color-inactive: white;--toggle-color-active: #a5ffff;--toggle-color-active-transparent: rgba(165, 255, 255, .5);--font-color: #fff;--background-color: #333;--background-color-active: #7a7a7a;--prop-background-color: rgb(162, 162, 162);--prop-icon-background-color: rgba(122, 122, 122, .6)}.panel-paint-box{width:100%;height:100%}#prompt-input-box{display:flex;justify-content:center;width:80%;margin-inline:auto}#prompt-input-box #prompt-input{border-radius:1rem;border-style:solid;border-width:1px;width:80%;padding:.2rem 1rem;margin-inline:.3rem;color:var(--font-color);background-color:var(--background-color)}#prompt-input-box #prompt-input::placeholder{color:var(--font-color);opacity:.3}#prompt-input-box #wand-icon{transition:color 1s ease}#prompt-image-box{display:flex}#prompt-image{height:1.5rem;width:3rem;object-fit:contain}#prompt-image-remove{height:1rem;width:1rem;margin:auto;fill:var(--toggle-color-inactive);cursor:pointer}.blinking{animation:blink .5s infinite alternate}@keyframes blink{0%{opacity:1}to{opacity:.1}}.shining{fill:#ffcd28!important;animation:shine .5s forwards}@keyframes shine{0%{transform:scale(1)}50%{transform:scale(1.5)}to{transform:scale(1)}}#tool-bar{display:flex;width:100%;overflow-x:scroll;scrollbar-width:none;-ms-overflow-style:none}#tool-bar::-webkit-scrollbar{display:none}#essential-tool-box{display:flex}.painter-tool-icon{width:1.5rem;height:1.5rem;margin-inline:.2rem;cursor:pointer;display:flex;align-self:center}.painter-tool-icon svg{width:100%;height:100%;align-self:center;-webkit-user-drag:none;-khtml-user-drag:none;-moz-user-drag:none;-o-user-drag:none}.painter-tool-icon svg:hover{opacity:.8}.painter-tool-icon svg{fill:var(--toggle-color-inactive)}.painter-tool-icon svg.active{fill:var(--toggle-color-active)}.painter-tool-icon.disabled{opacity:.3;cursor:not-allowed}#stroke-size-box{display:flex}#stroke-size-box #stroke-width-slider{width:6rem;align-self:center}#stroke-size-box #stroke-width-value{font-size:.8rem;margin-left:.2rem;align-self:center;color:var(--font-color)}#stroke-color{align-self:center;width:3rem;height:1.5rem;padding:0}#stroke-color-transparent{align-self:center;width:3.5rem;height:1.5rem;padding:.2rem;margin-left:.2rem;font-size:.8rem;color:var(--font-color);background-color:var(--background-color);border-radius:1rem;border-style:solid;border-width:1px;border-radius:.2rem;box-sizing:border-box}#painter-history-panel{display:flex}#download-box{margin-left:auto}.side-bar{width:7rem;display:flex;flex-direction:column;justify-content:space-between}.side-bar button{width:24px}.top-bar{width:100%;min-height:5rem;display:flex;flex-direction:column;justify-content:space-evenly}.lower-area{width:100%;height:calc(100% - 7rem);display:flex}.separator{align-self:center;width:1px;height:25px;background-color:var(--border-color);display:inline-block;vertical-align:middle;margin:0 4px}#color-and-alpha-box{display:flex}#output-img-box{position:relative}#output-operation-box{position:absolute;bottom:.5rem;width:80%;left:10%;background:#e3e3e333;padding:.5rem 1rem;box-sizing:border-box;border-radius:.5rem;display:flex;justify-content:space-around}.side-bar .layer-box{display:flex;flex-direction:column;height:calc(100% - 1.5rem)}.layer-item-list{display:flex;flex-direction:column;gap:2px;align-items:center;overflow-y:auto;overflow-x:hidden;padding-block:.5rem;max-height:350px}.layer-operation-box{display:flex;justify-content:space-between;padding-inline:.3rem}.layer-item-container{flex-direction:row;display:flex;justify-content:space-between;align-items:center;width:85%;padding:.05rem .4rem;margin-block:.1rem;box-sizing:border-box;border-radius:.4rem;border:1px solid #737373}.layer-item-container .layer-item{width:80%;font-size:.7rem;color:var(--font-color);cursor:pointer}.layer-item-container:hover{opacity:.8}.layer-item-container.active{background:var(--background-color-active)}.layer-item-container .layer-item-remove{width:20%;border-radius:50%;box-sizing:border-box;padding:2%;cursor:pointer;fill:var(--toggle-color-inactive);-webkit-user-drag:none;-khtml-user-drag:none;-moz-user-drag:none;-o-user-drag:none}.layer-item-container .layer-item-remove:hover{opacity:.6}#output-area{width:calc(100% - 7rem);display:flex}#canvas-box{width:50%}.canvas-locked{pointer-events:none}#left-box{position:relative}#prop-box{width:10%}#prop-box-list{width:100%;height:100%;display:flex}#prop-box-list .item{width:100%;min-width:3rem;aspect-ratio:1 / 1;padding:.5rem;box-sizing:border-box;position:relative}#prop-box-list .img{width:100%;height:100%;box-sizing:border-box;object-fit:contain;background-color:var(--prop-background-color);border-radius:10%;aspect-ratio:1 / 1}#prop-box-list .img:hover{outline:.1rem solid var(--toggle-color-active);cursor:pointer}#prop-box-list .img.active-prompt{background-color:var(--toggle-color-active-transparent);outline:.1rem solid var(--toggle-color-active)}#prop-box-list .img.disabled-prompt{opacity:.3;cursor:not-allowed}#prop-box-list .img.disabled-prompt:hover{outline:0}#prop-box-list .placeholder{width:100%;height:100%;box-sizing:border-box;background-color:var(--prop-background-color);border-radius:10%;display:flex;justify-content:center}#prop-box-list .prop-item-remove{position:absolute;top:8%;right:8%;background-color:var(--prop-icon-background-color);border-radius:30%}#prop-box-list .prop-item-sam{position:absolute;top:8%;left:8%;background-color:var(--prop-icon-background-color);border-radius:30%}#bg-reminder{position:absolute;width:100%;height:100%;z-index:10;display:flex;cursor:pointer}#bg-reminder-text{color:#fff;text-align:center;display:block;margin:auto;padding:.3rem 1rem;border-radius:1rem}#output-img{background-color:gray;width:100%;height:100%}#loading-status{text-align:center;margin-top:1rem;height:1.5rem}#loading-status svg{width:1.2rem;height:1.2rem;margin:auto;fill:var(--toggle-color-inactive)}@-webkit-keyframes rotating{0%{-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes rotating{0%{-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0)}to{-ms-transform:rotate(360deg);-moz-transform:rotate(360deg);-webkit-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}.rotating{-webkit-animation:rotating 2s linear infinite;-moz-animation:rotating 2s linear infinite;-ms-animation:rotating 2s linear infinite;-o-animation:rotating 2s linear infinite;animation:rotating 2s linear infinite}.popover-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background-color:#00000080;display:flex;align-items:center;justify-content:center;z-index:9999;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.popover-content{background:#fff;border-radius:12px;box-shadow:0 20px 25px -5px #0000001a,0 10px 10px -5px #0000000a;max-width:500px;width:90%;max-height:80vh;overflow:hidden;animation:popoverFadeIn .2s ease-out}.popover-small{max-width:350px}.popover-medium{max-width:500px}.popover-large{max-width:700px}.popover-full{max-width:90vw;max-height:90vh}@keyframes popoverFadeIn{0%{opacity:0;transform:scale(.95) translateY(-10px)}to{opacity:1;transform:scale(1) translateY(0)}}.popover-header{display:flex;justify-content:space-between;align-items:center;padding:1rem 1.5rem .8rem;border-bottom:1px solid #e5e7eb}.popover-title{margin:0;font-size:18px;font-weight:600;color:#111827}.popover-close{background:none;border:none;font-size:24px;color:#6b7280;cursor:pointer;padding:0;width:30px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:6px;transition:all .2s}.popover-close:hover{background-color:#f3f4f6;color:#374151}.popover-body{padding:24px;max-height:calc(80vh - 80px);overflow-y:auto}[data-theme=dark] .popover-content{background:#1f2937;color:#f9fafb}[data-theme=dark] .popover-header{border-bottom-color:#374151}[data-theme=dark] .popover-title{color:#f9fafb}[data-theme=dark] .popover-close{color:#9ca3af}[data-theme=dark] .popover-close:hover{background-color:#374151;color:#d1d5db}@media (max-width: 640px){.popover-content{margin:20px;width:calc(100% - 40px)}.popover-header{padding:16px 20px 12px}.popover-body{padding:20px}}.sam-popover-content{padding:0}.sam-status{margin-bottom:16px;padding:8px 12px;background-color:#f8fafc;border-radius:6px;font-size:14px;border:1px solid #e2e8f0}.status-ready{color:#059669;font-weight:500}.status-loading{color:#d97706;font-weight:500}.sam-upload-section{margin-bottom:20px}.sam-upload-area{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 20px;border:2px dashed #d1d5db;border-radius:8px;cursor:pointer;transition:all .2s;background-color:#f9fafb}.sam-upload-area:hover{border-color:#3b82f6;background-color:#f0f9ff}.sam-upload-area svg{margin-bottom:12px;color:#6b7280}.sam-upload-area span{font-size:16px;font-weight:500;color:#374151;margin-bottom:8px}.sam-example-btn{background:none;border:none;color:#3b82f6;cursor:pointer;font-size:14px;text-decoration:underline}.sam-example-btn:hover{color:#2563eb}.sam-canvas-wrapper{display:flex;justify-content:center;margin:1rem 0}.sam-canvas-wrapper.disabled{pointer-events:none;cursor:not-allowed;opacity:.5}.sam-fabric-canvas{max-width:100%;max-height:400px}.sam-image-container{position:relative;width:100%;max-height:400px;background-size:contain;background-repeat:no-repeat;background-position:center;border:1px solid #d1d5db;border-radius:8px;overflow:hidden;cursor:crosshair}.sam-point{position:absolute;width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;transform:translate(-50%,-50%);pointer-events:none;z-index:10}.sam-point.positive{background-color:#10b981;color:#fff;border:2px solid #ffffff;box-shadow:0 2px 4px #0000001a}.sam-point.negative{background-color:#ef4444;color:#fff;border:2px solid #ffffff;box-shadow:0 2px 4px #0000001a}.sam-mask-canvas{position:absolute;pointer-events:none;opacity:.7;height:100%;width:100%}.sam-instructions{text-align:center}.sam-instructions p{margin:0;font-size:14px;color:#6b7280;font-style:italic}.sam-controls{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap}.sam-controls .sam-button{flex:1;min-width:0}.sam-button{padding:.2rem .4rem;border:none;border-radius:6px;cursor:pointer;transition:all .2s;white-space:nowrap}.sam-button:disabled{opacity:.5;cursor:not-allowed}.sam-button-primary{background-color:#3b82f6;color:#fff}.sam-button-primary:hover:not(:disabled){background-color:#2563eb}.sam-button-secondary{background-color:#f3f4f6;color:#374151}.sam-button-secondary:hover:not(:disabled){background-color:#e5e7eb}.sam-bounding-box{position:absolute;border:2px dashed #3b82f6;background-color:#3b82f61a;pointer-events:none;z-index:10}.sam-eraser-canvas{position:absolute;pointer-events:none;opacity:.7;height:100%;width:100%;z-index:15}.sam-tool-selection{display:flex;gap:8px;margin-bottom:1rem;justify-content:center;flex-wrap:wrap}.sam-tool-btn{padding:8px 16px;border:1px solid #d1d5db;border-radius:6px;background-color:#f9fafb;color:#374151;cursor:pointer;font-size:14px;transition:all .2s}.sam-tool-btn:hover:not(:disabled){background-color:#f3f4f6;border-color:#9ca3af}.sam-tool-btn.active{background-color:#3b82f6;color:#fff;border-color:#3b82f6}.sam-tool-btn:disabled{opacity:.5;cursor:not-allowed}.sam-accept-options{margin-block:1rem}.sam-accept-options h4{margin:0 0 12px;font-size:16px;font-weight:600;color:#1f2937}.sam-accept-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px}.sam-accept-btn{padding:.2rem .1rem;border:1px solid #10b981;border-radius:6px;background-color:#ecfdf5;color:#065f46;cursor:pointer;font-weight:500;transition:all .2s;text-align:center}.sam-accept-btn:hover{background-color:#10b981;color:#fff}[data-theme=dark] .sam-status{background-color:#374151;border-color:#4b5563;color:#d1d5db}[data-theme=dark] .status-ready{color:#10b981}[data-theme=dark] .status-loading{color:#f59e0b}[data-theme=dark] .sam-upload-area{background-color:#374151;border-color:#4b5563}[data-theme=dark] .sam-upload-area:hover{border-color:#3b82f6;background-color:#1e3a8a}[data-theme=dark] .sam-upload-area span{color:#d1d5db}[data-theme=dark] .sam-upload-area svg{color:#9ca3af}[data-theme=dark] .sam-image-container{border-color:#4b5563}[data-theme=dark] .sam-instructions p{color:#9ca3af}[data-theme=dark] .sam-button-secondary{background-color:#4b5563;color:#d1d5db}[data-theme=dark] .sam-button-secondary:hover:not(:disabled){background-color:#374151}[data-theme=dark] .sam-bounding-box{border-color:#60a5fa;background-color:#60a5fa1a}[data-theme=dark] .sam-tool-btn{background-color:#4b5563;color:#d1d5db;border-color:#6b7280}[data-theme=dark] .sam-tool-btn:hover:not(:disabled){background-color:#374151;border-color:#9ca3af}[data-theme=dark] .sam-accept-options h4{color:#f9fafb}[data-theme=dark] .sam-accept-btn{background-color:#064e3b;color:#a7f3d0;border-color:#047857}[data-theme=dark] .sam-accept-btn:hover{background-color:#047857;color:#fff}#seg-loading-status{text-align:center;height:1.5rem}#seg-loading-status svg{width:1.5rem;height:1.5rem;margin:auto;fill:var(--toggle-color-inactive)}")), document.head.appendChild(t);
    }
  } catch (e) {
    console.error("vite-plugin-css-injected-by-js", e);
  }
})();
function Zl(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Od = { exports: {} }, zo = {}, Md = { exports: {} }, Rt = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ca = Symbol.for("react.element"), um = Symbol.for("react.portal"), hm = Symbol.for("react.fragment"), dm = Symbol.for("react.strict_mode"), fm = Symbol.for("react.profiler"), pm = Symbol.for("react.provider"), gm = Symbol.for("react.context"), mm = Symbol.for("react.forward_ref"), vm = Symbol.for("react.suspense"), ym = Symbol.for("react.memo"), bm = Symbol.for("react.lazy"), Mu = Symbol.iterator;
function xm(t) {
  return t === null || typeof t != "object" ? null : (t = Mu && t[Mu] || t["@@iterator"], typeof t == "function" ? t : null);
}
var Pd = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, Ad = Object.assign, jd = {};
function dr(t, e, n) {
  this.props = t, this.context = e, this.refs = jd, this.updater = n || Pd;
}
dr.prototype.isReactComponent = {};
dr.prototype.setState = function(t, e) {
  if (typeof t != "object" && typeof t != "function" && t != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, t, e, "setState");
};
dr.prototype.forceUpdate = function(t) {
  this.updater.enqueueForceUpdate(this, t, "forceUpdate");
};
function Dd() {
}
Dd.prototype = dr.prototype;
function Kl(t, e, n) {
  this.props = t, this.context = e, this.refs = jd, this.updater = n || Pd;
}
var Ql = Kl.prototype = new Dd();
Ql.constructor = Kl;
Ad(Ql, dr.prototype);
Ql.isPureReactComponent = !0;
var Pu = Array.isArray, Ld = Object.prototype.hasOwnProperty, Jl = { current: null }, Rd = { key: !0, ref: !0, __self: !0, __source: !0 };
function Id(t, e, n) {
  var o, u = {}, g = null, v = null;
  if (e != null) for (o in e.ref !== void 0 && (v = e.ref), e.key !== void 0 && (g = "" + e.key), e) Ld.call(e, o) && !Rd.hasOwnProperty(o) && (u[o] = e[o]);
  var x = arguments.length - 2;
  if (x === 1) u.children = n;
  else if (1 < x) {
    for (var S = Array(x), E = 0; E < x; E++) S[E] = arguments[E + 2];
    u.children = S;
  }
  if (t && t.defaultProps) for (o in x = t.defaultProps, x) u[o] === void 0 && (u[o] = x[o]);
  return { $$typeof: ca, type: t, key: g, ref: v, props: u, _owner: Jl.current };
}
function _m(t, e) {
  return { $$typeof: ca, type: t.type, key: e, ref: t.ref, props: t.props, _owner: t._owner };
}
function $l(t) {
  return typeof t == "object" && t !== null && t.$$typeof === ca;
}
function wm(t) {
  var e = { "=": "=0", ":": "=2" };
  return "$" + t.replace(/[=:]/g, function(n) {
    return e[n];
  });
}
var Au = /\/+/g;
function ds(t, e) {
  return typeof t == "object" && t !== null && t.key != null ? wm("" + t.key) : e.toString(36);
}
function qa(t, e, n, o, u) {
  var g = typeof t;
  (g === "undefined" || g === "boolean") && (t = null);
  var v = !1;
  if (t === null) v = !0;
  else switch (g) {
    case "string":
    case "number":
      v = !0;
      break;
    case "object":
      switch (t.$$typeof) {
        case ca:
        case um:
          v = !0;
      }
  }
  if (v) return v = t, u = u(v), t = o === "" ? "." + ds(v, 0) : o, Pu(u) ? (n = "", t != null && (n = t.replace(Au, "$&/") + "/"), qa(u, e, n, "", function(E) {
    return E;
  })) : u != null && ($l(u) && (u = _m(u, n + (!u.key || v && v.key === u.key ? "" : ("" + u.key).replace(Au, "$&/") + "/") + t)), e.push(u)), 1;
  if (v = 0, o = o === "" ? "." : o + ":", Pu(t)) for (var x = 0; x < t.length; x++) {
    g = t[x];
    var S = o + ds(g, x);
    v += qa(g, e, n, S, u);
  }
  else if (S = xm(t), typeof S == "function") for (t = S.call(t), x = 0; !(g = t.next()).done; ) g = g.value, S = o + ds(g, x++), v += qa(g, e, n, S, u);
  else if (g === "object") throw e = String(t), Error("Objects are not valid as a React child (found: " + (e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e) + "). If you meant to render a collection of children, use an array instead.");
  return v;
}
function Ca(t, e, n) {
  if (t == null) return t;
  var o = [], u = 0;
  return qa(t, o, "", "", function(g) {
    return e.call(n, g, u++);
  }), o;
}
function Sm(t) {
  if (t._status === -1) {
    var e = t._result;
    e = e(), e.then(function(n) {
      (t._status === 0 || t._status === -1) && (t._status = 1, t._result = n);
    }, function(n) {
      (t._status === 0 || t._status === -1) && (t._status = 2, t._result = n);
    }), t._status === -1 && (t._status = 0, t._result = e);
  }
  if (t._status === 1) return t._result.default;
  throw t._result;
}
var Te = { current: null }, Za = { transition: null }, Cm = { ReactCurrentDispatcher: Te, ReactCurrentBatchConfig: Za, ReactCurrentOwner: Jl };
function Fd() {
  throw Error("act(...) is not supported in production builds of React.");
}
Rt.Children = { map: Ca, forEach: function(t, e, n) {
  Ca(t, function() {
    e.apply(this, arguments);
  }, n);
}, count: function(t) {
  var e = 0;
  return Ca(t, function() {
    e++;
  }), e;
}, toArray: function(t) {
  return Ca(t, function(e) {
    return e;
  }) || [];
}, only: function(t) {
  if (!$l(t)) throw Error("React.Children.only expected to receive a single React element child.");
  return t;
} };
Rt.Component = dr;
Rt.Fragment = hm;
Rt.Profiler = fm;
Rt.PureComponent = Kl;
Rt.StrictMode = dm;
Rt.Suspense = vm;
Rt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Cm;
Rt.act = Fd;
Rt.cloneElement = function(t, e, n) {
  if (t == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + t + ".");
  var o = Ad({}, t.props), u = t.key, g = t.ref, v = t._owner;
  if (e != null) {
    if (e.ref !== void 0 && (g = e.ref, v = Jl.current), e.key !== void 0 && (u = "" + e.key), t.type && t.type.defaultProps) var x = t.type.defaultProps;
    for (S in e) Ld.call(e, S) && !Rd.hasOwnProperty(S) && (o[S] = e[S] === void 0 && x !== void 0 ? x[S] : e[S]);
  }
  var S = arguments.length - 2;
  if (S === 1) o.children = n;
  else if (1 < S) {
    x = Array(S);
    for (var E = 0; E < S; E++) x[E] = arguments[E + 2];
    o.children = x;
  }
  return { $$typeof: ca, type: t.type, key: u, ref: g, props: o, _owner: v };
};
Rt.createContext = function(t) {
  return t = { $$typeof: gm, _currentValue: t, _currentValue2: t, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, t.Provider = { $$typeof: pm, _context: t }, t.Consumer = t;
};
Rt.createElement = Id;
Rt.createFactory = function(t) {
  var e = Id.bind(null, t);
  return e.type = t, e;
};
Rt.createRef = function() {
  return { current: null };
};
Rt.forwardRef = function(t) {
  return { $$typeof: mm, render: t };
};
Rt.isValidElement = $l;
Rt.lazy = function(t) {
  return { $$typeof: bm, _payload: { _status: -1, _result: t }, _init: Sm };
};
Rt.memo = function(t, e) {
  return { $$typeof: ym, type: t, compare: e === void 0 ? null : e };
};
Rt.startTransition = function(t) {
  var e = Za.transition;
  Za.transition = {};
  try {
    t();
  } finally {
    Za.transition = e;
  }
};
Rt.unstable_act = Fd;
Rt.useCallback = function(t, e) {
  return Te.current.useCallback(t, e);
};
Rt.useContext = function(t) {
  return Te.current.useContext(t);
};
Rt.useDebugValue = function() {
};
Rt.useDeferredValue = function(t) {
  return Te.current.useDeferredValue(t);
};
Rt.useEffect = function(t, e) {
  return Te.current.useEffect(t, e);
};
Rt.useId = function() {
  return Te.current.useId();
};
Rt.useImperativeHandle = function(t, e, n) {
  return Te.current.useImperativeHandle(t, e, n);
};
Rt.useInsertionEffect = function(t, e) {
  return Te.current.useInsertionEffect(t, e);
};
Rt.useLayoutEffect = function(t, e) {
  return Te.current.useLayoutEffect(t, e);
};
Rt.useMemo = function(t, e) {
  return Te.current.useMemo(t, e);
};
Rt.useReducer = function(t, e, n) {
  return Te.current.useReducer(t, e, n);
};
Rt.useRef = function(t) {
  return Te.current.useRef(t);
};
Rt.useState = function(t) {
  return Te.current.useState(t);
};
Rt.useSyncExternalStore = function(t, e, n) {
  return Te.current.useSyncExternalStore(t, e, n);
};
Rt.useTransition = function() {
  return Te.current.useTransition();
};
Rt.version = "18.3.1";
Md.exports = Rt;
var C = Md.exports;
const so = /* @__PURE__ */ Zl(C);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var km = C, Em = Symbol.for("react.element"), Tm = Symbol.for("react.fragment"), Om = Object.prototype.hasOwnProperty, Mm = km.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, Pm = { key: !0, ref: !0, __self: !0, __source: !0 };
function Bd(t, e, n) {
  var o, u = {}, g = null, v = null;
  n !== void 0 && (g = "" + n), e.key !== void 0 && (g = "" + e.key), e.ref !== void 0 && (v = e.ref);
  for (o in e) Om.call(e, o) && !Pm.hasOwnProperty(o) && (u[o] = e[o]);
  if (t && t.defaultProps) for (o in e = t.defaultProps, e) u[o] === void 0 && (u[o] = e[o]);
  return { $$typeof: Em, type: t, key: g, ref: v, props: u, _owner: Mm.current };
}
zo.Fragment = Tm;
zo.jsx = Bd;
zo.jsxs = Bd;
Od.exports = zo;
var st = Od.exports, zd = { exports: {} }, Ge = {}, Nd = { exports: {} }, Ud = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(t) {
  function e(i, r) {
    var s = i.length;
    i.push(r);
    t: for (; 0 < s; ) {
      var h = s - 1 >>> 1, d = i[h];
      if (0 < u(d, r)) i[h] = r, i[s] = d, s = h;
      else break t;
    }
  }
  function n(i) {
    return i.length === 0 ? null : i[0];
  }
  function o(i) {
    if (i.length === 0) return null;
    var r = i[0], s = i.pop();
    if (s !== r) {
      i[0] = s;
      t: for (var h = 0, d = i.length, p = d >>> 1; h < p; ) {
        var m = 2 * (h + 1) - 1, y = i[m], _ = m + 1, k = i[_];
        if (0 > u(y, s)) _ < d && 0 > u(k, y) ? (i[h] = k, i[_] = s, h = _) : (i[h] = y, i[m] = s, h = m);
        else if (_ < d && 0 > u(k, s)) i[h] = k, i[_] = s, h = _;
        else break t;
      }
    }
    return r;
  }
  function u(i, r) {
    var s = i.sortIndex - r.sortIndex;
    return s !== 0 ? s : i.id - r.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var g = performance;
    t.unstable_now = function() {
      return g.now();
    };
  } else {
    var v = Date, x = v.now();
    t.unstable_now = function() {
      return v.now() - x;
    };
  }
  var S = [], E = [], A = 1, Y = null, V = 3, Q = !1, tt = !1, rt = !1, ut = typeof setTimeout == "function" ? setTimeout : null, H = typeof clearTimeout == "function" ? clearTimeout : null, R = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function N(i) {
    for (var r = n(E); r !== null; ) {
      if (r.callback === null) o(E);
      else if (r.startTime <= i) o(E), r.sortIndex = r.expirationTime, e(S, r);
      else break;
      r = n(E);
    }
  }
  function $(i) {
    if (rt = !1, N(i), !tt) if (n(S) !== null) tt = !0, c(at);
    else {
      var r = n(E);
      r !== null && f($, r.startTime - i);
    }
  }
  function at(i, r) {
    tt = !1, rt && (rt = !1, H(b), b = -1), Q = !0;
    var s = V;
    try {
      for (N(r), Y = n(S); Y !== null && (!(Y.expirationTime > r) || i && !nt()); ) {
        var h = Y.callback;
        if (typeof h == "function") {
          Y.callback = null, V = Y.priorityLevel;
          var d = h(Y.expirationTime <= r);
          r = t.unstable_now(), typeof d == "function" ? Y.callback = d : Y === n(S) && o(S), N(r);
        } else o(S);
        Y = n(S);
      }
      if (Y !== null) var p = !0;
      else {
        var m = n(E);
        m !== null && f($, m.startTime - r), p = !1;
      }
      return p;
    } finally {
      Y = null, V = s, Q = !1;
    }
  }
  var it = !1, gt = null, b = -1, Pt = 5, P = -1;
  function nt() {
    return !(t.unstable_now() - P < Pt);
  }
  function bt() {
    if (gt !== null) {
      var i = t.unstable_now();
      P = i;
      var r = !0;
      try {
        r = gt(!0, i);
      } finally {
        r ? ht() : (it = !1, gt = null);
      }
    } else it = !1;
  }
  var ht;
  if (typeof R == "function") ht = function() {
    R(bt);
  };
  else if (typeof MessageChannel < "u") {
    var l = new MessageChannel(), a = l.port2;
    l.port1.onmessage = bt, ht = function() {
      a.postMessage(null);
    };
  } else ht = function() {
    ut(bt, 0);
  };
  function c(i) {
    gt = i, it || (it = !0, ht());
  }
  function f(i, r) {
    b = ut(function() {
      i(t.unstable_now());
    }, r);
  }
  t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(i) {
    i.callback = null;
  }, t.unstable_continueExecution = function() {
    tt || Q || (tt = !0, c(at));
  }, t.unstable_forceFrameRate = function(i) {
    0 > i || 125 < i ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : Pt = 0 < i ? Math.floor(1e3 / i) : 5;
  }, t.unstable_getCurrentPriorityLevel = function() {
    return V;
  }, t.unstable_getFirstCallbackNode = function() {
    return n(S);
  }, t.unstable_next = function(i) {
    switch (V) {
      case 1:
      case 2:
      case 3:
        var r = 3;
        break;
      default:
        r = V;
    }
    var s = V;
    V = r;
    try {
      return i();
    } finally {
      V = s;
    }
  }, t.unstable_pauseExecution = function() {
  }, t.unstable_requestPaint = function() {
  }, t.unstable_runWithPriority = function(i, r) {
    switch (i) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        i = 3;
    }
    var s = V;
    V = i;
    try {
      return r();
    } finally {
      V = s;
    }
  }, t.unstable_scheduleCallback = function(i, r, s) {
    var h = t.unstable_now();
    switch (typeof s == "object" && s !== null ? (s = s.delay, s = typeof s == "number" && 0 < s ? h + s : h) : s = h, i) {
      case 1:
        var d = -1;
        break;
      case 2:
        d = 250;
        break;
      case 5:
        d = 1073741823;
        break;
      case 4:
        d = 1e4;
        break;
      default:
        d = 5e3;
    }
    return d = s + d, i = { id: A++, callback: r, priorityLevel: i, startTime: s, expirationTime: d, sortIndex: -1 }, s > h ? (i.sortIndex = s, e(E, i), n(S) === null && i === n(E) && (rt ? (H(b), b = -1) : rt = !0, f($, s - h))) : (i.sortIndex = d, e(S, i), tt || Q || (tt = !0, c(at))), i;
  }, t.unstable_shouldYield = nt, t.unstable_wrapCallback = function(i) {
    var r = V;
    return function() {
      var s = V;
      V = r;
      try {
        return i.apply(this, arguments);
      } finally {
        V = s;
      }
    };
  };
})(Ud);
Nd.exports = Ud;
var Am = Nd.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var jm = C, Ve = Am;
function vt(t) {
  for (var e = "https://reactjs.org/docs/error-decoder.html?invariant=" + t, n = 1; n < arguments.length; n++) e += "&args[]=" + encodeURIComponent(arguments[n]);
  return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var Wd = /* @__PURE__ */ new Set(), Gr = {};
function Oi(t, e) {
  ir(t, e), ir(t + "Capture", e);
}
function ir(t, e) {
  for (Gr[t] = e, t = 0; t < e.length; t++) Wd.add(e[t]);
}
var zn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Qs = Object.prototype.hasOwnProperty, Dm = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, ju = {}, Du = {};
function Lm(t) {
  return Qs.call(Du, t) ? !0 : Qs.call(ju, t) ? !1 : Dm.test(t) ? Du[t] = !0 : (ju[t] = !0, !1);
}
function Rm(t, e, n, o) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof e) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return o ? !1 : n !== null ? !n.acceptsBooleans : (t = t.toLowerCase().slice(0, 5), t !== "data-" && t !== "aria-");
    default:
      return !1;
  }
}
function Im(t, e, n, o) {
  if (e === null || typeof e > "u" || Rm(t, e, n, o)) return !0;
  if (o) return !1;
  if (n !== null) switch (n.type) {
    case 3:
      return !e;
    case 4:
      return e === !1;
    case 5:
      return isNaN(e);
    case 6:
      return isNaN(e) || 1 > e;
  }
  return !1;
}
function Oe(t, e, n, o, u, g, v) {
  this.acceptsBooleans = e === 2 || e === 3 || e === 4, this.attributeName = o, this.attributeNamespace = u, this.mustUseProperty = n, this.propertyName = t, this.type = e, this.sanitizeURL = g, this.removeEmptyString = v;
}
var me = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t) {
  me[t] = new Oe(t, 0, !1, t, null, !1, !1);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(t) {
  var e = t[0];
  me[e] = new Oe(e, 1, !1, t[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(t) {
  me[t] = new Oe(t, 2, !1, t.toLowerCase(), null, !1, !1);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(t) {
  me[t] = new Oe(t, 2, !1, t, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t) {
  me[t] = new Oe(t, 3, !1, t.toLowerCase(), null, !1, !1);
});
["checked", "multiple", "muted", "selected"].forEach(function(t) {
  me[t] = new Oe(t, 3, !0, t, null, !1, !1);
});
["capture", "download"].forEach(function(t) {
  me[t] = new Oe(t, 4, !1, t, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function(t) {
  me[t] = new Oe(t, 6, !1, t, null, !1, !1);
});
["rowSpan", "start"].forEach(function(t) {
  me[t] = new Oe(t, 5, !1, t.toLowerCase(), null, !1, !1);
});
var tc = /[\-:]([a-z])/g;
function ec(t) {
  return t[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t) {
  var e = t.replace(
    tc,
    ec
  );
  me[e] = new Oe(e, 1, !1, t, null, !1, !1);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t) {
  var e = t.replace(tc, ec);
  me[e] = new Oe(e, 1, !1, t, "http://www.w3.org/1999/xlink", !1, !1);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(t) {
  var e = t.replace(tc, ec);
  me[e] = new Oe(e, 1, !1, t, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function(t) {
  me[t] = new Oe(t, 1, !1, t.toLowerCase(), null, !1, !1);
});
me.xlinkHref = new Oe("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(t) {
  me[t] = new Oe(t, 1, !1, t.toLowerCase(), null, !0, !0);
});
function nc(t, e, n, o) {
  var u = me.hasOwnProperty(e) ? me[e] : null;
  (u !== null ? u.type !== 0 : o || !(2 < e.length) || e[0] !== "o" && e[0] !== "O" || e[1] !== "n" && e[1] !== "N") && (Im(e, n, u, o) && (n = null), o || u === null ? Lm(e) && (n === null ? t.removeAttribute(e) : t.setAttribute(e, "" + n)) : u.mustUseProperty ? t[u.propertyName] = n === null ? u.type === 3 ? !1 : "" : n : (e = u.attributeName, o = u.attributeNamespace, n === null ? t.removeAttribute(e) : (u = u.type, n = u === 3 || u === 4 && n === !0 ? "" : "" + n, o ? t.setAttributeNS(o, e, n) : t.setAttribute(e, n))));
}
var Yn = jm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, ka = Symbol.for("react.element"), Bi = Symbol.for("react.portal"), zi = Symbol.for("react.fragment"), ic = Symbol.for("react.strict_mode"), Js = Symbol.for("react.profiler"), Yd = Symbol.for("react.provider"), Vd = Symbol.for("react.context"), rc = Symbol.for("react.forward_ref"), $s = Symbol.for("react.suspense"), tl = Symbol.for("react.suspense_list"), ac = Symbol.for("react.memo"), Gn = Symbol.for("react.lazy"), Gd = Symbol.for("react.offscreen"), Lu = Symbol.iterator;
function Sr(t) {
  return t === null || typeof t != "object" ? null : (t = Lu && t[Lu] || t["@@iterator"], typeof t == "function" ? t : null);
}
var ee = Object.assign, fs;
function Ar(t) {
  if (fs === void 0) try {
    throw Error();
  } catch (n) {
    var e = n.stack.trim().match(/\n( *(at )?)/);
    fs = e && e[1] || "";
  }
  return `
` + fs + t;
}
var ps = !1;
function gs(t, e) {
  if (!t || ps) return "";
  ps = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (e) if (e = function() {
      throw Error();
    }, Object.defineProperty(e.prototype, "props", { set: function() {
      throw Error();
    } }), typeof Reflect == "object" && Reflect.construct) {
      try {
        Reflect.construct(e, []);
      } catch (E) {
        var o = E;
      }
      Reflect.construct(t, [], e);
    } else {
      try {
        e.call();
      } catch (E) {
        o = E;
      }
      t.call(e.prototype);
    }
    else {
      try {
        throw Error();
      } catch (E) {
        o = E;
      }
      t();
    }
  } catch (E) {
    if (E && o && typeof E.stack == "string") {
      for (var u = E.stack.split(`
`), g = o.stack.split(`
`), v = u.length - 1, x = g.length - 1; 1 <= v && 0 <= x && u[v] !== g[x]; ) x--;
      for (; 1 <= v && 0 <= x; v--, x--) if (u[v] !== g[x]) {
        if (v !== 1 || x !== 1)
          do
            if (v--, x--, 0 > x || u[v] !== g[x]) {
              var S = `
` + u[v].replace(" at new ", " at ");
              return t.displayName && S.includes("<anonymous>") && (S = S.replace("<anonymous>", t.displayName)), S;
            }
          while (1 <= v && 0 <= x);
        break;
      }
    }
  } finally {
    ps = !1, Error.prepareStackTrace = n;
  }
  return (t = t ? t.displayName || t.name : "") ? Ar(t) : "";
}
function Fm(t) {
  switch (t.tag) {
    case 5:
      return Ar(t.type);
    case 16:
      return Ar("Lazy");
    case 13:
      return Ar("Suspense");
    case 19:
      return Ar("SuspenseList");
    case 0:
    case 2:
    case 15:
      return t = gs(t.type, !1), t;
    case 11:
      return t = gs(t.type.render, !1), t;
    case 1:
      return t = gs(t.type, !0), t;
    default:
      return "";
  }
}
function el(t) {
  if (t == null) return null;
  if (typeof t == "function") return t.displayName || t.name || null;
  if (typeof t == "string") return t;
  switch (t) {
    case zi:
      return "Fragment";
    case Bi:
      return "Portal";
    case Js:
      return "Profiler";
    case ic:
      return "StrictMode";
    case $s:
      return "Suspense";
    case tl:
      return "SuspenseList";
  }
  if (typeof t == "object") switch (t.$$typeof) {
    case Vd:
      return (t.displayName || "Context") + ".Consumer";
    case Yd:
      return (t._context.displayName || "Context") + ".Provider";
    case rc:
      var e = t.render;
      return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
    case ac:
      return e = t.displayName || null, e !== null ? e : el(t.type) || "Memo";
    case Gn:
      e = t._payload, t = t._init;
      try {
        return el(t(e));
      } catch {
      }
  }
  return null;
}
function Bm(t) {
  var e = t.type;
  switch (t.tag) {
    case 24:
      return "Cache";
    case 9:
      return (e.displayName || "Context") + ".Consumer";
    case 10:
      return (e._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return t = e.render, t = t.displayName || t.name || "", e.displayName || (t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return e;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return el(e);
    case 8:
      return e === ic ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof e == "function") return e.displayName || e.name || null;
      if (typeof e == "string") return e;
  }
  return null;
}
function oi(t) {
  switch (typeof t) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return t;
    case "object":
      return t;
    default:
      return "";
  }
}
function Hd(t) {
  var e = t.type;
  return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio");
}
function zm(t) {
  var e = Hd(t) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(t.constructor.prototype, e), o = "" + t[e];
  if (!t.hasOwnProperty(e) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
    var u = n.get, g = n.set;
    return Object.defineProperty(t, e, { configurable: !0, get: function() {
      return u.call(this);
    }, set: function(v) {
      o = "" + v, g.call(this, v);
    } }), Object.defineProperty(t, e, { enumerable: n.enumerable }), { getValue: function() {
      return o;
    }, setValue: function(v) {
      o = "" + v;
    }, stopTracking: function() {
      t._valueTracker = null, delete t[e];
    } };
  }
}
function Ea(t) {
  t._valueTracker || (t._valueTracker = zm(t));
}
function Xd(t) {
  if (!t) return !1;
  var e = t._valueTracker;
  if (!e) return !0;
  var n = e.getValue(), o = "";
  return t && (o = Hd(t) ? t.checked ? "true" : "false" : t.value), t = o, t !== n ? (e.setValue(t), !0) : !1;
}
function lo(t) {
  if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
  try {
    return t.activeElement || t.body;
  } catch {
    return t.body;
  }
}
function nl(t, e) {
  var n = e.checked;
  return ee({}, e, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: n ?? t._wrapperState.initialChecked });
}
function Ru(t, e) {
  var n = e.defaultValue == null ? "" : e.defaultValue, o = e.checked != null ? e.checked : e.defaultChecked;
  n = oi(e.value != null ? e.value : n), t._wrapperState = { initialChecked: o, initialValue: n, controlled: e.type === "checkbox" || e.type === "radio" ? e.checked != null : e.value != null };
}
function qd(t, e) {
  e = e.checked, e != null && nc(t, "checked", e, !1);
}
function il(t, e) {
  qd(t, e);
  var n = oi(e.value), o = e.type;
  if (n != null) o === "number" ? (n === 0 && t.value === "" || t.value != n) && (t.value = "" + n) : t.value !== "" + n && (t.value = "" + n);
  else if (o === "submit" || o === "reset") {
    t.removeAttribute("value");
    return;
  }
  e.hasOwnProperty("value") ? rl(t, e.type, n) : e.hasOwnProperty("defaultValue") && rl(t, e.type, oi(e.defaultValue)), e.checked == null && e.defaultChecked != null && (t.defaultChecked = !!e.defaultChecked);
}
function Iu(t, e, n) {
  if (e.hasOwnProperty("value") || e.hasOwnProperty("defaultValue")) {
    var o = e.type;
    if (!(o !== "submit" && o !== "reset" || e.value !== void 0 && e.value !== null)) return;
    e = "" + t._wrapperState.initialValue, n || e === t.value || (t.value = e), t.defaultValue = e;
  }
  n = t.name, n !== "" && (t.name = ""), t.defaultChecked = !!t._wrapperState.initialChecked, n !== "" && (t.name = n);
}
function rl(t, e, n) {
  (e !== "number" || lo(t.ownerDocument) !== t) && (n == null ? t.defaultValue = "" + t._wrapperState.initialValue : t.defaultValue !== "" + n && (t.defaultValue = "" + n));
}
var jr = Array.isArray;
function Qi(t, e, n, o) {
  if (t = t.options, e) {
    e = {};
    for (var u = 0; u < n.length; u++) e["$" + n[u]] = !0;
    for (n = 0; n < t.length; n++) u = e.hasOwnProperty("$" + t[n].value), t[n].selected !== u && (t[n].selected = u), u && o && (t[n].defaultSelected = !0);
  } else {
    for (n = "" + oi(n), e = null, u = 0; u < t.length; u++) {
      if (t[u].value === n) {
        t[u].selected = !0, o && (t[u].defaultSelected = !0);
        return;
      }
      e !== null || t[u].disabled || (e = t[u]);
    }
    e !== null && (e.selected = !0);
  }
}
function al(t, e) {
  if (e.dangerouslySetInnerHTML != null) throw Error(vt(91));
  return ee({}, e, { value: void 0, defaultValue: void 0, children: "" + t._wrapperState.initialValue });
}
function Fu(t, e) {
  var n = e.value;
  if (n == null) {
    if (n = e.children, e = e.defaultValue, n != null) {
      if (e != null) throw Error(vt(92));
      if (jr(n)) {
        if (1 < n.length) throw Error(vt(93));
        n = n[0];
      }
      e = n;
    }
    e == null && (e = ""), n = e;
  }
  t._wrapperState = { initialValue: oi(n) };
}
function Zd(t, e) {
  var n = oi(e.value), o = oi(e.defaultValue);
  n != null && (n = "" + n, n !== t.value && (t.value = n), e.defaultValue == null && t.defaultValue !== n && (t.defaultValue = n)), o != null && (t.defaultValue = "" + o);
}
function Bu(t) {
  var e = t.textContent;
  e === t._wrapperState.initialValue && e !== "" && e !== null && (t.value = e);
}
function Kd(t) {
  switch (t) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function ol(t, e) {
  return t == null || t === "http://www.w3.org/1999/xhtml" ? Kd(e) : t === "http://www.w3.org/2000/svg" && e === "foreignObject" ? "http://www.w3.org/1999/xhtml" : t;
}
var Ta, Qd = function(t) {
  return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(e, n, o, u) {
    MSApp.execUnsafeLocalFunction(function() {
      return t(e, n, o, u);
    });
  } : t;
}(function(t, e) {
  if (t.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in t) t.innerHTML = e;
  else {
    for (Ta = Ta || document.createElement("div"), Ta.innerHTML = "<svg>" + e.valueOf().toString() + "</svg>", e = Ta.firstChild; t.firstChild; ) t.removeChild(t.firstChild);
    for (; e.firstChild; ) t.appendChild(e.firstChild);
  }
});
function Hr(t, e) {
  if (e) {
    var n = t.firstChild;
    if (n && n === t.lastChild && n.nodeType === 3) {
      n.nodeValue = e;
      return;
    }
  }
  t.textContent = e;
}
var Rr = {
  animationIterationCount: !0,
  aspectRatio: !0,
  borderImageOutset: !0,
  borderImageSlice: !0,
  borderImageWidth: !0,
  boxFlex: !0,
  boxFlexGroup: !0,
  boxOrdinalGroup: !0,
  columnCount: !0,
  columns: !0,
  flex: !0,
  flexGrow: !0,
  flexPositive: !0,
  flexShrink: !0,
  flexNegative: !0,
  flexOrder: !0,
  gridArea: !0,
  gridRow: !0,
  gridRowEnd: !0,
  gridRowSpan: !0,
  gridRowStart: !0,
  gridColumn: !0,
  gridColumnEnd: !0,
  gridColumnSpan: !0,
  gridColumnStart: !0,
  fontWeight: !0,
  lineClamp: !0,
  lineHeight: !0,
  opacity: !0,
  order: !0,
  orphans: !0,
  tabSize: !0,
  widows: !0,
  zIndex: !0,
  zoom: !0,
  fillOpacity: !0,
  floodOpacity: !0,
  stopOpacity: !0,
  strokeDasharray: !0,
  strokeDashoffset: !0,
  strokeMiterlimit: !0,
  strokeOpacity: !0,
  strokeWidth: !0
}, Nm = ["Webkit", "ms", "Moz", "O"];
Object.keys(Rr).forEach(function(t) {
  Nm.forEach(function(e) {
    e = e + t.charAt(0).toUpperCase() + t.substring(1), Rr[e] = Rr[t];
  });
});
function Jd(t, e, n) {
  return e == null || typeof e == "boolean" || e === "" ? "" : n || typeof e != "number" || e === 0 || Rr.hasOwnProperty(t) && Rr[t] ? ("" + e).trim() : e + "px";
}
function $d(t, e) {
  t = t.style;
  for (var n in e) if (e.hasOwnProperty(n)) {
    var o = n.indexOf("--") === 0, u = Jd(n, e[n], o);
    n === "float" && (n = "cssFloat"), o ? t.setProperty(n, u) : t[n] = u;
  }
}
var Um = ee({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
function sl(t, e) {
  if (e) {
    if (Um[t] && (e.children != null || e.dangerouslySetInnerHTML != null)) throw Error(vt(137, t));
    if (e.dangerouslySetInnerHTML != null) {
      if (e.children != null) throw Error(vt(60));
      if (typeof e.dangerouslySetInnerHTML != "object" || !("__html" in e.dangerouslySetInnerHTML)) throw Error(vt(61));
    }
    if (e.style != null && typeof e.style != "object") throw Error(vt(62));
  }
}
function ll(t, e) {
  if (t.indexOf("-") === -1) return typeof e.is == "string";
  switch (t) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var cl = null;
function oc(t) {
  return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
}
var ul = null, Ji = null, $i = null;
function zu(t) {
  if (t = da(t)) {
    if (typeof ul != "function") throw Error(vt(280));
    var e = t.stateNode;
    e && (e = Vo(e), ul(t.stateNode, t.type, e));
  }
}
function tf(t) {
  Ji ? $i ? $i.push(t) : $i = [t] : Ji = t;
}
function ef() {
  if (Ji) {
    var t = Ji, e = $i;
    if ($i = Ji = null, zu(t), e) for (t = 0; t < e.length; t++) zu(e[t]);
  }
}
function nf(t, e) {
  return t(e);
}
function rf() {
}
var ms = !1;
function af(t, e, n) {
  if (ms) return t(e, n);
  ms = !0;
  try {
    return nf(t, e, n);
  } finally {
    ms = !1, (Ji !== null || $i !== null) && (rf(), ef());
  }
}
function Xr(t, e) {
  var n = t.stateNode;
  if (n === null) return null;
  var o = Vo(n);
  if (o === null) return null;
  n = o[e];
  t: switch (e) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (o = !o.disabled) || (t = t.type, o = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !o;
      break t;
    default:
      t = !1;
  }
  if (t) return null;
  if (n && typeof n != "function") throw Error(vt(231, e, typeof n));
  return n;
}
var hl = !1;
if (zn) try {
  var Cr = {};
  Object.defineProperty(Cr, "passive", { get: function() {
    hl = !0;
  } }), window.addEventListener("test", Cr, Cr), window.removeEventListener("test", Cr, Cr);
} catch {
  hl = !1;
}
function Wm(t, e, n, o, u, g, v, x, S) {
  var E = Array.prototype.slice.call(arguments, 3);
  try {
    e.apply(n, E);
  } catch (A) {
    this.onError(A);
  }
}
var Ir = !1, co = null, uo = !1, dl = null, Ym = { onError: function(t) {
  Ir = !0, co = t;
} };
function Vm(t, e, n, o, u, g, v, x, S) {
  Ir = !1, co = null, Wm.apply(Ym, arguments);
}
function Gm(t, e, n, o, u, g, v, x, S) {
  if (Vm.apply(this, arguments), Ir) {
    if (Ir) {
      var E = co;
      Ir = !1, co = null;
    } else throw Error(vt(198));
    uo || (uo = !0, dl = E);
  }
}
function Mi(t) {
  var e = t, n = t;
  if (t.alternate) for (; e.return; ) e = e.return;
  else {
    t = e;
    do
      e = t, e.flags & 4098 && (n = e.return), t = e.return;
    while (t);
  }
  return e.tag === 3 ? n : null;
}
function of(t) {
  if (t.tag === 13) {
    var e = t.memoizedState;
    if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
  }
  return null;
}
function Nu(t) {
  if (Mi(t) !== t) throw Error(vt(188));
}
function Hm(t) {
  var e = t.alternate;
  if (!e) {
    if (e = Mi(t), e === null) throw Error(vt(188));
    return e !== t ? null : t;
  }
  for (var n = t, o = e; ; ) {
    var u = n.return;
    if (u === null) break;
    var g = u.alternate;
    if (g === null) {
      if (o = u.return, o !== null) {
        n = o;
        continue;
      }
      break;
    }
    if (u.child === g.child) {
      for (g = u.child; g; ) {
        if (g === n) return Nu(u), t;
        if (g === o) return Nu(u), e;
        g = g.sibling;
      }
      throw Error(vt(188));
    }
    if (n.return !== o.return) n = u, o = g;
    else {
      for (var v = !1, x = u.child; x; ) {
        if (x === n) {
          v = !0, n = u, o = g;
          break;
        }
        if (x === o) {
          v = !0, o = u, n = g;
          break;
        }
        x = x.sibling;
      }
      if (!v) {
        for (x = g.child; x; ) {
          if (x === n) {
            v = !0, n = g, o = u;
            break;
          }
          if (x === o) {
            v = !0, o = g, n = u;
            break;
          }
          x = x.sibling;
        }
        if (!v) throw Error(vt(189));
      }
    }
    if (n.alternate !== o) throw Error(vt(190));
  }
  if (n.tag !== 3) throw Error(vt(188));
  return n.stateNode.current === n ? t : e;
}
function sf(t) {
  return t = Hm(t), t !== null ? lf(t) : null;
}
function lf(t) {
  if (t.tag === 5 || t.tag === 6) return t;
  for (t = t.child; t !== null; ) {
    var e = lf(t);
    if (e !== null) return e;
    t = t.sibling;
  }
  return null;
}
var cf = Ve.unstable_scheduleCallback, Uu = Ve.unstable_cancelCallback, Xm = Ve.unstable_shouldYield, qm = Ve.unstable_requestPaint, ae = Ve.unstable_now, Zm = Ve.unstable_getCurrentPriorityLevel, sc = Ve.unstable_ImmediatePriority, uf = Ve.unstable_UserBlockingPriority, ho = Ve.unstable_NormalPriority, Km = Ve.unstable_LowPriority, hf = Ve.unstable_IdlePriority, No = null, Mn = null;
function Qm(t) {
  if (Mn && typeof Mn.onCommitFiberRoot == "function") try {
    Mn.onCommitFiberRoot(No, t, void 0, (t.current.flags & 128) === 128);
  } catch {
  }
}
var gn = Math.clz32 ? Math.clz32 : t1, Jm = Math.log, $m = Math.LN2;
function t1(t) {
  return t >>>= 0, t === 0 ? 32 : 31 - (Jm(t) / $m | 0) | 0;
}
var Oa = 64, Ma = 4194304;
function Dr(t) {
  switch (t & -t) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return t & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return t;
  }
}
function fo(t, e) {
  var n = t.pendingLanes;
  if (n === 0) return 0;
  var o = 0, u = t.suspendedLanes, g = t.pingedLanes, v = n & 268435455;
  if (v !== 0) {
    var x = v & ~u;
    x !== 0 ? o = Dr(x) : (g &= v, g !== 0 && (o = Dr(g)));
  } else v = n & ~u, v !== 0 ? o = Dr(v) : g !== 0 && (o = Dr(g));
  if (o === 0) return 0;
  if (e !== 0 && e !== o && !(e & u) && (u = o & -o, g = e & -e, u >= g || u === 16 && (g & 4194240) !== 0)) return e;
  if (o & 4 && (o |= n & 16), e = t.entangledLanes, e !== 0) for (t = t.entanglements, e &= o; 0 < e; ) n = 31 - gn(e), u = 1 << n, o |= t[n], e &= ~u;
  return o;
}
function e1(t, e) {
  switch (t) {
    case 1:
    case 2:
    case 4:
      return e + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function n1(t, e) {
  for (var n = t.suspendedLanes, o = t.pingedLanes, u = t.expirationTimes, g = t.pendingLanes; 0 < g; ) {
    var v = 31 - gn(g), x = 1 << v, S = u[v];
    S === -1 ? (!(x & n) || x & o) && (u[v] = e1(x, e)) : S <= e && (t.expiredLanes |= x), g &= ~x;
  }
}
function fl(t) {
  return t = t.pendingLanes & -1073741825, t !== 0 ? t : t & 1073741824 ? 1073741824 : 0;
}
function df() {
  var t = Oa;
  return Oa <<= 1, !(Oa & 4194240) && (Oa = 64), t;
}
function vs(t) {
  for (var e = [], n = 0; 31 > n; n++) e.push(t);
  return e;
}
function ua(t, e, n) {
  t.pendingLanes |= e, e !== 536870912 && (t.suspendedLanes = 0, t.pingedLanes = 0), t = t.eventTimes, e = 31 - gn(e), t[e] = n;
}
function i1(t, e) {
  var n = t.pendingLanes & ~e;
  t.pendingLanes = e, t.suspendedLanes = 0, t.pingedLanes = 0, t.expiredLanes &= e, t.mutableReadLanes &= e, t.entangledLanes &= e, e = t.entanglements;
  var o = t.eventTimes;
  for (t = t.expirationTimes; 0 < n; ) {
    var u = 31 - gn(n), g = 1 << u;
    e[u] = 0, o[u] = -1, t[u] = -1, n &= ~g;
  }
}
function lc(t, e) {
  var n = t.entangledLanes |= e;
  for (t = t.entanglements; n; ) {
    var o = 31 - gn(n), u = 1 << o;
    u & e | t[o] & e && (t[o] |= e), n &= ~u;
  }
}
var Yt = 0;
function ff(t) {
  return t &= -t, 1 < t ? 4 < t ? t & 268435455 ? 16 : 536870912 : 4 : 1;
}
var pf, cc, gf, mf, vf, pl = !1, Pa = [], Jn = null, $n = null, ti = null, qr = /* @__PURE__ */ new Map(), Zr = /* @__PURE__ */ new Map(), Xn = [], r1 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Wu(t, e) {
  switch (t) {
    case "focusin":
    case "focusout":
      Jn = null;
      break;
    case "dragenter":
    case "dragleave":
      $n = null;
      break;
    case "mouseover":
    case "mouseout":
      ti = null;
      break;
    case "pointerover":
    case "pointerout":
      qr.delete(e.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Zr.delete(e.pointerId);
  }
}
function kr(t, e, n, o, u, g) {
  return t === null || t.nativeEvent !== g ? (t = { blockedOn: e, domEventName: n, eventSystemFlags: o, nativeEvent: g, targetContainers: [u] }, e !== null && (e = da(e), e !== null && cc(e)), t) : (t.eventSystemFlags |= o, e = t.targetContainers, u !== null && e.indexOf(u) === -1 && e.push(u), t);
}
function a1(t, e, n, o, u) {
  switch (e) {
    case "focusin":
      return Jn = kr(Jn, t, e, n, o, u), !0;
    case "dragenter":
      return $n = kr($n, t, e, n, o, u), !0;
    case "mouseover":
      return ti = kr(ti, t, e, n, o, u), !0;
    case "pointerover":
      var g = u.pointerId;
      return qr.set(g, kr(qr.get(g) || null, t, e, n, o, u)), !0;
    case "gotpointercapture":
      return g = u.pointerId, Zr.set(g, kr(Zr.get(g) || null, t, e, n, o, u)), !0;
  }
  return !1;
}
function yf(t) {
  var e = yi(t.target);
  if (e !== null) {
    var n = Mi(e);
    if (n !== null) {
      if (e = n.tag, e === 13) {
        if (e = of(n), e !== null) {
          t.blockedOn = e, vf(t.priority, function() {
            gf(n);
          });
          return;
        }
      } else if (e === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        t.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  t.blockedOn = null;
}
function Ka(t) {
  if (t.blockedOn !== null) return !1;
  for (var e = t.targetContainers; 0 < e.length; ) {
    var n = gl(t.domEventName, t.eventSystemFlags, e[0], t.nativeEvent);
    if (n === null) {
      n = t.nativeEvent;
      var o = new n.constructor(n.type, n);
      cl = o, n.target.dispatchEvent(o), cl = null;
    } else return e = da(n), e !== null && cc(e), t.blockedOn = n, !1;
    e.shift();
  }
  return !0;
}
function Yu(t, e, n) {
  Ka(t) && n.delete(e);
}
function o1() {
  pl = !1, Jn !== null && Ka(Jn) && (Jn = null), $n !== null && Ka($n) && ($n = null), ti !== null && Ka(ti) && (ti = null), qr.forEach(Yu), Zr.forEach(Yu);
}
function Er(t, e) {
  t.blockedOn === e && (t.blockedOn = null, pl || (pl = !0, Ve.unstable_scheduleCallback(Ve.unstable_NormalPriority, o1)));
}
function Kr(t) {
  function e(u) {
    return Er(u, t);
  }
  if (0 < Pa.length) {
    Er(Pa[0], t);
    for (var n = 1; n < Pa.length; n++) {
      var o = Pa[n];
      o.blockedOn === t && (o.blockedOn = null);
    }
  }
  for (Jn !== null && Er(Jn, t), $n !== null && Er($n, t), ti !== null && Er(ti, t), qr.forEach(e), Zr.forEach(e), n = 0; n < Xn.length; n++) o = Xn[n], o.blockedOn === t && (o.blockedOn = null);
  for (; 0 < Xn.length && (n = Xn[0], n.blockedOn === null); ) yf(n), n.blockedOn === null && Xn.shift();
}
var tr = Yn.ReactCurrentBatchConfig, po = !0;
function s1(t, e, n, o) {
  var u = Yt, g = tr.transition;
  tr.transition = null;
  try {
    Yt = 1, uc(t, e, n, o);
  } finally {
    Yt = u, tr.transition = g;
  }
}
function l1(t, e, n, o) {
  var u = Yt, g = tr.transition;
  tr.transition = null;
  try {
    Yt = 4, uc(t, e, n, o);
  } finally {
    Yt = u, tr.transition = g;
  }
}
function uc(t, e, n, o) {
  if (po) {
    var u = gl(t, e, n, o);
    if (u === null) Ts(t, e, o, go, n), Wu(t, o);
    else if (a1(u, t, e, n, o)) o.stopPropagation();
    else if (Wu(t, o), e & 4 && -1 < r1.indexOf(t)) {
      for (; u !== null; ) {
        var g = da(u);
        if (g !== null && pf(g), g = gl(t, e, n, o), g === null && Ts(t, e, o, go, n), g === u) break;
        u = g;
      }
      u !== null && o.stopPropagation();
    } else Ts(t, e, o, null, n);
  }
}
var go = null;
function gl(t, e, n, o) {
  if (go = null, t = oc(o), t = yi(t), t !== null) if (e = Mi(t), e === null) t = null;
  else if (n = e.tag, n === 13) {
    if (t = of(e), t !== null) return t;
    t = null;
  } else if (n === 3) {
    if (e.stateNode.current.memoizedState.isDehydrated) return e.tag === 3 ? e.stateNode.containerInfo : null;
    t = null;
  } else e !== t && (t = null);
  return go = t, null;
}
function bf(t) {
  switch (t) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (Zm()) {
        case sc:
          return 1;
        case uf:
          return 4;
        case ho:
        case Km:
          return 16;
        case hf:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var Kn = null, hc = null, Qa = null;
function xf() {
  if (Qa) return Qa;
  var t, e = hc, n = e.length, o, u = "value" in Kn ? Kn.value : Kn.textContent, g = u.length;
  for (t = 0; t < n && e[t] === u[t]; t++) ;
  var v = n - t;
  for (o = 1; o <= v && e[n - o] === u[g - o]; o++) ;
  return Qa = u.slice(t, 1 < o ? 1 - o : void 0);
}
function Ja(t) {
  var e = t.keyCode;
  return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
}
function Aa() {
  return !0;
}
function Vu() {
  return !1;
}
function He(t) {
  function e(n, o, u, g, v) {
    this._reactName = n, this._targetInst = u, this.type = o, this.nativeEvent = g, this.target = v, this.currentTarget = null;
    for (var x in t) t.hasOwnProperty(x) && (n = t[x], this[x] = n ? n(g) : g[x]);
    return this.isDefaultPrevented = (g.defaultPrevented != null ? g.defaultPrevented : g.returnValue === !1) ? Aa : Vu, this.isPropagationStopped = Vu, this;
  }
  return ee(e.prototype, { preventDefault: function() {
    this.defaultPrevented = !0;
    var n = this.nativeEvent;
    n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Aa);
  }, stopPropagation: function() {
    var n = this.nativeEvent;
    n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Aa);
  }, persist: function() {
  }, isPersistent: Aa }), e;
}
var fr = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(t) {
  return t.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, dc = He(fr), ha = ee({}, fr, { view: 0, detail: 0 }), c1 = He(ha), ys, bs, Tr, Uo = ee({}, ha, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: fc, button: 0, buttons: 0, relatedTarget: function(t) {
  return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
}, movementX: function(t) {
  return "movementX" in t ? t.movementX : (t !== Tr && (Tr && t.type === "mousemove" ? (ys = t.screenX - Tr.screenX, bs = t.screenY - Tr.screenY) : bs = ys = 0, Tr = t), ys);
}, movementY: function(t) {
  return "movementY" in t ? t.movementY : bs;
} }), Gu = He(Uo), u1 = ee({}, Uo, { dataTransfer: 0 }), h1 = He(u1), d1 = ee({}, ha, { relatedTarget: 0 }), xs = He(d1), f1 = ee({}, fr, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), p1 = He(f1), g1 = ee({}, fr, { clipboardData: function(t) {
  return "clipboardData" in t ? t.clipboardData : window.clipboardData;
} }), m1 = He(g1), v1 = ee({}, fr, { data: 0 }), Hu = He(v1), y1 = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, b1 = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, x1 = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function _1(t) {
  var e = this.nativeEvent;
  return e.getModifierState ? e.getModifierState(t) : (t = x1[t]) ? !!e[t] : !1;
}
function fc() {
  return _1;
}
var w1 = ee({}, ha, { key: function(t) {
  if (t.key) {
    var e = y1[t.key] || t.key;
    if (e !== "Unidentified") return e;
  }
  return t.type === "keypress" ? (t = Ja(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? b1[t.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: fc, charCode: function(t) {
  return t.type === "keypress" ? Ja(t) : 0;
}, keyCode: function(t) {
  return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
}, which: function(t) {
  return t.type === "keypress" ? Ja(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
} }), S1 = He(w1), C1 = ee({}, Uo, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Xu = He(C1), k1 = ee({}, ha, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: fc }), E1 = He(k1), T1 = ee({}, fr, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), O1 = He(T1), M1 = ee({}, Uo, {
  deltaX: function(t) {
    return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
  },
  deltaY: function(t) {
    return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), P1 = He(M1), A1 = [9, 13, 27, 32], pc = zn && "CompositionEvent" in window, Fr = null;
zn && "documentMode" in document && (Fr = document.documentMode);
var j1 = zn && "TextEvent" in window && !Fr, _f = zn && (!pc || Fr && 8 < Fr && 11 >= Fr), qu = " ", Zu = !1;
function wf(t, e) {
  switch (t) {
    case "keyup":
      return A1.indexOf(e.keyCode) !== -1;
    case "keydown":
      return e.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function Sf(t) {
  return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
}
var Ni = !1;
function D1(t, e) {
  switch (t) {
    case "compositionend":
      return Sf(e);
    case "keypress":
      return e.which !== 32 ? null : (Zu = !0, qu);
    case "textInput":
      return t = e.data, t === qu && Zu ? null : t;
    default:
      return null;
  }
}
function L1(t, e) {
  if (Ni) return t === "compositionend" || !pc && wf(t, e) ? (t = xf(), Qa = hc = Kn = null, Ni = !1, t) : null;
  switch (t) {
    case "paste":
      return null;
    case "keypress":
      if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
        if (e.char && 1 < e.char.length) return e.char;
        if (e.which) return String.fromCharCode(e.which);
      }
      return null;
    case "compositionend":
      return _f && e.locale !== "ko" ? null : e.data;
    default:
      return null;
  }
}
var R1 = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
function Ku(t) {
  var e = t && t.nodeName && t.nodeName.toLowerCase();
  return e === "input" ? !!R1[t.type] : e === "textarea";
}
function Cf(t, e, n, o) {
  tf(o), e = mo(e, "onChange"), 0 < e.length && (n = new dc("onChange", "change", null, n, o), t.push({ event: n, listeners: e }));
}
var Br = null, Qr = null;
function I1(t) {
  Rf(t, 0);
}
function Wo(t) {
  var e = Yi(t);
  if (Xd(e)) return t;
}
function F1(t, e) {
  if (t === "change") return e;
}
var kf = !1;
if (zn) {
  var _s;
  if (zn) {
    var ws = "oninput" in document;
    if (!ws) {
      var Qu = document.createElement("div");
      Qu.setAttribute("oninput", "return;"), ws = typeof Qu.oninput == "function";
    }
    _s = ws;
  } else _s = !1;
  kf = _s && (!document.documentMode || 9 < document.documentMode);
}
function Ju() {
  Br && (Br.detachEvent("onpropertychange", Ef), Qr = Br = null);
}
function Ef(t) {
  if (t.propertyName === "value" && Wo(Qr)) {
    var e = [];
    Cf(e, Qr, t, oc(t)), af(I1, e);
  }
}
function B1(t, e, n) {
  t === "focusin" ? (Ju(), Br = e, Qr = n, Br.attachEvent("onpropertychange", Ef)) : t === "focusout" && Ju();
}
function z1(t) {
  if (t === "selectionchange" || t === "keyup" || t === "keydown") return Wo(Qr);
}
function N1(t, e) {
  if (t === "click") return Wo(e);
}
function U1(t, e) {
  if (t === "input" || t === "change") return Wo(e);
}
function W1(t, e) {
  return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e;
}
var vn = typeof Object.is == "function" ? Object.is : W1;
function Jr(t, e) {
  if (vn(t, e)) return !0;
  if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
  var n = Object.keys(t), o = Object.keys(e);
  if (n.length !== o.length) return !1;
  for (o = 0; o < n.length; o++) {
    var u = n[o];
    if (!Qs.call(e, u) || !vn(t[u], e[u])) return !1;
  }
  return !0;
}
function $u(t) {
  for (; t && t.firstChild; ) t = t.firstChild;
  return t;
}
function th(t, e) {
  var n = $u(t);
  t = 0;
  for (var o; n; ) {
    if (n.nodeType === 3) {
      if (o = t + n.textContent.length, t <= e && o >= e) return { node: n, offset: e - t };
      t = o;
    }
    t: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break t;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = $u(n);
  }
}
function Tf(t, e) {
  return t && e ? t === e ? !0 : t && t.nodeType === 3 ? !1 : e && e.nodeType === 3 ? Tf(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : !1 : !1;
}
function Of() {
  for (var t = window, e = lo(); e instanceof t.HTMLIFrameElement; ) {
    try {
      var n = typeof e.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) t = e.contentWindow;
    else break;
    e = lo(t.document);
  }
  return e;
}
function gc(t) {
  var e = t && t.nodeName && t.nodeName.toLowerCase();
  return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true");
}
function Y1(t) {
  var e = Of(), n = t.focusedElem, o = t.selectionRange;
  if (e !== n && n && n.ownerDocument && Tf(n.ownerDocument.documentElement, n)) {
    if (o !== null && gc(n)) {
      if (e = o.start, t = o.end, t === void 0 && (t = e), "selectionStart" in n) n.selectionStart = e, n.selectionEnd = Math.min(t, n.value.length);
      else if (t = (e = n.ownerDocument || document) && e.defaultView || window, t.getSelection) {
        t = t.getSelection();
        var u = n.textContent.length, g = Math.min(o.start, u);
        o = o.end === void 0 ? g : Math.min(o.end, u), !t.extend && g > o && (u = o, o = g, g = u), u = th(n, g);
        var v = th(
          n,
          o
        );
        u && v && (t.rangeCount !== 1 || t.anchorNode !== u.node || t.anchorOffset !== u.offset || t.focusNode !== v.node || t.focusOffset !== v.offset) && (e = e.createRange(), e.setStart(u.node, u.offset), t.removeAllRanges(), g > o ? (t.addRange(e), t.extend(v.node, v.offset)) : (e.setEnd(v.node, v.offset), t.addRange(e)));
      }
    }
    for (e = [], t = n; t = t.parentNode; ) t.nodeType === 1 && e.push({ element: t, left: t.scrollLeft, top: t.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < e.length; n++) t = e[n], t.element.scrollLeft = t.left, t.element.scrollTop = t.top;
  }
}
var V1 = zn && "documentMode" in document && 11 >= document.documentMode, Ui = null, ml = null, zr = null, vl = !1;
function eh(t, e, n) {
  var o = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  vl || Ui == null || Ui !== lo(o) || (o = Ui, "selectionStart" in o && gc(o) ? o = { start: o.selectionStart, end: o.selectionEnd } : (o = (o.ownerDocument && o.ownerDocument.defaultView || window).getSelection(), o = { anchorNode: o.anchorNode, anchorOffset: o.anchorOffset, focusNode: o.focusNode, focusOffset: o.focusOffset }), zr && Jr(zr, o) || (zr = o, o = mo(ml, "onSelect"), 0 < o.length && (e = new dc("onSelect", "select", null, e, n), t.push({ event: e, listeners: o }), e.target = Ui)));
}
function ja(t, e) {
  var n = {};
  return n[t.toLowerCase()] = e.toLowerCase(), n["Webkit" + t] = "webkit" + e, n["Moz" + t] = "moz" + e, n;
}
var Wi = { animationend: ja("Animation", "AnimationEnd"), animationiteration: ja("Animation", "AnimationIteration"), animationstart: ja("Animation", "AnimationStart"), transitionend: ja("Transition", "TransitionEnd") }, Ss = {}, Mf = {};
zn && (Mf = document.createElement("div").style, "AnimationEvent" in window || (delete Wi.animationend.animation, delete Wi.animationiteration.animation, delete Wi.animationstart.animation), "TransitionEvent" in window || delete Wi.transitionend.transition);
function Yo(t) {
  if (Ss[t]) return Ss[t];
  if (!Wi[t]) return t;
  var e = Wi[t], n;
  for (n in e) if (e.hasOwnProperty(n) && n in Mf) return Ss[t] = e[n];
  return t;
}
var Pf = Yo("animationend"), Af = Yo("animationiteration"), jf = Yo("animationstart"), Df = Yo("transitionend"), Lf = /* @__PURE__ */ new Map(), nh = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function li(t, e) {
  Lf.set(t, e), Oi(e, [t]);
}
for (var Cs = 0; Cs < nh.length; Cs++) {
  var ks = nh[Cs], G1 = ks.toLowerCase(), H1 = ks[0].toUpperCase() + ks.slice(1);
  li(G1, "on" + H1);
}
li(Pf, "onAnimationEnd");
li(Af, "onAnimationIteration");
li(jf, "onAnimationStart");
li("dblclick", "onDoubleClick");
li("focusin", "onFocus");
li("focusout", "onBlur");
li(Df, "onTransitionEnd");
ir("onMouseEnter", ["mouseout", "mouseover"]);
ir("onMouseLeave", ["mouseout", "mouseover"]);
ir("onPointerEnter", ["pointerout", "pointerover"]);
ir("onPointerLeave", ["pointerout", "pointerover"]);
Oi("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Oi("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Oi("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Oi("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Oi("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Oi("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Lr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), X1 = new Set("cancel close invalid load scroll toggle".split(" ").concat(Lr));
function ih(t, e, n) {
  var o = t.type || "unknown-event";
  t.currentTarget = n, Gm(o, e, void 0, t), t.currentTarget = null;
}
function Rf(t, e) {
  e = (e & 4) !== 0;
  for (var n = 0; n < t.length; n++) {
    var o = t[n], u = o.event;
    o = o.listeners;
    t: {
      var g = void 0;
      if (e) for (var v = o.length - 1; 0 <= v; v--) {
        var x = o[v], S = x.instance, E = x.currentTarget;
        if (x = x.listener, S !== g && u.isPropagationStopped()) break t;
        ih(u, x, E), g = S;
      }
      else for (v = 0; v < o.length; v++) {
        if (x = o[v], S = x.instance, E = x.currentTarget, x = x.listener, S !== g && u.isPropagationStopped()) break t;
        ih(u, x, E), g = S;
      }
    }
  }
  if (uo) throw t = dl, uo = !1, dl = null, t;
}
function Xt(t, e) {
  var n = e[wl];
  n === void 0 && (n = e[wl] = /* @__PURE__ */ new Set());
  var o = t + "__bubble";
  n.has(o) || (If(e, t, 2, !1), n.add(o));
}
function Es(t, e, n) {
  var o = 0;
  e && (o |= 4), If(n, t, o, e);
}
var Da = "_reactListening" + Math.random().toString(36).slice(2);
function $r(t) {
  if (!t[Da]) {
    t[Da] = !0, Wd.forEach(function(n) {
      n !== "selectionchange" && (X1.has(n) || Es(n, !1, t), Es(n, !0, t));
    });
    var e = t.nodeType === 9 ? t : t.ownerDocument;
    e === null || e[Da] || (e[Da] = !0, Es("selectionchange", !1, e));
  }
}
function If(t, e, n, o) {
  switch (bf(e)) {
    case 1:
      var u = s1;
      break;
    case 4:
      u = l1;
      break;
    default:
      u = uc;
  }
  n = u.bind(null, e, n, t), u = void 0, !hl || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (u = !0), o ? u !== void 0 ? t.addEventListener(e, n, { capture: !0, passive: u }) : t.addEventListener(e, n, !0) : u !== void 0 ? t.addEventListener(e, n, { passive: u }) : t.addEventListener(e, n, !1);
}
function Ts(t, e, n, o, u) {
  var g = o;
  if (!(e & 1) && !(e & 2) && o !== null) t: for (; ; ) {
    if (o === null) return;
    var v = o.tag;
    if (v === 3 || v === 4) {
      var x = o.stateNode.containerInfo;
      if (x === u || x.nodeType === 8 && x.parentNode === u) break;
      if (v === 4) for (v = o.return; v !== null; ) {
        var S = v.tag;
        if ((S === 3 || S === 4) && (S = v.stateNode.containerInfo, S === u || S.nodeType === 8 && S.parentNode === u)) return;
        v = v.return;
      }
      for (; x !== null; ) {
        if (v = yi(x), v === null) return;
        if (S = v.tag, S === 5 || S === 6) {
          o = g = v;
          continue t;
        }
        x = x.parentNode;
      }
    }
    o = o.return;
  }
  af(function() {
    var E = g, A = oc(n), Y = [];
    t: {
      var V = Lf.get(t);
      if (V !== void 0) {
        var Q = dc, tt = t;
        switch (t) {
          case "keypress":
            if (Ja(n) === 0) break t;
          case "keydown":
          case "keyup":
            Q = S1;
            break;
          case "focusin":
            tt = "focus", Q = xs;
            break;
          case "focusout":
            tt = "blur", Q = xs;
            break;
          case "beforeblur":
          case "afterblur":
            Q = xs;
            break;
          case "click":
            if (n.button === 2) break t;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            Q = Gu;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            Q = h1;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            Q = E1;
            break;
          case Pf:
          case Af:
          case jf:
            Q = p1;
            break;
          case Df:
            Q = O1;
            break;
          case "scroll":
            Q = c1;
            break;
          case "wheel":
            Q = P1;
            break;
          case "copy":
          case "cut":
          case "paste":
            Q = m1;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            Q = Xu;
        }
        var rt = (e & 4) !== 0, ut = !rt && t === "scroll", H = rt ? V !== null ? V + "Capture" : null : V;
        rt = [];
        for (var R = E, N; R !== null; ) {
          N = R;
          var $ = N.stateNode;
          if (N.tag === 5 && $ !== null && (N = $, H !== null && ($ = Xr(R, H), $ != null && rt.push(ta(R, $, N)))), ut) break;
          R = R.return;
        }
        0 < rt.length && (V = new Q(V, tt, null, n, A), Y.push({ event: V, listeners: rt }));
      }
    }
    if (!(e & 7)) {
      t: {
        if (V = t === "mouseover" || t === "pointerover", Q = t === "mouseout" || t === "pointerout", V && n !== cl && (tt = n.relatedTarget || n.fromElement) && (yi(tt) || tt[Nn])) break t;
        if ((Q || V) && (V = A.window === A ? A : (V = A.ownerDocument) ? V.defaultView || V.parentWindow : window, Q ? (tt = n.relatedTarget || n.toElement, Q = E, tt = tt ? yi(tt) : null, tt !== null && (ut = Mi(tt), tt !== ut || tt.tag !== 5 && tt.tag !== 6) && (tt = null)) : (Q = null, tt = E), Q !== tt)) {
          if (rt = Gu, $ = "onMouseLeave", H = "onMouseEnter", R = "mouse", (t === "pointerout" || t === "pointerover") && (rt = Xu, $ = "onPointerLeave", H = "onPointerEnter", R = "pointer"), ut = Q == null ? V : Yi(Q), N = tt == null ? V : Yi(tt), V = new rt($, R + "leave", Q, n, A), V.target = ut, V.relatedTarget = N, $ = null, yi(A) === E && (rt = new rt(H, R + "enter", tt, n, A), rt.target = N, rt.relatedTarget = ut, $ = rt), ut = $, Q && tt) e: {
            for (rt = Q, H = tt, R = 0, N = rt; N; N = Ii(N)) R++;
            for (N = 0, $ = H; $; $ = Ii($)) N++;
            for (; 0 < R - N; ) rt = Ii(rt), R--;
            for (; 0 < N - R; ) H = Ii(H), N--;
            for (; R--; ) {
              if (rt === H || H !== null && rt === H.alternate) break e;
              rt = Ii(rt), H = Ii(H);
            }
            rt = null;
          }
          else rt = null;
          Q !== null && rh(Y, V, Q, rt, !1), tt !== null && ut !== null && rh(Y, ut, tt, rt, !0);
        }
      }
      t: {
        if (V = E ? Yi(E) : window, Q = V.nodeName && V.nodeName.toLowerCase(), Q === "select" || Q === "input" && V.type === "file") var at = F1;
        else if (Ku(V)) if (kf) at = U1;
        else {
          at = z1;
          var it = B1;
        }
        else (Q = V.nodeName) && Q.toLowerCase() === "input" && (V.type === "checkbox" || V.type === "radio") && (at = N1);
        if (at && (at = at(t, E))) {
          Cf(Y, at, n, A);
          break t;
        }
        it && it(t, V, E), t === "focusout" && (it = V._wrapperState) && it.controlled && V.type === "number" && rl(V, "number", V.value);
      }
      switch (it = E ? Yi(E) : window, t) {
        case "focusin":
          (Ku(it) || it.contentEditable === "true") && (Ui = it, ml = E, zr = null);
          break;
        case "focusout":
          zr = ml = Ui = null;
          break;
        case "mousedown":
          vl = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          vl = !1, eh(Y, n, A);
          break;
        case "selectionchange":
          if (V1) break;
        case "keydown":
        case "keyup":
          eh(Y, n, A);
      }
      var gt;
      if (pc) t: {
        switch (t) {
          case "compositionstart":
            var b = "onCompositionStart";
            break t;
          case "compositionend":
            b = "onCompositionEnd";
            break t;
          case "compositionupdate":
            b = "onCompositionUpdate";
            break t;
        }
        b = void 0;
      }
      else Ni ? wf(t, n) && (b = "onCompositionEnd") : t === "keydown" && n.keyCode === 229 && (b = "onCompositionStart");
      b && (_f && n.locale !== "ko" && (Ni || b !== "onCompositionStart" ? b === "onCompositionEnd" && Ni && (gt = xf()) : (Kn = A, hc = "value" in Kn ? Kn.value : Kn.textContent, Ni = !0)), it = mo(E, b), 0 < it.length && (b = new Hu(b, t, null, n, A), Y.push({ event: b, listeners: it }), gt ? b.data = gt : (gt = Sf(n), gt !== null && (b.data = gt)))), (gt = j1 ? D1(t, n) : L1(t, n)) && (E = mo(E, "onBeforeInput"), 0 < E.length && (A = new Hu("onBeforeInput", "beforeinput", null, n, A), Y.push({ event: A, listeners: E }), A.data = gt));
    }
    Rf(Y, e);
  });
}
function ta(t, e, n) {
  return { instance: t, listener: e, currentTarget: n };
}
function mo(t, e) {
  for (var n = e + "Capture", o = []; t !== null; ) {
    var u = t, g = u.stateNode;
    u.tag === 5 && g !== null && (u = g, g = Xr(t, n), g != null && o.unshift(ta(t, g, u)), g = Xr(t, e), g != null && o.push(ta(t, g, u))), t = t.return;
  }
  return o;
}
function Ii(t) {
  if (t === null) return null;
  do
    t = t.return;
  while (t && t.tag !== 5);
  return t || null;
}
function rh(t, e, n, o, u) {
  for (var g = e._reactName, v = []; n !== null && n !== o; ) {
    var x = n, S = x.alternate, E = x.stateNode;
    if (S !== null && S === o) break;
    x.tag === 5 && E !== null && (x = E, u ? (S = Xr(n, g), S != null && v.unshift(ta(n, S, x))) : u || (S = Xr(n, g), S != null && v.push(ta(n, S, x)))), n = n.return;
  }
  v.length !== 0 && t.push({ event: e, listeners: v });
}
var q1 = /\r\n?/g, Z1 = /\u0000|\uFFFD/g;
function ah(t) {
  return (typeof t == "string" ? t : "" + t).replace(q1, `
`).replace(Z1, "");
}
function La(t, e, n) {
  if (e = ah(e), ah(t) !== e && n) throw Error(vt(425));
}
function vo() {
}
var yl = null, bl = null;
function xl(t, e) {
  return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null;
}
var _l = typeof setTimeout == "function" ? setTimeout : void 0, K1 = typeof clearTimeout == "function" ? clearTimeout : void 0, oh = typeof Promise == "function" ? Promise : void 0, Q1 = typeof queueMicrotask == "function" ? queueMicrotask : typeof oh < "u" ? function(t) {
  return oh.resolve(null).then(t).catch(J1);
} : _l;
function J1(t) {
  setTimeout(function() {
    throw t;
  });
}
function Os(t, e) {
  var n = e, o = 0;
  do {
    var u = n.nextSibling;
    if (t.removeChild(n), u && u.nodeType === 8) if (n = u.data, n === "/$") {
      if (o === 0) {
        t.removeChild(u), Kr(e);
        return;
      }
      o--;
    } else n !== "$" && n !== "$?" && n !== "$!" || o++;
    n = u;
  } while (n);
  Kr(e);
}
function ei(t) {
  for (; t != null; t = t.nextSibling) {
    var e = t.nodeType;
    if (e === 1 || e === 3) break;
    if (e === 8) {
      if (e = t.data, e === "$" || e === "$!" || e === "$?") break;
      if (e === "/$") return null;
    }
  }
  return t;
}
function sh(t) {
  t = t.previousSibling;
  for (var e = 0; t; ) {
    if (t.nodeType === 8) {
      var n = t.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (e === 0) return t;
        e--;
      } else n === "/$" && e++;
    }
    t = t.previousSibling;
  }
  return null;
}
var pr = Math.random().toString(36).slice(2), Cn = "__reactFiber$" + pr, ea = "__reactProps$" + pr, Nn = "__reactContainer$" + pr, wl = "__reactEvents$" + pr, $1 = "__reactListeners$" + pr, tv = "__reactHandles$" + pr;
function yi(t) {
  var e = t[Cn];
  if (e) return e;
  for (var n = t.parentNode; n; ) {
    if (e = n[Nn] || n[Cn]) {
      if (n = e.alternate, e.child !== null || n !== null && n.child !== null) for (t = sh(t); t !== null; ) {
        if (n = t[Cn]) return n;
        t = sh(t);
      }
      return e;
    }
    t = n, n = t.parentNode;
  }
  return null;
}
function da(t) {
  return t = t[Cn] || t[Nn], !t || t.tag !== 5 && t.tag !== 6 && t.tag !== 13 && t.tag !== 3 ? null : t;
}
function Yi(t) {
  if (t.tag === 5 || t.tag === 6) return t.stateNode;
  throw Error(vt(33));
}
function Vo(t) {
  return t[ea] || null;
}
var Sl = [], Vi = -1;
function ci(t) {
  return { current: t };
}
function qt(t) {
  0 > Vi || (t.current = Sl[Vi], Sl[Vi] = null, Vi--);
}
function Ht(t, e) {
  Vi++, Sl[Vi] = t.current, t.current = e;
}
var si = {}, _e = ci(si), Le = ci(!1), Si = si;
function rr(t, e) {
  var n = t.type.contextTypes;
  if (!n) return si;
  var o = t.stateNode;
  if (o && o.__reactInternalMemoizedUnmaskedChildContext === e) return o.__reactInternalMemoizedMaskedChildContext;
  var u = {}, g;
  for (g in n) u[g] = e[g];
  return o && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = e, t.__reactInternalMemoizedMaskedChildContext = u), u;
}
function Re(t) {
  return t = t.childContextTypes, t != null;
}
function yo() {
  qt(Le), qt(_e);
}
function lh(t, e, n) {
  if (_e.current !== si) throw Error(vt(168));
  Ht(_e, e), Ht(Le, n);
}
function Ff(t, e, n) {
  var o = t.stateNode;
  if (e = e.childContextTypes, typeof o.getChildContext != "function") return n;
  o = o.getChildContext();
  for (var u in o) if (!(u in e)) throw Error(vt(108, Bm(t) || "Unknown", u));
  return ee({}, n, o);
}
function bo(t) {
  return t = (t = t.stateNode) && t.__reactInternalMemoizedMergedChildContext || si, Si = _e.current, Ht(_e, t), Ht(Le, Le.current), !0;
}
function ch(t, e, n) {
  var o = t.stateNode;
  if (!o) throw Error(vt(169));
  n ? (t = Ff(t, e, Si), o.__reactInternalMemoizedMergedChildContext = t, qt(Le), qt(_e), Ht(_e, t)) : qt(Le), Ht(Le, n);
}
var Ln = null, Go = !1, Ms = !1;
function Bf(t) {
  Ln === null ? Ln = [t] : Ln.push(t);
}
function ev(t) {
  Go = !0, Bf(t);
}
function ui() {
  if (!Ms && Ln !== null) {
    Ms = !0;
    var t = 0, e = Yt;
    try {
      var n = Ln;
      for (Yt = 1; t < n.length; t++) {
        var o = n[t];
        do
          o = o(!0);
        while (o !== null);
      }
      Ln = null, Go = !1;
    } catch (u) {
      throw Ln !== null && (Ln = Ln.slice(t + 1)), cf(sc, ui), u;
    } finally {
      Yt = e, Ms = !1;
    }
  }
  return null;
}
var Gi = [], Hi = 0, xo = null, _o = 0, Ze = [], Ke = 0, Ci = null, Rn = 1, In = "";
function pi(t, e) {
  Gi[Hi++] = _o, Gi[Hi++] = xo, xo = t, _o = e;
}
function zf(t, e, n) {
  Ze[Ke++] = Rn, Ze[Ke++] = In, Ze[Ke++] = Ci, Ci = t;
  var o = Rn;
  t = In;
  var u = 32 - gn(o) - 1;
  o &= ~(1 << u), n += 1;
  var g = 32 - gn(e) + u;
  if (30 < g) {
    var v = u - u % 5;
    g = (o & (1 << v) - 1).toString(32), o >>= v, u -= v, Rn = 1 << 32 - gn(e) + u | n << u | o, In = g + t;
  } else Rn = 1 << g | n << u | o, In = t;
}
function mc(t) {
  t.return !== null && (pi(t, 1), zf(t, 1, 0));
}
function vc(t) {
  for (; t === xo; ) xo = Gi[--Hi], Gi[Hi] = null, _o = Gi[--Hi], Gi[Hi] = null;
  for (; t === Ci; ) Ci = Ze[--Ke], Ze[Ke] = null, In = Ze[--Ke], Ze[Ke] = null, Rn = Ze[--Ke], Ze[Ke] = null;
}
var We = null, Ue = null, Kt = !1, dn = null;
function Nf(t, e) {
  var n = Je(5, null, null, 0);
  n.elementType = "DELETED", n.stateNode = e, n.return = t, e = t.deletions, e === null ? (t.deletions = [n], t.flags |= 16) : e.push(n);
}
function uh(t, e) {
  switch (t.tag) {
    case 5:
      var n = t.type;
      return e = e.nodeType !== 1 || n.toLowerCase() !== e.nodeName.toLowerCase() ? null : e, e !== null ? (t.stateNode = e, We = t, Ue = ei(e.firstChild), !0) : !1;
    case 6:
      return e = t.pendingProps === "" || e.nodeType !== 3 ? null : e, e !== null ? (t.stateNode = e, We = t, Ue = null, !0) : !1;
    case 13:
      return e = e.nodeType !== 8 ? null : e, e !== null ? (n = Ci !== null ? { id: Rn, overflow: In } : null, t.memoizedState = { dehydrated: e, treeContext: n, retryLane: 1073741824 }, n = Je(18, null, null, 0), n.stateNode = e, n.return = t, t.child = n, We = t, Ue = null, !0) : !1;
    default:
      return !1;
  }
}
function Cl(t) {
  return (t.mode & 1) !== 0 && (t.flags & 128) === 0;
}
function kl(t) {
  if (Kt) {
    var e = Ue;
    if (e) {
      var n = e;
      if (!uh(t, e)) {
        if (Cl(t)) throw Error(vt(418));
        e = ei(n.nextSibling);
        var o = We;
        e && uh(t, e) ? Nf(o, n) : (t.flags = t.flags & -4097 | 2, Kt = !1, We = t);
      }
    } else {
      if (Cl(t)) throw Error(vt(418));
      t.flags = t.flags & -4097 | 2, Kt = !1, We = t;
    }
  }
}
function hh(t) {
  for (t = t.return; t !== null && t.tag !== 5 && t.tag !== 3 && t.tag !== 13; ) t = t.return;
  We = t;
}
function Ra(t) {
  if (t !== We) return !1;
  if (!Kt) return hh(t), Kt = !0, !1;
  var e;
  if ((e = t.tag !== 3) && !(e = t.tag !== 5) && (e = t.type, e = e !== "head" && e !== "body" && !xl(t.type, t.memoizedProps)), e && (e = Ue)) {
    if (Cl(t)) throw Uf(), Error(vt(418));
    for (; e; ) Nf(t, e), e = ei(e.nextSibling);
  }
  if (hh(t), t.tag === 13) {
    if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(vt(317));
    t: {
      for (t = t.nextSibling, e = 0; t; ) {
        if (t.nodeType === 8) {
          var n = t.data;
          if (n === "/$") {
            if (e === 0) {
              Ue = ei(t.nextSibling);
              break t;
            }
            e--;
          } else n !== "$" && n !== "$!" && n !== "$?" || e++;
        }
        t = t.nextSibling;
      }
      Ue = null;
    }
  } else Ue = We ? ei(t.stateNode.nextSibling) : null;
  return !0;
}
function Uf() {
  for (var t = Ue; t; ) t = ei(t.nextSibling);
}
function ar() {
  Ue = We = null, Kt = !1;
}
function yc(t) {
  dn === null ? dn = [t] : dn.push(t);
}
var nv = Yn.ReactCurrentBatchConfig;
function Or(t, e, n) {
  if (t = n.ref, t !== null && typeof t != "function" && typeof t != "object") {
    if (n._owner) {
      if (n = n._owner, n) {
        if (n.tag !== 1) throw Error(vt(309));
        var o = n.stateNode;
      }
      if (!o) throw Error(vt(147, t));
      var u = o, g = "" + t;
      return e !== null && e.ref !== null && typeof e.ref == "function" && e.ref._stringRef === g ? e.ref : (e = function(v) {
        var x = u.refs;
        v === null ? delete x[g] : x[g] = v;
      }, e._stringRef = g, e);
    }
    if (typeof t != "string") throw Error(vt(284));
    if (!n._owner) throw Error(vt(290, t));
  }
  return t;
}
function Ia(t, e) {
  throw t = Object.prototype.toString.call(e), Error(vt(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t));
}
function dh(t) {
  var e = t._init;
  return e(t._payload);
}
function Wf(t) {
  function e(H, R) {
    if (t) {
      var N = H.deletions;
      N === null ? (H.deletions = [R], H.flags |= 16) : N.push(R);
    }
  }
  function n(H, R) {
    if (!t) return null;
    for (; R !== null; ) e(H, R), R = R.sibling;
    return null;
  }
  function o(H, R) {
    for (H = /* @__PURE__ */ new Map(); R !== null; ) R.key !== null ? H.set(R.key, R) : H.set(R.index, R), R = R.sibling;
    return H;
  }
  function u(H, R) {
    return H = ai(H, R), H.index = 0, H.sibling = null, H;
  }
  function g(H, R, N) {
    return H.index = N, t ? (N = H.alternate, N !== null ? (N = N.index, N < R ? (H.flags |= 2, R) : N) : (H.flags |= 2, R)) : (H.flags |= 1048576, R);
  }
  function v(H) {
    return t && H.alternate === null && (H.flags |= 2), H;
  }
  function x(H, R, N, $) {
    return R === null || R.tag !== 6 ? (R = Is(N, H.mode, $), R.return = H, R) : (R = u(R, N), R.return = H, R);
  }
  function S(H, R, N, $) {
    var at = N.type;
    return at === zi ? A(H, R, N.props.children, $, N.key) : R !== null && (R.elementType === at || typeof at == "object" && at !== null && at.$$typeof === Gn && dh(at) === R.type) ? ($ = u(R, N.props), $.ref = Or(H, R, N), $.return = H, $) : ($ = ao(N.type, N.key, N.props, null, H.mode, $), $.ref = Or(H, R, N), $.return = H, $);
  }
  function E(H, R, N, $) {
    return R === null || R.tag !== 4 || R.stateNode.containerInfo !== N.containerInfo || R.stateNode.implementation !== N.implementation ? (R = Fs(N, H.mode, $), R.return = H, R) : (R = u(R, N.children || []), R.return = H, R);
  }
  function A(H, R, N, $, at) {
    return R === null || R.tag !== 7 ? (R = wi(N, H.mode, $, at), R.return = H, R) : (R = u(R, N), R.return = H, R);
  }
  function Y(H, R, N) {
    if (typeof R == "string" && R !== "" || typeof R == "number") return R = Is("" + R, H.mode, N), R.return = H, R;
    if (typeof R == "object" && R !== null) {
      switch (R.$$typeof) {
        case ka:
          return N = ao(R.type, R.key, R.props, null, H.mode, N), N.ref = Or(H, null, R), N.return = H, N;
        case Bi:
          return R = Fs(R, H.mode, N), R.return = H, R;
        case Gn:
          var $ = R._init;
          return Y(H, $(R._payload), N);
      }
      if (jr(R) || Sr(R)) return R = wi(R, H.mode, N, null), R.return = H, R;
      Ia(H, R);
    }
    return null;
  }
  function V(H, R, N, $) {
    var at = R !== null ? R.key : null;
    if (typeof N == "string" && N !== "" || typeof N == "number") return at !== null ? null : x(H, R, "" + N, $);
    if (typeof N == "object" && N !== null) {
      switch (N.$$typeof) {
        case ka:
          return N.key === at ? S(H, R, N, $) : null;
        case Bi:
          return N.key === at ? E(H, R, N, $) : null;
        case Gn:
          return at = N._init, V(
            H,
            R,
            at(N._payload),
            $
          );
      }
      if (jr(N) || Sr(N)) return at !== null ? null : A(H, R, N, $, null);
      Ia(H, N);
    }
    return null;
  }
  function Q(H, R, N, $, at) {
    if (typeof $ == "string" && $ !== "" || typeof $ == "number") return H = H.get(N) || null, x(R, H, "" + $, at);
    if (typeof $ == "object" && $ !== null) {
      switch ($.$$typeof) {
        case ka:
          return H = H.get($.key === null ? N : $.key) || null, S(R, H, $, at);
        case Bi:
          return H = H.get($.key === null ? N : $.key) || null, E(R, H, $, at);
        case Gn:
          var it = $._init;
          return Q(H, R, N, it($._payload), at);
      }
      if (jr($) || Sr($)) return H = H.get(N) || null, A(R, H, $, at, null);
      Ia(R, $);
    }
    return null;
  }
  function tt(H, R, N, $) {
    for (var at = null, it = null, gt = R, b = R = 0, Pt = null; gt !== null && b < N.length; b++) {
      gt.index > b ? (Pt = gt, gt = null) : Pt = gt.sibling;
      var P = V(H, gt, N[b], $);
      if (P === null) {
        gt === null && (gt = Pt);
        break;
      }
      t && gt && P.alternate === null && e(H, gt), R = g(P, R, b), it === null ? at = P : it.sibling = P, it = P, gt = Pt;
    }
    if (b === N.length) return n(H, gt), Kt && pi(H, b), at;
    if (gt === null) {
      for (; b < N.length; b++) gt = Y(H, N[b], $), gt !== null && (R = g(gt, R, b), it === null ? at = gt : it.sibling = gt, it = gt);
      return Kt && pi(H, b), at;
    }
    for (gt = o(H, gt); b < N.length; b++) Pt = Q(gt, H, b, N[b], $), Pt !== null && (t && Pt.alternate !== null && gt.delete(Pt.key === null ? b : Pt.key), R = g(Pt, R, b), it === null ? at = Pt : it.sibling = Pt, it = Pt);
    return t && gt.forEach(function(nt) {
      return e(H, nt);
    }), Kt && pi(H, b), at;
  }
  function rt(H, R, N, $) {
    var at = Sr(N);
    if (typeof at != "function") throw Error(vt(150));
    if (N = at.call(N), N == null) throw Error(vt(151));
    for (var it = at = null, gt = R, b = R = 0, Pt = null, P = N.next(); gt !== null && !P.done; b++, P = N.next()) {
      gt.index > b ? (Pt = gt, gt = null) : Pt = gt.sibling;
      var nt = V(H, gt, P.value, $);
      if (nt === null) {
        gt === null && (gt = Pt);
        break;
      }
      t && gt && nt.alternate === null && e(H, gt), R = g(nt, R, b), it === null ? at = nt : it.sibling = nt, it = nt, gt = Pt;
    }
    if (P.done) return n(
      H,
      gt
    ), Kt && pi(H, b), at;
    if (gt === null) {
      for (; !P.done; b++, P = N.next()) P = Y(H, P.value, $), P !== null && (R = g(P, R, b), it === null ? at = P : it.sibling = P, it = P);
      return Kt && pi(H, b), at;
    }
    for (gt = o(H, gt); !P.done; b++, P = N.next()) P = Q(gt, H, b, P.value, $), P !== null && (t && P.alternate !== null && gt.delete(P.key === null ? b : P.key), R = g(P, R, b), it === null ? at = P : it.sibling = P, it = P);
    return t && gt.forEach(function(bt) {
      return e(H, bt);
    }), Kt && pi(H, b), at;
  }
  function ut(H, R, N, $) {
    if (typeof N == "object" && N !== null && N.type === zi && N.key === null && (N = N.props.children), typeof N == "object" && N !== null) {
      switch (N.$$typeof) {
        case ka:
          t: {
            for (var at = N.key, it = R; it !== null; ) {
              if (it.key === at) {
                if (at = N.type, at === zi) {
                  if (it.tag === 7) {
                    n(H, it.sibling), R = u(it, N.props.children), R.return = H, H = R;
                    break t;
                  }
                } else if (it.elementType === at || typeof at == "object" && at !== null && at.$$typeof === Gn && dh(at) === it.type) {
                  n(H, it.sibling), R = u(it, N.props), R.ref = Or(H, it, N), R.return = H, H = R;
                  break t;
                }
                n(H, it);
                break;
              } else e(H, it);
              it = it.sibling;
            }
            N.type === zi ? (R = wi(N.props.children, H.mode, $, N.key), R.return = H, H = R) : ($ = ao(N.type, N.key, N.props, null, H.mode, $), $.ref = Or(H, R, N), $.return = H, H = $);
          }
          return v(H);
        case Bi:
          t: {
            for (it = N.key; R !== null; ) {
              if (R.key === it) if (R.tag === 4 && R.stateNode.containerInfo === N.containerInfo && R.stateNode.implementation === N.implementation) {
                n(H, R.sibling), R = u(R, N.children || []), R.return = H, H = R;
                break t;
              } else {
                n(H, R);
                break;
              }
              else e(H, R);
              R = R.sibling;
            }
            R = Fs(N, H.mode, $), R.return = H, H = R;
          }
          return v(H);
        case Gn:
          return it = N._init, ut(H, R, it(N._payload), $);
      }
      if (jr(N)) return tt(H, R, N, $);
      if (Sr(N)) return rt(H, R, N, $);
      Ia(H, N);
    }
    return typeof N == "string" && N !== "" || typeof N == "number" ? (N = "" + N, R !== null && R.tag === 6 ? (n(H, R.sibling), R = u(R, N), R.return = H, H = R) : (n(H, R), R = Is(N, H.mode, $), R.return = H, H = R), v(H)) : n(H, R);
  }
  return ut;
}
var or = Wf(!0), Yf = Wf(!1), wo = ci(null), So = null, Xi = null, bc = null;
function xc() {
  bc = Xi = So = null;
}
function _c(t) {
  var e = wo.current;
  qt(wo), t._currentValue = e;
}
function El(t, e, n) {
  for (; t !== null; ) {
    var o = t.alternate;
    if ((t.childLanes & e) !== e ? (t.childLanes |= e, o !== null && (o.childLanes |= e)) : o !== null && (o.childLanes & e) !== e && (o.childLanes |= e), t === n) break;
    t = t.return;
  }
}
function er(t, e) {
  So = t, bc = Xi = null, t = t.dependencies, t !== null && t.firstContext !== null && (t.lanes & e && (De = !0), t.firstContext = null);
}
function nn(t) {
  var e = t._currentValue;
  if (bc !== t) if (t = { context: t, memoizedValue: e, next: null }, Xi === null) {
    if (So === null) throw Error(vt(308));
    Xi = t, So.dependencies = { lanes: 0, firstContext: t };
  } else Xi = Xi.next = t;
  return e;
}
var bi = null;
function wc(t) {
  bi === null ? bi = [t] : bi.push(t);
}
function Vf(t, e, n, o) {
  var u = e.interleaved;
  return u === null ? (n.next = n, wc(e)) : (n.next = u.next, u.next = n), e.interleaved = n, Un(t, o);
}
function Un(t, e) {
  t.lanes |= e;
  var n = t.alternate;
  for (n !== null && (n.lanes |= e), n = t, t = t.return; t !== null; ) t.childLanes |= e, n = t.alternate, n !== null && (n.childLanes |= e), n = t, t = t.return;
  return n.tag === 3 ? n.stateNode : null;
}
var Hn = !1;
function Sc(t) {
  t.updateQueue = { baseState: t.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function Gf(t, e) {
  t = t.updateQueue, e.updateQueue === t && (e.updateQueue = { baseState: t.baseState, firstBaseUpdate: t.firstBaseUpdate, lastBaseUpdate: t.lastBaseUpdate, shared: t.shared, effects: t.effects });
}
function Bn(t, e) {
  return { eventTime: t, lane: e, tag: 0, payload: null, callback: null, next: null };
}
function ni(t, e, n) {
  var o = t.updateQueue;
  if (o === null) return null;
  if (o = o.shared, zt & 2) {
    var u = o.pending;
    return u === null ? e.next = e : (e.next = u.next, u.next = e), o.pending = e, Un(t, n);
  }
  return u = o.interleaved, u === null ? (e.next = e, wc(o)) : (e.next = u.next, u.next = e), o.interleaved = e, Un(t, n);
}
function $a(t, e, n) {
  if (e = e.updateQueue, e !== null && (e = e.shared, (n & 4194240) !== 0)) {
    var o = e.lanes;
    o &= t.pendingLanes, n |= o, e.lanes = n, lc(t, n);
  }
}
function fh(t, e) {
  var n = t.updateQueue, o = t.alternate;
  if (o !== null && (o = o.updateQueue, n === o)) {
    var u = null, g = null;
    if (n = n.firstBaseUpdate, n !== null) {
      do {
        var v = { eventTime: n.eventTime, lane: n.lane, tag: n.tag, payload: n.payload, callback: n.callback, next: null };
        g === null ? u = g = v : g = g.next = v, n = n.next;
      } while (n !== null);
      g === null ? u = g = e : g = g.next = e;
    } else u = g = e;
    n = { baseState: o.baseState, firstBaseUpdate: u, lastBaseUpdate: g, shared: o.shared, effects: o.effects }, t.updateQueue = n;
    return;
  }
  t = n.lastBaseUpdate, t === null ? n.firstBaseUpdate = e : t.next = e, n.lastBaseUpdate = e;
}
function Co(t, e, n, o) {
  var u = t.updateQueue;
  Hn = !1;
  var g = u.firstBaseUpdate, v = u.lastBaseUpdate, x = u.shared.pending;
  if (x !== null) {
    u.shared.pending = null;
    var S = x, E = S.next;
    S.next = null, v === null ? g = E : v.next = E, v = S;
    var A = t.alternate;
    A !== null && (A = A.updateQueue, x = A.lastBaseUpdate, x !== v && (x === null ? A.firstBaseUpdate = E : x.next = E, A.lastBaseUpdate = S));
  }
  if (g !== null) {
    var Y = u.baseState;
    v = 0, A = E = S = null, x = g;
    do {
      var V = x.lane, Q = x.eventTime;
      if ((o & V) === V) {
        A !== null && (A = A.next = {
          eventTime: Q,
          lane: 0,
          tag: x.tag,
          payload: x.payload,
          callback: x.callback,
          next: null
        });
        t: {
          var tt = t, rt = x;
          switch (V = e, Q = n, rt.tag) {
            case 1:
              if (tt = rt.payload, typeof tt == "function") {
                Y = tt.call(Q, Y, V);
                break t;
              }
              Y = tt;
              break t;
            case 3:
              tt.flags = tt.flags & -65537 | 128;
            case 0:
              if (tt = rt.payload, V = typeof tt == "function" ? tt.call(Q, Y, V) : tt, V == null) break t;
              Y = ee({}, Y, V);
              break t;
            case 2:
              Hn = !0;
          }
        }
        x.callback !== null && x.lane !== 0 && (t.flags |= 64, V = u.effects, V === null ? u.effects = [x] : V.push(x));
      } else Q = { eventTime: Q, lane: V, tag: x.tag, payload: x.payload, callback: x.callback, next: null }, A === null ? (E = A = Q, S = Y) : A = A.next = Q, v |= V;
      if (x = x.next, x === null) {
        if (x = u.shared.pending, x === null) break;
        V = x, x = V.next, V.next = null, u.lastBaseUpdate = V, u.shared.pending = null;
      }
    } while (!0);
    if (A === null && (S = Y), u.baseState = S, u.firstBaseUpdate = E, u.lastBaseUpdate = A, e = u.shared.interleaved, e !== null) {
      u = e;
      do
        v |= u.lane, u = u.next;
      while (u !== e);
    } else g === null && (u.shared.lanes = 0);
    Ei |= v, t.lanes = v, t.memoizedState = Y;
  }
}
function ph(t, e, n) {
  if (t = e.effects, e.effects = null, t !== null) for (e = 0; e < t.length; e++) {
    var o = t[e], u = o.callback;
    if (u !== null) {
      if (o.callback = null, o = n, typeof u != "function") throw Error(vt(191, u));
      u.call(o);
    }
  }
}
var fa = {}, Pn = ci(fa), na = ci(fa), ia = ci(fa);
function xi(t) {
  if (t === fa) throw Error(vt(174));
  return t;
}
function Cc(t, e) {
  switch (Ht(ia, e), Ht(na, t), Ht(Pn, fa), t = e.nodeType, t) {
    case 9:
    case 11:
      e = (e = e.documentElement) ? e.namespaceURI : ol(null, "");
      break;
    default:
      t = t === 8 ? e.parentNode : e, e = t.namespaceURI || null, t = t.tagName, e = ol(e, t);
  }
  qt(Pn), Ht(Pn, e);
}
function sr() {
  qt(Pn), qt(na), qt(ia);
}
function Hf(t) {
  xi(ia.current);
  var e = xi(Pn.current), n = ol(e, t.type);
  e !== n && (Ht(na, t), Ht(Pn, n));
}
function kc(t) {
  na.current === t && (qt(Pn), qt(na));
}
var Jt = ci(0);
function ko(t) {
  for (var e = t; e !== null; ) {
    if (e.tag === 13) {
      var n = e.memoizedState;
      if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return e;
    } else if (e.tag === 19 && e.memoizedProps.revealOrder !== void 0) {
      if (e.flags & 128) return e;
    } else if (e.child !== null) {
      e.child.return = e, e = e.child;
      continue;
    }
    if (e === t) break;
    for (; e.sibling === null; ) {
      if (e.return === null || e.return === t) return null;
      e = e.return;
    }
    e.sibling.return = e.return, e = e.sibling;
  }
  return null;
}
var Ps = [];
function Ec() {
  for (var t = 0; t < Ps.length; t++) Ps[t]._workInProgressVersionPrimary = null;
  Ps.length = 0;
}
var to = Yn.ReactCurrentDispatcher, As = Yn.ReactCurrentBatchConfig, ki = 0, te = null, le = null, he = null, Eo = !1, Nr = !1, ra = 0, iv = 0;
function ye() {
  throw Error(vt(321));
}
function Tc(t, e) {
  if (e === null) return !1;
  for (var n = 0; n < e.length && n < t.length; n++) if (!vn(t[n], e[n])) return !1;
  return !0;
}
function Oc(t, e, n, o, u, g) {
  if (ki = g, te = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, to.current = t === null || t.memoizedState === null ? sv : lv, t = n(o, u), Nr) {
    g = 0;
    do {
      if (Nr = !1, ra = 0, 25 <= g) throw Error(vt(301));
      g += 1, he = le = null, e.updateQueue = null, to.current = cv, t = n(o, u);
    } while (Nr);
  }
  if (to.current = To, e = le !== null && le.next !== null, ki = 0, he = le = te = null, Eo = !1, e) throw Error(vt(300));
  return t;
}
function Mc() {
  var t = ra !== 0;
  return ra = 0, t;
}
function Sn() {
  var t = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  return he === null ? te.memoizedState = he = t : he = he.next = t, he;
}
function rn() {
  if (le === null) {
    var t = te.alternate;
    t = t !== null ? t.memoizedState : null;
  } else t = le.next;
  var e = he === null ? te.memoizedState : he.next;
  if (e !== null) he = e, le = t;
  else {
    if (t === null) throw Error(vt(310));
    le = t, t = { memoizedState: le.memoizedState, baseState: le.baseState, baseQueue: le.baseQueue, queue: le.queue, next: null }, he === null ? te.memoizedState = he = t : he = he.next = t;
  }
  return he;
}
function aa(t, e) {
  return typeof e == "function" ? e(t) : e;
}
function js(t) {
  var e = rn(), n = e.queue;
  if (n === null) throw Error(vt(311));
  n.lastRenderedReducer = t;
  var o = le, u = o.baseQueue, g = n.pending;
  if (g !== null) {
    if (u !== null) {
      var v = u.next;
      u.next = g.next, g.next = v;
    }
    o.baseQueue = u = g, n.pending = null;
  }
  if (u !== null) {
    g = u.next, o = o.baseState;
    var x = v = null, S = null, E = g;
    do {
      var A = E.lane;
      if ((ki & A) === A) S !== null && (S = S.next = { lane: 0, action: E.action, hasEagerState: E.hasEagerState, eagerState: E.eagerState, next: null }), o = E.hasEagerState ? E.eagerState : t(o, E.action);
      else {
        var Y = {
          lane: A,
          action: E.action,
          hasEagerState: E.hasEagerState,
          eagerState: E.eagerState,
          next: null
        };
        S === null ? (x = S = Y, v = o) : S = S.next = Y, te.lanes |= A, Ei |= A;
      }
      E = E.next;
    } while (E !== null && E !== g);
    S === null ? v = o : S.next = x, vn(o, e.memoizedState) || (De = !0), e.memoizedState = o, e.baseState = v, e.baseQueue = S, n.lastRenderedState = o;
  }
  if (t = n.interleaved, t !== null) {
    u = t;
    do
      g = u.lane, te.lanes |= g, Ei |= g, u = u.next;
    while (u !== t);
  } else u === null && (n.lanes = 0);
  return [e.memoizedState, n.dispatch];
}
function Ds(t) {
  var e = rn(), n = e.queue;
  if (n === null) throw Error(vt(311));
  n.lastRenderedReducer = t;
  var o = n.dispatch, u = n.pending, g = e.memoizedState;
  if (u !== null) {
    n.pending = null;
    var v = u = u.next;
    do
      g = t(g, v.action), v = v.next;
    while (v !== u);
    vn(g, e.memoizedState) || (De = !0), e.memoizedState = g, e.baseQueue === null && (e.baseState = g), n.lastRenderedState = g;
  }
  return [g, o];
}
function Xf() {
}
function qf(t, e) {
  var n = te, o = rn(), u = e(), g = !vn(o.memoizedState, u);
  if (g && (o.memoizedState = u, De = !0), o = o.queue, Pc(Qf.bind(null, n, o, t), [t]), o.getSnapshot !== e || g || he !== null && he.memoizedState.tag & 1) {
    if (n.flags |= 2048, oa(9, Kf.bind(null, n, o, u, e), void 0, null), de === null) throw Error(vt(349));
    ki & 30 || Zf(n, e, u);
  }
  return u;
}
function Zf(t, e, n) {
  t.flags |= 16384, t = { getSnapshot: e, value: n }, e = te.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, te.updateQueue = e, e.stores = [t]) : (n = e.stores, n === null ? e.stores = [t] : n.push(t));
}
function Kf(t, e, n, o) {
  e.value = n, e.getSnapshot = o, Jf(e) && $f(t);
}
function Qf(t, e, n) {
  return n(function() {
    Jf(e) && $f(t);
  });
}
function Jf(t) {
  var e = t.getSnapshot;
  t = t.value;
  try {
    var n = e();
    return !vn(t, n);
  } catch {
    return !0;
  }
}
function $f(t) {
  var e = Un(t, 1);
  e !== null && mn(e, t, 1, -1);
}
function gh(t) {
  var e = Sn();
  return typeof t == "function" && (t = t()), e.memoizedState = e.baseState = t, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: aa, lastRenderedState: t }, e.queue = t, t = t.dispatch = ov.bind(null, te, t), [e.memoizedState, t];
}
function oa(t, e, n, o) {
  return t = { tag: t, create: e, destroy: n, deps: o, next: null }, e = te.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, te.updateQueue = e, e.lastEffect = t.next = t) : (n = e.lastEffect, n === null ? e.lastEffect = t.next = t : (o = n.next, n.next = t, t.next = o, e.lastEffect = t)), t;
}
function tp() {
  return rn().memoizedState;
}
function eo(t, e, n, o) {
  var u = Sn();
  te.flags |= t, u.memoizedState = oa(1 | e, n, void 0, o === void 0 ? null : o);
}
function Ho(t, e, n, o) {
  var u = rn();
  o = o === void 0 ? null : o;
  var g = void 0;
  if (le !== null) {
    var v = le.memoizedState;
    if (g = v.destroy, o !== null && Tc(o, v.deps)) {
      u.memoizedState = oa(e, n, g, o);
      return;
    }
  }
  te.flags |= t, u.memoizedState = oa(1 | e, n, g, o);
}
function mh(t, e) {
  return eo(8390656, 8, t, e);
}
function Pc(t, e) {
  return Ho(2048, 8, t, e);
}
function ep(t, e) {
  return Ho(4, 2, t, e);
}
function np(t, e) {
  return Ho(4, 4, t, e);
}
function ip(t, e) {
  if (typeof e == "function") return t = t(), e(t), function() {
    e(null);
  };
  if (e != null) return t = t(), e.current = t, function() {
    e.current = null;
  };
}
function rp(t, e, n) {
  return n = n != null ? n.concat([t]) : null, Ho(4, 4, ip.bind(null, e, t), n);
}
function Ac() {
}
function ap(t, e) {
  var n = rn();
  e = e === void 0 ? null : e;
  var o = n.memoizedState;
  return o !== null && e !== null && Tc(e, o[1]) ? o[0] : (n.memoizedState = [t, e], t);
}
function op(t, e) {
  var n = rn();
  e = e === void 0 ? null : e;
  var o = n.memoizedState;
  return o !== null && e !== null && Tc(e, o[1]) ? o[0] : (t = t(), n.memoizedState = [t, e], t);
}
function sp(t, e, n) {
  return ki & 21 ? (vn(n, e) || (n = df(), te.lanes |= n, Ei |= n, t.baseState = !0), e) : (t.baseState && (t.baseState = !1, De = !0), t.memoizedState = n);
}
function rv(t, e) {
  var n = Yt;
  Yt = n !== 0 && 4 > n ? n : 4, t(!0);
  var o = As.transition;
  As.transition = {};
  try {
    t(!1), e();
  } finally {
    Yt = n, As.transition = o;
  }
}
function lp() {
  return rn().memoizedState;
}
function av(t, e, n) {
  var o = ri(t);
  if (n = { lane: o, action: n, hasEagerState: !1, eagerState: null, next: null }, cp(t)) up(e, n);
  else if (n = Vf(t, e, n, o), n !== null) {
    var u = ke();
    mn(n, t, o, u), hp(n, e, o);
  }
}
function ov(t, e, n) {
  var o = ri(t), u = { lane: o, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (cp(t)) up(e, u);
  else {
    var g = t.alternate;
    if (t.lanes === 0 && (g === null || g.lanes === 0) && (g = e.lastRenderedReducer, g !== null)) try {
      var v = e.lastRenderedState, x = g(v, n);
      if (u.hasEagerState = !0, u.eagerState = x, vn(x, v)) {
        var S = e.interleaved;
        S === null ? (u.next = u, wc(e)) : (u.next = S.next, S.next = u), e.interleaved = u;
        return;
      }
    } catch {
    } finally {
    }
    n = Vf(t, e, u, o), n !== null && (u = ke(), mn(n, t, o, u), hp(n, e, o));
  }
}
function cp(t) {
  var e = t.alternate;
  return t === te || e !== null && e === te;
}
function up(t, e) {
  Nr = Eo = !0;
  var n = t.pending;
  n === null ? e.next = e : (e.next = n.next, n.next = e), t.pending = e;
}
function hp(t, e, n) {
  if (n & 4194240) {
    var o = e.lanes;
    o &= t.pendingLanes, n |= o, e.lanes = n, lc(t, n);
  }
}
var To = { readContext: nn, useCallback: ye, useContext: ye, useEffect: ye, useImperativeHandle: ye, useInsertionEffect: ye, useLayoutEffect: ye, useMemo: ye, useReducer: ye, useRef: ye, useState: ye, useDebugValue: ye, useDeferredValue: ye, useTransition: ye, useMutableSource: ye, useSyncExternalStore: ye, useId: ye, unstable_isNewReconciler: !1 }, sv = { readContext: nn, useCallback: function(t, e) {
  return Sn().memoizedState = [t, e === void 0 ? null : e], t;
}, useContext: nn, useEffect: mh, useImperativeHandle: function(t, e, n) {
  return n = n != null ? n.concat([t]) : null, eo(
    4194308,
    4,
    ip.bind(null, e, t),
    n
  );
}, useLayoutEffect: function(t, e) {
  return eo(4194308, 4, t, e);
}, useInsertionEffect: function(t, e) {
  return eo(4, 2, t, e);
}, useMemo: function(t, e) {
  var n = Sn();
  return e = e === void 0 ? null : e, t = t(), n.memoizedState = [t, e], t;
}, useReducer: function(t, e, n) {
  var o = Sn();
  return e = n !== void 0 ? n(e) : e, o.memoizedState = o.baseState = e, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: t, lastRenderedState: e }, o.queue = t, t = t.dispatch = av.bind(null, te, t), [o.memoizedState, t];
}, useRef: function(t) {
  var e = Sn();
  return t = { current: t }, e.memoizedState = t;
}, useState: gh, useDebugValue: Ac, useDeferredValue: function(t) {
  return Sn().memoizedState = t;
}, useTransition: function() {
  var t = gh(!1), e = t[0];
  return t = rv.bind(null, t[1]), Sn().memoizedState = t, [e, t];
}, useMutableSource: function() {
}, useSyncExternalStore: function(t, e, n) {
  var o = te, u = Sn();
  if (Kt) {
    if (n === void 0) throw Error(vt(407));
    n = n();
  } else {
    if (n = e(), de === null) throw Error(vt(349));
    ki & 30 || Zf(o, e, n);
  }
  u.memoizedState = n;
  var g = { value: n, getSnapshot: e };
  return u.queue = g, mh(Qf.bind(
    null,
    o,
    g,
    t
  ), [t]), o.flags |= 2048, oa(9, Kf.bind(null, o, g, n, e), void 0, null), n;
}, useId: function() {
  var t = Sn(), e = de.identifierPrefix;
  if (Kt) {
    var n = In, o = Rn;
    n = (o & ~(1 << 32 - gn(o) - 1)).toString(32) + n, e = ":" + e + "R" + n, n = ra++, 0 < n && (e += "H" + n.toString(32)), e += ":";
  } else n = iv++, e = ":" + e + "r" + n.toString(32) + ":";
  return t.memoizedState = e;
}, unstable_isNewReconciler: !1 }, lv = {
  readContext: nn,
  useCallback: ap,
  useContext: nn,
  useEffect: Pc,
  useImperativeHandle: rp,
  useInsertionEffect: ep,
  useLayoutEffect: np,
  useMemo: op,
  useReducer: js,
  useRef: tp,
  useState: function() {
    return js(aa);
  },
  useDebugValue: Ac,
  useDeferredValue: function(t) {
    var e = rn();
    return sp(e, le.memoizedState, t);
  },
  useTransition: function() {
    var t = js(aa)[0], e = rn().memoizedState;
    return [t, e];
  },
  useMutableSource: Xf,
  useSyncExternalStore: qf,
  useId: lp,
  unstable_isNewReconciler: !1
}, cv = { readContext: nn, useCallback: ap, useContext: nn, useEffect: Pc, useImperativeHandle: rp, useInsertionEffect: ep, useLayoutEffect: np, useMemo: op, useReducer: Ds, useRef: tp, useState: function() {
  return Ds(aa);
}, useDebugValue: Ac, useDeferredValue: function(t) {
  var e = rn();
  return le === null ? e.memoizedState = t : sp(e, le.memoizedState, t);
}, useTransition: function() {
  var t = Ds(aa)[0], e = rn().memoizedState;
  return [t, e];
}, useMutableSource: Xf, useSyncExternalStore: qf, useId: lp, unstable_isNewReconciler: !1 };
function un(t, e) {
  if (t && t.defaultProps) {
    e = ee({}, e), t = t.defaultProps;
    for (var n in t) e[n] === void 0 && (e[n] = t[n]);
    return e;
  }
  return e;
}
function Tl(t, e, n, o) {
  e = t.memoizedState, n = n(o, e), n = n == null ? e : ee({}, e, n), t.memoizedState = n, t.lanes === 0 && (t.updateQueue.baseState = n);
}
var Xo = { isMounted: function(t) {
  return (t = t._reactInternals) ? Mi(t) === t : !1;
}, enqueueSetState: function(t, e, n) {
  t = t._reactInternals;
  var o = ke(), u = ri(t), g = Bn(o, u);
  g.payload = e, n != null && (g.callback = n), e = ni(t, g, u), e !== null && (mn(e, t, u, o), $a(e, t, u));
}, enqueueReplaceState: function(t, e, n) {
  t = t._reactInternals;
  var o = ke(), u = ri(t), g = Bn(o, u);
  g.tag = 1, g.payload = e, n != null && (g.callback = n), e = ni(t, g, u), e !== null && (mn(e, t, u, o), $a(e, t, u));
}, enqueueForceUpdate: function(t, e) {
  t = t._reactInternals;
  var n = ke(), o = ri(t), u = Bn(n, o);
  u.tag = 2, e != null && (u.callback = e), e = ni(t, u, o), e !== null && (mn(e, t, o, n), $a(e, t, o));
} };
function vh(t, e, n, o, u, g, v) {
  return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(o, g, v) : e.prototype && e.prototype.isPureReactComponent ? !Jr(n, o) || !Jr(u, g) : !0;
}
function dp(t, e, n) {
  var o = !1, u = si, g = e.contextType;
  return typeof g == "object" && g !== null ? g = nn(g) : (u = Re(e) ? Si : _e.current, o = e.contextTypes, g = (o = o != null) ? rr(t, u) : si), e = new e(n, g), t.memoizedState = e.state !== null && e.state !== void 0 ? e.state : null, e.updater = Xo, t.stateNode = e, e._reactInternals = t, o && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = u, t.__reactInternalMemoizedMaskedChildContext = g), e;
}
function yh(t, e, n, o) {
  t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(n, o), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(n, o), e.state !== t && Xo.enqueueReplaceState(e, e.state, null);
}
function Ol(t, e, n, o) {
  var u = t.stateNode;
  u.props = n, u.state = t.memoizedState, u.refs = {}, Sc(t);
  var g = e.contextType;
  typeof g == "object" && g !== null ? u.context = nn(g) : (g = Re(e) ? Si : _e.current, u.context = rr(t, g)), u.state = t.memoizedState, g = e.getDerivedStateFromProps, typeof g == "function" && (Tl(t, e, g, n), u.state = t.memoizedState), typeof e.getDerivedStateFromProps == "function" || typeof u.getSnapshotBeforeUpdate == "function" || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (e = u.state, typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount(), e !== u.state && Xo.enqueueReplaceState(u, u.state, null), Co(t, n, u, o), u.state = t.memoizedState), typeof u.componentDidMount == "function" && (t.flags |= 4194308);
}
function lr(t, e) {
  try {
    var n = "", o = e;
    do
      n += Fm(o), o = o.return;
    while (o);
    var u = n;
  } catch (g) {
    u = `
Error generating stack: ` + g.message + `
` + g.stack;
  }
  return { value: t, source: e, stack: u, digest: null };
}
function Ls(t, e, n) {
  return { value: t, source: null, stack: n ?? null, digest: e ?? null };
}
function Ml(t, e) {
  try {
    console.error(e.value);
  } catch (n) {
    setTimeout(function() {
      throw n;
    });
  }
}
var uv = typeof WeakMap == "function" ? WeakMap : Map;
function fp(t, e, n) {
  n = Bn(-1, n), n.tag = 3, n.payload = { element: null };
  var o = e.value;
  return n.callback = function() {
    Mo || (Mo = !0, Bl = o), Ml(t, e);
  }, n;
}
function pp(t, e, n) {
  n = Bn(-1, n), n.tag = 3;
  var o = t.type.getDerivedStateFromError;
  if (typeof o == "function") {
    var u = e.value;
    n.payload = function() {
      return o(u);
    }, n.callback = function() {
      Ml(t, e);
    };
  }
  var g = t.stateNode;
  return g !== null && typeof g.componentDidCatch == "function" && (n.callback = function() {
    Ml(t, e), typeof o != "function" && (ii === null ? ii = /* @__PURE__ */ new Set([this]) : ii.add(this));
    var v = e.stack;
    this.componentDidCatch(e.value, { componentStack: v !== null ? v : "" });
  }), n;
}
function bh(t, e, n) {
  var o = t.pingCache;
  if (o === null) {
    o = t.pingCache = new uv();
    var u = /* @__PURE__ */ new Set();
    o.set(e, u);
  } else u = o.get(e), u === void 0 && (u = /* @__PURE__ */ new Set(), o.set(e, u));
  u.has(n) || (u.add(n), t = Cv.bind(null, t, e, n), e.then(t, t));
}
function xh(t) {
  do {
    var e;
    if ((e = t.tag === 13) && (e = t.memoizedState, e = e !== null ? e.dehydrated !== null : !0), e) return t;
    t = t.return;
  } while (t !== null);
  return null;
}
function _h(t, e, n, o, u) {
  return t.mode & 1 ? (t.flags |= 65536, t.lanes = u, t) : (t === e ? t.flags |= 65536 : (t.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (e = Bn(-1, 1), e.tag = 2, ni(n, e, 1))), n.lanes |= 1), t);
}
var hv = Yn.ReactCurrentOwner, De = !1;
function Ce(t, e, n, o) {
  e.child = t === null ? Yf(e, null, n, o) : or(e, t.child, n, o);
}
function wh(t, e, n, o, u) {
  n = n.render;
  var g = e.ref;
  return er(e, u), o = Oc(t, e, n, o, g, u), n = Mc(), t !== null && !De ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~u, Wn(t, e, u)) : (Kt && n && mc(e), e.flags |= 1, Ce(t, e, o, u), e.child);
}
function Sh(t, e, n, o, u) {
  if (t === null) {
    var g = n.type;
    return typeof g == "function" && !zc(g) && g.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (e.tag = 15, e.type = g, gp(t, e, g, o, u)) : (t = ao(n.type, null, o, e, e.mode, u), t.ref = e.ref, t.return = e, e.child = t);
  }
  if (g = t.child, !(t.lanes & u)) {
    var v = g.memoizedProps;
    if (n = n.compare, n = n !== null ? n : Jr, n(v, o) && t.ref === e.ref) return Wn(t, e, u);
  }
  return e.flags |= 1, t = ai(g, o), t.ref = e.ref, t.return = e, e.child = t;
}
function gp(t, e, n, o, u) {
  if (t !== null) {
    var g = t.memoizedProps;
    if (Jr(g, o) && t.ref === e.ref) if (De = !1, e.pendingProps = o = g, (t.lanes & u) !== 0) t.flags & 131072 && (De = !0);
    else return e.lanes = t.lanes, Wn(t, e, u);
  }
  return Pl(t, e, n, o, u);
}
function mp(t, e, n) {
  var o = e.pendingProps, u = o.children, g = t !== null ? t.memoizedState : null;
  if (o.mode === "hidden") if (!(e.mode & 1)) e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, Ht(Zi, Ne), Ne |= n;
  else {
    if (!(n & 1073741824)) return t = g !== null ? g.baseLanes | n : n, e.lanes = e.childLanes = 1073741824, e.memoizedState = { baseLanes: t, cachePool: null, transitions: null }, e.updateQueue = null, Ht(Zi, Ne), Ne |= t, null;
    e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, o = g !== null ? g.baseLanes : n, Ht(Zi, Ne), Ne |= o;
  }
  else g !== null ? (o = g.baseLanes | n, e.memoizedState = null) : o = n, Ht(Zi, Ne), Ne |= o;
  return Ce(t, e, u, n), e.child;
}
function vp(t, e) {
  var n = e.ref;
  (t === null && n !== null || t !== null && t.ref !== n) && (e.flags |= 512, e.flags |= 2097152);
}
function Pl(t, e, n, o, u) {
  var g = Re(n) ? Si : _e.current;
  return g = rr(e, g), er(e, u), n = Oc(t, e, n, o, g, u), o = Mc(), t !== null && !De ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~u, Wn(t, e, u)) : (Kt && o && mc(e), e.flags |= 1, Ce(t, e, n, u), e.child);
}
function Ch(t, e, n, o, u) {
  if (Re(n)) {
    var g = !0;
    bo(e);
  } else g = !1;
  if (er(e, u), e.stateNode === null) no(t, e), dp(e, n, o), Ol(e, n, o, u), o = !0;
  else if (t === null) {
    var v = e.stateNode, x = e.memoizedProps;
    v.props = x;
    var S = v.context, E = n.contextType;
    typeof E == "object" && E !== null ? E = nn(E) : (E = Re(n) ? Si : _e.current, E = rr(e, E));
    var A = n.getDerivedStateFromProps, Y = typeof A == "function" || typeof v.getSnapshotBeforeUpdate == "function";
    Y || typeof v.UNSAFE_componentWillReceiveProps != "function" && typeof v.componentWillReceiveProps != "function" || (x !== o || S !== E) && yh(e, v, o, E), Hn = !1;
    var V = e.memoizedState;
    v.state = V, Co(e, o, v, u), S = e.memoizedState, x !== o || V !== S || Le.current || Hn ? (typeof A == "function" && (Tl(e, n, A, o), S = e.memoizedState), (x = Hn || vh(e, n, x, o, V, S, E)) ? (Y || typeof v.UNSAFE_componentWillMount != "function" && typeof v.componentWillMount != "function" || (typeof v.componentWillMount == "function" && v.componentWillMount(), typeof v.UNSAFE_componentWillMount == "function" && v.UNSAFE_componentWillMount()), typeof v.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof v.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = o, e.memoizedState = S), v.props = o, v.state = S, v.context = E, o = x) : (typeof v.componentDidMount == "function" && (e.flags |= 4194308), o = !1);
  } else {
    v = e.stateNode, Gf(t, e), x = e.memoizedProps, E = e.type === e.elementType ? x : un(e.type, x), v.props = E, Y = e.pendingProps, V = v.context, S = n.contextType, typeof S == "object" && S !== null ? S = nn(S) : (S = Re(n) ? Si : _e.current, S = rr(e, S));
    var Q = n.getDerivedStateFromProps;
    (A = typeof Q == "function" || typeof v.getSnapshotBeforeUpdate == "function") || typeof v.UNSAFE_componentWillReceiveProps != "function" && typeof v.componentWillReceiveProps != "function" || (x !== Y || V !== S) && yh(e, v, o, S), Hn = !1, V = e.memoizedState, v.state = V, Co(e, o, v, u);
    var tt = e.memoizedState;
    x !== Y || V !== tt || Le.current || Hn ? (typeof Q == "function" && (Tl(e, n, Q, o), tt = e.memoizedState), (E = Hn || vh(e, n, E, o, V, tt, S) || !1) ? (A || typeof v.UNSAFE_componentWillUpdate != "function" && typeof v.componentWillUpdate != "function" || (typeof v.componentWillUpdate == "function" && v.componentWillUpdate(o, tt, S), typeof v.UNSAFE_componentWillUpdate == "function" && v.UNSAFE_componentWillUpdate(o, tt, S)), typeof v.componentDidUpdate == "function" && (e.flags |= 4), typeof v.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof v.componentDidUpdate != "function" || x === t.memoizedProps && V === t.memoizedState || (e.flags |= 4), typeof v.getSnapshotBeforeUpdate != "function" || x === t.memoizedProps && V === t.memoizedState || (e.flags |= 1024), e.memoizedProps = o, e.memoizedState = tt), v.props = o, v.state = tt, v.context = S, o = E) : (typeof v.componentDidUpdate != "function" || x === t.memoizedProps && V === t.memoizedState || (e.flags |= 4), typeof v.getSnapshotBeforeUpdate != "function" || x === t.memoizedProps && V === t.memoizedState || (e.flags |= 1024), o = !1);
  }
  return Al(t, e, n, o, g, u);
}
function Al(t, e, n, o, u, g) {
  vp(t, e);
  var v = (e.flags & 128) !== 0;
  if (!o && !v) return u && ch(e, n, !1), Wn(t, e, g);
  o = e.stateNode, hv.current = e;
  var x = v && typeof n.getDerivedStateFromError != "function" ? null : o.render();
  return e.flags |= 1, t !== null && v ? (e.child = or(e, t.child, null, g), e.child = or(e, null, x, g)) : Ce(t, e, x, g), e.memoizedState = o.state, u && ch(e, n, !0), e.child;
}
function yp(t) {
  var e = t.stateNode;
  e.pendingContext ? lh(t, e.pendingContext, e.pendingContext !== e.context) : e.context && lh(t, e.context, !1), Cc(t, e.containerInfo);
}
function kh(t, e, n, o, u) {
  return ar(), yc(u), e.flags |= 256, Ce(t, e, n, o), e.child;
}
var jl = { dehydrated: null, treeContext: null, retryLane: 0 };
function Dl(t) {
  return { baseLanes: t, cachePool: null, transitions: null };
}
function bp(t, e, n) {
  var o = e.pendingProps, u = Jt.current, g = !1, v = (e.flags & 128) !== 0, x;
  if ((x = v) || (x = t !== null && t.memoizedState === null ? !1 : (u & 2) !== 0), x ? (g = !0, e.flags &= -129) : (t === null || t.memoizedState !== null) && (u |= 1), Ht(Jt, u & 1), t === null)
    return kl(e), t = e.memoizedState, t !== null && (t = t.dehydrated, t !== null) ? (e.mode & 1 ? t.data === "$!" ? e.lanes = 8 : e.lanes = 1073741824 : e.lanes = 1, null) : (v = o.children, t = o.fallback, g ? (o = e.mode, g = e.child, v = { mode: "hidden", children: v }, !(o & 1) && g !== null ? (g.childLanes = 0, g.pendingProps = v) : g = Ko(v, o, 0, null), t = wi(t, o, n, null), g.return = e, t.return = e, g.sibling = t, e.child = g, e.child.memoizedState = Dl(n), e.memoizedState = jl, t) : jc(e, v));
  if (u = t.memoizedState, u !== null && (x = u.dehydrated, x !== null)) return dv(t, e, v, o, x, u, n);
  if (g) {
    g = o.fallback, v = e.mode, u = t.child, x = u.sibling;
    var S = { mode: "hidden", children: o.children };
    return !(v & 1) && e.child !== u ? (o = e.child, o.childLanes = 0, o.pendingProps = S, e.deletions = null) : (o = ai(u, S), o.subtreeFlags = u.subtreeFlags & 14680064), x !== null ? g = ai(x, g) : (g = wi(g, v, n, null), g.flags |= 2), g.return = e, o.return = e, o.sibling = g, e.child = o, o = g, g = e.child, v = t.child.memoizedState, v = v === null ? Dl(n) : { baseLanes: v.baseLanes | n, cachePool: null, transitions: v.transitions }, g.memoizedState = v, g.childLanes = t.childLanes & ~n, e.memoizedState = jl, o;
  }
  return g = t.child, t = g.sibling, o = ai(g, { mode: "visible", children: o.children }), !(e.mode & 1) && (o.lanes = n), o.return = e, o.sibling = null, t !== null && (n = e.deletions, n === null ? (e.deletions = [t], e.flags |= 16) : n.push(t)), e.child = o, e.memoizedState = null, o;
}
function jc(t, e) {
  return e = Ko({ mode: "visible", children: e }, t.mode, 0, null), e.return = t, t.child = e;
}
function Fa(t, e, n, o) {
  return o !== null && yc(o), or(e, t.child, null, n), t = jc(e, e.pendingProps.children), t.flags |= 2, e.memoizedState = null, t;
}
function dv(t, e, n, o, u, g, v) {
  if (n)
    return e.flags & 256 ? (e.flags &= -257, o = Ls(Error(vt(422))), Fa(t, e, v, o)) : e.memoizedState !== null ? (e.child = t.child, e.flags |= 128, null) : (g = o.fallback, u = e.mode, o = Ko({ mode: "visible", children: o.children }, u, 0, null), g = wi(g, u, v, null), g.flags |= 2, o.return = e, g.return = e, o.sibling = g, e.child = o, e.mode & 1 && or(e, t.child, null, v), e.child.memoizedState = Dl(v), e.memoizedState = jl, g);
  if (!(e.mode & 1)) return Fa(t, e, v, null);
  if (u.data === "$!") {
    if (o = u.nextSibling && u.nextSibling.dataset, o) var x = o.dgst;
    return o = x, g = Error(vt(419)), o = Ls(g, o, void 0), Fa(t, e, v, o);
  }
  if (x = (v & t.childLanes) !== 0, De || x) {
    if (o = de, o !== null) {
      switch (v & -v) {
        case 4:
          u = 2;
          break;
        case 16:
          u = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          u = 32;
          break;
        case 536870912:
          u = 268435456;
          break;
        default:
          u = 0;
      }
      u = u & (o.suspendedLanes | v) ? 0 : u, u !== 0 && u !== g.retryLane && (g.retryLane = u, Un(t, u), mn(o, t, u, -1));
    }
    return Bc(), o = Ls(Error(vt(421))), Fa(t, e, v, o);
  }
  return u.data === "$?" ? (e.flags |= 128, e.child = t.child, e = kv.bind(null, t), u._reactRetry = e, null) : (t = g.treeContext, Ue = ei(u.nextSibling), We = e, Kt = !0, dn = null, t !== null && (Ze[Ke++] = Rn, Ze[Ke++] = In, Ze[Ke++] = Ci, Rn = t.id, In = t.overflow, Ci = e), e = jc(e, o.children), e.flags |= 4096, e);
}
function Eh(t, e, n) {
  t.lanes |= e;
  var o = t.alternate;
  o !== null && (o.lanes |= e), El(t.return, e, n);
}
function Rs(t, e, n, o, u) {
  var g = t.memoizedState;
  g === null ? t.memoizedState = { isBackwards: e, rendering: null, renderingStartTime: 0, last: o, tail: n, tailMode: u } : (g.isBackwards = e, g.rendering = null, g.renderingStartTime = 0, g.last = o, g.tail = n, g.tailMode = u);
}
function xp(t, e, n) {
  var o = e.pendingProps, u = o.revealOrder, g = o.tail;
  if (Ce(t, e, o.children, n), o = Jt.current, o & 2) o = o & 1 | 2, e.flags |= 128;
  else {
    if (t !== null && t.flags & 128) t: for (t = e.child; t !== null; ) {
      if (t.tag === 13) t.memoizedState !== null && Eh(t, n, e);
      else if (t.tag === 19) Eh(t, n, e);
      else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e) break t;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) break t;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    o &= 1;
  }
  if (Ht(Jt, o), !(e.mode & 1)) e.memoizedState = null;
  else switch (u) {
    case "forwards":
      for (n = e.child, u = null; n !== null; ) t = n.alternate, t !== null && ko(t) === null && (u = n), n = n.sibling;
      n = u, n === null ? (u = e.child, e.child = null) : (u = n.sibling, n.sibling = null), Rs(e, !1, u, n, g);
      break;
    case "backwards":
      for (n = null, u = e.child, e.child = null; u !== null; ) {
        if (t = u.alternate, t !== null && ko(t) === null) {
          e.child = u;
          break;
        }
        t = u.sibling, u.sibling = n, n = u, u = t;
      }
      Rs(e, !0, n, null, g);
      break;
    case "together":
      Rs(e, !1, null, null, void 0);
      break;
    default:
      e.memoizedState = null;
  }
  return e.child;
}
function no(t, e) {
  !(e.mode & 1) && t !== null && (t.alternate = null, e.alternate = null, e.flags |= 2);
}
function Wn(t, e, n) {
  if (t !== null && (e.dependencies = t.dependencies), Ei |= e.lanes, !(n & e.childLanes)) return null;
  if (t !== null && e.child !== t.child) throw Error(vt(153));
  if (e.child !== null) {
    for (t = e.child, n = ai(t, t.pendingProps), e.child = n, n.return = e; t.sibling !== null; ) t = t.sibling, n = n.sibling = ai(t, t.pendingProps), n.return = e;
    n.sibling = null;
  }
  return e.child;
}
function fv(t, e, n) {
  switch (e.tag) {
    case 3:
      yp(e), ar();
      break;
    case 5:
      Hf(e);
      break;
    case 1:
      Re(e.type) && bo(e);
      break;
    case 4:
      Cc(e, e.stateNode.containerInfo);
      break;
    case 10:
      var o = e.type._context, u = e.memoizedProps.value;
      Ht(wo, o._currentValue), o._currentValue = u;
      break;
    case 13:
      if (o = e.memoizedState, o !== null)
        return o.dehydrated !== null ? (Ht(Jt, Jt.current & 1), e.flags |= 128, null) : n & e.child.childLanes ? bp(t, e, n) : (Ht(Jt, Jt.current & 1), t = Wn(t, e, n), t !== null ? t.sibling : null);
      Ht(Jt, Jt.current & 1);
      break;
    case 19:
      if (o = (n & e.childLanes) !== 0, t.flags & 128) {
        if (o) return xp(t, e, n);
        e.flags |= 128;
      }
      if (u = e.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), Ht(Jt, Jt.current), o) break;
      return null;
    case 22:
    case 23:
      return e.lanes = 0, mp(t, e, n);
  }
  return Wn(t, e, n);
}
var _p, Ll, wp, Sp;
_p = function(t, e) {
  for (var n = e.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) t.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      n.child.return = n, n = n.child;
      continue;
    }
    if (n === e) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === e) return;
      n = n.return;
    }
    n.sibling.return = n.return, n = n.sibling;
  }
};
Ll = function() {
};
wp = function(t, e, n, o) {
  var u = t.memoizedProps;
  if (u !== o) {
    t = e.stateNode, xi(Pn.current);
    var g = null;
    switch (n) {
      case "input":
        u = nl(t, u), o = nl(t, o), g = [];
        break;
      case "select":
        u = ee({}, u, { value: void 0 }), o = ee({}, o, { value: void 0 }), g = [];
        break;
      case "textarea":
        u = al(t, u), o = al(t, o), g = [];
        break;
      default:
        typeof u.onClick != "function" && typeof o.onClick == "function" && (t.onclick = vo);
    }
    sl(n, o);
    var v;
    n = null;
    for (E in u) if (!o.hasOwnProperty(E) && u.hasOwnProperty(E) && u[E] != null) if (E === "style") {
      var x = u[E];
      for (v in x) x.hasOwnProperty(v) && (n || (n = {}), n[v] = "");
    } else E !== "dangerouslySetInnerHTML" && E !== "children" && E !== "suppressContentEditableWarning" && E !== "suppressHydrationWarning" && E !== "autoFocus" && (Gr.hasOwnProperty(E) ? g || (g = []) : (g = g || []).push(E, null));
    for (E in o) {
      var S = o[E];
      if (x = u != null ? u[E] : void 0, o.hasOwnProperty(E) && S !== x && (S != null || x != null)) if (E === "style") if (x) {
        for (v in x) !x.hasOwnProperty(v) || S && S.hasOwnProperty(v) || (n || (n = {}), n[v] = "");
        for (v in S) S.hasOwnProperty(v) && x[v] !== S[v] && (n || (n = {}), n[v] = S[v]);
      } else n || (g || (g = []), g.push(
        E,
        n
      )), n = S;
      else E === "dangerouslySetInnerHTML" ? (S = S ? S.__html : void 0, x = x ? x.__html : void 0, S != null && x !== S && (g = g || []).push(E, S)) : E === "children" ? typeof S != "string" && typeof S != "number" || (g = g || []).push(E, "" + S) : E !== "suppressContentEditableWarning" && E !== "suppressHydrationWarning" && (Gr.hasOwnProperty(E) ? (S != null && E === "onScroll" && Xt("scroll", t), g || x === S || (g = [])) : (g = g || []).push(E, S));
    }
    n && (g = g || []).push("style", n);
    var E = g;
    (e.updateQueue = E) && (e.flags |= 4);
  }
};
Sp = function(t, e, n, o) {
  n !== o && (e.flags |= 4);
};
function Mr(t, e) {
  if (!Kt) switch (t.tailMode) {
    case "hidden":
      e = t.tail;
      for (var n = null; e !== null; ) e.alternate !== null && (n = e), e = e.sibling;
      n === null ? t.tail = null : n.sibling = null;
      break;
    case "collapsed":
      n = t.tail;
      for (var o = null; n !== null; ) n.alternate !== null && (o = n), n = n.sibling;
      o === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : o.sibling = null;
  }
}
function be(t) {
  var e = t.alternate !== null && t.alternate.child === t.child, n = 0, o = 0;
  if (e) for (var u = t.child; u !== null; ) n |= u.lanes | u.childLanes, o |= u.subtreeFlags & 14680064, o |= u.flags & 14680064, u.return = t, u = u.sibling;
  else for (u = t.child; u !== null; ) n |= u.lanes | u.childLanes, o |= u.subtreeFlags, o |= u.flags, u.return = t, u = u.sibling;
  return t.subtreeFlags |= o, t.childLanes = n, e;
}
function pv(t, e, n) {
  var o = e.pendingProps;
  switch (vc(e), e.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return be(e), null;
    case 1:
      return Re(e.type) && yo(), be(e), null;
    case 3:
      return o = e.stateNode, sr(), qt(Le), qt(_e), Ec(), o.pendingContext && (o.context = o.pendingContext, o.pendingContext = null), (t === null || t.child === null) && (Ra(e) ? e.flags |= 4 : t === null || t.memoizedState.isDehydrated && !(e.flags & 256) || (e.flags |= 1024, dn !== null && (Ul(dn), dn = null))), Ll(t, e), be(e), null;
    case 5:
      kc(e);
      var u = xi(ia.current);
      if (n = e.type, t !== null && e.stateNode != null) wp(t, e, n, o, u), t.ref !== e.ref && (e.flags |= 512, e.flags |= 2097152);
      else {
        if (!o) {
          if (e.stateNode === null) throw Error(vt(166));
          return be(e), null;
        }
        if (t = xi(Pn.current), Ra(e)) {
          o = e.stateNode, n = e.type;
          var g = e.memoizedProps;
          switch (o[Cn] = e, o[ea] = g, t = (e.mode & 1) !== 0, n) {
            case "dialog":
              Xt("cancel", o), Xt("close", o);
              break;
            case "iframe":
            case "object":
            case "embed":
              Xt("load", o);
              break;
            case "video":
            case "audio":
              for (u = 0; u < Lr.length; u++) Xt(Lr[u], o);
              break;
            case "source":
              Xt("error", o);
              break;
            case "img":
            case "image":
            case "link":
              Xt(
                "error",
                o
              ), Xt("load", o);
              break;
            case "details":
              Xt("toggle", o);
              break;
            case "input":
              Ru(o, g), Xt("invalid", o);
              break;
            case "select":
              o._wrapperState = { wasMultiple: !!g.multiple }, Xt("invalid", o);
              break;
            case "textarea":
              Fu(o, g), Xt("invalid", o);
          }
          sl(n, g), u = null;
          for (var v in g) if (g.hasOwnProperty(v)) {
            var x = g[v];
            v === "children" ? typeof x == "string" ? o.textContent !== x && (g.suppressHydrationWarning !== !0 && La(o.textContent, x, t), u = ["children", x]) : typeof x == "number" && o.textContent !== "" + x && (g.suppressHydrationWarning !== !0 && La(
              o.textContent,
              x,
              t
            ), u = ["children", "" + x]) : Gr.hasOwnProperty(v) && x != null && v === "onScroll" && Xt("scroll", o);
          }
          switch (n) {
            case "input":
              Ea(o), Iu(o, g, !0);
              break;
            case "textarea":
              Ea(o), Bu(o);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof g.onClick == "function" && (o.onclick = vo);
          }
          o = u, e.updateQueue = o, o !== null && (e.flags |= 4);
        } else {
          v = u.nodeType === 9 ? u : u.ownerDocument, t === "http://www.w3.org/1999/xhtml" && (t = Kd(n)), t === "http://www.w3.org/1999/xhtml" ? n === "script" ? (t = v.createElement("div"), t.innerHTML = "<script><\/script>", t = t.removeChild(t.firstChild)) : typeof o.is == "string" ? t = v.createElement(n, { is: o.is }) : (t = v.createElement(n), n === "select" && (v = t, o.multiple ? v.multiple = !0 : o.size && (v.size = o.size))) : t = v.createElementNS(t, n), t[Cn] = e, t[ea] = o, _p(t, e, !1, !1), e.stateNode = t;
          t: {
            switch (v = ll(n, o), n) {
              case "dialog":
                Xt("cancel", t), Xt("close", t), u = o;
                break;
              case "iframe":
              case "object":
              case "embed":
                Xt("load", t), u = o;
                break;
              case "video":
              case "audio":
                for (u = 0; u < Lr.length; u++) Xt(Lr[u], t);
                u = o;
                break;
              case "source":
                Xt("error", t), u = o;
                break;
              case "img":
              case "image":
              case "link":
                Xt(
                  "error",
                  t
                ), Xt("load", t), u = o;
                break;
              case "details":
                Xt("toggle", t), u = o;
                break;
              case "input":
                Ru(t, o), u = nl(t, o), Xt("invalid", t);
                break;
              case "option":
                u = o;
                break;
              case "select":
                t._wrapperState = { wasMultiple: !!o.multiple }, u = ee({}, o, { value: void 0 }), Xt("invalid", t);
                break;
              case "textarea":
                Fu(t, o), u = al(t, o), Xt("invalid", t);
                break;
              default:
                u = o;
            }
            sl(n, u), x = u;
            for (g in x) if (x.hasOwnProperty(g)) {
              var S = x[g];
              g === "style" ? $d(t, S) : g === "dangerouslySetInnerHTML" ? (S = S ? S.__html : void 0, S != null && Qd(t, S)) : g === "children" ? typeof S == "string" ? (n !== "textarea" || S !== "") && Hr(t, S) : typeof S == "number" && Hr(t, "" + S) : g !== "suppressContentEditableWarning" && g !== "suppressHydrationWarning" && g !== "autoFocus" && (Gr.hasOwnProperty(g) ? S != null && g === "onScroll" && Xt("scroll", t) : S != null && nc(t, g, S, v));
            }
            switch (n) {
              case "input":
                Ea(t), Iu(t, o, !1);
                break;
              case "textarea":
                Ea(t), Bu(t);
                break;
              case "option":
                o.value != null && t.setAttribute("value", "" + oi(o.value));
                break;
              case "select":
                t.multiple = !!o.multiple, g = o.value, g != null ? Qi(t, !!o.multiple, g, !1) : o.defaultValue != null && Qi(
                  t,
                  !!o.multiple,
                  o.defaultValue,
                  !0
                );
                break;
              default:
                typeof u.onClick == "function" && (t.onclick = vo);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                o = !!o.autoFocus;
                break t;
              case "img":
                o = !0;
                break t;
              default:
                o = !1;
            }
          }
          o && (e.flags |= 4);
        }
        e.ref !== null && (e.flags |= 512, e.flags |= 2097152);
      }
      return be(e), null;
    case 6:
      if (t && e.stateNode != null) Sp(t, e, t.memoizedProps, o);
      else {
        if (typeof o != "string" && e.stateNode === null) throw Error(vt(166));
        if (n = xi(ia.current), xi(Pn.current), Ra(e)) {
          if (o = e.stateNode, n = e.memoizedProps, o[Cn] = e, (g = o.nodeValue !== n) && (t = We, t !== null)) switch (t.tag) {
            case 3:
              La(o.nodeValue, n, (t.mode & 1) !== 0);
              break;
            case 5:
              t.memoizedProps.suppressHydrationWarning !== !0 && La(o.nodeValue, n, (t.mode & 1) !== 0);
          }
          g && (e.flags |= 4);
        } else o = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(o), o[Cn] = e, e.stateNode = o;
      }
      return be(e), null;
    case 13:
      if (qt(Jt), o = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
        if (Kt && Ue !== null && e.mode & 1 && !(e.flags & 128)) Uf(), ar(), e.flags |= 98560, g = !1;
        else if (g = Ra(e), o !== null && o.dehydrated !== null) {
          if (t === null) {
            if (!g) throw Error(vt(318));
            if (g = e.memoizedState, g = g !== null ? g.dehydrated : null, !g) throw Error(vt(317));
            g[Cn] = e;
          } else ar(), !(e.flags & 128) && (e.memoizedState = null), e.flags |= 4;
          be(e), g = !1;
        } else dn !== null && (Ul(dn), dn = null), g = !0;
        if (!g) return e.flags & 65536 ? e : null;
      }
      return e.flags & 128 ? (e.lanes = n, e) : (o = o !== null, o !== (t !== null && t.memoizedState !== null) && o && (e.child.flags |= 8192, e.mode & 1 && (t === null || Jt.current & 1 ? ce === 0 && (ce = 3) : Bc())), e.updateQueue !== null && (e.flags |= 4), be(e), null);
    case 4:
      return sr(), Ll(t, e), t === null && $r(e.stateNode.containerInfo), be(e), null;
    case 10:
      return _c(e.type._context), be(e), null;
    case 17:
      return Re(e.type) && yo(), be(e), null;
    case 19:
      if (qt(Jt), g = e.memoizedState, g === null) return be(e), null;
      if (o = (e.flags & 128) !== 0, v = g.rendering, v === null) if (o) Mr(g, !1);
      else {
        if (ce !== 0 || t !== null && t.flags & 128) for (t = e.child; t !== null; ) {
          if (v = ko(t), v !== null) {
            for (e.flags |= 128, Mr(g, !1), o = v.updateQueue, o !== null && (e.updateQueue = o, e.flags |= 4), e.subtreeFlags = 0, o = n, n = e.child; n !== null; ) g = n, t = o, g.flags &= 14680066, v = g.alternate, v === null ? (g.childLanes = 0, g.lanes = t, g.child = null, g.subtreeFlags = 0, g.memoizedProps = null, g.memoizedState = null, g.updateQueue = null, g.dependencies = null, g.stateNode = null) : (g.childLanes = v.childLanes, g.lanes = v.lanes, g.child = v.child, g.subtreeFlags = 0, g.deletions = null, g.memoizedProps = v.memoizedProps, g.memoizedState = v.memoizedState, g.updateQueue = v.updateQueue, g.type = v.type, t = v.dependencies, g.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }), n = n.sibling;
            return Ht(Jt, Jt.current & 1 | 2), e.child;
          }
          t = t.sibling;
        }
        g.tail !== null && ae() > cr && (e.flags |= 128, o = !0, Mr(g, !1), e.lanes = 4194304);
      }
      else {
        if (!o) if (t = ko(v), t !== null) {
          if (e.flags |= 128, o = !0, n = t.updateQueue, n !== null && (e.updateQueue = n, e.flags |= 4), Mr(g, !0), g.tail === null && g.tailMode === "hidden" && !v.alternate && !Kt) return be(e), null;
        } else 2 * ae() - g.renderingStartTime > cr && n !== 1073741824 && (e.flags |= 128, o = !0, Mr(g, !1), e.lanes = 4194304);
        g.isBackwards ? (v.sibling = e.child, e.child = v) : (n = g.last, n !== null ? n.sibling = v : e.child = v, g.last = v);
      }
      return g.tail !== null ? (e = g.tail, g.rendering = e, g.tail = e.sibling, g.renderingStartTime = ae(), e.sibling = null, n = Jt.current, Ht(Jt, o ? n & 1 | 2 : n & 1), e) : (be(e), null);
    case 22:
    case 23:
      return Fc(), o = e.memoizedState !== null, t !== null && t.memoizedState !== null !== o && (e.flags |= 8192), o && e.mode & 1 ? Ne & 1073741824 && (be(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : be(e), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(vt(156, e.tag));
}
function gv(t, e) {
  switch (vc(e), e.tag) {
    case 1:
      return Re(e.type) && yo(), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
    case 3:
      return sr(), qt(Le), qt(_e), Ec(), t = e.flags, t & 65536 && !(t & 128) ? (e.flags = t & -65537 | 128, e) : null;
    case 5:
      return kc(e), null;
    case 13:
      if (qt(Jt), t = e.memoizedState, t !== null && t.dehydrated !== null) {
        if (e.alternate === null) throw Error(vt(340));
        ar();
      }
      return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
    case 19:
      return qt(Jt), null;
    case 4:
      return sr(), null;
    case 10:
      return _c(e.type._context), null;
    case 22:
    case 23:
      return Fc(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var Ba = !1, xe = !1, mv = typeof WeakSet == "function" ? WeakSet : Set, Ct = null;
function qi(t, e) {
  var n = t.ref;
  if (n !== null) if (typeof n == "function") try {
    n(null);
  } catch (o) {
    ie(t, e, o);
  }
  else n.current = null;
}
function Cp(t, e, n) {
  try {
    n();
  } catch (o) {
    ie(t, e, o);
  }
}
var Th = !1;
function vv(t, e) {
  if (yl = po, t = Of(), gc(t)) {
    if ("selectionStart" in t) var n = { start: t.selectionStart, end: t.selectionEnd };
    else t: {
      n = (n = t.ownerDocument) && n.defaultView || window;
      var o = n.getSelection && n.getSelection();
      if (o && o.rangeCount !== 0) {
        n = o.anchorNode;
        var u = o.anchorOffset, g = o.focusNode;
        o = o.focusOffset;
        try {
          n.nodeType, g.nodeType;
        } catch {
          n = null;
          break t;
        }
        var v = 0, x = -1, S = -1, E = 0, A = 0, Y = t, V = null;
        e: for (; ; ) {
          for (var Q; Y !== n || u !== 0 && Y.nodeType !== 3 || (x = v + u), Y !== g || o !== 0 && Y.nodeType !== 3 || (S = v + o), Y.nodeType === 3 && (v += Y.nodeValue.length), (Q = Y.firstChild) !== null; )
            V = Y, Y = Q;
          for (; ; ) {
            if (Y === t) break e;
            if (V === n && ++E === u && (x = v), V === g && ++A === o && (S = v), (Q = Y.nextSibling) !== null) break;
            Y = V, V = Y.parentNode;
          }
          Y = Q;
        }
        n = x === -1 || S === -1 ? null : { start: x, end: S };
      } else n = null;
    }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (bl = { focusedElem: t, selectionRange: n }, po = !1, Ct = e; Ct !== null; ) if (e = Ct, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, Ct = t;
  else for (; Ct !== null; ) {
    e = Ct;
    try {
      var tt = e.alternate;
      if (e.flags & 1024) switch (e.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (tt !== null) {
            var rt = tt.memoizedProps, ut = tt.memoizedState, H = e.stateNode, R = H.getSnapshotBeforeUpdate(e.elementType === e.type ? rt : un(e.type, rt), ut);
            H.__reactInternalSnapshotBeforeUpdate = R;
          }
          break;
        case 3:
          var N = e.stateNode.containerInfo;
          N.nodeType === 1 ? N.textContent = "" : N.nodeType === 9 && N.documentElement && N.removeChild(N.documentElement);
          break;
        case 5:
        case 6:
        case 4:
        case 17:
          break;
        default:
          throw Error(vt(163));
      }
    } catch ($) {
      ie(e, e.return, $);
    }
    if (t = e.sibling, t !== null) {
      t.return = e.return, Ct = t;
      break;
    }
    Ct = e.return;
  }
  return tt = Th, Th = !1, tt;
}
function Ur(t, e, n) {
  var o = e.updateQueue;
  if (o = o !== null ? o.lastEffect : null, o !== null) {
    var u = o = o.next;
    do {
      if ((u.tag & t) === t) {
        var g = u.destroy;
        u.destroy = void 0, g !== void 0 && Cp(e, n, g);
      }
      u = u.next;
    } while (u !== o);
  }
}
function qo(t, e) {
  if (e = e.updateQueue, e = e !== null ? e.lastEffect : null, e !== null) {
    var n = e = e.next;
    do {
      if ((n.tag & t) === t) {
        var o = n.create;
        n.destroy = o();
      }
      n = n.next;
    } while (n !== e);
  }
}
function Rl(t) {
  var e = t.ref;
  if (e !== null) {
    var n = t.stateNode;
    switch (t.tag) {
      case 5:
        t = n;
        break;
      default:
        t = n;
    }
    typeof e == "function" ? e(t) : e.current = t;
  }
}
function kp(t) {
  var e = t.alternate;
  e !== null && (t.alternate = null, kp(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && (delete e[Cn], delete e[ea], delete e[wl], delete e[$1], delete e[tv])), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
}
function Ep(t) {
  return t.tag === 5 || t.tag === 3 || t.tag === 4;
}
function Oh(t) {
  t: for (; ; ) {
    for (; t.sibling === null; ) {
      if (t.return === null || Ep(t.return)) return null;
      t = t.return;
    }
    for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
      if (t.flags & 2 || t.child === null || t.tag === 4) continue t;
      t.child.return = t, t = t.child;
    }
    if (!(t.flags & 2)) return t.stateNode;
  }
}
function Il(t, e, n) {
  var o = t.tag;
  if (o === 5 || o === 6) t = t.stateNode, e ? n.nodeType === 8 ? n.parentNode.insertBefore(t, e) : n.insertBefore(t, e) : (n.nodeType === 8 ? (e = n.parentNode, e.insertBefore(t, n)) : (e = n, e.appendChild(t)), n = n._reactRootContainer, n != null || e.onclick !== null || (e.onclick = vo));
  else if (o !== 4 && (t = t.child, t !== null)) for (Il(t, e, n), t = t.sibling; t !== null; ) Il(t, e, n), t = t.sibling;
}
function Fl(t, e, n) {
  var o = t.tag;
  if (o === 5 || o === 6) t = t.stateNode, e ? n.insertBefore(t, e) : n.appendChild(t);
  else if (o !== 4 && (t = t.child, t !== null)) for (Fl(t, e, n), t = t.sibling; t !== null; ) Fl(t, e, n), t = t.sibling;
}
var pe = null, hn = !1;
function Vn(t, e, n) {
  for (n = n.child; n !== null; ) Tp(t, e, n), n = n.sibling;
}
function Tp(t, e, n) {
  if (Mn && typeof Mn.onCommitFiberUnmount == "function") try {
    Mn.onCommitFiberUnmount(No, n);
  } catch {
  }
  switch (n.tag) {
    case 5:
      xe || qi(n, e);
    case 6:
      var o = pe, u = hn;
      pe = null, Vn(t, e, n), pe = o, hn = u, pe !== null && (hn ? (t = pe, n = n.stateNode, t.nodeType === 8 ? t.parentNode.removeChild(n) : t.removeChild(n)) : pe.removeChild(n.stateNode));
      break;
    case 18:
      pe !== null && (hn ? (t = pe, n = n.stateNode, t.nodeType === 8 ? Os(t.parentNode, n) : t.nodeType === 1 && Os(t, n), Kr(t)) : Os(pe, n.stateNode));
      break;
    case 4:
      o = pe, u = hn, pe = n.stateNode.containerInfo, hn = !0, Vn(t, e, n), pe = o, hn = u;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!xe && (o = n.updateQueue, o !== null && (o = o.lastEffect, o !== null))) {
        u = o = o.next;
        do {
          var g = u, v = g.destroy;
          g = g.tag, v !== void 0 && (g & 2 || g & 4) && Cp(n, e, v), u = u.next;
        } while (u !== o);
      }
      Vn(t, e, n);
      break;
    case 1:
      if (!xe && (qi(n, e), o = n.stateNode, typeof o.componentWillUnmount == "function")) try {
        o.props = n.memoizedProps, o.state = n.memoizedState, o.componentWillUnmount();
      } catch (x) {
        ie(n, e, x);
      }
      Vn(t, e, n);
      break;
    case 21:
      Vn(t, e, n);
      break;
    case 22:
      n.mode & 1 ? (xe = (o = xe) || n.memoizedState !== null, Vn(t, e, n), xe = o) : Vn(t, e, n);
      break;
    default:
      Vn(t, e, n);
  }
}
function Mh(t) {
  var e = t.updateQueue;
  if (e !== null) {
    t.updateQueue = null;
    var n = t.stateNode;
    n === null && (n = t.stateNode = new mv()), e.forEach(function(o) {
      var u = Ev.bind(null, t, o);
      n.has(o) || (n.add(o), o.then(u, u));
    });
  }
}
function ln(t, e) {
  var n = e.deletions;
  if (n !== null) for (var o = 0; o < n.length; o++) {
    var u = n[o];
    try {
      var g = t, v = e, x = v;
      t: for (; x !== null; ) {
        switch (x.tag) {
          case 5:
            pe = x.stateNode, hn = !1;
            break t;
          case 3:
            pe = x.stateNode.containerInfo, hn = !0;
            break t;
          case 4:
            pe = x.stateNode.containerInfo, hn = !0;
            break t;
        }
        x = x.return;
      }
      if (pe === null) throw Error(vt(160));
      Tp(g, v, u), pe = null, hn = !1;
      var S = u.alternate;
      S !== null && (S.return = null), u.return = null;
    } catch (E) {
      ie(u, e, E);
    }
  }
  if (e.subtreeFlags & 12854) for (e = e.child; e !== null; ) Op(e, t), e = e.sibling;
}
function Op(t, e) {
  var n = t.alternate, o = t.flags;
  switch (t.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (ln(e, t), _n(t), o & 4) {
        try {
          Ur(3, t, t.return), qo(3, t);
        } catch (rt) {
          ie(t, t.return, rt);
        }
        try {
          Ur(5, t, t.return);
        } catch (rt) {
          ie(t, t.return, rt);
        }
      }
      break;
    case 1:
      ln(e, t), _n(t), o & 512 && n !== null && qi(n, n.return);
      break;
    case 5:
      if (ln(e, t), _n(t), o & 512 && n !== null && qi(n, n.return), t.flags & 32) {
        var u = t.stateNode;
        try {
          Hr(u, "");
        } catch (rt) {
          ie(t, t.return, rt);
        }
      }
      if (o & 4 && (u = t.stateNode, u != null)) {
        var g = t.memoizedProps, v = n !== null ? n.memoizedProps : g, x = t.type, S = t.updateQueue;
        if (t.updateQueue = null, S !== null) try {
          x === "input" && g.type === "radio" && g.name != null && qd(u, g), ll(x, v);
          var E = ll(x, g);
          for (v = 0; v < S.length; v += 2) {
            var A = S[v], Y = S[v + 1];
            A === "style" ? $d(u, Y) : A === "dangerouslySetInnerHTML" ? Qd(u, Y) : A === "children" ? Hr(u, Y) : nc(u, A, Y, E);
          }
          switch (x) {
            case "input":
              il(u, g);
              break;
            case "textarea":
              Zd(u, g);
              break;
            case "select":
              var V = u._wrapperState.wasMultiple;
              u._wrapperState.wasMultiple = !!g.multiple;
              var Q = g.value;
              Q != null ? Qi(u, !!g.multiple, Q, !1) : V !== !!g.multiple && (g.defaultValue != null ? Qi(
                u,
                !!g.multiple,
                g.defaultValue,
                !0
              ) : Qi(u, !!g.multiple, g.multiple ? [] : "", !1));
          }
          u[ea] = g;
        } catch (rt) {
          ie(t, t.return, rt);
        }
      }
      break;
    case 6:
      if (ln(e, t), _n(t), o & 4) {
        if (t.stateNode === null) throw Error(vt(162));
        u = t.stateNode, g = t.memoizedProps;
        try {
          u.nodeValue = g;
        } catch (rt) {
          ie(t, t.return, rt);
        }
      }
      break;
    case 3:
      if (ln(e, t), _n(t), o & 4 && n !== null && n.memoizedState.isDehydrated) try {
        Kr(e.containerInfo);
      } catch (rt) {
        ie(t, t.return, rt);
      }
      break;
    case 4:
      ln(e, t), _n(t);
      break;
    case 13:
      ln(e, t), _n(t), u = t.child, u.flags & 8192 && (g = u.memoizedState !== null, u.stateNode.isHidden = g, !g || u.alternate !== null && u.alternate.memoizedState !== null || (Rc = ae())), o & 4 && Mh(t);
      break;
    case 22:
      if (A = n !== null && n.memoizedState !== null, t.mode & 1 ? (xe = (E = xe) || A, ln(e, t), xe = E) : ln(e, t), _n(t), o & 8192) {
        if (E = t.memoizedState !== null, (t.stateNode.isHidden = E) && !A && t.mode & 1) for (Ct = t, A = t.child; A !== null; ) {
          for (Y = Ct = A; Ct !== null; ) {
            switch (V = Ct, Q = V.child, V.tag) {
              case 0:
              case 11:
              case 14:
              case 15:
                Ur(4, V, V.return);
                break;
              case 1:
                qi(V, V.return);
                var tt = V.stateNode;
                if (typeof tt.componentWillUnmount == "function") {
                  o = V, n = V.return;
                  try {
                    e = o, tt.props = e.memoizedProps, tt.state = e.memoizedState, tt.componentWillUnmount();
                  } catch (rt) {
                    ie(o, n, rt);
                  }
                }
                break;
              case 5:
                qi(V, V.return);
                break;
              case 22:
                if (V.memoizedState !== null) {
                  Ah(Y);
                  continue;
                }
            }
            Q !== null ? (Q.return = V, Ct = Q) : Ah(Y);
          }
          A = A.sibling;
        }
        t: for (A = null, Y = t; ; ) {
          if (Y.tag === 5) {
            if (A === null) {
              A = Y;
              try {
                u = Y.stateNode, E ? (g = u.style, typeof g.setProperty == "function" ? g.setProperty("display", "none", "important") : g.display = "none") : (x = Y.stateNode, S = Y.memoizedProps.style, v = S != null && S.hasOwnProperty("display") ? S.display : null, x.style.display = Jd("display", v));
              } catch (rt) {
                ie(t, t.return, rt);
              }
            }
          } else if (Y.tag === 6) {
            if (A === null) try {
              Y.stateNode.nodeValue = E ? "" : Y.memoizedProps;
            } catch (rt) {
              ie(t, t.return, rt);
            }
          } else if ((Y.tag !== 22 && Y.tag !== 23 || Y.memoizedState === null || Y === t) && Y.child !== null) {
            Y.child.return = Y, Y = Y.child;
            continue;
          }
          if (Y === t) break t;
          for (; Y.sibling === null; ) {
            if (Y.return === null || Y.return === t) break t;
            A === Y && (A = null), Y = Y.return;
          }
          A === Y && (A = null), Y.sibling.return = Y.return, Y = Y.sibling;
        }
      }
      break;
    case 19:
      ln(e, t), _n(t), o & 4 && Mh(t);
      break;
    case 21:
      break;
    default:
      ln(
        e,
        t
      ), _n(t);
  }
}
function _n(t) {
  var e = t.flags;
  if (e & 2) {
    try {
      t: {
        for (var n = t.return; n !== null; ) {
          if (Ep(n)) {
            var o = n;
            break t;
          }
          n = n.return;
        }
        throw Error(vt(160));
      }
      switch (o.tag) {
        case 5:
          var u = o.stateNode;
          o.flags & 32 && (Hr(u, ""), o.flags &= -33);
          var g = Oh(t);
          Fl(t, g, u);
          break;
        case 3:
        case 4:
          var v = o.stateNode.containerInfo, x = Oh(t);
          Il(t, x, v);
          break;
        default:
          throw Error(vt(161));
      }
    } catch (S) {
      ie(t, t.return, S);
    }
    t.flags &= -3;
  }
  e & 4096 && (t.flags &= -4097);
}
function yv(t, e, n) {
  Ct = t, Mp(t);
}
function Mp(t, e, n) {
  for (var o = (t.mode & 1) !== 0; Ct !== null; ) {
    var u = Ct, g = u.child;
    if (u.tag === 22 && o) {
      var v = u.memoizedState !== null || Ba;
      if (!v) {
        var x = u.alternate, S = x !== null && x.memoizedState !== null || xe;
        x = Ba;
        var E = xe;
        if (Ba = v, (xe = S) && !E) for (Ct = u; Ct !== null; ) v = Ct, S = v.child, v.tag === 22 && v.memoizedState !== null ? jh(u) : S !== null ? (S.return = v, Ct = S) : jh(u);
        for (; g !== null; ) Ct = g, Mp(g), g = g.sibling;
        Ct = u, Ba = x, xe = E;
      }
      Ph(t);
    } else u.subtreeFlags & 8772 && g !== null ? (g.return = u, Ct = g) : Ph(t);
  }
}
function Ph(t) {
  for (; Ct !== null; ) {
    var e = Ct;
    if (e.flags & 8772) {
      var n = e.alternate;
      try {
        if (e.flags & 8772) switch (e.tag) {
          case 0:
          case 11:
          case 15:
            xe || qo(5, e);
            break;
          case 1:
            var o = e.stateNode;
            if (e.flags & 4 && !xe) if (n === null) o.componentDidMount();
            else {
              var u = e.elementType === e.type ? n.memoizedProps : un(e.type, n.memoizedProps);
              o.componentDidUpdate(u, n.memoizedState, o.__reactInternalSnapshotBeforeUpdate);
            }
            var g = e.updateQueue;
            g !== null && ph(e, g, o);
            break;
          case 3:
            var v = e.updateQueue;
            if (v !== null) {
              if (n = null, e.child !== null) switch (e.child.tag) {
                case 5:
                  n = e.child.stateNode;
                  break;
                case 1:
                  n = e.child.stateNode;
              }
              ph(e, v, n);
            }
            break;
          case 5:
            var x = e.stateNode;
            if (n === null && e.flags & 4) {
              n = x;
              var S = e.memoizedProps;
              switch (e.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  S.autoFocus && n.focus();
                  break;
                case "img":
                  S.src && (n.src = S.src);
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (e.memoizedState === null) {
              var E = e.alternate;
              if (E !== null) {
                var A = E.memoizedState;
                if (A !== null) {
                  var Y = A.dehydrated;
                  Y !== null && Kr(Y);
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error(vt(163));
        }
        xe || e.flags & 512 && Rl(e);
      } catch (V) {
        ie(e, e.return, V);
      }
    }
    if (e === t) {
      Ct = null;
      break;
    }
    if (n = e.sibling, n !== null) {
      n.return = e.return, Ct = n;
      break;
    }
    Ct = e.return;
  }
}
function Ah(t) {
  for (; Ct !== null; ) {
    var e = Ct;
    if (e === t) {
      Ct = null;
      break;
    }
    var n = e.sibling;
    if (n !== null) {
      n.return = e.return, Ct = n;
      break;
    }
    Ct = e.return;
  }
}
function jh(t) {
  for (; Ct !== null; ) {
    var e = Ct;
    try {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          var n = e.return;
          try {
            qo(4, e);
          } catch (S) {
            ie(e, n, S);
          }
          break;
        case 1:
          var o = e.stateNode;
          if (typeof o.componentDidMount == "function") {
            var u = e.return;
            try {
              o.componentDidMount();
            } catch (S) {
              ie(e, u, S);
            }
          }
          var g = e.return;
          try {
            Rl(e);
          } catch (S) {
            ie(e, g, S);
          }
          break;
        case 5:
          var v = e.return;
          try {
            Rl(e);
          } catch (S) {
            ie(e, v, S);
          }
      }
    } catch (S) {
      ie(e, e.return, S);
    }
    if (e === t) {
      Ct = null;
      break;
    }
    var x = e.sibling;
    if (x !== null) {
      x.return = e.return, Ct = x;
      break;
    }
    Ct = e.return;
  }
}
var bv = Math.ceil, Oo = Yn.ReactCurrentDispatcher, Dc = Yn.ReactCurrentOwner, $e = Yn.ReactCurrentBatchConfig, zt = 0, de = null, oe = null, ge = 0, Ne = 0, Zi = ci(0), ce = 0, sa = null, Ei = 0, Zo = 0, Lc = 0, Wr = null, je = null, Rc = 0, cr = 1 / 0, Dn = null, Mo = !1, Bl = null, ii = null, za = !1, Qn = null, Po = 0, Yr = 0, zl = null, io = -1, ro = 0;
function ke() {
  return zt & 6 ? ae() : io !== -1 ? io : io = ae();
}
function ri(t) {
  return t.mode & 1 ? zt & 2 && ge !== 0 ? ge & -ge : nv.transition !== null ? (ro === 0 && (ro = df()), ro) : (t = Yt, t !== 0 || (t = window.event, t = t === void 0 ? 16 : bf(t.type)), t) : 1;
}
function mn(t, e, n, o) {
  if (50 < Yr) throw Yr = 0, zl = null, Error(vt(185));
  ua(t, n, o), (!(zt & 2) || t !== de) && (t === de && (!(zt & 2) && (Zo |= n), ce === 4 && qn(t, ge)), Ie(t, o), n === 1 && zt === 0 && !(e.mode & 1) && (cr = ae() + 500, Go && ui()));
}
function Ie(t, e) {
  var n = t.callbackNode;
  n1(t, e);
  var o = fo(t, t === de ? ge : 0);
  if (o === 0) n !== null && Uu(n), t.callbackNode = null, t.callbackPriority = 0;
  else if (e = o & -o, t.callbackPriority !== e) {
    if (n != null && Uu(n), e === 1) t.tag === 0 ? ev(Dh.bind(null, t)) : Bf(Dh.bind(null, t)), Q1(function() {
      !(zt & 6) && ui();
    }), n = null;
    else {
      switch (ff(o)) {
        case 1:
          n = sc;
          break;
        case 4:
          n = uf;
          break;
        case 16:
          n = ho;
          break;
        case 536870912:
          n = hf;
          break;
        default:
          n = ho;
      }
      n = Fp(n, Pp.bind(null, t));
    }
    t.callbackPriority = e, t.callbackNode = n;
  }
}
function Pp(t, e) {
  if (io = -1, ro = 0, zt & 6) throw Error(vt(327));
  var n = t.callbackNode;
  if (nr() && t.callbackNode !== n) return null;
  var o = fo(t, t === de ? ge : 0);
  if (o === 0) return null;
  if (o & 30 || o & t.expiredLanes || e) e = Ao(t, o);
  else {
    e = o;
    var u = zt;
    zt |= 2;
    var g = jp();
    (de !== t || ge !== e) && (Dn = null, cr = ae() + 500, _i(t, e));
    do
      try {
        wv();
        break;
      } catch (x) {
        Ap(t, x);
      }
    while (!0);
    xc(), Oo.current = g, zt = u, oe !== null ? e = 0 : (de = null, ge = 0, e = ce);
  }
  if (e !== 0) {
    if (e === 2 && (u = fl(t), u !== 0 && (o = u, e = Nl(t, u))), e === 1) throw n = sa, _i(t, 0), qn(t, o), Ie(t, ae()), n;
    if (e === 6) qn(t, o);
    else {
      if (u = t.current.alternate, !(o & 30) && !xv(u) && (e = Ao(t, o), e === 2 && (g = fl(t), g !== 0 && (o = g, e = Nl(t, g))), e === 1)) throw n = sa, _i(t, 0), qn(t, o), Ie(t, ae()), n;
      switch (t.finishedWork = u, t.finishedLanes = o, e) {
        case 0:
        case 1:
          throw Error(vt(345));
        case 2:
          gi(t, je, Dn);
          break;
        case 3:
          if (qn(t, o), (o & 130023424) === o && (e = Rc + 500 - ae(), 10 < e)) {
            if (fo(t, 0) !== 0) break;
            if (u = t.suspendedLanes, (u & o) !== o) {
              ke(), t.pingedLanes |= t.suspendedLanes & u;
              break;
            }
            t.timeoutHandle = _l(gi.bind(null, t, je, Dn), e);
            break;
          }
          gi(t, je, Dn);
          break;
        case 4:
          if (qn(t, o), (o & 4194240) === o) break;
          for (e = t.eventTimes, u = -1; 0 < o; ) {
            var v = 31 - gn(o);
            g = 1 << v, v = e[v], v > u && (u = v), o &= ~g;
          }
          if (o = u, o = ae() - o, o = (120 > o ? 120 : 480 > o ? 480 : 1080 > o ? 1080 : 1920 > o ? 1920 : 3e3 > o ? 3e3 : 4320 > o ? 4320 : 1960 * bv(o / 1960)) - o, 10 < o) {
            t.timeoutHandle = _l(gi.bind(null, t, je, Dn), o);
            break;
          }
          gi(t, je, Dn);
          break;
        case 5:
          gi(t, je, Dn);
          break;
        default:
          throw Error(vt(329));
      }
    }
  }
  return Ie(t, ae()), t.callbackNode === n ? Pp.bind(null, t) : null;
}
function Nl(t, e) {
  var n = Wr;
  return t.current.memoizedState.isDehydrated && (_i(t, e).flags |= 256), t = Ao(t, e), t !== 2 && (e = je, je = n, e !== null && Ul(e)), t;
}
function Ul(t) {
  je === null ? je = t : je.push.apply(je, t);
}
function xv(t) {
  for (var e = t; ; ) {
    if (e.flags & 16384) {
      var n = e.updateQueue;
      if (n !== null && (n = n.stores, n !== null)) for (var o = 0; o < n.length; o++) {
        var u = n[o], g = u.getSnapshot;
        u = u.value;
        try {
          if (!vn(g(), u)) return !1;
        } catch {
          return !1;
        }
      }
    }
    if (n = e.child, e.subtreeFlags & 16384 && n !== null) n.return = e, e = n;
    else {
      if (e === t) break;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) return !0;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
  }
  return !0;
}
function qn(t, e) {
  for (e &= ~Lc, e &= ~Zo, t.suspendedLanes |= e, t.pingedLanes &= ~e, t = t.expirationTimes; 0 < e; ) {
    var n = 31 - gn(e), o = 1 << n;
    t[n] = -1, e &= ~o;
  }
}
function Dh(t) {
  if (zt & 6) throw Error(vt(327));
  nr();
  var e = fo(t, 0);
  if (!(e & 1)) return Ie(t, ae()), null;
  var n = Ao(t, e);
  if (t.tag !== 0 && n === 2) {
    var o = fl(t);
    o !== 0 && (e = o, n = Nl(t, o));
  }
  if (n === 1) throw n = sa, _i(t, 0), qn(t, e), Ie(t, ae()), n;
  if (n === 6) throw Error(vt(345));
  return t.finishedWork = t.current.alternate, t.finishedLanes = e, gi(t, je, Dn), Ie(t, ae()), null;
}
function Ic(t, e) {
  var n = zt;
  zt |= 1;
  try {
    return t(e);
  } finally {
    zt = n, zt === 0 && (cr = ae() + 500, Go && ui());
  }
}
function Ti(t) {
  Qn !== null && Qn.tag === 0 && !(zt & 6) && nr();
  var e = zt;
  zt |= 1;
  var n = $e.transition, o = Yt;
  try {
    if ($e.transition = null, Yt = 1, t) return t();
  } finally {
    Yt = o, $e.transition = n, zt = e, !(zt & 6) && ui();
  }
}
function Fc() {
  Ne = Zi.current, qt(Zi);
}
function _i(t, e) {
  t.finishedWork = null, t.finishedLanes = 0;
  var n = t.timeoutHandle;
  if (n !== -1 && (t.timeoutHandle = -1, K1(n)), oe !== null) for (n = oe.return; n !== null; ) {
    var o = n;
    switch (vc(o), o.tag) {
      case 1:
        o = o.type.childContextTypes, o != null && yo();
        break;
      case 3:
        sr(), qt(Le), qt(_e), Ec();
        break;
      case 5:
        kc(o);
        break;
      case 4:
        sr();
        break;
      case 13:
        qt(Jt);
        break;
      case 19:
        qt(Jt);
        break;
      case 10:
        _c(o.type._context);
        break;
      case 22:
      case 23:
        Fc();
    }
    n = n.return;
  }
  if (de = t, oe = t = ai(t.current, null), ge = Ne = e, ce = 0, sa = null, Lc = Zo = Ei = 0, je = Wr = null, bi !== null) {
    for (e = 0; e < bi.length; e++) if (n = bi[e], o = n.interleaved, o !== null) {
      n.interleaved = null;
      var u = o.next, g = n.pending;
      if (g !== null) {
        var v = g.next;
        g.next = u, o.next = v;
      }
      n.pending = o;
    }
    bi = null;
  }
  return t;
}
function Ap(t, e) {
  do {
    var n = oe;
    try {
      if (xc(), to.current = To, Eo) {
        for (var o = te.memoizedState; o !== null; ) {
          var u = o.queue;
          u !== null && (u.pending = null), o = o.next;
        }
        Eo = !1;
      }
      if (ki = 0, he = le = te = null, Nr = !1, ra = 0, Dc.current = null, n === null || n.return === null) {
        ce = 1, sa = e, oe = null;
        break;
      }
      t: {
        var g = t, v = n.return, x = n, S = e;
        if (e = ge, x.flags |= 32768, S !== null && typeof S == "object" && typeof S.then == "function") {
          var E = S, A = x, Y = A.tag;
          if (!(A.mode & 1) && (Y === 0 || Y === 11 || Y === 15)) {
            var V = A.alternate;
            V ? (A.updateQueue = V.updateQueue, A.memoizedState = V.memoizedState, A.lanes = V.lanes) : (A.updateQueue = null, A.memoizedState = null);
          }
          var Q = xh(v);
          if (Q !== null) {
            Q.flags &= -257, _h(Q, v, x, g, e), Q.mode & 1 && bh(g, E, e), e = Q, S = E;
            var tt = e.updateQueue;
            if (tt === null) {
              var rt = /* @__PURE__ */ new Set();
              rt.add(S), e.updateQueue = rt;
            } else tt.add(S);
            break t;
          } else {
            if (!(e & 1)) {
              bh(g, E, e), Bc();
              break t;
            }
            S = Error(vt(426));
          }
        } else if (Kt && x.mode & 1) {
          var ut = xh(v);
          if (ut !== null) {
            !(ut.flags & 65536) && (ut.flags |= 256), _h(ut, v, x, g, e), yc(lr(S, x));
            break t;
          }
        }
        g = S = lr(S, x), ce !== 4 && (ce = 2), Wr === null ? Wr = [g] : Wr.push(g), g = v;
        do {
          switch (g.tag) {
            case 3:
              g.flags |= 65536, e &= -e, g.lanes |= e;
              var H = fp(g, S, e);
              fh(g, H);
              break t;
            case 1:
              x = S;
              var R = g.type, N = g.stateNode;
              if (!(g.flags & 128) && (typeof R.getDerivedStateFromError == "function" || N !== null && typeof N.componentDidCatch == "function" && (ii === null || !ii.has(N)))) {
                g.flags |= 65536, e &= -e, g.lanes |= e;
                var $ = pp(g, x, e);
                fh(g, $);
                break t;
              }
          }
          g = g.return;
        } while (g !== null);
      }
      Lp(n);
    } catch (at) {
      e = at, oe === n && n !== null && (oe = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function jp() {
  var t = Oo.current;
  return Oo.current = To, t === null ? To : t;
}
function Bc() {
  (ce === 0 || ce === 3 || ce === 2) && (ce = 4), de === null || !(Ei & 268435455) && !(Zo & 268435455) || qn(de, ge);
}
function Ao(t, e) {
  var n = zt;
  zt |= 2;
  var o = jp();
  (de !== t || ge !== e) && (Dn = null, _i(t, e));
  do
    try {
      _v();
      break;
    } catch (u) {
      Ap(t, u);
    }
  while (!0);
  if (xc(), zt = n, Oo.current = o, oe !== null) throw Error(vt(261));
  return de = null, ge = 0, ce;
}
function _v() {
  for (; oe !== null; ) Dp(oe);
}
function wv() {
  for (; oe !== null && !Xm(); ) Dp(oe);
}
function Dp(t) {
  var e = Ip(t.alternate, t, Ne);
  t.memoizedProps = t.pendingProps, e === null ? Lp(t) : oe = e, Dc.current = null;
}
function Lp(t) {
  var e = t;
  do {
    var n = e.alternate;
    if (t = e.return, e.flags & 32768) {
      if (n = gv(n, e), n !== null) {
        n.flags &= 32767, oe = n;
        return;
      }
      if (t !== null) t.flags |= 32768, t.subtreeFlags = 0, t.deletions = null;
      else {
        ce = 6, oe = null;
        return;
      }
    } else if (n = pv(n, e, Ne), n !== null) {
      oe = n;
      return;
    }
    if (e = e.sibling, e !== null) {
      oe = e;
      return;
    }
    oe = e = t;
  } while (e !== null);
  ce === 0 && (ce = 5);
}
function gi(t, e, n) {
  var o = Yt, u = $e.transition;
  try {
    $e.transition = null, Yt = 1, Sv(t, e, n, o);
  } finally {
    $e.transition = u, Yt = o;
  }
  return null;
}
function Sv(t, e, n, o) {
  do
    nr();
  while (Qn !== null);
  if (zt & 6) throw Error(vt(327));
  n = t.finishedWork;
  var u = t.finishedLanes;
  if (n === null) return null;
  if (t.finishedWork = null, t.finishedLanes = 0, n === t.current) throw Error(vt(177));
  t.callbackNode = null, t.callbackPriority = 0;
  var g = n.lanes | n.childLanes;
  if (i1(t, g), t === de && (oe = de = null, ge = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || za || (za = !0, Fp(ho, function() {
    return nr(), null;
  })), g = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || g) {
    g = $e.transition, $e.transition = null;
    var v = Yt;
    Yt = 1;
    var x = zt;
    zt |= 4, Dc.current = null, vv(t, n), Op(n, t), Y1(bl), po = !!yl, bl = yl = null, t.current = n, yv(n), qm(), zt = x, Yt = v, $e.transition = g;
  } else t.current = n;
  if (za && (za = !1, Qn = t, Po = u), g = t.pendingLanes, g === 0 && (ii = null), Qm(n.stateNode), Ie(t, ae()), e !== null) for (o = t.onRecoverableError, n = 0; n < e.length; n++) u = e[n], o(u.value, { componentStack: u.stack, digest: u.digest });
  if (Mo) throw Mo = !1, t = Bl, Bl = null, t;
  return Po & 1 && t.tag !== 0 && nr(), g = t.pendingLanes, g & 1 ? t === zl ? Yr++ : (Yr = 0, zl = t) : Yr = 0, ui(), null;
}
function nr() {
  if (Qn !== null) {
    var t = ff(Po), e = $e.transition, n = Yt;
    try {
      if ($e.transition = null, Yt = 16 > t ? 16 : t, Qn === null) var o = !1;
      else {
        if (t = Qn, Qn = null, Po = 0, zt & 6) throw Error(vt(331));
        var u = zt;
        for (zt |= 4, Ct = t.current; Ct !== null; ) {
          var g = Ct, v = g.child;
          if (Ct.flags & 16) {
            var x = g.deletions;
            if (x !== null) {
              for (var S = 0; S < x.length; S++) {
                var E = x[S];
                for (Ct = E; Ct !== null; ) {
                  var A = Ct;
                  switch (A.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Ur(8, A, g);
                  }
                  var Y = A.child;
                  if (Y !== null) Y.return = A, Ct = Y;
                  else for (; Ct !== null; ) {
                    A = Ct;
                    var V = A.sibling, Q = A.return;
                    if (kp(A), A === E) {
                      Ct = null;
                      break;
                    }
                    if (V !== null) {
                      V.return = Q, Ct = V;
                      break;
                    }
                    Ct = Q;
                  }
                }
              }
              var tt = g.alternate;
              if (tt !== null) {
                var rt = tt.child;
                if (rt !== null) {
                  tt.child = null;
                  do {
                    var ut = rt.sibling;
                    rt.sibling = null, rt = ut;
                  } while (rt !== null);
                }
              }
              Ct = g;
            }
          }
          if (g.subtreeFlags & 2064 && v !== null) v.return = g, Ct = v;
          else t: for (; Ct !== null; ) {
            if (g = Ct, g.flags & 2048) switch (g.tag) {
              case 0:
              case 11:
              case 15:
                Ur(9, g, g.return);
            }
            var H = g.sibling;
            if (H !== null) {
              H.return = g.return, Ct = H;
              break t;
            }
            Ct = g.return;
          }
        }
        var R = t.current;
        for (Ct = R; Ct !== null; ) {
          v = Ct;
          var N = v.child;
          if (v.subtreeFlags & 2064 && N !== null) N.return = v, Ct = N;
          else t: for (v = R; Ct !== null; ) {
            if (x = Ct, x.flags & 2048) try {
              switch (x.tag) {
                case 0:
                case 11:
                case 15:
                  qo(9, x);
              }
            } catch (at) {
              ie(x, x.return, at);
            }
            if (x === v) {
              Ct = null;
              break t;
            }
            var $ = x.sibling;
            if ($ !== null) {
              $.return = x.return, Ct = $;
              break t;
            }
            Ct = x.return;
          }
        }
        if (zt = u, ui(), Mn && typeof Mn.onPostCommitFiberRoot == "function") try {
          Mn.onPostCommitFiberRoot(No, t);
        } catch {
        }
        o = !0;
      }
      return o;
    } finally {
      Yt = n, $e.transition = e;
    }
  }
  return !1;
}
function Lh(t, e, n) {
  e = lr(n, e), e = fp(t, e, 1), t = ni(t, e, 1), e = ke(), t !== null && (ua(t, 1, e), Ie(t, e));
}
function ie(t, e, n) {
  if (t.tag === 3) Lh(t, t, n);
  else for (; e !== null; ) {
    if (e.tag === 3) {
      Lh(e, t, n);
      break;
    } else if (e.tag === 1) {
      var o = e.stateNode;
      if (typeof e.type.getDerivedStateFromError == "function" || typeof o.componentDidCatch == "function" && (ii === null || !ii.has(o))) {
        t = lr(n, t), t = pp(e, t, 1), e = ni(e, t, 1), t = ke(), e !== null && (ua(e, 1, t), Ie(e, t));
        break;
      }
    }
    e = e.return;
  }
}
function Cv(t, e, n) {
  var o = t.pingCache;
  o !== null && o.delete(e), e = ke(), t.pingedLanes |= t.suspendedLanes & n, de === t && (ge & n) === n && (ce === 4 || ce === 3 && (ge & 130023424) === ge && 500 > ae() - Rc ? _i(t, 0) : Lc |= n), Ie(t, e);
}
function Rp(t, e) {
  e === 0 && (t.mode & 1 ? (e = Ma, Ma <<= 1, !(Ma & 130023424) && (Ma = 4194304)) : e = 1);
  var n = ke();
  t = Un(t, e), t !== null && (ua(t, e, n), Ie(t, n));
}
function kv(t) {
  var e = t.memoizedState, n = 0;
  e !== null && (n = e.retryLane), Rp(t, n);
}
function Ev(t, e) {
  var n = 0;
  switch (t.tag) {
    case 13:
      var o = t.stateNode, u = t.memoizedState;
      u !== null && (n = u.retryLane);
      break;
    case 19:
      o = t.stateNode;
      break;
    default:
      throw Error(vt(314));
  }
  o !== null && o.delete(e), Rp(t, n);
}
var Ip;
Ip = function(t, e, n) {
  if (t !== null) if (t.memoizedProps !== e.pendingProps || Le.current) De = !0;
  else {
    if (!(t.lanes & n) && !(e.flags & 128)) return De = !1, fv(t, e, n);
    De = !!(t.flags & 131072);
  }
  else De = !1, Kt && e.flags & 1048576 && zf(e, _o, e.index);
  switch (e.lanes = 0, e.tag) {
    case 2:
      var o = e.type;
      no(t, e), t = e.pendingProps;
      var u = rr(e, _e.current);
      er(e, n), u = Oc(null, e, o, t, u, n);
      var g = Mc();
      return e.flags |= 1, typeof u == "object" && u !== null && typeof u.render == "function" && u.$$typeof === void 0 ? (e.tag = 1, e.memoizedState = null, e.updateQueue = null, Re(o) ? (g = !0, bo(e)) : g = !1, e.memoizedState = u.state !== null && u.state !== void 0 ? u.state : null, Sc(e), u.updater = Xo, e.stateNode = u, u._reactInternals = e, Ol(e, o, t, n), e = Al(null, e, o, !0, g, n)) : (e.tag = 0, Kt && g && mc(e), Ce(null, e, u, n), e = e.child), e;
    case 16:
      o = e.elementType;
      t: {
        switch (no(t, e), t = e.pendingProps, u = o._init, o = u(o._payload), e.type = o, u = e.tag = Ov(o), t = un(o, t), u) {
          case 0:
            e = Pl(null, e, o, t, n);
            break t;
          case 1:
            e = Ch(null, e, o, t, n);
            break t;
          case 11:
            e = wh(null, e, o, t, n);
            break t;
          case 14:
            e = Sh(null, e, o, un(o.type, t), n);
            break t;
        }
        throw Error(vt(
          306,
          o,
          ""
        ));
      }
      return e;
    case 0:
      return o = e.type, u = e.pendingProps, u = e.elementType === o ? u : un(o, u), Pl(t, e, o, u, n);
    case 1:
      return o = e.type, u = e.pendingProps, u = e.elementType === o ? u : un(o, u), Ch(t, e, o, u, n);
    case 3:
      t: {
        if (yp(e), t === null) throw Error(vt(387));
        o = e.pendingProps, g = e.memoizedState, u = g.element, Gf(t, e), Co(e, o, null, n);
        var v = e.memoizedState;
        if (o = v.element, g.isDehydrated) if (g = { element: o, isDehydrated: !1, cache: v.cache, pendingSuspenseBoundaries: v.pendingSuspenseBoundaries, transitions: v.transitions }, e.updateQueue.baseState = g, e.memoizedState = g, e.flags & 256) {
          u = lr(Error(vt(423)), e), e = kh(t, e, o, n, u);
          break t;
        } else if (o !== u) {
          u = lr(Error(vt(424)), e), e = kh(t, e, o, n, u);
          break t;
        } else for (Ue = ei(e.stateNode.containerInfo.firstChild), We = e, Kt = !0, dn = null, n = Yf(e, null, o, n), e.child = n; n; ) n.flags = n.flags & -3 | 4096, n = n.sibling;
        else {
          if (ar(), o === u) {
            e = Wn(t, e, n);
            break t;
          }
          Ce(t, e, o, n);
        }
        e = e.child;
      }
      return e;
    case 5:
      return Hf(e), t === null && kl(e), o = e.type, u = e.pendingProps, g = t !== null ? t.memoizedProps : null, v = u.children, xl(o, u) ? v = null : g !== null && xl(o, g) && (e.flags |= 32), vp(t, e), Ce(t, e, v, n), e.child;
    case 6:
      return t === null && kl(e), null;
    case 13:
      return bp(t, e, n);
    case 4:
      return Cc(e, e.stateNode.containerInfo), o = e.pendingProps, t === null ? e.child = or(e, null, o, n) : Ce(t, e, o, n), e.child;
    case 11:
      return o = e.type, u = e.pendingProps, u = e.elementType === o ? u : un(o, u), wh(t, e, o, u, n);
    case 7:
      return Ce(t, e, e.pendingProps, n), e.child;
    case 8:
      return Ce(t, e, e.pendingProps.children, n), e.child;
    case 12:
      return Ce(t, e, e.pendingProps.children, n), e.child;
    case 10:
      t: {
        if (o = e.type._context, u = e.pendingProps, g = e.memoizedProps, v = u.value, Ht(wo, o._currentValue), o._currentValue = v, g !== null) if (vn(g.value, v)) {
          if (g.children === u.children && !Le.current) {
            e = Wn(t, e, n);
            break t;
          }
        } else for (g = e.child, g !== null && (g.return = e); g !== null; ) {
          var x = g.dependencies;
          if (x !== null) {
            v = g.child;
            for (var S = x.firstContext; S !== null; ) {
              if (S.context === o) {
                if (g.tag === 1) {
                  S = Bn(-1, n & -n), S.tag = 2;
                  var E = g.updateQueue;
                  if (E !== null) {
                    E = E.shared;
                    var A = E.pending;
                    A === null ? S.next = S : (S.next = A.next, A.next = S), E.pending = S;
                  }
                }
                g.lanes |= n, S = g.alternate, S !== null && (S.lanes |= n), El(
                  g.return,
                  n,
                  e
                ), x.lanes |= n;
                break;
              }
              S = S.next;
            }
          } else if (g.tag === 10) v = g.type === e.type ? null : g.child;
          else if (g.tag === 18) {
            if (v = g.return, v === null) throw Error(vt(341));
            v.lanes |= n, x = v.alternate, x !== null && (x.lanes |= n), El(v, n, e), v = g.sibling;
          } else v = g.child;
          if (v !== null) v.return = g;
          else for (v = g; v !== null; ) {
            if (v === e) {
              v = null;
              break;
            }
            if (g = v.sibling, g !== null) {
              g.return = v.return, v = g;
              break;
            }
            v = v.return;
          }
          g = v;
        }
        Ce(t, e, u.children, n), e = e.child;
      }
      return e;
    case 9:
      return u = e.type, o = e.pendingProps.children, er(e, n), u = nn(u), o = o(u), e.flags |= 1, Ce(t, e, o, n), e.child;
    case 14:
      return o = e.type, u = un(o, e.pendingProps), u = un(o.type, u), Sh(t, e, o, u, n);
    case 15:
      return gp(t, e, e.type, e.pendingProps, n);
    case 17:
      return o = e.type, u = e.pendingProps, u = e.elementType === o ? u : un(o, u), no(t, e), e.tag = 1, Re(o) ? (t = !0, bo(e)) : t = !1, er(e, n), dp(e, o, u), Ol(e, o, u, n), Al(null, e, o, !0, t, n);
    case 19:
      return xp(t, e, n);
    case 22:
      return mp(t, e, n);
  }
  throw Error(vt(156, e.tag));
};
function Fp(t, e) {
  return cf(t, e);
}
function Tv(t, e, n, o) {
  this.tag = t, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = o, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
}
function Je(t, e, n, o) {
  return new Tv(t, e, n, o);
}
function zc(t) {
  return t = t.prototype, !(!t || !t.isReactComponent);
}
function Ov(t) {
  if (typeof t == "function") return zc(t) ? 1 : 0;
  if (t != null) {
    if (t = t.$$typeof, t === rc) return 11;
    if (t === ac) return 14;
  }
  return 2;
}
function ai(t, e) {
  var n = t.alternate;
  return n === null ? (n = Je(t.tag, e, t.key, t.mode), n.elementType = t.elementType, n.type = t.type, n.stateNode = t.stateNode, n.alternate = t, t.alternate = n) : (n.pendingProps = e, n.type = t.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = t.flags & 14680064, n.childLanes = t.childLanes, n.lanes = t.lanes, n.child = t.child, n.memoizedProps = t.memoizedProps, n.memoizedState = t.memoizedState, n.updateQueue = t.updateQueue, e = t.dependencies, n.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }, n.sibling = t.sibling, n.index = t.index, n.ref = t.ref, n;
}
function ao(t, e, n, o, u, g) {
  var v = 2;
  if (o = t, typeof t == "function") zc(t) && (v = 1);
  else if (typeof t == "string") v = 5;
  else t: switch (t) {
    case zi:
      return wi(n.children, u, g, e);
    case ic:
      v = 8, u |= 8;
      break;
    case Js:
      return t = Je(12, n, e, u | 2), t.elementType = Js, t.lanes = g, t;
    case $s:
      return t = Je(13, n, e, u), t.elementType = $s, t.lanes = g, t;
    case tl:
      return t = Je(19, n, e, u), t.elementType = tl, t.lanes = g, t;
    case Gd:
      return Ko(n, u, g, e);
    default:
      if (typeof t == "object" && t !== null) switch (t.$$typeof) {
        case Yd:
          v = 10;
          break t;
        case Vd:
          v = 9;
          break t;
        case rc:
          v = 11;
          break t;
        case ac:
          v = 14;
          break t;
        case Gn:
          v = 16, o = null;
          break t;
      }
      throw Error(vt(130, t == null ? t : typeof t, ""));
  }
  return e = Je(v, n, e, u), e.elementType = t, e.type = o, e.lanes = g, e;
}
function wi(t, e, n, o) {
  return t = Je(7, t, o, e), t.lanes = n, t;
}
function Ko(t, e, n, o) {
  return t = Je(22, t, o, e), t.elementType = Gd, t.lanes = n, t.stateNode = { isHidden: !1 }, t;
}
function Is(t, e, n) {
  return t = Je(6, t, null, e), t.lanes = n, t;
}
function Fs(t, e, n) {
  return e = Je(4, t.children !== null ? t.children : [], t.key, e), e.lanes = n, e.stateNode = { containerInfo: t.containerInfo, pendingChildren: null, implementation: t.implementation }, e;
}
function Mv(t, e, n, o, u) {
  this.tag = e, this.containerInfo = t, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = vs(0), this.expirationTimes = vs(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = vs(0), this.identifierPrefix = o, this.onRecoverableError = u, this.mutableSourceEagerHydrationData = null;
}
function Nc(t, e, n, o, u, g, v, x, S) {
  return t = new Mv(t, e, n, x, S), e === 1 ? (e = 1, g === !0 && (e |= 8)) : e = 0, g = Je(3, null, null, e), t.current = g, g.stateNode = t, g.memoizedState = { element: o, isDehydrated: n, cache: null, transitions: null, pendingSuspenseBoundaries: null }, Sc(g), t;
}
function Pv(t, e, n) {
  var o = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return { $$typeof: Bi, key: o == null ? null : "" + o, children: t, containerInfo: e, implementation: n };
}
function Bp(t) {
  if (!t) return si;
  t = t._reactInternals;
  t: {
    if (Mi(t) !== t || t.tag !== 1) throw Error(vt(170));
    var e = t;
    do {
      switch (e.tag) {
        case 3:
          e = e.stateNode.context;
          break t;
        case 1:
          if (Re(e.type)) {
            e = e.stateNode.__reactInternalMemoizedMergedChildContext;
            break t;
          }
      }
      e = e.return;
    } while (e !== null);
    throw Error(vt(171));
  }
  if (t.tag === 1) {
    var n = t.type;
    if (Re(n)) return Ff(t, n, e);
  }
  return e;
}
function zp(t, e, n, o, u, g, v, x, S) {
  return t = Nc(n, o, !0, t, u, g, v, x, S), t.context = Bp(null), n = t.current, o = ke(), u = ri(n), g = Bn(o, u), g.callback = e ?? null, ni(n, g, u), t.current.lanes = u, ua(t, u, o), Ie(t, o), t;
}
function Qo(t, e, n, o) {
  var u = e.current, g = ke(), v = ri(u);
  return n = Bp(n), e.context === null ? e.context = n : e.pendingContext = n, e = Bn(g, v), e.payload = { element: t }, o = o === void 0 ? null : o, o !== null && (e.callback = o), t = ni(u, e, v), t !== null && (mn(t, u, v, g), $a(t, u, v)), v;
}
function jo(t) {
  if (t = t.current, !t.child) return null;
  switch (t.child.tag) {
    case 5:
      return t.child.stateNode;
    default:
      return t.child.stateNode;
  }
}
function Rh(t, e) {
  if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
    var n = t.retryLane;
    t.retryLane = n !== 0 && n < e ? n : e;
  }
}
function Uc(t, e) {
  Rh(t, e), (t = t.alternate) && Rh(t, e);
}
function Av() {
  return null;
}
var Np = typeof reportError == "function" ? reportError : function(t) {
  console.error(t);
};
function Wc(t) {
  this._internalRoot = t;
}
Jo.prototype.render = Wc.prototype.render = function(t) {
  var e = this._internalRoot;
  if (e === null) throw Error(vt(409));
  Qo(t, e, null, null);
};
Jo.prototype.unmount = Wc.prototype.unmount = function() {
  var t = this._internalRoot;
  if (t !== null) {
    this._internalRoot = null;
    var e = t.containerInfo;
    Ti(function() {
      Qo(null, t, null, null);
    }), e[Nn] = null;
  }
};
function Jo(t) {
  this._internalRoot = t;
}
Jo.prototype.unstable_scheduleHydration = function(t) {
  if (t) {
    var e = mf();
    t = { blockedOn: null, target: t, priority: e };
    for (var n = 0; n < Xn.length && e !== 0 && e < Xn[n].priority; n++) ;
    Xn.splice(n, 0, t), n === 0 && yf(t);
  }
};
function Yc(t) {
  return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
}
function $o(t) {
  return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11 && (t.nodeType !== 8 || t.nodeValue !== " react-mount-point-unstable "));
}
function Ih() {
}
function jv(t, e, n, o, u) {
  if (u) {
    if (typeof o == "function") {
      var g = o;
      o = function() {
        var E = jo(v);
        g.call(E);
      };
    }
    var v = zp(e, o, t, 0, null, !1, !1, "", Ih);
    return t._reactRootContainer = v, t[Nn] = v.current, $r(t.nodeType === 8 ? t.parentNode : t), Ti(), v;
  }
  for (; u = t.lastChild; ) t.removeChild(u);
  if (typeof o == "function") {
    var x = o;
    o = function() {
      var E = jo(S);
      x.call(E);
    };
  }
  var S = Nc(t, 0, !1, null, null, !1, !1, "", Ih);
  return t._reactRootContainer = S, t[Nn] = S.current, $r(t.nodeType === 8 ? t.parentNode : t), Ti(function() {
    Qo(e, S, n, o);
  }), S;
}
function ts(t, e, n, o, u) {
  var g = n._reactRootContainer;
  if (g) {
    var v = g;
    if (typeof u == "function") {
      var x = u;
      u = function() {
        var S = jo(v);
        x.call(S);
      };
    }
    Qo(e, v, t, u);
  } else v = jv(n, e, t, u, o);
  return jo(v);
}
pf = function(t) {
  switch (t.tag) {
    case 3:
      var e = t.stateNode;
      if (e.current.memoizedState.isDehydrated) {
        var n = Dr(e.pendingLanes);
        n !== 0 && (lc(e, n | 1), Ie(e, ae()), !(zt & 6) && (cr = ae() + 500, ui()));
      }
      break;
    case 13:
      Ti(function() {
        var o = Un(t, 1);
        if (o !== null) {
          var u = ke();
          mn(o, t, 1, u);
        }
      }), Uc(t, 1);
  }
};
cc = function(t) {
  if (t.tag === 13) {
    var e = Un(t, 134217728);
    if (e !== null) {
      var n = ke();
      mn(e, t, 134217728, n);
    }
    Uc(t, 134217728);
  }
};
gf = function(t) {
  if (t.tag === 13) {
    var e = ri(t), n = Un(t, e);
    if (n !== null) {
      var o = ke();
      mn(n, t, e, o);
    }
    Uc(t, e);
  }
};
mf = function() {
  return Yt;
};
vf = function(t, e) {
  var n = Yt;
  try {
    return Yt = t, e();
  } finally {
    Yt = n;
  }
};
ul = function(t, e, n) {
  switch (e) {
    case "input":
      if (il(t, n), e = n.name, n.type === "radio" && e != null) {
        for (n = t; n.parentNode; ) n = n.parentNode;
        for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + e) + '][type="radio"]'), e = 0; e < n.length; e++) {
          var o = n[e];
          if (o !== t && o.form === t.form) {
            var u = Vo(o);
            if (!u) throw Error(vt(90));
            Xd(o), il(o, u);
          }
        }
      }
      break;
    case "textarea":
      Zd(t, n);
      break;
    case "select":
      e = n.value, e != null && Qi(t, !!n.multiple, e, !1);
  }
};
nf = Ic;
rf = Ti;
var Dv = { usingClientEntryPoint: !1, Events: [da, Yi, Vo, tf, ef, Ic] }, Pr = { findFiberByHostInstance: yi, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, Lv = { bundleType: Pr.bundleType, version: Pr.version, rendererPackageName: Pr.rendererPackageName, rendererConfig: Pr.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: Yn.ReactCurrentDispatcher, findHostInstanceByFiber: function(t) {
  return t = sf(t), t === null ? null : t.stateNode;
}, findFiberByHostInstance: Pr.findFiberByHostInstance || Av, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var Na = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!Na.isDisabled && Na.supportsFiber) try {
    No = Na.inject(Lv), Mn = Na;
  } catch {
  }
}
Ge.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Dv;
Ge.createPortal = function(t, e) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!Yc(e)) throw Error(vt(200));
  return Pv(t, e, null, n);
};
Ge.createRoot = function(t, e) {
  if (!Yc(t)) throw Error(vt(299));
  var n = !1, o = "", u = Np;
  return e != null && (e.unstable_strictMode === !0 && (n = !0), e.identifierPrefix !== void 0 && (o = e.identifierPrefix), e.onRecoverableError !== void 0 && (u = e.onRecoverableError)), e = Nc(t, 1, !1, null, null, n, !1, o, u), t[Nn] = e.current, $r(t.nodeType === 8 ? t.parentNode : t), new Wc(e);
};
Ge.findDOMNode = function(t) {
  if (t == null) return null;
  if (t.nodeType === 1) return t;
  var e = t._reactInternals;
  if (e === void 0)
    throw typeof t.render == "function" ? Error(vt(188)) : (t = Object.keys(t).join(","), Error(vt(268, t)));
  return t = sf(e), t = t === null ? null : t.stateNode, t;
};
Ge.flushSync = function(t) {
  return Ti(t);
};
Ge.hydrate = function(t, e, n) {
  if (!$o(e)) throw Error(vt(200));
  return ts(null, t, e, !0, n);
};
Ge.hydrateRoot = function(t, e, n) {
  if (!Yc(t)) throw Error(vt(405));
  var o = n != null && n.hydratedSources || null, u = !1, g = "", v = Np;
  if (n != null && (n.unstable_strictMode === !0 && (u = !0), n.identifierPrefix !== void 0 && (g = n.identifierPrefix), n.onRecoverableError !== void 0 && (v = n.onRecoverableError)), e = zp(e, null, t, 1, n ?? null, u, !1, g, v), t[Nn] = e.current, $r(t), o) for (t = 0; t < o.length; t++) n = o[t], u = n._getVersion, u = u(n._source), e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [n, u] : e.mutableSourceEagerHydrationData.push(
    n,
    u
  );
  return new Jo(e);
};
Ge.render = function(t, e, n) {
  if (!$o(e)) throw Error(vt(200));
  return ts(null, t, e, !1, n);
};
Ge.unmountComponentAtNode = function(t) {
  if (!$o(t)) throw Error(vt(40));
  return t._reactRootContainer ? (Ti(function() {
    ts(null, null, t, !1, function() {
      t._reactRootContainer = null, t[Nn] = null;
    });
  }), !0) : !1;
};
Ge.unstable_batchedUpdates = Ic;
Ge.unstable_renderSubtreeIntoContainer = function(t, e, n, o) {
  if (!$o(n)) throw Error(vt(200));
  if (t == null || t._reactInternals === void 0) throw Error(vt(38));
  return ts(t, e, n, !1, o);
};
Ge.version = "18.3.1-next-f1338f8080-20240426";
function Up() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Up);
    } catch (t) {
      console.error(t);
    }
}
Up(), zd.exports = Ge;
var Rv = zd.exports;
const Iv = /* @__PURE__ */ Zl(Rv);
function Fv(t, e) {
  return e.forEach(function(n) {
    n && typeof n != "string" && !Array.isArray(n) && Object.keys(n).forEach(function(o) {
      if (o !== "default" && !(o in t)) {
        var u = Object.getOwnPropertyDescriptor(n, o);
        Object.defineProperty(t, o, u.get ? u : { enumerable: !0, get: function() {
          return n[o];
        } });
      }
    });
  }), Object.freeze(t);
}
var Fh = typeof global < "u" ? global : typeof self < "u" ? self : typeof window < "u" ? window : {}, kn = [], Xe = [], Bv = typeof Uint8Array < "u" ? Uint8Array : Array, Vc = !1;
function Wp() {
  Vc = !0;
  for (var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", e = 0; e < 64; ++e) kn[e] = t[e], Xe[t.charCodeAt(e)] = e;
  Xe[45] = 62, Xe[95] = 63;
}
function zv(t, e, n) {
  for (var o, u, g = [], v = e; v < n; v += 3) o = (t[v] << 16) + (t[v + 1] << 8) + t[v + 2], g.push(kn[(u = o) >> 18 & 63] + kn[u >> 12 & 63] + kn[u >> 6 & 63] + kn[63 & u]);
  return g.join("");
}
function Bh(t) {
  var e;
  Vc || Wp();
  for (var n = t.length, o = n % 3, u = "", g = [], v = 16383, x = 0, S = n - o; x < S; x += v) g.push(zv(t, x, x + v > S ? S : x + v));
  return o === 1 ? (e = t[n - 1], u += kn[e >> 2], u += kn[e << 4 & 63], u += "==") : o === 2 && (e = (t[n - 2] << 8) + t[n - 1], u += kn[e >> 10], u += kn[e >> 4 & 63], u += kn[e << 2 & 63], u += "="), g.push(u), g.join("");
}
function Ua(t, e, n, o, u) {
  var g, v, x = 8 * u - o - 1, S = (1 << x) - 1, E = S >> 1, A = -7, Y = n ? u - 1 : 0, V = n ? -1 : 1, Q = t[e + Y];
  for (Y += V, g = Q & (1 << -A) - 1, Q >>= -A, A += x; A > 0; g = 256 * g + t[e + Y], Y += V, A -= 8) ;
  for (v = g & (1 << -A) - 1, g >>= -A, A += o; A > 0; v = 256 * v + t[e + Y], Y += V, A -= 8) ;
  if (g === 0) g = 1 - E;
  else {
    if (g === S) return v ? NaN : 1 / 0 * (Q ? -1 : 1);
    v += Math.pow(2, o), g -= E;
  }
  return (Q ? -1 : 1) * v * Math.pow(2, g - o);
}
function Yp(t, e, n, o, u, g) {
  var v, x, S, E = 8 * g - u - 1, A = (1 << E) - 1, Y = A >> 1, V = u === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, Q = o ? 0 : g - 1, tt = o ? 1 : -1, rt = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
  for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (x = isNaN(e) ? 1 : 0, v = A) : (v = Math.floor(Math.log(e) / Math.LN2), e * (S = Math.pow(2, -v)) < 1 && (v--, S *= 2), (e += v + Y >= 1 ? V / S : V * Math.pow(2, 1 - Y)) * S >= 2 && (v++, S /= 2), v + Y >= A ? (x = 0, v = A) : v + Y >= 1 ? (x = (e * S - 1) * Math.pow(2, u), v += Y) : (x = e * Math.pow(2, Y - 1) * Math.pow(2, u), v = 0)); u >= 8; t[n + Q] = 255 & x, Q += tt, x /= 256, u -= 8) ;
  for (v = v << u | x, E += u; E > 0; t[n + Q] = 255 & v, Q += tt, v /= 256, E -= 8) ;
  t[n + Q - tt] |= 128 * rt;
}
var Nv = {}.toString, Vp = Array.isArray || function(t) {
  return Nv.call(t) == "[object Array]";
};
function Do() {
  return pt.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
}
function Fn(t, e) {
  if (Do() < e) throw new RangeError("Invalid typed array length");
  return pt.TYPED_ARRAY_SUPPORT ? (t = new Uint8Array(e)).__proto__ = pt.prototype : (t === null && (t = new pt(e)), t.length = e), t;
}
function pt(t, e, n) {
  if (!(pt.TYPED_ARRAY_SUPPORT || this instanceof pt)) return new pt(t, e, n);
  if (typeof t == "number") {
    if (typeof e == "string") throw new Error("If encoding is specified then the first argument must be a string");
    return Wl(this, t);
  }
  return Gp(this, t, e, n);
}
function Gp(t, e, n, o) {
  if (typeof e == "number") throw new TypeError('"value" argument must not be a number');
  return typeof ArrayBuffer < "u" && e instanceof ArrayBuffer ? function(u, g, v, x) {
    if (g.byteLength, v < 0 || g.byteLength < v) throw new RangeError("'offset' is out of bounds");
    if (g.byteLength < v + (x || 0)) throw new RangeError("'length' is out of bounds");
    return g = v === void 0 && x === void 0 ? new Uint8Array(g) : x === void 0 ? new Uint8Array(g, v) : new Uint8Array(g, v, x), pt.TYPED_ARRAY_SUPPORT ? (u = g).__proto__ = pt.prototype : u = Bs(u, g), u;
  }(t, e, n, o) : typeof e == "string" ? function(u, g, v) {
    if (typeof v == "string" && v !== "" || (v = "utf8"), !pt.isEncoding(v)) throw new TypeError('"encoding" must be a valid string encoding');
    var x = 0 | Xp(g, v);
    u = Fn(u, x);
    var S = u.write(g, v);
    return S !== x && (u = u.slice(0, S)), u;
  }(t, e, n) : function(u, g) {
    if (En(g)) {
      var v = 0 | Gc(g.length);
      return (u = Fn(u, v)).length === 0 || g.copy(u, 0, 0, v), u;
    }
    if (g) {
      if (typeof ArrayBuffer < "u" && g.buffer instanceof ArrayBuffer || "length" in g) return typeof g.length != "number" || (x = g.length) != x ? Fn(u, 0) : Bs(u, g);
      if (g.type === "Buffer" && Vp(g.data)) return Bs(u, g.data);
    }
    var x;
    throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
  }(t, e);
}
function Hp(t) {
  if (typeof t != "number") throw new TypeError('"size" argument must be a number');
  if (t < 0) throw new RangeError('"size" argument must not be negative');
}
function Wl(t, e) {
  if (Hp(e), t = Fn(t, e < 0 ? 0 : 0 | Gc(e)), !pt.TYPED_ARRAY_SUPPORT) for (var n = 0; n < e; ++n) t[n] = 0;
  return t;
}
function Bs(t, e) {
  var n = e.length < 0 ? 0 : 0 | Gc(e.length);
  t = Fn(t, n);
  for (var o = 0; o < n; o += 1) t[o] = 255 & e[o];
  return t;
}
function Gc(t) {
  if (t >= Do()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + Do().toString(16) + " bytes");
  return 0 | t;
}
function En(t) {
  return !(t == null || !t._isBuffer);
}
function Xp(t, e) {
  if (En(t)) return t.length;
  if (typeof ArrayBuffer < "u" && typeof ArrayBuffer.isView == "function" && (ArrayBuffer.isView(t) || t instanceof ArrayBuffer)) return t.byteLength;
  typeof t != "string" && (t = "" + t);
  var n = t.length;
  if (n === 0) return 0;
  for (var o = !1; ; ) switch (e) {
    case "ascii":
    case "latin1":
    case "binary":
      return n;
    case "utf8":
    case "utf-8":
    case void 0:
      return Lo(t).length;
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return 2 * n;
    case "hex":
      return n >>> 1;
    case "base64":
      return Qp(t).length;
    default:
      if (o) return Lo(t).length;
      e = ("" + e).toLowerCase(), o = !0;
  }
}
function Uv(t, e, n) {
  var o = !1;
  if ((e === void 0 || e < 0) && (e = 0), e > this.length || ((n === void 0 || n > this.length) && (n = this.length), n <= 0) || (n >>>= 0) <= (e >>>= 0)) return "";
  for (t || (t = "utf8"); ; ) switch (t) {
    case "hex":
      return Kv(this, e, n);
    case "utf8":
    case "utf-8":
      return Zp(this, e, n);
    case "ascii":
      return qv(this, e, n);
    case "latin1":
    case "binary":
      return Zv(this, e, n);
    case "base64":
      return Xv(this, e, n);
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return Qv(this, e, n);
    default:
      if (o) throw new TypeError("Unknown encoding: " + t);
      t = (t + "").toLowerCase(), o = !0;
  }
}
function di(t, e, n) {
  var o = t[e];
  t[e] = t[n], t[n] = o;
}
function zh(t, e, n, o, u) {
  if (t.length === 0) return -1;
  if (typeof n == "string" ? (o = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), n = +n, isNaN(n) && (n = u ? 0 : t.length - 1), n < 0 && (n = t.length + n), n >= t.length) {
    if (u) return -1;
    n = t.length - 1;
  } else if (n < 0) {
    if (!u) return -1;
    n = 0;
  }
  if (typeof e == "string" && (e = pt.from(e, o)), En(e)) return e.length === 0 ? -1 : Nh(t, e, n, o, u);
  if (typeof e == "number") return e &= 255, pt.TYPED_ARRAY_SUPPORT && typeof Uint8Array.prototype.indexOf == "function" ? u ? Uint8Array.prototype.indexOf.call(t, e, n) : Uint8Array.prototype.lastIndexOf.call(t, e, n) : Nh(t, [e], n, o, u);
  throw new TypeError("val must be string, number or Buffer");
}
function Nh(t, e, n, o, u) {
  var g, v = 1, x = t.length, S = e.length;
  if (o !== void 0 && ((o = String(o).toLowerCase()) === "ucs2" || o === "ucs-2" || o === "utf16le" || o === "utf-16le")) {
    if (t.length < 2 || e.length < 2) return -1;
    v = 2, x /= 2, S /= 2, n /= 2;
  }
  function E(Q, tt) {
    return v === 1 ? Q[tt] : Q.readUInt16BE(tt * v);
  }
  if (u) {
    var A = -1;
    for (g = n; g < x; g++) if (E(t, g) === E(e, A === -1 ? 0 : g - A)) {
      if (A === -1 && (A = g), g - A + 1 === S) return A * v;
    } else A !== -1 && (g -= g - A), A = -1;
  } else for (n + S > x && (n = x - S), g = n; g >= 0; g--) {
    for (var Y = !0, V = 0; V < S; V++) if (E(t, g + V) !== E(e, V)) {
      Y = !1;
      break;
    }
    if (Y) return g;
  }
  return -1;
}
function Wv(t, e, n, o) {
  n = Number(n) || 0;
  var u = t.length - n;
  o ? (o = Number(o)) > u && (o = u) : o = u;
  var g = e.length;
  if (g % 2 != 0) throw new TypeError("Invalid hex string");
  o > g / 2 && (o = g / 2);
  for (var v = 0; v < o; ++v) {
    var x = parseInt(e.substr(2 * v, 2), 16);
    if (isNaN(x)) return v;
    t[n + v] = x;
  }
  return v;
}
function Yv(t, e, n, o) {
  return es(Lo(e, t.length - n), t, n, o);
}
function qp(t, e, n, o) {
  return es(function(u) {
    for (var g = [], v = 0; v < u.length; ++v) g.push(255 & u.charCodeAt(v));
    return g;
  }(e), t, n, o);
}
function Vv(t, e, n, o) {
  return qp(t, e, n, o);
}
function Gv(t, e, n, o) {
  return es(Qp(e), t, n, o);
}
function Hv(t, e, n, o) {
  return es(function(u, g) {
    for (var v, x, S, E = [], A = 0; A < u.length && !((g -= 2) < 0); ++A) x = (v = u.charCodeAt(A)) >> 8, S = v % 256, E.push(S), E.push(x);
    return E;
  }(e, t.length - n), t, n, o);
}
function Xv(t, e, n) {
  return e === 0 && n === t.length ? Bh(t) : Bh(t.slice(e, n));
}
function Zp(t, e, n) {
  n = Math.min(t.length, n);
  for (var o = [], u = e; u < n; ) {
    var g, v, x, S, E = t[u], A = null, Y = E > 239 ? 4 : E > 223 ? 3 : E > 191 ? 2 : 1;
    if (u + Y <= n) switch (Y) {
      case 1:
        E < 128 && (A = E);
        break;
      case 2:
        (192 & (g = t[u + 1])) == 128 && (S = (31 & E) << 6 | 63 & g) > 127 && (A = S);
        break;
      case 3:
        g = t[u + 1], v = t[u + 2], (192 & g) == 128 && (192 & v) == 128 && (S = (15 & E) << 12 | (63 & g) << 6 | 63 & v) > 2047 && (S < 55296 || S > 57343) && (A = S);
        break;
      case 4:
        g = t[u + 1], v = t[u + 2], x = t[u + 3], (192 & g) == 128 && (192 & v) == 128 && (192 & x) == 128 && (S = (15 & E) << 18 | (63 & g) << 12 | (63 & v) << 6 | 63 & x) > 65535 && S < 1114112 && (A = S);
    }
    A === null ? (A = 65533, Y = 1) : A > 65535 && (A -= 65536, o.push(A >>> 10 & 1023 | 55296), A = 56320 | 1023 & A), o.push(A), u += Y;
  }
  return function(V) {
    var Q = V.length;
    if (Q <= Uh) return String.fromCharCode.apply(String, V);
    for (var tt = "", rt = 0; rt < Q; ) tt += String.fromCharCode.apply(String, V.slice(rt, rt += Uh));
    return tt;
  }(o);
}
pt.TYPED_ARRAY_SUPPORT = Fh.TYPED_ARRAY_SUPPORT === void 0 || Fh.TYPED_ARRAY_SUPPORT, Do(), pt.poolSize = 8192, pt._augment = function(t) {
  return t.__proto__ = pt.prototype, t;
}, pt.from = function(t, e, n) {
  return Gp(null, t, e, n);
}, pt.TYPED_ARRAY_SUPPORT && (pt.prototype.__proto__ = Uint8Array.prototype, pt.__proto__ = Uint8Array, typeof Symbol < "u" && Symbol.species && pt[Symbol.species]), pt.alloc = function(t, e, n) {
  return function(o, u, g, v) {
    return Hp(u), u <= 0 ? Fn(o, u) : g !== void 0 ? typeof v == "string" ? Fn(o, u).fill(g, v) : Fn(o, u).fill(g) : Fn(o, u);
  }(null, t, e, n);
}, pt.allocUnsafe = function(t) {
  return Wl(null, t);
}, pt.allocUnsafeSlow = function(t) {
  return Wl(null, t);
}, pt.isBuffer = function(t) {
  return t != null && (!!t._isBuffer || Vh(t) || function(e) {
    return typeof e.readFloatLE == "function" && typeof e.slice == "function" && Vh(e.slice(0, 0));
  }(t));
}, pt.compare = function(t, e) {
  if (!En(t) || !En(e)) throw new TypeError("Arguments must be Buffers");
  if (t === e) return 0;
  for (var n = t.length, o = e.length, u = 0, g = Math.min(n, o); u < g; ++u) if (t[u] !== e[u]) {
    n = t[u], o = e[u];
    break;
  }
  return n < o ? -1 : o < n ? 1 : 0;
}, pt.isEncoding = function(t) {
  switch (String(t).toLowerCase()) {
    case "hex":
    case "utf8":
    case "utf-8":
    case "ascii":
    case "latin1":
    case "binary":
    case "base64":
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return !0;
    default:
      return !1;
  }
}, pt.concat = function(t, e) {
  if (!Vp(t)) throw new TypeError('"list" argument must be an Array of Buffers');
  if (t.length === 0) return pt.alloc(0);
  var n;
  if (e === void 0) for (e = 0, n = 0; n < t.length; ++n) e += t[n].length;
  var o = pt.allocUnsafe(e), u = 0;
  for (n = 0; n < t.length; ++n) {
    var g = t[n];
    if (!En(g)) throw new TypeError('"list" argument must be an Array of Buffers');
    g.copy(o, u), u += g.length;
  }
  return o;
}, pt.byteLength = Xp, pt.prototype._isBuffer = !0, pt.prototype.swap16 = function() {
  var t = this.length;
  if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
  for (var e = 0; e < t; e += 2) di(this, e, e + 1);
  return this;
}, pt.prototype.swap32 = function() {
  var t = this.length;
  if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
  for (var e = 0; e < t; e += 4) di(this, e, e + 3), di(this, e + 1, e + 2);
  return this;
}, pt.prototype.swap64 = function() {
  var t = this.length;
  if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
  for (var e = 0; e < t; e += 8) di(this, e, e + 7), di(this, e + 1, e + 6), di(this, e + 2, e + 5), di(this, e + 3, e + 4);
  return this;
}, pt.prototype.toString = function() {
  var t = 0 | this.length;
  return t === 0 ? "" : arguments.length === 0 ? Zp(this, 0, t) : Uv.apply(this, arguments);
}, pt.prototype.equals = function(t) {
  if (!En(t)) throw new TypeError("Argument must be a Buffer");
  return this === t || pt.compare(this, t) === 0;
}, pt.prototype.inspect = function() {
  var t = "";
  return this.length > 0 && (t = this.toString("hex", 0, 50).match(/.{2}/g).join(" "), this.length > 50 && (t += " ... ")), "<Buffer " + t + ">";
}, pt.prototype.compare = function(t, e, n, o, u) {
  if (!En(t)) throw new TypeError("Argument must be a Buffer");
  if (e === void 0 && (e = 0), n === void 0 && (n = t ? t.length : 0), o === void 0 && (o = 0), u === void 0 && (u = this.length), e < 0 || n > t.length || o < 0 || u > this.length) throw new RangeError("out of range index");
  if (o >= u && e >= n) return 0;
  if (o >= u) return -1;
  if (e >= n) return 1;
  if (this === t) return 0;
  for (var g = (u >>>= 0) - (o >>>= 0), v = (n >>>= 0) - (e >>>= 0), x = Math.min(g, v), S = this.slice(o, u), E = t.slice(e, n), A = 0; A < x; ++A) if (S[A] !== E[A]) {
    g = S[A], v = E[A];
    break;
  }
  return g < v ? -1 : v < g ? 1 : 0;
}, pt.prototype.includes = function(t, e, n) {
  return this.indexOf(t, e, n) !== -1;
}, pt.prototype.indexOf = function(t, e, n) {
  return zh(this, t, e, n, !0);
}, pt.prototype.lastIndexOf = function(t, e, n) {
  return zh(this, t, e, n, !1);
}, pt.prototype.write = function(t, e, n, o) {
  if (e === void 0) o = "utf8", n = this.length, e = 0;
  else if (n === void 0 && typeof e == "string") o = e, n = this.length, e = 0;
  else {
    if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
    e |= 0, isFinite(n) ? (n |= 0, o === void 0 && (o = "utf8")) : (o = n, n = void 0);
  }
  var u = this.length - e;
  if ((n === void 0 || n > u) && (n = u), t.length > 0 && (n < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
  o || (o = "utf8");
  for (var g = !1; ; ) switch (o) {
    case "hex":
      return Wv(this, t, e, n);
    case "utf8":
    case "utf-8":
      return Yv(this, t, e, n);
    case "ascii":
      return qp(this, t, e, n);
    case "latin1":
    case "binary":
      return Vv(this, t, e, n);
    case "base64":
      return Gv(this, t, e, n);
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return Hv(this, t, e, n);
    default:
      if (g) throw new TypeError("Unknown encoding: " + o);
      o = ("" + o).toLowerCase(), g = !0;
  }
}, pt.prototype.toJSON = function() {
  return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
};
var Uh = 4096;
function qv(t, e, n) {
  var o = "";
  n = Math.min(t.length, n);
  for (var u = e; u < n; ++u) o += String.fromCharCode(127 & t[u]);
  return o;
}
function Zv(t, e, n) {
  var o = "";
  n = Math.min(t.length, n);
  for (var u = e; u < n; ++u) o += String.fromCharCode(t[u]);
  return o;
}
function Kv(t, e, n) {
  var o = t.length;
  (!e || e < 0) && (e = 0), (!n || n < 0 || n > o) && (n = o);
  for (var u = "", g = e; g < n; ++g) u += $v(t[g]);
  return u;
}
function Qv(t, e, n) {
  for (var o = t.slice(e, n), u = "", g = 0; g < o.length; g += 2) u += String.fromCharCode(o[g] + 256 * o[g + 1]);
  return u;
}
function ue(t, e, n) {
  if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
  if (t + e > n) throw new RangeError("Trying to access beyond buffer length");
}
function Ae(t, e, n, o, u, g) {
  if (!En(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
  if (e > u || e < g) throw new RangeError('"value" argument is out of bounds');
  if (n + o > t.length) throw new RangeError("Index out of range");
}
function Wa(t, e, n, o) {
  e < 0 && (e = 65535 + e + 1);
  for (var u = 0, g = Math.min(t.length - n, 2); u < g; ++u) t[n + u] = (e & 255 << 8 * (o ? u : 1 - u)) >>> 8 * (o ? u : 1 - u);
}
function Ya(t, e, n, o) {
  e < 0 && (e = 4294967295 + e + 1);
  for (var u = 0, g = Math.min(t.length - n, 4); u < g; ++u) t[n + u] = e >>> 8 * (o ? u : 3 - u) & 255;
}
function Kp(t, e, n, o, u, g) {
  if (n + o > t.length) throw new RangeError("Index out of range");
  if (n < 0) throw new RangeError("Index out of range");
}
function Wh(t, e, n, o, u) {
  return u || Kp(t, 0, n, 4), Yp(t, e, n, o, 23, 4), n + 4;
}
function Yh(t, e, n, o, u) {
  return u || Kp(t, 0, n, 8), Yp(t, e, n, o, 52, 8), n + 8;
}
pt.prototype.slice = function(t, e) {
  var n, o = this.length;
  if ((t = ~~t) < 0 ? (t += o) < 0 && (t = 0) : t > o && (t = o), (e = e === void 0 ? o : ~~e) < 0 ? (e += o) < 0 && (e = 0) : e > o && (e = o), e < t && (e = t), pt.TYPED_ARRAY_SUPPORT) (n = this.subarray(t, e)).__proto__ = pt.prototype;
  else {
    var u = e - t;
    n = new pt(u, void 0);
    for (var g = 0; g < u; ++g) n[g] = this[g + t];
  }
  return n;
}, pt.prototype.readUIntLE = function(t, e, n) {
  t |= 0, e |= 0, n || ue(t, e, this.length);
  for (var o = this[t], u = 1, g = 0; ++g < e && (u *= 256); ) o += this[t + g] * u;
  return o;
}, pt.prototype.readUIntBE = function(t, e, n) {
  t |= 0, e |= 0, n || ue(t, e, this.length);
  for (var o = this[t + --e], u = 1; e > 0 && (u *= 256); ) o += this[t + --e] * u;
  return o;
}, pt.prototype.readUInt8 = function(t, e) {
  return e || ue(t, 1, this.length), this[t];
}, pt.prototype.readUInt16LE = function(t, e) {
  return e || ue(t, 2, this.length), this[t] | this[t + 1] << 8;
}, pt.prototype.readUInt16BE = function(t, e) {
  return e || ue(t, 2, this.length), this[t] << 8 | this[t + 1];
}, pt.prototype.readUInt32LE = function(t, e) {
  return e || ue(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
}, pt.prototype.readUInt32BE = function(t, e) {
  return e || ue(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
}, pt.prototype.readIntLE = function(t, e, n) {
  t |= 0, e |= 0, n || ue(t, e, this.length);
  for (var o = this[t], u = 1, g = 0; ++g < e && (u *= 256); ) o += this[t + g] * u;
  return o >= (u *= 128) && (o -= Math.pow(2, 8 * e)), o;
}, pt.prototype.readIntBE = function(t, e, n) {
  t |= 0, e |= 0, n || ue(t, e, this.length);
  for (var o = e, u = 1, g = this[t + --o]; o > 0 && (u *= 256); ) g += this[t + --o] * u;
  return g >= (u *= 128) && (g -= Math.pow(2, 8 * e)), g;
}, pt.prototype.readInt8 = function(t, e) {
  return e || ue(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
}, pt.prototype.readInt16LE = function(t, e) {
  e || ue(t, 2, this.length);
  var n = this[t] | this[t + 1] << 8;
  return 32768 & n ? 4294901760 | n : n;
}, pt.prototype.readInt16BE = function(t, e) {
  e || ue(t, 2, this.length);
  var n = this[t + 1] | this[t] << 8;
  return 32768 & n ? 4294901760 | n : n;
}, pt.prototype.readInt32LE = function(t, e) {
  return e || ue(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
}, pt.prototype.readInt32BE = function(t, e) {
  return e || ue(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
}, pt.prototype.readFloatLE = function(t, e) {
  return e || ue(t, 4, this.length), Ua(this, t, !0, 23, 4);
}, pt.prototype.readFloatBE = function(t, e) {
  return e || ue(t, 4, this.length), Ua(this, t, !1, 23, 4);
}, pt.prototype.readDoubleLE = function(t, e) {
  return e || ue(t, 8, this.length), Ua(this, t, !0, 52, 8);
}, pt.prototype.readDoubleBE = function(t, e) {
  return e || ue(t, 8, this.length), Ua(this, t, !1, 52, 8);
}, pt.prototype.writeUIntLE = function(t, e, n, o) {
  t = +t, e |= 0, n |= 0, o || Ae(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
  var u = 1, g = 0;
  for (this[e] = 255 & t; ++g < n && (u *= 256); ) this[e + g] = t / u & 255;
  return e + n;
}, pt.prototype.writeUIntBE = function(t, e, n, o) {
  t = +t, e |= 0, n |= 0, o || Ae(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
  var u = n - 1, g = 1;
  for (this[e + u] = 255 & t; --u >= 0 && (g *= 256); ) this[e + u] = t / g & 255;
  return e + n;
}, pt.prototype.writeUInt8 = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 1, 255, 0), pt.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), this[e] = 255 & t, e + 1;
}, pt.prototype.writeUInt16LE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 2, 65535, 0), pt.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8) : Wa(this, t, e, !0), e + 2;
}, pt.prototype.writeUInt16BE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 2, 65535, 0), pt.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, this[e + 1] = 255 & t) : Wa(this, t, e, !1), e + 2;
}, pt.prototype.writeUInt32LE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 4, 4294967295, 0), pt.TYPED_ARRAY_SUPPORT ? (this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t) : Ya(this, t, e, !0), e + 4;
}, pt.prototype.writeUInt32BE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 4, 4294967295, 0), pt.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t) : Ya(this, t, e, !1), e + 4;
}, pt.prototype.writeIntLE = function(t, e, n, o) {
  if (t = +t, e |= 0, !o) {
    var u = Math.pow(2, 8 * n - 1);
    Ae(this, t, e, n, u - 1, -u);
  }
  var g = 0, v = 1, x = 0;
  for (this[e] = 255 & t; ++g < n && (v *= 256); ) t < 0 && x === 0 && this[e + g - 1] !== 0 && (x = 1), this[e + g] = (t / v >> 0) - x & 255;
  return e + n;
}, pt.prototype.writeIntBE = function(t, e, n, o) {
  if (t = +t, e |= 0, !o) {
    var u = Math.pow(2, 8 * n - 1);
    Ae(this, t, e, n, u - 1, -u);
  }
  var g = n - 1, v = 1, x = 0;
  for (this[e + g] = 255 & t; --g >= 0 && (v *= 256); ) t < 0 && x === 0 && this[e + g + 1] !== 0 && (x = 1), this[e + g] = (t / v >> 0) - x & 255;
  return e + n;
}, pt.prototype.writeInt8 = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 1, 127, -128), pt.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
}, pt.prototype.writeInt16LE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 2, 32767, -32768), pt.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8) : Wa(this, t, e, !0), e + 2;
}, pt.prototype.writeInt16BE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 2, 32767, -32768), pt.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, this[e + 1] = 255 & t) : Wa(this, t, e, !1), e + 2;
}, pt.prototype.writeInt32LE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 4, 2147483647, -2147483648), pt.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24) : Ya(this, t, e, !0), e + 4;
}, pt.prototype.writeInt32BE = function(t, e, n) {
  return t = +t, e |= 0, n || Ae(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), pt.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t) : Ya(this, t, e, !1), e + 4;
}, pt.prototype.writeFloatLE = function(t, e, n) {
  return Wh(this, t, e, !0, n);
}, pt.prototype.writeFloatBE = function(t, e, n) {
  return Wh(this, t, e, !1, n);
}, pt.prototype.writeDoubleLE = function(t, e, n) {
  return Yh(this, t, e, !0, n);
}, pt.prototype.writeDoubleBE = function(t, e, n) {
  return Yh(this, t, e, !1, n);
}, pt.prototype.copy = function(t, e, n, o) {
  if (n || (n = 0), o || o === 0 || (o = this.length), e >= t.length && (e = t.length), e || (e = 0), o > 0 && o < n && (o = n), o === n || t.length === 0 || this.length === 0) return 0;
  if (e < 0) throw new RangeError("targetStart out of bounds");
  if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
  if (o < 0) throw new RangeError("sourceEnd out of bounds");
  o > this.length && (o = this.length), t.length - e < o - n && (o = t.length - e + n);
  var u, g = o - n;
  if (this === t && n < e && e < o) for (u = g - 1; u >= 0; --u) t[u + e] = this[u + n];
  else if (g < 1e3 || !pt.TYPED_ARRAY_SUPPORT) for (u = 0; u < g; ++u) t[u + e] = this[u + n];
  else Uint8Array.prototype.set.call(t, this.subarray(n, n + g), e);
  return g;
}, pt.prototype.fill = function(t, e, n, o) {
  if (typeof t == "string") {
    if (typeof e == "string" ? (o = e, e = 0, n = this.length) : typeof n == "string" && (o = n, n = this.length), t.length === 1) {
      var u = t.charCodeAt(0);
      u < 256 && (t = u);
    }
    if (o !== void 0 && typeof o != "string") throw new TypeError("encoding must be a string");
    if (typeof o == "string" && !pt.isEncoding(o)) throw new TypeError("Unknown encoding: " + o);
  } else typeof t == "number" && (t &= 255);
  if (e < 0 || this.length < e || this.length < n) throw new RangeError("Out of range index");
  if (n <= e) return this;
  var g;
  if (e >>>= 0, n = n === void 0 ? this.length : n >>> 0, t || (t = 0), typeof t == "number") for (g = e; g < n; ++g) this[g] = t;
  else {
    var v = En(t) ? t : Lo(new pt(t, o).toString()), x = v.length;
    for (g = 0; g < n - e; ++g) this[g + e] = v[g % x];
  }
  return this;
};
var Jv = /[^+\/0-9A-Za-z-_]/g;
function $v(t) {
  return t < 16 ? "0" + t.toString(16) : t.toString(16);
}
function Lo(t, e) {
  var n;
  e = e || 1 / 0;
  for (var o = t.length, u = null, g = [], v = 0; v < o; ++v) {
    if ((n = t.charCodeAt(v)) > 55295 && n < 57344) {
      if (!u) {
        if (n > 56319) {
          (e -= 3) > -1 && g.push(239, 191, 189);
          continue;
        }
        if (v + 1 === o) {
          (e -= 3) > -1 && g.push(239, 191, 189);
          continue;
        }
        u = n;
        continue;
      }
      if (n < 56320) {
        (e -= 3) > -1 && g.push(239, 191, 189), u = n;
        continue;
      }
      n = 65536 + (u - 55296 << 10 | n - 56320);
    } else u && (e -= 3) > -1 && g.push(239, 191, 189);
    if (u = null, n < 128) {
      if ((e -= 1) < 0) break;
      g.push(n);
    } else if (n < 2048) {
      if ((e -= 2) < 0) break;
      g.push(n >> 6 | 192, 63 & n | 128);
    } else if (n < 65536) {
      if ((e -= 3) < 0) break;
      g.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128);
    } else {
      if (!(n < 1114112)) throw new Error("Invalid code point");
      if ((e -= 4) < 0) break;
      g.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128);
    }
  }
  return g;
}
function Qp(t) {
  return function(e) {
    var n, o, u, g, v, x;
    Vc || Wp();
    var S = e.length;
    if (S % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    v = e[S - 2] === "=" ? 2 : e[S - 1] === "=" ? 1 : 0, x = new Bv(3 * S / 4 - v), u = v > 0 ? S - 4 : S;
    var E = 0;
    for (n = 0, o = 0; n < u; n += 4, o += 3) g = Xe[e.charCodeAt(n)] << 18 | Xe[e.charCodeAt(n + 1)] << 12 | Xe[e.charCodeAt(n + 2)] << 6 | Xe[e.charCodeAt(n + 3)], x[E++] = g >> 16 & 255, x[E++] = g >> 8 & 255, x[E++] = 255 & g;
    return v === 2 ? (g = Xe[e.charCodeAt(n)] << 2 | Xe[e.charCodeAt(n + 1)] >> 4, x[E++] = 255 & g) : v === 1 && (g = Xe[e.charCodeAt(n)] << 10 | Xe[e.charCodeAt(n + 1)] << 4 | Xe[e.charCodeAt(n + 2)] >> 2, x[E++] = g >> 8 & 255, x[E++] = 255 & g), x;
  }(function(e) {
    if ((e = function(n) {
      return n.trim ? n.trim() : n.replace(/^\s+|\s+$/g, "");
    }(e).replace(Jv, "")).length < 2) return "";
    for (; e.length % 4 != 0; ) e += "=";
    return e;
  }(t));
}
function es(t, e, n, o) {
  for (var u = 0; u < o && !(u + n >= e.length || u >= t.length); ++u) e[u + n] = t[u];
  return u;
}
function Vh(t) {
  return !!t.constructor && typeof t.constructor.isBuffer == "function" && t.constructor.isBuffer(t);
}
function t3(t) {
  if (t.__esModule) return t;
  var e = Object.defineProperty({}, "__esModule", { value: !0 });
  return Object.keys(t).forEach(function(n) {
    var o = Object.getOwnPropertyDescriptor(t, n);
    Object.defineProperty(e, n, o.get ? o : { enumerable: !0, get: function() {
      return t[n];
    } });
  }), e;
}
var Jp = {}, Gh = {}, zs = t3(Fv({ __proto__: null, default: Gh }, [Gh]));
(function(t) {
  /*! Fabric.js Copyright 2008-2015, Printio (Juriy Zaytsev, Maxim Chernyak) */
  var e, n, o, u, g, v, x, S, E, A, Y, V, Q, tt, rt, ut, H, R, N, $, at, it, gt, b = b || { version: "4.6.0" };
  if (t.fabric = b, typeof document < "u" && typeof window < "u") document instanceof (typeof HTMLDocument < "u" ? HTMLDocument : Document) ? b.document = document : b.document = document.implementation.createHTMLDocument(""), b.window = window;
  else {
    var Pt = new zs.JSDOM(decodeURIComponent("%3C!DOCTYPE%20html%3E%3Chtml%3E%3Chead%3E%3C%2Fhead%3E%3Cbody%3E%3C%2Fbody%3E%3C%2Fhtml%3E"), { features: { FetchExternalResources: ["img"] }, resources: "usable" }).window;
    b.document = Pt.document, b.jsdomImplForWrapper = zs.implForWrapper, b.nodeCanvas = zs.Canvas, b.window = Pt, DOMParser = b.window.DOMParser;
  }
  if (b.isTouchSupported = "ontouchstart" in b.window || "ontouchstart" in b.document || b.window && b.window.navigator && b.window.navigator.maxTouchPoints > 0, b.isLikelyNode = pt !== void 0 && typeof window > "u", b.SHARED_ATTRIBUTES = ["display", "transform", "fill", "fill-opacity", "fill-rule", "opacity", "stroke", "stroke-dasharray", "stroke-linecap", "stroke-dashoffset", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke-width", "id", "paint-order", "vector-effect", "instantiated_by_use", "clip-path"], b.DPI = 96, b.reNum = "(?:[-+]?(?:\\d+|\\d*\\.\\d+)(?:[eE][-+]?\\d+)?)", b.commaWsp = "(?:\\s+,?\\s*|,\\s*)", b.rePathCommand = /([-+]?((\d+\.\d+)|((\d+)|(\.\d+)))(?:[eE][-+]?\d+)?)/gi, b.reNonWord = /[ \n\.,;!\?\-]/, b.fontPaths = {}, b.iMatrix = [1, 0, 0, 1, 0, 0], b.svgNS = "http://www.w3.org/2000/svg", b.perfLimitSizeTotal = 2097152, b.maxCacheSideLimit = 4096, b.minCacheSideLimit = 256, b.charWidthsCache = {}, b.textureSize = 2048, b.disableStyleCopyPaste = !1, b.enableGLFiltering = !0, b.devicePixelRatio = b.window.devicePixelRatio || b.window.webkitDevicePixelRatio || b.window.mozDevicePixelRatio || 1, b.browserShadowBlurConstant = 1, b.arcToSegmentsCache = {}, b.boundsOfCurveCache = {}, b.cachesBoundsOfCurve = !0, b.forceGLPutImageData = !1, b.initFilterBackend = function() {
    return b.enableGLFiltering && b.isWebglSupported && b.isWebglSupported(b.textureSize) ? (console.log("max texture size: " + b.maxTextureSize), new b.WebglFilterBackend({ tileSize: b.textureSize })) : b.Canvas2dFilterBackend ? new b.Canvas2dFilterBackend() : void 0;
  }, typeof document < "u" && typeof window < "u" && (window.fabric = b), P === void 0) var P = {};
  if (function(l) {
    l.modifyEventListener = !1, l.modifySelectors = !1, l.configure = function(w) {
      isFinite(w.modifyEventListener) && (l.modifyEventListener = w.modifyEventListener), isFinite(w.modifySelectors) && (l.modifySelectors = w.modifySelectors), k === !1 && l.modifyEventListener && T(), D === !1 && l.modifySelectors && j();
    }, l.add = function(w, O, L, U) {
      return c(w, O, L, U, "add");
    }, l.remove = function(w, O, L, U) {
      return c(w, O, L, U, "remove");
    }, l.returnFalse = function(w) {
      return !1;
    }, l.stop = function(w) {
      w && (w.stopPropagation && w.stopPropagation(), w.cancelBubble = !0, w.cancelBubbleCount = 0);
    }, l.prevent = function(w) {
      w && (w.preventDefault ? w.preventDefault() : w.preventManipulation ? w.preventManipulation() : w.returnValue = !1);
    }, l.cancel = function(w) {
      l.stop(w), l.prevent(w);
    }, l.blur = function() {
      var w = document.activeElement;
      if (w) {
        var O = document.activeElement.nodeName;
        O !== "INPUT" && O !== "TEXTAREA" && w.contentEditable !== "true" || w.blur && w.blur();
      }
    }, l.getEventSupport = function(w, O) {
      if (typeof w == "string" && (O = w, w = window), (O = "on" + O) in w) return !0;
      if (w.setAttribute || (w = document.createElement("div")), w.setAttribute && w.removeAttribute) {
        w.setAttribute(O, "");
        var L = typeof w[O] == "function";
        return w[O] !== void 0 && (w[O] = null), w.removeAttribute(O), L;
      }
    };
    var a = function(w) {
      if (!w || typeof w != "object") return w;
      var O = new w.constructor();
      for (var L in w) w[L] && typeof w[L] == "object" ? O[L] = a(w[L]) : O[L] = w[L];
      return O;
    }, c = function(w, O, L, U, W, I) {
      if (U = U || {}, String(w) === "[object Object]") {
        var M = w;
        if (w = M.target, delete M.target, !M.type || !M.listener) {
          for (var B in M) {
            var Z = M[B];
            typeof Z != "function" && (U[B] = Z);
          }
          var J = {};
          for (var G in M) {
            B = G.split(",");
            var F = M[G], q = {};
            for (var z in U) q[z] = U[z];
            if (typeof F == "function") L = F;
            else {
              if (typeof F.listener != "function") continue;
              L = F.listener;
              for (var z in F) typeof F[z] != "function" && (q[z] = F[z]);
            }
            for (var X = 0; X < B.length; X++) J[G] = P.add(w, B[X], L, q, W);
          }
          return J;
        }
        for (var G in O = M.type, delete M.type, L = M.listener, delete M.listener, M) U[G] = M[G];
      }
      if (w && O && L) {
        if (typeof w == "string" && O === "ready") {
          if (!window.eventjs_stallOnReady) {
            var et = (/* @__PURE__ */ new Date()).getTime(), ct = U.timeout, ot = U.interval || 1e3 / 60, mt = window.setInterval(function() {
              (/* @__PURE__ */ new Date()).getTime() - et > ct && window.clearInterval(mt), document.querySelector(w) && (window.clearInterval(mt), setTimeout(L, 1));
            }, ot);
            return;
          }
          O = "load", w = window;
        }
        if (typeof w == "string") {
          if ((w = document.querySelectorAll(w)).length === 0) return i("Missing target on listener!", arguments);
          w.length === 1 && (w = w[0]);
        }
        var lt, dt = {};
        if (w.length > 0 && w !== window) {
          for (var ft = 0, St = w.length; ft < St; ft++) (lt = c(w[ft], O, L, a(U), W)) && (dt[ft] = lt);
          return f(dt);
        }
        if (typeof O == "string" && ((O = O.toLowerCase()).indexOf(" ") !== -1 ? O = O.split(" ") : O.indexOf(",") !== -1 && (O = O.split(","))), typeof O != "string") {
          if (typeof O.length == "number") for (var yt = 0, Ot = O.length; yt < Ot; yt++) (lt = c(w, O[yt], L, a(U), W)) && (dt[O[yt]] = lt);
          else for (var G in O) (lt = typeof O[G] == "function" ? c(w, G, O[G], a(U), W) : c(w, G, O[G].listener, a(O[G]), W)) && (dt[G] = lt);
          return f(dt);
        }
        if (O.indexOf("on") === 0 && (O = O.substr(2)), typeof w != "object") return i("Target is not defined!", arguments);
        if (typeof L != "function") return i("Listener is not a function!", arguments);
        var Et = U.useCapture || !1, Dt = m(w) + "." + m(L) + "." + (Et ? 1 : 0);
        if (l.Gesture && l.Gesture._gestureHandlers[O]) {
          if (Dt = O + Dt, W === "remove") {
            if (!d[Dt]) return;
            d[Dt].remove(), delete d[Dt];
          } else if (W === "add") {
            if (d[Dt]) return d[Dt].add(), d[Dt];
            if (U.useCall && !l.modifyEventListener) {
              var Zt = L;
              L = function(se, Nt) {
                for (var ne in Nt) se[ne] = Nt[ne];
                return Zt.call(w, se);
              };
            }
            U.gesture = O, U.target = w, U.listener = L, U.fromOverwrite = I, d[Dt] = l.proxy[O](U);
          }
          return d[Dt];
        }
        var Ut, It = h(O);
        for (X = 0; X < It.length; X++) if (Ut = (O = It[X]) + "." + Dt, W === "remove") {
          if (!d[Ut]) continue;
          w[_](O, L, Et), delete d[Ut];
        } else if (W === "add") {
          if (d[Ut]) return d[Ut];
          w[y](O, L, Et), d[Ut] = { id: Ut, type: O, target: w, listener: L, remove: function() {
            for (var se = 0; se < It.length; se++) l.remove(w, It[se], L, U);
          } };
        }
        return d[Ut];
      }
    }, f = function(w) {
      return { remove: function() {
        for (var O in w) w[O].remove();
      }, add: function() {
        for (var O in w) w[O].add();
      } };
    }, i = function(w, O) {
      typeof console < "u" && console.error !== void 0 && console.error(w, O);
    }, r = { msPointer: ["MSPointerDown", "MSPointerMove", "MSPointerUp"], touch: ["touchstart", "touchmove", "touchend"], mouse: ["mousedown", "mousemove", "mouseup"] }, s = { MSPointerDown: 0, MSPointerMove: 1, MSPointerUp: 2, touchstart: 0, touchmove: 1, touchend: 2, mousedown: 0, mousemove: 1, mouseup: 2 };
    l.supports = {}, window.navigator.msPointerEnabled && (l.supports.msPointer = !0), l.getEventSupport("touchstart") && (l.supports.touch = !0), l.getEventSupport("mousedown") && (l.supports.mouse = !0);
    var h = function(w) {
      var O = document.addEventListener ? "" : "on", L = s[w];
      if (isFinite(L)) {
        var U = [];
        for (var W in l.supports) U.push(O + r[W][L]);
        return U;
      }
      return [O + w];
    }, d = {}, p = 0, m = function(w) {
      return w === window ? "#window" : w === document ? "#document" : (w.uniqueID || (w.uniqueID = "e" + p++), w.uniqueID);
    }, y = document.addEventListener ? "addEventListener" : "attachEvent", _ = document.removeEventListener ? "removeEventListener" : "detachEvent";
    l.createPointerEvent = function(w, O, L) {
      var U = O.gesture, W = O.target, I = w.changedTouches || l.proxy.getCoords(w);
      if (I.length) {
        var M = I[0];
        O.pointers = L ? [] : I, O.pageX = M.pageX, O.pageY = M.pageY, O.x = O.pageX, O.y = O.pageY;
      }
      var B = document.createEvent("Event");
      for (var Z in B.initEvent(U, !0, !0), B.originalEvent = w, O) Z !== "target" && (B[Z] = O[Z]);
      var J = B.type;
      l.Gesture && l.Gesture._gestureHandlers[J] && O.oldListener.call(W, B, O, !1);
    };
    var k = !1, T = function() {
      if (window.HTMLElement) {
        var w = function(O) {
          var L = function(U) {
            var W = U + "EventListener", I = O[W];
            O[W] = function(M, B, Z) {
              if (l.Gesture && l.Gesture._gestureHandlers[M]) {
                var J = Z;
                typeof Z == "object" ? J.useCall = !0 : J = { useCall: !0, useCapture: Z }, c(this, M, B, J, U, !0);
              } else for (var G = h(M), F = 0; F < G.length; F++) I.call(this, G[F], B, Z);
            };
          };
          L("add"), L("remove");
        };
        navigator.userAgent.match(/Firefox/) ? (w(HTMLDivElement.prototype), w(HTMLCanvasElement.prototype)) : w(HTMLElement.prototype), w(document), w(window);
      }
    }, D = !1, j = function() {
      var w = NodeList.prototype;
      w.removeEventListener = function(O, L, U) {
        for (var W = 0, I = this.length; W < I; W++) this[W].removeEventListener(O, L, U);
      }, w.addEventListener = function(O, L, U) {
        for (var W = 0, I = this.length; W < I; W++) this[W].addEventListener(O, L, U);
      };
    };
  }(P), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    l.pointerSetup = function(s, h) {
      s.target = s.target || window, s.doc = s.target.ownerDocument || s.target, s.minFingers = s.minFingers || s.fingers || 1, s.maxFingers = s.maxFingers || s.fingers || 1 / 0, s.position = s.position || "relative", delete s.fingers, (h = h || {}).enabled = !0, h.gesture = s.gesture, h.target = s.target, h.env = s.env, P.modifyEventListener && s.fromOverwrite && (s.oldListener = s.listener, s.listener = P.createPointerEvent);
      var d = 0, p = h.gesture.indexOf("pointer") === 0 && P.modifyEventListener ? "pointer" : "mouse";
      return s.oldListener && (h.oldListener = s.oldListener), h.listener = s.listener, h.proxy = function(m) {
        h.defaultListener = s.listener, s.listener = m, m(s.event, h);
      }, h.add = function() {
        h.enabled !== !0 && (s.onPointerDown && P.add(s.target, p + "down", s.onPointerDown), s.onPointerMove && P.add(s.doc, p + "move", s.onPointerMove), s.onPointerUp && P.add(s.doc, p + "up", s.onPointerUp), h.enabled = !0);
      }, h.remove = function() {
        h.enabled !== !1 && (s.onPointerDown && P.remove(s.target, p + "down", s.onPointerDown), s.onPointerMove && P.remove(s.doc, p + "move", s.onPointerMove), s.onPointerUp && P.remove(s.doc, p + "up", s.onPointerUp), h.reset(), h.enabled = !1);
      }, h.pause = function(m) {
        !s.onPointerMove || m && !m.move || P.remove(s.doc, p + "move", s.onPointerMove), !s.onPointerUp || m && !m.up || P.remove(s.doc, p + "up", s.onPointerUp), d = s.fingers, s.fingers = 0;
      }, h.resume = function(m) {
        !s.onPointerMove || m && !m.move || P.add(s.doc, p + "move", s.onPointerMove), !s.onPointerUp || m && !m.up || P.add(s.doc, p + "up", s.onPointerUp), s.fingers = d;
      }, h.reset = function() {
        s.tracker = {}, s.fingers = 0;
      }, h;
    };
    var a = P.supports;
    P.isMouse = !!a.mouse, P.isMSPointer = !!a.touch, P.isTouch = !!a.msPointer, l.pointerStart = function(s, h, d) {
      var p = (s.type || "mousedown").toUpperCase();
      p.indexOf("MOUSE") === 0 ? (P.isMouse = !0, P.isTouch = !1, P.isMSPointer = !1) : p.indexOf("TOUCH") === 0 ? (P.isMouse = !1, P.isTouch = !0, P.isMSPointer = !1) : p.indexOf("MSPOINTER") === 0 && (P.isMouse = !1, P.isTouch = !1, P.isMSPointer = !0);
      var m = function(U, W) {
        var I = d.bbox, M = _[W] = {};
        switch (d.position) {
          case "absolute":
            M.offsetX = 0, M.offsetY = 0;
            break;
          case "differenceFromLast":
          case "difference":
            M.offsetX = U.pageX, M.offsetY = U.pageY;
            break;
          case "move":
            M.offsetX = U.pageX - I.x1, M.offsetY = U.pageY - I.y1;
            break;
          default:
            M.offsetX = I.x1 - I.scrollLeft, M.offsetY = I.y1 - I.scrollTop;
        }
        var B = U.pageX - M.offsetX, Z = U.pageY - M.offsetY;
        M.rotation = 0, M.scale = 1, M.startTime = M.moveTime = (/* @__PURE__ */ new Date()).getTime(), M.move = { x: B, y: Z }, M.start = { x: B, y: Z }, d.fingers++;
      };
      d.event = s, h.defaultListener && (d.listener = h.defaultListener, delete h.defaultListener);
      for (var y = !d.fingers, _ = d.tracker, k = s.changedTouches || l.getCoords(s), T = k.length, D = 0; D < T; D++) {
        var j = k[D], w = j.identifier || 1 / 0;
        if (d.fingers) {
          if (d.fingers >= d.maxFingers) {
            var O = [];
            for (var w in d.tracker) O.push(w);
            return h.identifier = O.join(","), y;
          }
          for (var L in _) if (_[L].up) {
            delete _[L], m(j, w), d.cancel = !0;
            break;
          }
          if (_[w]) continue;
          m(j, w);
        } else _ = d.tracker = {}, h.bbox = d.bbox = l.getBoundingBox(d.target), d.fingers = 0, d.cancel = !1, m(j, w);
      }
      O = [];
      for (var w in d.tracker) O.push(w);
      return h.identifier = O.join(","), y;
    }, l.pointerEnd = function(s, h, d, p) {
      for (var m = s.touches || [], y = m.length, _ = {}, k = 0; k < y; k++)
        _[(T = m[k].identifier) || 1 / 0] = !0;
      for (var T in d.tracker) {
        var D = d.tracker[T];
        _[T] || D.up || (p && p({ pageX: D.pageX, pageY: D.pageY, changedTouches: [{ pageX: D.pageX, pageY: D.pageY, identifier: T === "Infinity" ? 1 / 0 : T }] }, "up"), D.up = !0, d.fingers--);
      }
      if (d.fingers !== 0) return !1;
      var j = [];
      for (var T in d.gestureFingers = 0, d.tracker) d.gestureFingers++, j.push(T);
      return h.identifier = j.join(","), !0;
    }, l.getCoords = function(s) {
      return s.pageX !== void 0 ? l.getCoords = function(h) {
        return Array({ type: "mouse", x: h.pageX, y: h.pageY, pageX: h.pageX, pageY: h.pageY, identifier: h.pointerId || 1 / 0 });
      } : l.getCoords = function(h) {
        var d = document.documentElement;
        return h = h || window.event, Array({ type: "mouse", x: h.clientX + d.scrollLeft, y: h.clientY + d.scrollTop, pageX: h.clientX + d.scrollLeft, pageY: h.clientY + d.scrollTop, identifier: 1 / 0 });
      }, l.getCoords(s);
    }, l.getCoord = function(s) {
      if ("ontouchstart" in window) {
        var h = 0, d = 0;
        l.getCoord = function(p) {
          var m = p.changedTouches;
          return m && m.length ? { x: h = m[0].pageX, y: d = m[0].pageY } : { x: h, y: d };
        };
      } else s.pageX !== void 0 && s.pageY !== void 0 ? l.getCoord = function(p) {
        return { x: p.pageX, y: p.pageY };
      } : l.getCoord = function(p) {
        var m = document.documentElement;
        return { x: (p = p || window.event).clientX + m.scrollLeft, y: p.clientY + m.scrollTop };
      };
      return l.getCoord(s);
    };
    var c, f, i, r = function(s, h) {
      var d = parseFloat(s.getPropertyValue(h), 10);
      return isFinite(d) ? d : 0;
    };
    return l.getBoundingBox = function(s) {
      s !== window && s !== document || (s = document.body);
      var h = {}, d = s.getBoundingClientRect();
      if (h.width = d.width, h.height = d.height, h.x1 = d.left, h.y1 = d.top, h.scaleX = d.width / s.offsetWidth || 1, h.scaleY = d.height / s.offsetHeight || 1, h.scrollLeft = 0, h.scrollTop = 0, (T = window.getComputedStyle(s)).getPropertyValue("box-sizing") !== "border-box") {
        var p = r(T, "border-left-width"), m = r(T, "border-right-width"), y = r(T, "border-bottom-width"), _ = r(T, "border-top-width");
        h.border = [p, m, _, y], h.x1 += p, h.y1 += _, h.width -= m + p, h.height -= y + _;
      }
      h.x2 = h.x1 + h.width, h.y2 = h.y1 + h.height;
      for (var k = (D = T.getPropertyValue("position")) === "fixed" ? s : s.parentNode; k !== null && k !== document.body && k.scrollTop !== void 0; ) {
        var T, D;
        if ((D = (T = window.getComputedStyle(k)).getPropertyValue("position")) !== "absolute") {
          if (D === "fixed") {
            h.scrollTop -= k.parentNode.scrollTop, h.scrollLeft -= k.parentNode.scrollLeft;
            break;
          }
          h.scrollLeft += k.scrollLeft, h.scrollTop += k.scrollTop;
        }
        k = k.parentNode;
      }
      return h.scrollBodyLeft = window.pageXOffset !== void 0 ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft, h.scrollBodyTop = window.pageYOffset !== void 0 ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop, h.scrollLeft -= h.scrollBodyLeft, h.scrollTop -= h.scrollBodyTop, h;
    }, f = navigator.userAgent.toLowerCase(), i = f.indexOf("macintosh") !== -1, c = i && f.indexOf("khtml") !== -1 ? { 91: !0, 93: !0 } : i && f.indexOf("firefox") !== -1 ? { 224: !0 } : { 17: !0 }, (l.metaTrackerReset = function() {
      P.fnKey = l.fnKey = !1, P.metaKey = l.metaKey = !1, P.escKey = l.escKey = !1, P.ctrlKey = l.ctrlKey = !1, P.shiftKey = l.shiftKey = !1, P.altKey = l.altKey = !1;
    })(), l.metaTracker = function(s) {
      var h = s.type === "keydown";
      s.keyCode === 27 && (P.escKey = l.escKey = h), c[s.keyCode] && (P.metaKey = l.metaKey = h), P.ctrlKey = l.ctrlKey = s.ctrlKey, P.shiftKey = l.shiftKey = s.shiftKey, P.altKey = l.altKey = s.altKey;
    }, l;
  }(P.proxy), P === void 0 && (P = {}), P.MutationObserver = (e = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver, n = !e && function() {
    var l = document.createElement("p"), a = !1, c = function() {
      a = !0;
    };
    if (l.addEventListener) l.addEventListener("DOMAttrModified", c, !1);
    else {
      if (!l.attachEvent) return !1;
      l.attachEvent("onDOMAttrModified", c);
    }
    return l.setAttribute("id", "target"), a;
  }(), function(l, a) {
    e ? new e(function(c) {
      c.forEach(function(f) {
        a.call(f.target, f.attributeName);
      });
    }).observe(l, { subtree: !1, attributes: !0 }) : n ? P.add(l, "DOMAttrModified", function(c) {
      a.call(l, c.attrName);
    }) : "onpropertychange" in document.body && P.add(l, "propertychange", function(c) {
      a.call(l, window.event.propertyName);
    });
  }), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = ((o = P.proxy).click = function(l) {
    l.gesture = l.gesture || "click", l.maxFingers = l.maxFingers || l.fingers || 1, l.onPointerDown = function(c) {
      o.pointerStart(c, a, l) && P.add(l.target, "mouseup", l.onPointerUp);
    }, l.onPointerUp = function(c) {
      if (o.pointerEnd(c, a, l)) {
        P.remove(l.target, "mouseup", l.onPointerUp);
        var f = (c.changedTouches || o.getCoords(c))[0], i = l.bbox, r = o.getBoundingBox(l.target), s = f.pageY - r.scrollBodyTop, h = f.pageX - r.scrollBodyLeft;
        if (h > i.x1 && s > i.y1 && h < i.x2 && s < i.y2 && i.scrollTop === r.scrollTop) {
          for (var d in l.tracker) break;
          var p = l.tracker[d];
          a.x = p.start.x, a.y = p.start.y, l.listener(c, a);
        }
      }
    };
    var a = o.pointerSetup(l);
    return a.state = "click", P.add(l.target, "mousedown", l.onPointerDown), a;
  }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.click = o.click, o), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.dbltap = l.dblclick = function(a) {
      a.gesture = a.gesture || "dbltap", a.maxFingers = a.maxFingers || a.fingers || 1;
      var c, f, i, r, s;
      a.onPointerDown = function(d) {
        var p = d.changedTouches || l.getCoords(d);
        c && !f ? (s = p[0], f = (/* @__PURE__ */ new Date()).getTime() - c) : (r = p[0], c = (/* @__PURE__ */ new Date()).getTime(), f = 0, clearTimeout(i), i = setTimeout(function() {
          c = 0;
        }, 700)), l.pointerStart(d, h, a) && (P.add(a.target, "mousemove", a.onPointerMove).listener(d), P.add(a.target, "mouseup", a.onPointerUp));
      }, a.onPointerMove = function(d) {
        if (c && !f) {
          var p = d.changedTouches || l.getCoords(d);
          s = p[0];
        }
        var m = a.bbox, y = s.pageX - m.x1, _ = s.pageY - m.y1;
        y > 0 && y < m.width && _ > 0 && _ < m.height && Math.abs(s.pageX - r.pageX) <= 25 && Math.abs(s.pageY - r.pageY) <= 25 || (P.remove(a.target, "mousemove", a.onPointerMove), clearTimeout(i), c = f = 0);
      }, a.onPointerUp = function(d) {
        if (l.pointerEnd(d, h, a) && (P.remove(a.target, "mousemove", a.onPointerMove), P.remove(a.target, "mouseup", a.onPointerUp)), c && f) {
          if (f <= 700) {
            for (var p in h.state = a.gesture, a.tracker) break;
            var m = a.tracker[p];
            h.x = m.start.x, h.y = m.start.y, a.listener(d, h);
          }
          clearTimeout(i), c = f = 0;
        }
      };
      var h = l.pointerSetup(a);
      return h.state = "dblclick", P.add(a.target, "mousedown", a.onPointerDown), h;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.dbltap = l.dbltap, P.Gesture._gestureHandlers.dblclick = l.dblclick, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.dragElement = function(a, c) {
      l.drag({ event: c, target: a, position: "move", listener: function(f, i) {
        a.style.left = i.x + "px", a.style.top = i.y + "px", P.prevent(f);
      } });
    }, l.drag = function(a) {
      a.gesture = "drag", a.onPointerDown = function(f) {
        l.pointerStart(f, c, a) && (a.monitor || (P.add(a.doc, "mousemove", a.onPointerMove), P.add(a.doc, "mouseup", a.onPointerUp))), a.onPointerMove(f, "down");
      }, a.onPointerMove = function(f, i) {
        if (!a.tracker) return a.onPointerDown(f);
        a.bbox;
        for (var r = f.changedTouches || l.getCoords(f), s = r.length, h = 0; h < s; h++) {
          var d = r[h], p = d.identifier || 1 / 0, m = a.tracker[p];
          m && (m.pageX = d.pageX, m.pageY = d.pageY, c.state = i || "move", c.identifier = p, c.start = m.start, c.fingers = a.fingers, a.position === "differenceFromLast" ? (c.x = m.pageX - m.offsetX, c.y = m.pageY - m.offsetY, m.offsetX = m.pageX, m.offsetY = m.pageY) : (c.x = m.pageX - m.offsetX, c.y = m.pageY - m.offsetY), a.listener(f, c));
        }
      }, a.onPointerUp = function(f) {
        l.pointerEnd(f, c, a, a.onPointerMove) && (a.monitor || (P.remove(a.doc, "mousemove", a.onPointerMove), P.remove(a.doc, "mouseup", a.onPointerUp)));
      };
      var c = l.pointerSetup(a);
      return a.event ? a.onPointerDown(a.event) : (P.add(a.target, "mousedown", a.onPointerDown), a.monitor && (P.add(a.doc, "mousemove", a.onPointerMove), P.add(a.doc, "mouseup", a.onPointerUp))), c;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.drag = l.drag, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    var a = Math.PI / 180, c = function(f, i) {
      var r = 0, s = 0, h = 0;
      for (var d in i) {
        var p = i[d];
        p.up || (r += p.move.x, s += p.move.y, h++);
      }
      return f.x = r /= h, f.y = s /= h, f;
    };
    return l.gesture = function(f) {
      f.gesture = f.gesture || "gesture", f.minFingers = f.minFingers || f.fingers || 2, f.onPointerDown = function(r) {
        var s = f.fingers;
        if (l.pointerStart(r, i, f) && (P.add(f.doc, "mousemove", f.onPointerMove), P.add(f.doc, "mouseup", f.onPointerUp)), f.fingers === f.minFingers && s !== f.fingers) {
          i.fingers = f.minFingers, i.scale = 1, i.rotation = 0, i.state = "start";
          var h = "";
          for (var d in f.tracker) h += d;
          i.identifier = parseInt(h), c(i, f.tracker), f.listener(r, i);
        }
      }, f.onPointerMove = function(r, s) {
        for (var h = f.bbox, d = f.tracker, p = (_ = r.changedTouches || l.getCoords(r)).length, m = 0; m < p; m++) {
          var y = d[D = (j = _[m]).identifier || 1 / 0];
          y && (y.move.x = j.pageX - h.x1, y.move.y = j.pageY - h.y1);
        }
        if (!(f.fingers < f.minFingers)) {
          var _ = [], k = 0, T = 0;
          for (var D in c(i, d), d) {
            var j;
            if (!(j = d[D]).up) {
              var w = j.start;
              if (!w.distance) {
                var O = w.x - i.x, L = w.y - i.y;
                w.distance = Math.sqrt(O * O + L * L), w.angle = Math.atan2(O, L) / a;
              }
              O = j.move.x - i.x, L = j.move.y - i.y, k += Math.sqrt(O * O + L * L) / w.distance;
              var U = Math.atan2(O, L) / a, W = (w.angle - U + 360) % 360 - 180;
              j.DEG2 = j.DEG1, j.DEG1 = W > 0 ? W : -W, j.DEG2 !== void 0 && (W > 0 ? j.rotation += j.DEG1 - j.DEG2 : j.rotation -= j.DEG1 - j.DEG2, T += j.rotation), _.push(j.move);
            }
          }
          i.touches = _, i.fingers = f.fingers, i.scale = k / f.fingers, i.rotation = T / f.fingers, i.state = "change", f.listener(r, i);
        }
      }, f.onPointerUp = function(r) {
        var s = f.fingers;
        l.pointerEnd(r, i, f) && (P.remove(f.doc, "mousemove", f.onPointerMove), P.remove(f.doc, "mouseup", f.onPointerUp)), s === f.minFingers && f.fingers < f.minFingers && (i.fingers = f.fingers, i.state = "end", f.listener(r, i));
      };
      var i = l.pointerSetup(f);
      return P.add(f.target, "mousedown", f.onPointerDown), i;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.gesture = l.gesture, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.pointerdown = l.pointermove = l.pointerup = function(a) {
      if (a.gesture = a.gesture || "pointer", !a.target.isPointerEmitter) {
        var c = !0;
        a.onPointerDown = function(i) {
          c = !1, f.gesture = "pointerdown", a.listener(i, f);
        }, a.onPointerMove = function(i) {
          f.gesture = "pointermove", a.listener(i, f, c);
        }, a.onPointerUp = function(i) {
          c = !0, f.gesture = "pointerup", a.listener(i, f, !0);
        };
        var f = l.pointerSetup(a);
        return P.add(a.target, "mousedown", a.onPointerDown), P.add(a.target, "mousemove", a.onPointerMove), P.add(a.doc, "mouseup", a.onPointerUp), a.target.isPointerEmitter = !0, f;
      }
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.pointerdown = l.pointerdown, P.Gesture._gestureHandlers.pointermove = l.pointermove, P.Gesture._gestureHandlers.pointerup = l.pointerup, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.shake = function(a) {
      var c = { gesture: "devicemotion", acceleration: {}, accelerationIncludingGravity: {}, target: a.target, listener: a.listener, remove: function() {
        window.removeEventListener("devicemotion", s, !1);
      } }, f = (/* @__PURE__ */ new Date()).getTime(), i = { x: 0, y: 0, z: 0 }, r = { x: { count: 0, value: 0 }, y: { count: 0, value: 0 }, z: { count: 0, value: 0 } }, s = function(h) {
        var d = 0.8, p = h.accelerationIncludingGravity;
        if (i.x = d * i.x + (1 - d) * p.x, i.y = d * i.y + (1 - d) * p.y, i.z = d * i.z + (1 - d) * p.z, c.accelerationIncludingGravity = i, c.acceleration.x = p.x - i.x, c.acceleration.y = p.y - i.y, c.acceleration.z = p.z - i.z, a.gesture !== "devicemotion") for (var m = (/* @__PURE__ */ new Date()).getTime(), y = 0; y < 3; y++) {
          var _ = "xyz"[y], k = c.acceleration[_], T = r[_], D = Math.abs(k);
          if (!(m - f < 1e3) && D > 4) {
            var j = m * k / D, w = Math.abs(j + T.value);
            T.value && w < 200 ? (T.value = j, T.count++, T.count === 3 && (a.listener(h, c), f = m, T.value = 0, T.count = 0)) : (T.value = j, T.count = 1);
          }
        }
        else a.listener(h, c);
      };
      if (window.addEventListener) return window.addEventListener("devicemotion", s, !1), c;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.shake = l.shake, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    var a = Math.PI / 180;
    return l.swipe = function(c) {
      c.snap = c.snap || 90, c.threshold = c.threshold || 1, c.gesture = c.gesture || "swipe", c.onPointerDown = function(i) {
        l.pointerStart(i, f, c) && (P.add(c.doc, "mousemove", c.onPointerMove).listener(i), P.add(c.doc, "mouseup", c.onPointerUp));
      }, c.onPointerMove = function(i) {
        for (var r = i.changedTouches || l.getCoords(i), s = r.length, h = 0; h < s; h++) {
          var d = r[h], p = d.identifier || 1 / 0, m = c.tracker[p];
          m && (m.move.x = d.pageX, m.move.y = d.pageY, m.moveTime = (/* @__PURE__ */ new Date()).getTime());
        }
      }, c.onPointerUp = function(i) {
        if (l.pointerEnd(i, f, c)) {
          var r, s;
          P.remove(c.doc, "mousemove", c.onPointerMove), P.remove(c.doc, "mouseup", c.onPointerUp);
          var h = { x: 0, y: 0 }, d = 0, p = 0, m = 0;
          for (var y in c.tracker) {
            var _ = c.tracker[y], k = _.move.x - _.start.x, T = _.move.y - _.start.y;
            d += _.move.x, p += _.move.y, h.x += _.start.x, h.y += _.start.y, m++;
            var D = Math.sqrt(k * k + T * T), j = _.moveTime - _.startTime, w = Math.atan2(k, T) / a + 180, O = j ? D / j : 0;
            if (s === void 0) s = w, r = O;
            else {
              if (!(Math.abs(w - s) <= 20)) return;
              s = (s + w) / 2, r = (r + O) / 2;
            }
          }
          var L = c.gestureFingers;
          c.minFingers <= L && c.maxFingers >= L && r > c.threshold && (h.x /= m, h.y /= m, f.start = h, f.x = d / m, f.y = p / m, f.angle = -(((s / c.snap + 0.5 >> 0) * c.snap || 360) - 360), f.velocity = r, f.fingers = L, f.state = "swipe", c.listener(i, f));
        }
      };
      var f = l.pointerSetup(c);
      return P.add(c.target, "mousedown", c.onPointerDown), f;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.swipe = l.swipe, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.longpress = function(a) {
      return a.gesture = "longpress", l.tap(a);
    }, l.tap = function(a) {
      var c, f;
      a.delay = a.delay || 500, a.timeout = a.timeout || 250, a.driftDeviance = a.driftDeviance || 10, a.gesture = a.gesture || "tap", a.onPointerDown = function(r) {
        if (l.pointerStart(r, i, a)) {
          if (c = (/* @__PURE__ */ new Date()).getTime(), P.add(a.doc, "mousemove", a.onPointerMove).listener(r), P.add(a.doc, "mouseup", a.onPointerUp), a.gesture !== "longpress") return;
          f = setTimeout(function() {
            if (!(r.cancelBubble && ++r.cancelBubbleCount > 1)) {
              var s = 0;
              for (var h in a.tracker) {
                var d = a.tracker[h];
                if (d.end === !0 || a.cancel) return;
                s++;
              }
              a.minFingers <= s && a.maxFingers >= s && (i.state = "start", i.fingers = s, i.x = d.start.x, i.y = d.start.y, a.listener(r, i));
            }
          }, a.delay);
        }
      }, a.onPointerMove = function(r) {
        for (var s = a.bbox, h = r.changedTouches || l.getCoords(r), d = h.length, p = 0; p < d; p++) {
          var m = h[p], y = m.identifier || 1 / 0, _ = a.tracker[y];
          if (_) {
            var k = m.pageX - s.x1, T = m.pageY - s.y1, D = k - _.start.x, j = T - _.start.y, w = Math.sqrt(D * D + j * j);
            if (!(k > 0 && k < s.width && T > 0 && T < s.height && w <= a.driftDeviance)) return P.remove(a.doc, "mousemove", a.onPointerMove), void (a.cancel = !0);
          }
        }
      }, a.onPointerUp = function(r) {
        if (l.pointerEnd(r, i, a)) {
          if (clearTimeout(f), P.remove(a.doc, "mousemove", a.onPointerMove), P.remove(a.doc, "mouseup", a.onPointerUp), r.cancelBubble && ++r.cancelBubbleCount > 1) return;
          if (a.gesture === "longpress") return void (i.state === "start" && (i.state = "end", a.listener(r, i)));
          if (a.cancel || (/* @__PURE__ */ new Date()).getTime() - c > a.timeout) return;
          var s = a.gestureFingers;
          a.minFingers <= s && a.maxFingers >= s && (i.state = "tap", i.fingers = a.gestureFingers, a.listener(r, i));
        }
      };
      var i = l.pointerSetup(a);
      return P.add(a.target, "mousedown", a.onPointerDown), i;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.tap = l.tap, P.Gesture._gestureHandlers.longpress = l.longpress, l;
  }(P.proxy), P === void 0 && (P = {}), P.proxy === void 0 && (P.proxy = {}), P.proxy = function(l) {
    return l.wheelPreventElasticBounce = function(a) {
      a && (typeof a == "string" && (a = document.querySelector(a)), P.add(a, "wheel", function(c, f) {
        f.preventElasticBounce(), P.stop(c);
      }));
    }, l.wheel = function(a) {
      var c, f = a.timeout || 150, i = 0, r = { gesture: "wheel", state: "start", wheelDelta: 0, target: a.target, listener: a.listener, preventElasticBounce: function(m) {
        var y = this.target, _ = y.scrollTop;
        (_ + y.offsetHeight === y.scrollHeight && this.wheelDelta <= 0 || _ === 0 && this.wheelDelta >= 0) && P.cancel(m), P.stop(m);
      }, add: function() {
        a.target[h](p, s, !1);
      }, remove: function() {
        a.target[d](p, s, !1);
      } }, s = function(m) {
        m = m || window.event, r.state = i++ ? "change" : "start", r.wheelDelta = m.detail ? -20 * m.detail : m.wheelDelta, a.listener(m, r), clearTimeout(c), c = setTimeout(function() {
          i = 0, r.state = "end", r.wheelDelta = 0, a.listener(m, r);
        }, f);
      }, h = document.addEventListener ? "addEventListener" : "attachEvent", d = document.removeEventListener ? "removeEventListener" : "detachEvent", p = P.getEventSupport("mousewheel") ? "mousewheel" : "DOMMouseScroll";
      return a.target[h](p, s, !1), r;
    }, P.Gesture = P.Gesture || {}, P.Gesture._gestureHandlers = P.Gesture._gestureHandlers || {}, P.Gesture._gestureHandlers.wheel = l.wheel, l;
  }(P.proxy), nt === void 0) var nt = {};
  function bt(l, a) {
    var c = l.canvas, f = a.targetCanvas, i = f.getContext("2d");
    i.translate(0, f.height), i.scale(1, -1);
    var r = c.height - f.height;
    i.drawImage(c, 0, r, f.width, f.height, 0, 0, f.width, f.height);
  }
  function ht(l, a) {
    var c = a.targetCanvas.getContext("2d"), f = a.destinationWidth, i = a.destinationHeight, r = f * i * 4, s = new Uint8Array(this.imageBuffer, 0, r), h = new Uint8ClampedArray(this.imageBuffer, 0, r);
    l.readPixels(0, 0, f, i, l.RGBA, l.UNSIGNED_BYTE, s);
    var d = new ImageData(h, f, i);
    c.putImageData(d, 0, 0);
  }
  nt.proxy === void 0 && (nt.proxy = {}), nt.proxy = function(l) {
    return l.orientation = function(a) {
      var c = { gesture: "orientationchange", previous: null, current: window.orientation, target: a.target, listener: a.listener, remove: function() {
        window.removeEventListener("orientationchange", f, !1);
      } }, f = function(i) {
        c.previous = c.current, c.current = window.orientation, c.previous === null || c.previous == c.current || a.listener(i, c);
      };
      return window.DeviceOrientationEvent && window.addEventListener("orientationchange", f, !1), c;
    }, nt.Gesture = nt.Gesture || {}, nt.Gesture._gestureHandlers = nt.Gesture._gestureHandlers || {}, nt.Gesture._gestureHandlers.orientation = l.orientation, l;
  }(nt.proxy), function() {
    function l(c, f) {
      if (this.__eventListeners[c]) {
        var i = this.__eventListeners[c];
        f ? i[i.indexOf(f)] = !1 : b.util.array.fill(i, !1);
      }
    }
    function a(c, f) {
      var i = (function() {
        f.apply(this, arguments), this.off(c, i);
      }).bind(this);
      this.on(c, i);
    }
    b.Observable = { fire: function(c, f) {
      if (!this.__eventListeners) return this;
      var i = this.__eventListeners[c];
      if (!i) return this;
      for (var r = 0, s = i.length; r < s; r++) i[r] && i[r].call(this, f || {});
      return this.__eventListeners[c] = i.filter(function(h) {
        return h !== !1;
      }), this;
    }, on: function(c, f) {
      if (this.__eventListeners || (this.__eventListeners = {}), arguments.length === 1) for (var i in c) this.on(i, c[i]);
      else this.__eventListeners[c] || (this.__eventListeners[c] = []), this.__eventListeners[c].push(f);
      return this;
    }, once: function(c, f) {
      if (arguments.length === 1) for (var i in c) a.call(this, i, c[i]);
      else a.call(this, c, f);
      return this;
    }, off: function(c, f) {
      if (!this.__eventListeners) return this;
      if (arguments.length === 0) for (c in this.__eventListeners) l.call(this, c);
      else if (arguments.length === 1 && typeof arguments[0] == "object") for (var i in c) l.call(this, i, c[i]);
      else l.call(this, c, f);
      return this;
    } };
  }(), b.Collection = { _objects: [], add: function() {
    if (this._objects.push.apply(this._objects, arguments), this._onObjectAdded) for (var l = 0, a = arguments.length; l < a; l++) this._onObjectAdded(arguments[l]);
    return this.renderOnAddRemove && this.requestRenderAll(), this;
  }, insertAt: function(l, a, c) {
    var f = this._objects;
    return c ? f[a] = l : f.splice(a, 0, l), this._onObjectAdded && this._onObjectAdded(l), this.renderOnAddRemove && this.requestRenderAll(), this;
  }, remove: function() {
    for (var l, a = this._objects, c = !1, f = 0, i = arguments.length; f < i; f++) (l = a.indexOf(arguments[f])) !== -1 && (c = !0, a.splice(l, 1), this._onObjectRemoved && this._onObjectRemoved(arguments[f]));
    return this.renderOnAddRemove && c && this.requestRenderAll(), this;
  }, forEachObject: function(l, a) {
    for (var c = this.getObjects(), f = 0, i = c.length; f < i; f++) l.call(a, c[f], f, c);
    return this;
  }, getObjects: function(l) {
    return l === void 0 ? this._objects.concat() : this._objects.filter(function(a) {
      return a.type === l;
    });
  }, item: function(l) {
    return this._objects[l];
  }, isEmpty: function() {
    return this._objects.length === 0;
  }, size: function() {
    return this._objects.length;
  }, contains: function(l, a) {
    return this._objects.indexOf(l) > -1 || !!a && this._objects.some(function(c) {
      return typeof c.contains == "function" && c.contains(l, !0);
    });
  }, complexity: function() {
    return this._objects.reduce(function(l, a) {
      return l += a.complexity ? a.complexity() : 0;
    }, 0);
  } }, b.CommonMethods = { _setOptions: function(l) {
    for (var a in l) this.set(a, l[a]);
  }, _initGradient: function(l, a) {
    !l || !l.colorStops || l instanceof b.Gradient || this.set(a, new b.Gradient(l));
  }, _initPattern: function(l, a, c) {
    !l || !l.source || l instanceof b.Pattern ? c && c() : this.set(a, new b.Pattern(l, c));
  }, _setObject: function(l) {
    for (var a in l) this._set(a, l[a]);
  }, set: function(l, a) {
    return typeof l == "object" ? this._setObject(l) : this._set(l, a), this;
  }, _set: function(l, a) {
    this[l] = a;
  }, toggle: function(l) {
    var a = this.get(l);
    return typeof a == "boolean" && this.set(l, !a), this;
  }, get: function(l) {
    return this[l];
  } }, u = t, g = Math.sqrt, v = Math.atan2, x = Math.pow, S = Math.PI / 180, E = Math.PI / 2, b.util = { cos: function(l) {
    if (l === 0) return 1;
    switch (l < 0 && (l = -l), l / E) {
      case 1:
      case 3:
        return 0;
      case 2:
        return -1;
    }
    return Math.cos(l);
  }, sin: function(l) {
    if (l === 0) return 0;
    var a = 1;
    switch (l < 0 && (a = -1), l / E) {
      case 1:
        return a;
      case 2:
        return 0;
      case 3:
        return -a;
    }
    return Math.sin(l);
  }, removeFromArray: function(l, a) {
    var c = l.indexOf(a);
    return c !== -1 && l.splice(c, 1), l;
  }, getRandomInt: function(l, a) {
    return Math.floor(Math.random() * (a - l + 1)) + l;
  }, degreesToRadians: function(l) {
    return l * S;
  }, radiansToDegrees: function(l) {
    return l / S;
  }, rotatePoint: function(l, a, c) {
    var f = new b.Point(l.x - a.x, l.y - a.y), i = b.util.rotateVector(f, c);
    return new b.Point(i.x, i.y).addEquals(a);
  }, rotateVector: function(l, a) {
    var c = b.util.sin(a), f = b.util.cos(a);
    return { x: l.x * f - l.y * c, y: l.x * c + l.y * f };
  }, transformPoint: function(l, a, c) {
    return c ? new b.Point(a[0] * l.x + a[2] * l.y, a[1] * l.x + a[3] * l.y) : new b.Point(a[0] * l.x + a[2] * l.y + a[4], a[1] * l.x + a[3] * l.y + a[5]);
  }, makeBoundingBoxFromPoints: function(l, a) {
    if (a) for (var c = 0; c < l.length; c++) l[c] = b.util.transformPoint(l[c], a);
    var f = [l[0].x, l[1].x, l[2].x, l[3].x], i = b.util.array.min(f), r = b.util.array.max(f) - i, s = [l[0].y, l[1].y, l[2].y, l[3].y], h = b.util.array.min(s);
    return { left: i, top: h, width: r, height: b.util.array.max(s) - h };
  }, invertTransform: function(l) {
    var a = 1 / (l[0] * l[3] - l[1] * l[2]), c = [a * l[3], -a * l[1], -a * l[2], a * l[0]], f = b.util.transformPoint({ x: l[4], y: l[5] }, c, !0);
    return c[4] = -f.x, c[5] = -f.y, c;
  }, toFixed: function(l, a) {
    return parseFloat(Number(l).toFixed(a));
  }, parseUnit: function(l, a) {
    var c = /\D{0,2}$/.exec(l), f = parseFloat(l);
    switch (a || (a = b.Text.DEFAULT_SVG_FONT_SIZE), c[0]) {
      case "mm":
        return f * b.DPI / 25.4;
      case "cm":
        return f * b.DPI / 2.54;
      case "in":
        return f * b.DPI;
      case "pt":
        return f * b.DPI / 72;
      case "pc":
        return f * b.DPI / 72 * 12;
      case "em":
        return f * a;
      default:
        return f;
    }
  }, falseFunction: function() {
    return !1;
  }, getKlass: function(l, a) {
    return l = b.util.string.camelize(l.charAt(0).toUpperCase() + l.slice(1)), b.util.resolveNamespace(a)[l];
  }, getSvgAttributes: function(l) {
    var a = ["instantiated_by_use", "style", "id", "class"];
    switch (l) {
      case "linearGradient":
        a = a.concat(["x1", "y1", "x2", "y2", "gradientUnits", "gradientTransform"]);
        break;
      case "radialGradient":
        a = a.concat(["gradientUnits", "gradientTransform", "cx", "cy", "r", "fx", "fy", "fr"]);
        break;
      case "stop":
        a = a.concat(["offset", "stop-color", "stop-opacity"]);
    }
    return a;
  }, resolveNamespace: function(l) {
    if (!l) return b;
    var a, c = l.split("."), f = c.length, i = u || b.window;
    for (a = 0; a < f; ++a) i = i[c[a]];
    return i;
  }, loadImage: function(l, a, c, f) {
    if (l) {
      var i = b.util.createImage(), r = function() {
        a && a.call(c, i, !1), i = i.onload = i.onerror = null;
      };
      i.onload = r, i.onerror = function() {
        b.log("Error loading " + i.src), a && a.call(c, null, !0), i = i.onload = i.onerror = null;
      }, l.indexOf("data") !== 0 && f != null && (i.crossOrigin = f), l.substring(0, 14) === "data:image/svg" && (i.onload = null, b.util.loadImageInDom(i, r)), i.src = l;
    } else a && a.call(c, l);
  }, loadImageInDom: function(l, a) {
    var c = b.document.createElement("div");
    c.style.width = c.style.height = "1px", c.style.left = c.style.top = "-100%", c.style.position = "absolute", c.appendChild(l), b.document.querySelector("body").appendChild(c), l.onload = function() {
      a(), c.parentNode.removeChild(c), c = null;
    };
  }, enlivenObjects: function(l, a, c, f) {
    var i = [], r = 0, s = (l = l || []).length;
    function h() {
      ++r === s && a && a(i.filter(function(d) {
        return d;
      }));
    }
    s ? l.forEach(function(d, p) {
      d && d.type ? b.util.getKlass(d.type, c).fromObject(d, function(m, y) {
        y || (i[p] = m), f && f(d, m, y), h();
      }) : h();
    }) : a && a(i);
  }, enlivenPatterns: function(l, a) {
    function c() {
      ++i === r && a && a(f);
    }
    var f = [], i = 0, r = (l = l || []).length;
    r ? l.forEach(function(s, h) {
      s && s.source ? new b.Pattern(s, function(d) {
        f[h] = d, c();
      }) : (f[h] = s, c());
    }) : a && a(f);
  }, groupSVGElements: function(l, a, c) {
    var f;
    return l && l.length === 1 ? l[0] : (a && (a.width && a.height ? a.centerPoint = { x: a.width / 2, y: a.height / 2 } : (delete a.width, delete a.height)), f = new b.Group(l, a), c !== void 0 && (f.sourcePath = c), f);
  }, populateWithProperties: function(l, a, c) {
    if (c && Object.prototype.toString.call(c) === "[object Array]") for (var f = 0, i = c.length; f < i; f++) c[f] in l && (a[c[f]] = l[c[f]]);
  }, drawDashedLine: function(l, a, c, f, i, r) {
    var s = f - a, h = i - c, d = g(s * s + h * h), p = v(h, s), m = r.length, y = 0, _ = !0;
    for (l.save(), l.translate(a, c), l.moveTo(0, 0), l.rotate(p), a = 0; d > a; ) (a += r[y++ % m]) > d && (a = d), l[_ ? "lineTo" : "moveTo"](a, 0), _ = !_;
    l.restore();
  }, createCanvasElement: function() {
    return b.document.createElement("canvas");
  }, copyCanvasElement: function(l) {
    var a = b.util.createCanvasElement();
    return a.width = l.width, a.height = l.height, a.getContext("2d").drawImage(l, 0, 0), a;
  }, toDataURL: function(l, a, c) {
    return l.toDataURL("image/" + a, c);
  }, createImage: function() {
    return b.document.createElement("img");
  }, multiplyTransformMatrices: function(l, a, c) {
    return [l[0] * a[0] + l[2] * a[1], l[1] * a[0] + l[3] * a[1], l[0] * a[2] + l[2] * a[3], l[1] * a[2] + l[3] * a[3], c ? 0 : l[0] * a[4] + l[2] * a[5] + l[4], c ? 0 : l[1] * a[4] + l[3] * a[5] + l[5]];
  }, qrDecompose: function(l) {
    var a = v(l[1], l[0]), c = x(l[0], 2) + x(l[1], 2), f = g(c), i = (l[0] * l[3] - l[2] * l[1]) / f, r = v(l[0] * l[2] + l[1] * l[3], c);
    return { angle: a / S, scaleX: f, scaleY: i, skewX: r / S, skewY: 0, translateX: l[4], translateY: l[5] };
  }, calcRotateMatrix: function(l) {
    if (!l.angle) return b.iMatrix.concat();
    var a = b.util.degreesToRadians(l.angle), c = b.util.cos(a), f = b.util.sin(a);
    return [c, f, -f, c, 0, 0];
  }, calcDimensionsMatrix: function(l) {
    var a = l.scaleX === void 0 ? 1 : l.scaleX, c = l.scaleY === void 0 ? 1 : l.scaleY, f = [l.flipX ? -a : a, 0, 0, l.flipY ? -c : c, 0, 0], i = b.util.multiplyTransformMatrices, r = b.util.degreesToRadians;
    return l.skewX && (f = i(f, [1, 0, Math.tan(r(l.skewX)), 1], !0)), l.skewY && (f = i(f, [1, Math.tan(r(l.skewY)), 0, 1], !0)), f;
  }, composeMatrix: function(l) {
    var a = [1, 0, 0, 1, l.translateX || 0, l.translateY || 0], c = b.util.multiplyTransformMatrices;
    return l.angle && (a = c(a, b.util.calcRotateMatrix(l))), (l.scaleX !== 1 || l.scaleY !== 1 || l.skewX || l.skewY || l.flipX || l.flipY) && (a = c(a, b.util.calcDimensionsMatrix(l))), a;
  }, resetObjectTransform: function(l) {
    l.scaleX = 1, l.scaleY = 1, l.skewX = 0, l.skewY = 0, l.flipX = !1, l.flipY = !1, l.rotate(0);
  }, saveObjectTransform: function(l) {
    return { scaleX: l.scaleX, scaleY: l.scaleY, skewX: l.skewX, skewY: l.skewY, angle: l.angle, left: l.left, flipX: l.flipX, flipY: l.flipY, top: l.top };
  }, isTransparent: function(l, a, c, f) {
    f > 0 && (a > f ? a -= f : a = 0, c > f ? c -= f : c = 0);
    var i, r = !0, s = l.getImageData(a, c, 2 * f || 1, 2 * f || 1), h = s.data.length;
    for (i = 3; i < h && (r = s.data[i] <= 0); i += 4) ;
    return s = null, r;
  }, parsePreserveAspectRatioAttribute: function(l) {
    var a, c = "meet", f = l.split(" ");
    return f && f.length && ((c = f.pop()) !== "meet" && c !== "slice" ? (a = c, c = "meet") : f.length && (a = f.pop())), { meetOrSlice: c, alignX: a !== "none" ? a.slice(1, 4) : "none", alignY: a !== "none" ? a.slice(5, 8) : "none" };
  }, clearFabricFontCache: function(l) {
    (l = (l || "").toLowerCase()) ? b.charWidthsCache[l] && delete b.charWidthsCache[l] : b.charWidthsCache = {};
  }, limitDimsByArea: function(l, a) {
    var c = Math.sqrt(a * l), f = Math.floor(a / c);
    return { x: Math.floor(c), y: f };
  }, capValue: function(l, a, c) {
    return Math.max(l, Math.min(a, c));
  }, findScaleToFit: function(l, a) {
    return Math.min(a.width / l.width, a.height / l.height);
  }, findScaleToCover: function(l, a) {
    return Math.max(a.width / l.width, a.height / l.height);
  }, matrixToSVG: function(l) {
    return "matrix(" + l.map(function(a) {
      return b.util.toFixed(a, b.Object.NUM_FRACTION_DIGITS);
    }).join(" ") + ")";
  }, removeTransformFromObject: function(l, a) {
    var c = b.util.invertTransform(a), f = b.util.multiplyTransformMatrices(c, l.calcOwnMatrix());
    b.util.applyTransformToObject(l, f);
  }, addTransformToObject: function(l, a) {
    b.util.applyTransformToObject(l, b.util.multiplyTransformMatrices(a, l.calcOwnMatrix()));
  }, applyTransformToObject: function(l, a) {
    var c = b.util.qrDecompose(a), f = new b.Point(c.translateX, c.translateY);
    l.flipX = !1, l.flipY = !1, l.set("scaleX", c.scaleX), l.set("scaleY", c.scaleY), l.skewX = c.skewX, l.skewY = c.skewY, l.angle = c.angle, l.setPositionByOrigin(f, "center", "center");
  }, sizeAfterTransform: function(l, a, c) {
    var f = l / 2, i = a / 2, r = [{ x: -f, y: -i }, { x: f, y: -i }, { x: -f, y: i }, { x: f, y: i }], s = b.util.calcDimensionsMatrix(c), h = b.util.makeBoundingBoxFromPoints(r, s);
    return { x: h.width, y: h.height };
  } }, b.util.createAccessors = function(l) {
    var a, c, f, i, r, s = l.prototype;
    for (a = s.stateProperties.length; a--; ) i = "set" + (f = (c = s.stateProperties[a]).charAt(0).toUpperCase() + c.slice(1)), s[r = "get" + f] || (s[r] = new Function('return this.get("' + c + '")')), s[i] || (s[i] = function(h) {
      return new Function("value", 'return this.set("' + h + '", value)');
    }(c));
  }, function() {
    var l = Array.prototype.join, a = { m: 2, l: 2, h: 1, v: 1, c: 6, s: 4, q: 4, t: 2, a: 7 }, c = { m: "l", M: "L" };
    function f(j, w, O, L, U, W, I, M, B, Z, J) {
      var G = b.util.cos(j), F = b.util.sin(j), q = b.util.cos(w), z = b.util.sin(w), X = O * U * q - L * W * z + I, et = L * U * q + O * W * z + M;
      return ["C", Z + B * (-O * U * F - L * W * G), J + B * (-L * U * F + O * W * G), X + B * (O * U * z + L * W * q), et + B * (L * U * z - O * W * q), X, et];
    }
    function i(j, w, O, L, U, W, I) {
      var M = Math.PI, B = I * M / 180, Z = b.util.sin(B), J = b.util.cos(B), G = 0, F = 0, q = -J * j * 0.5 - Z * w * 0.5, z = -J * w * 0.5 + Z * j * 0.5, X = (O = Math.abs(O)) * O, et = (L = Math.abs(L)) * L, ct = z * z, ot = q * q, mt = X * et - X * ct - et * ot, lt = 0;
      if (mt < 0) {
        var dt = Math.sqrt(1 - mt / (X * et));
        O *= dt, L *= dt;
      } else lt = (U === W ? -1 : 1) * Math.sqrt(mt / (X * ct + et * ot));
      var ft = lt * O * z / L, St = -lt * L * q / O, yt = J * ft - Z * St + 0.5 * j, Ot = Z * ft + J * St + 0.5 * w, Et = r(1, 0, (q - ft) / O, (z - St) / L), Dt = r((q - ft) / O, (z - St) / L, (-q - ft) / O, (-z - St) / L);
      W === 0 && Dt > 0 ? Dt -= 2 * M : W === 1 && Dt < 0 && (Dt += 2 * M);
      for (var Zt = Math.ceil(Math.abs(Dt / M * 2)), Ut = [], It = Dt / Zt, se = 8 / 3 * Math.sin(It / 4) * Math.sin(It / 4) / Math.sin(It / 2), Nt = Et + It, ne = 0; ne < Zt; ne++) Ut[ne] = f(Et, Nt, J, Z, O, L, yt, Ot, se, G, F), G = Ut[ne][5], F = Ut[ne][6], Et = Nt, Nt += It;
      return Ut;
    }
    function r(j, w, O, L) {
      var U = Math.atan2(w, j), W = Math.atan2(L, O);
      return W >= U ? W - U : 2 * Math.PI - (U - W);
    }
    function s(j, w, O, L, U, W, I, M) {
      var B;
      if (b.cachesBoundsOfCurve && (B = l.call(arguments), b.boundsOfCurveCache[B])) return b.boundsOfCurveCache[B];
      var Z, J, G, F, q, z, X, et, ct = Math.sqrt, ot = Math.min, mt = Math.max, lt = Math.abs, dt = [], ft = [[], []];
      J = 6 * j - 12 * O + 6 * U, Z = -3 * j + 9 * O - 9 * U + 3 * I, G = 3 * O - 3 * j;
      for (var St = 0; St < 2; ++St) if (St > 0 && (J = 6 * w - 12 * L + 6 * W, Z = -3 * w + 9 * L - 9 * W + 3 * M, G = 3 * L - 3 * w), lt(Z) < 1e-12) {
        if (lt(J) < 1e-12) continue;
        0 < (F = -G / J) && F < 1 && dt.push(F);
      } else (X = J * J - 4 * G * Z) < 0 || (0 < (q = (-J + (et = ct(X))) / (2 * Z)) && q < 1 && dt.push(q), 0 < (z = (-J - et) / (2 * Z)) && z < 1 && dt.push(z));
      for (var yt, Ot, Et, Dt = dt.length, Zt = Dt; Dt--; ) yt = (Et = 1 - (F = dt[Dt])) * Et * Et * j + 3 * Et * Et * F * O + 3 * Et * F * F * U + F * F * F * I, ft[0][Dt] = yt, Ot = Et * Et * Et * w + 3 * Et * Et * F * L + 3 * Et * F * F * W + F * F * F * M, ft[1][Dt] = Ot;
      ft[0][Zt] = j, ft[1][Zt] = w, ft[0][Zt + 1] = I, ft[1][Zt + 1] = M;
      var Ut = [{ x: ot.apply(null, ft[0]), y: ot.apply(null, ft[1]) }, { x: mt.apply(null, ft[0]), y: mt.apply(null, ft[1]) }];
      return b.cachesBoundsOfCurve && (b.boundsOfCurveCache[B] = Ut), Ut;
    }
    function h(j, w, O) {
      for (var L = O[1], U = O[2], W = O[3], I = O[4], M = O[5], B = i(O[6] - j, O[7] - w, L, U, I, M, W), Z = 0, J = B.length; Z < J; Z++) B[Z][1] += j, B[Z][2] += w, B[Z][3] += j, B[Z][4] += w, B[Z][5] += j, B[Z][6] += w;
      return B;
    }
    function d(j, w, O, L) {
      return Math.sqrt((O - j) * (O - j) + (L - w) * (L - w));
    }
    function p(j, w, O, L, U, W, I, M) {
      return function(B) {
        var Z, J = (Z = B) * Z * Z, G = function(z) {
          return 3 * z * z * (1 - z);
        }(B), F = function(z) {
          return 3 * z * (1 - z) * (1 - z);
        }(B), q = function(z) {
          return (1 - z) * (1 - z) * (1 - z);
        }(B);
        return { x: I * J + U * G + O * F + j * q, y: M * J + W * G + L * F + w * q };
      };
    }
    function m(j, w, O, L, U, W, I, M) {
      return function(B) {
        var Z = 1 - B, J = 3 * Z * Z * (O - j) + 6 * Z * B * (U - O) + 3 * B * B * (I - U), G = 3 * Z * Z * (L - w) + 6 * Z * B * (W - L) + 3 * B * B * (M - W);
        return Math.atan2(G, J);
      };
    }
    function y(j, w, O, L, U, W) {
      return function(I) {
        var M, B = (M = I) * M, Z = function(G) {
          return 2 * G * (1 - G);
        }(I), J = function(G) {
          return (1 - G) * (1 - G);
        }(I);
        return { x: U * B + O * Z + j * J, y: W * B + L * Z + w * J };
      };
    }
    function _(j, w, O, L, U, W) {
      return function(I) {
        var M = 1 - I, B = 2 * M * (O - j) + 2 * I * (U - O), Z = 2 * M * (L - w) + 2 * I * (W - L);
        return Math.atan2(Z, B);
      };
    }
    function k(j, w, O) {
      var L, U, W = { x: w, y: O }, I = 0;
      for (U = 1; U <= 100; U += 1) L = j(U / 100), I += d(W.x, W.y, L.x, L.y), W = L;
      return I;
    }
    function T(j, w) {
      for (var O, L, U, W = 0, I = 0, M = j.iterator, B = { x: j.x, y: j.y }, Z = 0.01, J = j.angleFinder; I < w && W <= 1 && Z > 1e-4; ) O = M(W), U = W, (L = d(B.x, B.y, O.x, O.y)) + I > w ? W -= Z /= 2 : (B = O, W += Z, I += L);
      return O.angle = J(U), O;
    }
    function D(j) {
      for (var w, O, L, U, W = 0, I = j.length, M = 0, B = 0, Z = 0, J = 0, G = [], F = 0; F < I; F++) {
        switch (L = { x: M, y: B, command: (w = j[F])[0] }, w[0]) {
          case "M":
            L.length = 0, Z = M = w[1], J = B = w[2];
            break;
          case "L":
            L.length = d(M, B, w[1], w[2]), M = w[1], B = w[2];
            break;
          case "C":
            O = p(M, B, w[1], w[2], w[3], w[4], w[5], w[6]), U = m(M, B, w[1], w[2], w[3], w[4], w[5], w[6]), L.iterator = O, L.angleFinder = U, L.length = k(O, M, B), M = w[5], B = w[6];
            break;
          case "Q":
            O = y(M, B, w[1], w[2], w[3], w[4]), U = _(M, B, w[1], w[2], w[3], w[4]), L.iterator = O, L.angleFinder = U, L.length = k(O, M, B), M = w[3], B = w[4];
            break;
          case "Z":
          case "z":
            L.destX = Z, L.destY = J, L.length = d(M, B, Z, J), M = Z, B = J;
        }
        W += L.length, G.push(L);
      }
      return G.push({ length: W, x: M, y: B }), G;
    }
    b.util.joinPath = function(j) {
      return j.map(function(w) {
        return w.join(" ");
      }).join(" ");
    }, b.util.parsePath = function(j) {
      var w, O, L, U, W, I = [], M = [], B = b.rePathCommand, Z = "[-+]?(?:\\d*\\.\\d+|\\d+\\.?)(?:[eE][-+]?\\d+)?\\s*", J = "(" + Z + ")" + b.commaWsp, G = "([01])" + b.commaWsp + "?", F = new RegExp(J + "?" + J + "?" + J + G + G + J + "?(" + Z + ")", "g");
      if (!j || !j.match) return I;
      for (var q, z = 0, X = (W = j.match(/[mzlhvcsqta][^mzlhvcsqta]*/gi)).length; z < X; z++) {
        U = (w = W[z]).slice(1).trim(), M.length = 0;
        var et = w.charAt(0);
        if (q = [et], et.toLowerCase() === "a") for (var ct; ct = F.exec(U); ) for (var ot = 1; ot < ct.length; ot++) M.push(ct[ot]);
        else for (; L = B.exec(U); ) M.push(L[0]);
        ot = 0;
        for (var mt = M.length; ot < mt; ot++) O = parseFloat(M[ot]), isNaN(O) || q.push(O);
        var lt = a[et.toLowerCase()], dt = c[et] || et;
        if (q.length - 1 > lt) for (var ft = 1, St = q.length; ft < St; ft += lt) I.push([et].concat(q.slice(ft, ft + lt))), et = dt;
        else I.push(q);
      }
      return I;
    }, b.util.makePathSimpler = function(j) {
      var w, O, L, U, W, I, M = 0, B = 0, Z = j.length, J = 0, G = 0, F = [];
      for (O = 0; O < Z; ++O) {
        switch (L = !1, (w = j[O].slice(0))[0]) {
          case "l":
            w[0] = "L", w[1] += M, w[2] += B;
          case "L":
            M = w[1], B = w[2];
            break;
          case "h":
            w[1] += M;
          case "H":
            w[0] = "L", w[2] = B, M = w[1];
            break;
          case "v":
            w[1] += B;
          case "V":
            w[0] = "L", B = w[1], w[1] = M, w[2] = B;
            break;
          case "m":
            w[0] = "M", w[1] += M, w[2] += B;
          case "M":
            M = w[1], B = w[2], J = w[1], G = w[2];
            break;
          case "c":
            w[0] = "C", w[1] += M, w[2] += B, w[3] += M, w[4] += B, w[5] += M, w[6] += B;
          case "C":
            W = w[3], I = w[4], M = w[5], B = w[6];
            break;
          case "s":
            w[0] = "S", w[1] += M, w[2] += B, w[3] += M, w[4] += B;
          case "S":
            U === "C" ? (W = 2 * M - W, I = 2 * B - I) : (W = M, I = B), M = w[3], B = w[4], w[0] = "C", w[5] = w[3], w[6] = w[4], w[3] = w[1], w[4] = w[2], w[1] = W, w[2] = I, W = w[3], I = w[4];
            break;
          case "q":
            w[0] = "Q", w[1] += M, w[2] += B, w[3] += M, w[4] += B;
          case "Q":
            W = w[1], I = w[2], M = w[3], B = w[4];
            break;
          case "t":
            w[0] = "T", w[1] += M, w[2] += B;
          case "T":
            U === "Q" ? (W = 2 * M - W, I = 2 * B - I) : (W = M, I = B), w[0] = "Q", M = w[1], B = w[2], w[1] = W, w[2] = I, w[3] = M, w[4] = B;
            break;
          case "a":
            w[0] = "A", w[6] += M, w[7] += B;
          case "A":
            L = !0, F = F.concat(h(M, B, w)), M = w[6], B = w[7];
            break;
          case "z":
          case "Z":
            M = J, B = G;
        }
        L || F.push(w), U = w[0];
      }
      return F;
    }, b.util.getSmoothPathFromPoints = function(j, w) {
      var O, L = [], U = new b.Point(j[0].x, j[0].y), W = new b.Point(j[1].x, j[1].y), I = j.length, M = 1, B = 0, Z = I > 2;
      for (w = w || 0, Z && (M = j[2].x < W.x ? -1 : j[2].x === W.x ? 0 : 1, B = j[2].y < W.y ? -1 : j[2].y === W.y ? 0 : 1), L.push(["M", U.x - M * w, U.y - B * w]), O = 1; O < I; O++) {
        if (!U.eq(W)) {
          var J = U.midPointFrom(W);
          L.push(["Q", U.x, U.y, J.x, J.y]);
        }
        U = j[O], O + 1 < j.length && (W = j[O + 1]);
      }
      return Z && (M = U.x > j[O - 2].x ? 1 : U.x === j[O - 2].x ? 0 : -1, B = U.y > j[O - 2].y ? 1 : U.y === j[O - 2].y ? 0 : -1), L.push(["L", U.x + M * w, U.y + B * w]), L;
    }, b.util.getPathSegmentsInfo = D, b.util.getBoundsOfCurve = s, b.util.getPointOnPath = function(j, w, O) {
      O || (O = D(j));
      for (var L = 0; w - O[L].length > 0 && L < O.length - 2; ) w -= O[L].length, L++;
      var U, W = O[L], I = w / W.length, M = W.command, B = j[L];
      switch (M) {
        case "M":
          return { x: W.x, y: W.y, angle: 0 };
        case "Z":
        case "z":
          return (U = new b.Point(W.x, W.y).lerp(new b.Point(W.destX, W.destY), I)).angle = Math.atan2(W.destY - W.y, W.destX - W.x), U;
        case "L":
          return (U = new b.Point(W.x, W.y).lerp(new b.Point(B[1], B[2]), I)).angle = Math.atan2(B[2] - W.y, B[1] - W.x), U;
        case "C":
        case "Q":
          return T(W, w);
      }
    }, b.util.transformPath = function(j, w, O) {
      return O && (w = b.util.multiplyTransformMatrices(w, [1, 0, 0, 1, -O.x, -O.y])), j.map(function(L) {
        for (var U = L.slice(0), W = {}, I = 1; I < L.length - 1; I += 2) W.x = L[I], W.y = L[I + 1], W = b.util.transformPoint(W, w), U[I] = W.x, U[I + 1] = W.y;
        return U;
      });
    }, b.util.fromArcToBeizers = h, b.util.getBoundsOfArc = function(j, w, O, L, U, W, I, M, B) {
      for (var Z, J = 0, G = 0, F = [], q = i(M - j, B - w, O, L, W, I, U), z = 0, X = q.length; z < X; z++) Z = s(J, G, q[z][1], q[z][2], q[z][3], q[z][4], q[z][5], q[z][6]), F.push({ x: Z[0].x + j, y: Z[0].y + w }), F.push({ x: Z[1].x + j, y: Z[1].y + w }), J = q[z][5], G = q[z][6];
      return F;
    }, b.util.drawArc = function(j, w, O, L) {
      h(w, O, L = L.slice(0).unshift("X")).forEach(function(U) {
        j.bezierCurveTo.apply(j, U.slice(1));
      });
    };
  }(), function() {
    var l = Array.prototype.slice;
    function a(c, f, i) {
      if (c && c.length !== 0) {
        var r = c.length - 1, s = f ? c[r][f] : c[r];
        if (f) for (; r--; ) i(c[r][f], s) && (s = c[r][f]);
        else for (; r--; ) i(c[r], s) && (s = c[r]);
        return s;
      }
    }
    b.util.array = { fill: function(c, f) {
      for (var i = c.length; i--; ) c[i] = f;
      return c;
    }, invoke: function(c, f) {
      for (var i = l.call(arguments, 2), r = [], s = 0, h = c.length; s < h; s++) r[s] = i.length ? c[s][f].apply(c[s], i) : c[s][f].call(c[s]);
      return r;
    }, min: function(c, f) {
      return a(c, f, function(i, r) {
        return i < r;
      });
    }, max: function(c, f) {
      return a(c, f, function(i, r) {
        return i >= r;
      });
    } };
  }(), function() {
    function l(a, c, f) {
      if (f) if (!b.isLikelyNode && c instanceof Element) a = c;
      else if (c instanceof Array) {
        a = [];
        for (var i = 0, r = c.length; i < r; i++) a[i] = l({}, c[i], f);
      } else if (c && typeof c == "object") for (var s in c) s === "canvas" || s === "group" ? a[s] = null : c.hasOwnProperty(s) && (a[s] = l({}, c[s], f));
      else a = c;
      else for (var s in c) a[s] = c[s];
      return a;
    }
    b.util.object = { extend: l, clone: function(a, c) {
      return l({}, a, c);
    } }, b.util.object.extend(b.util, b.Observable);
  }(), function() {
    function l(a, c) {
      var f = a.charCodeAt(c);
      if (isNaN(f)) return "";
      if (f < 55296 || f > 57343) return a.charAt(c);
      if (55296 <= f && f <= 56319) {
        if (a.length <= c + 1) throw "High surrogate without following low surrogate";
        var i = a.charCodeAt(c + 1);
        if (56320 > i || i > 57343) throw "High surrogate without following low surrogate";
        return a.charAt(c) + a.charAt(c + 1);
      }
      if (c === 0) throw "Low surrogate without preceding high surrogate";
      var r = a.charCodeAt(c - 1);
      if (55296 > r || r > 56319) throw "Low surrogate without preceding high surrogate";
      return !1;
    }
    b.util.string = { camelize: function(a) {
      return a.replace(/-+(.)?/g, function(c, f) {
        return f ? f.toUpperCase() : "";
      });
    }, capitalize: function(a, c) {
      return a.charAt(0).toUpperCase() + (c ? a.slice(1) : a.slice(1).toLowerCase());
    }, escapeXml: function(a) {
      return a.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }, graphemeSplit: function(a) {
      var c, f = 0, i = [];
      for (f = 0; f < a.length; f++) (c = l(a, f)) !== !1 && i.push(c);
      return i;
    } };
  }(), function() {
    var l = Array.prototype.slice, a = function() {
    }, c = function() {
      for (var s in { toString: 1 }) if (s === "toString") return !1;
      return !0;
    }(), f = function(s, h, d) {
      for (var p in h) p in s.prototype && typeof s.prototype[p] == "function" && (h[p] + "").indexOf("callSuper") > -1 ? s.prototype[p] = /* @__PURE__ */ function(m) {
        return function() {
          var y = this.constructor.superclass;
          this.constructor.superclass = d;
          var _ = h[m].apply(this, arguments);
          if (this.constructor.superclass = y, m !== "initialize") return _;
        };
      }(p) : s.prototype[p] = h[p], c && (h.toString !== Object.prototype.toString && (s.prototype.toString = h.toString), h.valueOf !== Object.prototype.valueOf && (s.prototype.valueOf = h.valueOf));
    };
    function i() {
    }
    function r(s) {
      for (var h = null, d = this; d.constructor.superclass; ) {
        var p = d.constructor.superclass.prototype[s];
        if (d[s] !== p) {
          h = p;
          break;
        }
        d = d.constructor.superclass.prototype;
      }
      return h ? arguments.length > 1 ? h.apply(this, l.call(arguments, 1)) : h.call(this) : console.log("tried to callSuper " + s + ", method not found in prototype chain", this);
    }
    b.util.createClass = function() {
      var s = null, h = l.call(arguments, 0);
      function d() {
        this.initialize.apply(this, arguments);
      }
      typeof h[0] == "function" && (s = h.shift()), d.superclass = s, d.subclasses = [], s && (i.prototype = s.prototype, d.prototype = new i(), s.subclasses.push(d));
      for (var p = 0, m = h.length; p < m; p++) f(d, h[p], s);
      return d.prototype.initialize || (d.prototype.initialize = a), d.prototype.constructor = d, d.prototype.callSuper = r, d;
    };
  }(), A = !!b.document.createElement("div").attachEvent, Y = ["touchstart", "touchmove", "touchend"], b.util.addListener = function(l, a, c, f) {
    l && l.addEventListener(a, c, !A && f);
  }, b.util.removeListener = function(l, a, c, f) {
    l && l.removeEventListener(a, c, !A && f);
  }, b.util.getPointer = function(l) {
    var a = l.target, c = b.util.getScrollLeftTop(a), f = function(i) {
      var r = i.changedTouches;
      return r && r[0] ? r[0] : i;
    }(l);
    return { x: f.clientX + c.left, y: f.clientY + c.top };
  }, b.util.isTouchEvent = function(l) {
    return Y.indexOf(l.type) > -1 || l.pointerType === "touch";
  }, V = b.document.createElement("div"), Q = typeof V.style.opacity == "string", tt = typeof V.style.filter == "string", rt = /alpha\s*\(\s*opacity\s*=\s*([^\)]+)\)/, ut = function(l) {
    return l;
  }, Q ? ut = function(l, a) {
    return l.style.opacity = a, l;
  } : tt && (ut = function(l, a) {
    var c = l.style;
    return l.currentStyle && !l.currentStyle.hasLayout && (c.zoom = 1), rt.test(c.filter) ? (a = a >= 0.9999 ? "" : "alpha(opacity=" + 100 * a + ")", c.filter = c.filter.replace(rt, a)) : c.filter += " alpha(opacity=" + 100 * a + ")", l;
  }), b.util.setStyle = function(l, a) {
    var c = l.style;
    if (!c) return l;
    if (typeof a == "string") return l.style.cssText += ";" + a, a.indexOf("opacity") > -1 ? ut(l, a.match(/opacity:\s*(\d?\.?\d*)/)[1]) : l;
    for (var f in a) f === "opacity" ? ut(l, a[f]) : c[f === "float" || f === "cssFloat" ? c.styleFloat === void 0 ? "cssFloat" : "styleFloat" : f] = a[f];
    return l;
  }, function() {
    var l = Array.prototype.slice, a, c, f, i, r = function(d) {
      return l.call(d, 0);
    };
    try {
      a = r(b.document.childNodes) instanceof Array;
    } catch {
    }
    function s(d, p) {
      var m = b.document.createElement(d);
      for (var y in p) y === "class" ? m.className = p[y] : y === "for" ? m.htmlFor = p[y] : m.setAttribute(y, p[y]);
      return m;
    }
    function h(d) {
      for (var p = 0, m = 0, y = b.document.documentElement, _ = b.document.body || { scrollLeft: 0, scrollTop: 0 }; d && (d.parentNode || d.host) && ((d = d.parentNode || d.host) === b.document ? (p = _.scrollLeft || y.scrollLeft || 0, m = _.scrollTop || y.scrollTop || 0) : (p += d.scrollLeft || 0, m += d.scrollTop || 0), d.nodeType !== 1 || d.style.position !== "fixed"); ) ;
      return { left: p, top: m };
    }
    a || (r = function(d) {
      for (var p = new Array(d.length), m = d.length; m--; ) p[m] = d[m];
      return p;
    }), c = b.document.defaultView && b.document.defaultView.getComputedStyle ? function(d, p) {
      var m = b.document.defaultView.getComputedStyle(d, null);
      return m ? m[p] : void 0;
    } : function(d, p) {
      var m = d.style[p];
      return !m && d.currentStyle && (m = d.currentStyle[p]), m;
    }, f = b.document.documentElement.style, i = "userSelect" in f ? "userSelect" : "MozUserSelect" in f ? "MozUserSelect" : "WebkitUserSelect" in f ? "WebkitUserSelect" : "KhtmlUserSelect" in f ? "KhtmlUserSelect" : "", b.util.makeElementUnselectable = function(d) {
      return d.onselectstart !== void 0 && (d.onselectstart = b.util.falseFunction), i ? d.style[i] = "none" : typeof d.unselectable == "string" && (d.unselectable = "on"), d;
    }, b.util.makeElementSelectable = function(d) {
      return d.onselectstart !== void 0 && (d.onselectstart = null), i ? d.style[i] = "" : typeof d.unselectable == "string" && (d.unselectable = ""), d;
    }, b.util.setImageSmoothing = function(d, p) {
      d.imageSmoothingEnabled = d.imageSmoothingEnabled || d.webkitImageSmoothingEnabled || d.mozImageSmoothingEnabled || d.msImageSmoothingEnabled || d.oImageSmoothingEnabled, d.imageSmoothingEnabled = p;
    }, b.util.getById = function(d) {
      return typeof d == "string" ? b.document.getElementById(d) : d;
    }, b.util.toArray = r, b.util.addClass = function(d, p) {
      d && (" " + d.className + " ").indexOf(" " + p + " ") === -1 && (d.className += (d.className ? " " : "") + p);
    }, b.util.makeElement = s, b.util.wrapElement = function(d, p, m) {
      return typeof p == "string" && (p = s(p, m)), d.parentNode && d.parentNode.replaceChild(p, d), p.appendChild(d), p;
    }, b.util.getScrollLeftTop = h, b.util.getElementOffset = function(d) {
      var p, m, y = d && d.ownerDocument, _ = { left: 0, top: 0 }, k = { left: 0, top: 0 }, T = { borderLeftWidth: "left", borderTopWidth: "top", paddingLeft: "left", paddingTop: "top" };
      if (!y) return k;
      for (var D in T) k[T[D]] += parseInt(c(d, D), 10) || 0;
      return p = y.documentElement, d.getBoundingClientRect !== void 0 && (_ = d.getBoundingClientRect()), m = h(d), { left: _.left + m.left - (p.clientLeft || 0) + k.left, top: _.top + m.top - (p.clientTop || 0) + k.top };
    }, b.util.getNodeCanvas = function(d) {
      var p = b.jsdomImplForWrapper(d);
      return p._canvas || p._image;
    }, b.util.cleanUpJsdomNode = function(d) {
      if (b.isLikelyNode) {
        var p = b.jsdomImplForWrapper(d);
        p && (p._image = null, p._canvas = null, p._currentSrc = null, p._attributes = null, p._classList = null);
      }
    };
  }(), function() {
    function l() {
    }
    b.util.request = function(a, c) {
      c || (c = {});
      var f = c.method ? c.method.toUpperCase() : "GET", i = c.onComplete || function() {
      }, r = new b.window.XMLHttpRequest(), s = c.body || c.parameters;
      return r.onreadystatechange = function() {
        r.readyState === 4 && (i(r), r.onreadystatechange = l);
      }, f === "GET" && (s = null, typeof c.parameters == "string" && (a = function(h, d) {
        return h + (/\?/.test(h) ? "&" : "?") + d;
      }(a, c.parameters))), r.open(f, a, !0), f !== "POST" && f !== "PUT" || r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), r.send(s), r;
    };
  }(), b.log = console.log, b.warn = console.warn, function() {
    function l() {
      return !1;
    }
    function a(r, s, h, d) {
      return -h * Math.cos(r / d * (Math.PI / 2)) + h + s;
    }
    var c = b.window.requestAnimationFrame || b.window.webkitRequestAnimationFrame || b.window.mozRequestAnimationFrame || b.window.oRequestAnimationFrame || b.window.msRequestAnimationFrame || function(r) {
      return b.window.setTimeout(r, 1e3 / 60);
    }, f = b.window.cancelAnimationFrame || b.window.clearTimeout;
    function i() {
      return c.apply(b.window, arguments);
    }
    b.util.animate = function(r) {
      var s = !1;
      return i(function(h) {
        r || (r = {});
        var d, p = h || +/* @__PURE__ */ new Date(), m = r.duration || 500, y = p + m, _ = r.onChange || l, k = r.abort || l, T = r.onComplete || l, D = r.easing || a, j = "startValue" in r ? r.startValue : 0, w = "endValue" in r ? r.endValue : 100, O = r.byValue || w - j;
        r.onStart && r.onStart(), function L(U) {
          var W = (d = U || +/* @__PURE__ */ new Date()) > y ? m : d - p, I = W / m, M = D(W, j, O, m), B = Math.abs((M - j) / O);
          if (!s) {
            if (!k(M, B, I)) return d > y ? (_(w, 1, 1), void T(w, 1, 1)) : (_(M, B, I), void i(L));
            T(w, 1, 1);
          }
        }(p);
      }), function() {
        s = !0;
      };
    }, b.util.requestAnimFrame = i, b.util.cancelAnimFrame = function() {
      return f.apply(b.window, arguments);
    };
  }(), function() {
    function l(a, c, f) {
      var i = "rgba(" + parseInt(a[0] + f * (c[0] - a[0]), 10) + "," + parseInt(a[1] + f * (c[1] - a[1]), 10) + "," + parseInt(a[2] + f * (c[2] - a[2]), 10);
      return i += "," + (a && c ? parseFloat(a[3] + f * (c[3] - a[3])) : 1), i += ")";
    }
    b.util.animateColor = function(a, c, f, i) {
      var r = new b.Color(a).getSource(), s = new b.Color(c).getSource(), h = i.onComplete, d = i.onChange;
      return i = i || {}, b.util.animate(b.util.object.extend(i, { duration: f || 500, startValue: r, endValue: s, byValue: s, easing: function(p, m, y, _) {
        return l(m, y, i.colorEasing ? i.colorEasing(p, _) : 1 - Math.cos(p / _ * (Math.PI / 2)));
      }, onComplete: function(p, m, y) {
        if (h) return h(l(s, s, 0), m, y);
      }, onChange: function(p, m, y) {
        if (d) {
          if (Array.isArray(p)) return d(l(p, p, 0), m, y);
          d(p, m, y);
        }
      } }));
    };
  }(), function() {
    function l(i, r, s, h) {
      return i < Math.abs(r) ? (i = r, h = s / 4) : h = r === 0 && i === 0 ? s / (2 * Math.PI) * Math.asin(1) : s / (2 * Math.PI) * Math.asin(r / i), { a: i, c: r, p: s, s: h };
    }
    function a(i, r, s) {
      return i.a * Math.pow(2, 10 * (r -= 1)) * Math.sin((r * s - i.s) * (2 * Math.PI) / i.p);
    }
    function c(i, r, s, h) {
      return s - f(h - i, 0, s, h) + r;
    }
    function f(i, r, s, h) {
      return (i /= h) < 1 / 2.75 ? s * (7.5625 * i * i) + r : i < 2 / 2.75 ? s * (7.5625 * (i -= 1.5 / 2.75) * i + 0.75) + r : i < 2.5 / 2.75 ? s * (7.5625 * (i -= 2.25 / 2.75) * i + 0.9375) + r : s * (7.5625 * (i -= 2.625 / 2.75) * i + 0.984375) + r;
    }
    b.util.ease = { easeInQuad: function(i, r, s, h) {
      return s * (i /= h) * i + r;
    }, easeOutQuad: function(i, r, s, h) {
      return -s * (i /= h) * (i - 2) + r;
    }, easeInOutQuad: function(i, r, s, h) {
      return (i /= h / 2) < 1 ? s / 2 * i * i + r : -s / 2 * (--i * (i - 2) - 1) + r;
    }, easeInCubic: function(i, r, s, h) {
      return s * (i /= h) * i * i + r;
    }, easeOutCubic: function(i, r, s, h) {
      return s * ((i = i / h - 1) * i * i + 1) + r;
    }, easeInOutCubic: function(i, r, s, h) {
      return (i /= h / 2) < 1 ? s / 2 * i * i * i + r : s / 2 * ((i -= 2) * i * i + 2) + r;
    }, easeInQuart: function(i, r, s, h) {
      return s * (i /= h) * i * i * i + r;
    }, easeOutQuart: function(i, r, s, h) {
      return -s * ((i = i / h - 1) * i * i * i - 1) + r;
    }, easeInOutQuart: function(i, r, s, h) {
      return (i /= h / 2) < 1 ? s / 2 * i * i * i * i + r : -s / 2 * ((i -= 2) * i * i * i - 2) + r;
    }, easeInQuint: function(i, r, s, h) {
      return s * (i /= h) * i * i * i * i + r;
    }, easeOutQuint: function(i, r, s, h) {
      return s * ((i = i / h - 1) * i * i * i * i + 1) + r;
    }, easeInOutQuint: function(i, r, s, h) {
      return (i /= h / 2) < 1 ? s / 2 * i * i * i * i * i + r : s / 2 * ((i -= 2) * i * i * i * i + 2) + r;
    }, easeInSine: function(i, r, s, h) {
      return -s * Math.cos(i / h * (Math.PI / 2)) + s + r;
    }, easeOutSine: function(i, r, s, h) {
      return s * Math.sin(i / h * (Math.PI / 2)) + r;
    }, easeInOutSine: function(i, r, s, h) {
      return -s / 2 * (Math.cos(Math.PI * i / h) - 1) + r;
    }, easeInExpo: function(i, r, s, h) {
      return i === 0 ? r : s * Math.pow(2, 10 * (i / h - 1)) + r;
    }, easeOutExpo: function(i, r, s, h) {
      return i === h ? r + s : s * (1 - Math.pow(2, -10 * i / h)) + r;
    }, easeInOutExpo: function(i, r, s, h) {
      return i === 0 ? r : i === h ? r + s : (i /= h / 2) < 1 ? s / 2 * Math.pow(2, 10 * (i - 1)) + r : s / 2 * (2 - Math.pow(2, -10 * --i)) + r;
    }, easeInCirc: function(i, r, s, h) {
      return -s * (Math.sqrt(1 - (i /= h) * i) - 1) + r;
    }, easeOutCirc: function(i, r, s, h) {
      return s * Math.sqrt(1 - (i = i / h - 1) * i) + r;
    }, easeInOutCirc: function(i, r, s, h) {
      return (i /= h / 2) < 1 ? -s / 2 * (Math.sqrt(1 - i * i) - 1) + r : s / 2 * (Math.sqrt(1 - (i -= 2) * i) + 1) + r;
    }, easeInElastic: function(i, r, s, h) {
      var d = 0;
      return i === 0 ? r : (i /= h) === 1 ? r + s : (d || (d = 0.3 * h), -a(l(s, s, d, 1.70158), i, h) + r);
    }, easeOutElastic: function(i, r, s, h) {
      var d = 0;
      if (i === 0) return r;
      if ((i /= h) === 1) return r + s;
      d || (d = 0.3 * h);
      var p = l(s, s, d, 1.70158);
      return p.a * Math.pow(2, -10 * i) * Math.sin((i * h - p.s) * (2 * Math.PI) / p.p) + p.c + r;
    }, easeInOutElastic: function(i, r, s, h) {
      var d = 0;
      if (i === 0) return r;
      if ((i /= h / 2) === 2) return r + s;
      d || (d = h * (0.3 * 1.5));
      var p = l(s, s, d, 1.70158);
      return i < 1 ? -0.5 * a(p, i, h) + r : p.a * Math.pow(2, -10 * (i -= 1)) * Math.sin((i * h - p.s) * (2 * Math.PI) / p.p) * 0.5 + p.c + r;
    }, easeInBack: function(i, r, s, h, d) {
      return d === void 0 && (d = 1.70158), s * (i /= h) * i * ((d + 1) * i - d) + r;
    }, easeOutBack: function(i, r, s, h, d) {
      return d === void 0 && (d = 1.70158), s * ((i = i / h - 1) * i * ((d + 1) * i + d) + 1) + r;
    }, easeInOutBack: function(i, r, s, h, d) {
      return d === void 0 && (d = 1.70158), (i /= h / 2) < 1 ? s / 2 * (i * i * ((1 + (d *= 1.525)) * i - d)) + r : s / 2 * ((i -= 2) * i * ((1 + (d *= 1.525)) * i + d) + 2) + r;
    }, easeInBounce: c, easeOutBounce: f, easeInOutBounce: function(i, r, s, h) {
      return i < h / 2 ? 0.5 * c(2 * i, 0, s, h) + r : 0.5 * f(2 * i - h, 0, s, h) + 0.5 * s + r;
    } };
  }(), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.util.object.clone, i = a.util.toFixed, r = a.util.parseUnit, s = a.util.multiplyTransformMatrices, h = { cx: "left", x: "left", r: "radius", cy: "top", y: "top", display: "visible", visibility: "visible", transform: "transformMatrix", "fill-opacity": "fillOpacity", "fill-rule": "fillRule", "font-family": "fontFamily", "font-size": "fontSize", "font-style": "fontStyle", "font-weight": "fontWeight", "letter-spacing": "charSpacing", "paint-order": "paintFirst", "stroke-dasharray": "strokeDashArray", "stroke-dashoffset": "strokeDashOffset", "stroke-linecap": "strokeLineCap", "stroke-linejoin": "strokeLineJoin", "stroke-miterlimit": "strokeMiterLimit", "stroke-opacity": "strokeOpacity", "stroke-width": "strokeWidth", "text-decoration": "textDecoration", "text-anchor": "textAnchor", opacity: "opacity", "clip-path": "clipPath", "clip-rule": "clipRule", "vector-effect": "strokeUniform", "image-rendering": "imageSmoothing" }, d = { stroke: "strokeOpacity", fill: "fillOpacity" }, p = "font-size", m = "clip-path";
    function y(I) {
      return I in h ? h[I] : I;
    }
    function _(I, M, B, Z) {
      var J, G = Object.prototype.toString.call(M) === "[object Array]";
      if (I !== "fill" && I !== "stroke" || M !== "none") {
        if (I === "strokeUniform") return M === "non-scaling-stroke";
        if (I === "strokeDashArray") M = M === "none" ? null : M.replace(/,/g, " ").split(/\s+/).map(parseFloat);
        else if (I === "transformMatrix") M = B && B.transformMatrix ? s(B.transformMatrix, a.parseTransformAttribute(M)) : a.parseTransformAttribute(M);
        else if (I === "visible") M = M !== "none" && M !== "hidden", B && B.visible === !1 && (M = !1);
        else if (I === "opacity") M = parseFloat(M), B && B.opacity !== void 0 && (M *= B.opacity);
        else if (I === "textAnchor") M = M === "start" ? "left" : M === "end" ? "right" : "center";
        else if (I === "charSpacing") J = r(M, Z) / Z * 1e3;
        else if (I === "paintFirst") {
          var F = M.indexOf("fill"), q = M.indexOf("stroke");
          M = "fill", (F > -1 && q > -1 && q < F || F === -1 && q > -1) && (M = "stroke");
        } else {
          if (I === "href" || I === "xlink:href" || I === "font") return M;
          if (I === "imageSmoothing") return M === "optimizeQuality";
          J = G ? M.map(r) : r(M, Z);
        }
      } else M = "";
      return !G && isNaN(J) ? M : J;
    }
    function k(I) {
      return new RegExp("^(" + I.join("|") + ")\\b", "i");
    }
    function T(I, M) {
      var B, Z, J, G, F = [];
      for (J = 0, G = M.length; J < G; J++) B = M[J], Z = I.getElementsByTagName(B), F = F.concat(Array.prototype.slice.call(Z));
      return F;
    }
    function D(I, M) {
      var B, Z = !0;
      return (B = j(I, M.pop())) && M.length && (Z = function(J, G) {
        for (var F, q = !0; J.parentNode && J.parentNode.nodeType === 1 && G.length; ) q && (F = G.pop()), q = j(J = J.parentNode, F);
        return G.length === 0;
      }(I, M)), B && Z && M.length === 0;
    }
    function j(I, M) {
      var B, Z, J = I.nodeName, G = I.getAttribute("class"), F = I.getAttribute("id");
      if (B = new RegExp("^" + J, "i"), M = M.replace(B, ""), F && M.length && (B = new RegExp("#" + F + "(?![a-zA-Z\\-]+)", "i"), M = M.replace(B, "")), G && M.length) for (Z = (G = G.split(" ")).length; Z--; ) B = new RegExp("\\." + G[Z] + "(?![a-zA-Z\\-]+)", "i"), M = M.replace(B, "");
      return M.length === 0;
    }
    function w(I, M) {
      var B;
      if (I.getElementById && (B = I.getElementById(M)), B) return B;
      var Z, J, G, F = I.getElementsByTagName("*");
      for (J = 0, G = F.length; J < G; J++) if (M === (Z = F[J]).getAttribute("id")) return Z;
    }
    a.svgValidTagNamesRegEx = k(["path", "circle", "polygon", "polyline", "ellipse", "rect", "line", "image", "text"]), a.svgViewBoxElementsRegEx = k(["symbol", "image", "marker", "pattern", "view", "svg"]), a.svgInvalidAncestorsRegEx = k(["pattern", "defs", "symbol", "metadata", "clipPath", "mask", "desc"]), a.svgValidParentsRegEx = k(["symbol", "g", "a", "svg", "clipPath", "defs"]), a.cssRules = {}, a.gradientDefs = {}, a.clipPaths = {}, a.parseTransformAttribute = function() {
      function I(q, z, X) {
        q[X] = Math.tan(a.util.degreesToRadians(z[0]));
      }
      var M = a.iMatrix, B = a.reNum, Z = a.commaWsp, J = "(?:" + ("(?:(matrix)\\s*\\(\\s*(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")\\s*\\))") + "|" + ("(?:(translate)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(scale)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(rotate)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + ")" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(skewX)\\s*\\(\\s*(" + B + ")\\s*\\))") + "|" + ("(?:(skewY)\\s*\\(\\s*(" + B + ")\\s*\\))") + ")", G = new RegExp("^\\s*(?:" + ("(?:" + J + "(?:" + Z + "*" + J + ")*)") + "?)\\s*$"), F = new RegExp(J, "g");
      return function(q) {
        var z = M.concat(), X = [];
        if (!q || q && !G.test(q)) return z;
        q.replace(F, function(ct) {
          var ot = new RegExp(J).exec(ct).filter(function(dt) {
            return !!dt;
          }), mt = ot[1], lt = ot.slice(2).map(parseFloat);
          switch (mt) {
            case "translate":
              (function(dt, ft) {
                dt[4] = ft[0], ft.length === 2 && (dt[5] = ft[1]);
              })(z, lt);
              break;
            case "rotate":
              lt[0] = a.util.degreesToRadians(lt[0]), function(dt, ft) {
                var St = a.util.cos(ft[0]), yt = a.util.sin(ft[0]), Ot = 0, Et = 0;
                ft.length === 3 && (Ot = ft[1], Et = ft[2]), dt[0] = St, dt[1] = yt, dt[2] = -yt, dt[3] = St, dt[4] = Ot - (St * Ot - yt * Et), dt[5] = Et - (yt * Ot + St * Et);
              }(z, lt);
              break;
            case "scale":
              (function(dt, ft) {
                var St = ft[0], yt = ft.length === 2 ? ft[1] : ft[0];
                dt[0] = St, dt[3] = yt;
              })(z, lt);
              break;
            case "skewX":
              I(z, lt, 2);
              break;
            case "skewY":
              I(z, lt, 1);
              break;
            case "matrix":
              z = lt;
          }
          X.push(z.concat()), z = M.concat();
        });
        for (var et = X[0]; X.length > 1; ) X.shift(), et = a.util.multiplyTransformMatrices(et, X[0]);
        return et;
      };
    }();
    var O = new RegExp("^\\s*(" + a.reNum + "+)\\s*,?\\s*(" + a.reNum + "+)\\s*,?\\s*(" + a.reNum + "+)\\s*,?\\s*(" + a.reNum + "+)\\s*$");
    function L(I) {
      if (!a.svgViewBoxElementsRegEx.test(I.nodeName)) return {};
      var M, B, Z, J, G, F, q = I.getAttribute("viewBox"), z = 1, X = 1, et = I.getAttribute("width"), ct = I.getAttribute("height"), ot = I.getAttribute("x") || 0, mt = I.getAttribute("y") || 0, lt = I.getAttribute("preserveAspectRatio") || "", dt = !q || !(q = q.match(O)), ft = !et || !ct || et === "100%" || ct === "100%", St = dt && ft, yt = {}, Ot = "", Et = 0, Dt = 0;
      if (yt.width = 0, yt.height = 0, yt.toBeParsed = St, dt && (ot || mt) && I.parentNode && I.parentNode.nodeName !== "#document" && (Ot = " translate(" + r(ot) + " " + r(mt) + ") ", G = (I.getAttribute("transform") || "") + Ot, I.setAttribute("transform", G), I.removeAttribute("x"), I.removeAttribute("y")), St) return yt;
      if (dt) return yt.width = r(et), yt.height = r(ct), yt;
      if (M = -parseFloat(q[1]), B = -parseFloat(q[2]), Z = parseFloat(q[3]), J = parseFloat(q[4]), yt.minX = M, yt.minY = B, yt.viewBoxWidth = Z, yt.viewBoxHeight = J, ft ? (yt.width = Z, yt.height = J) : (yt.width = r(et), yt.height = r(ct), z = yt.width / Z, X = yt.height / J), (lt = a.util.parsePreserveAspectRatioAttribute(lt)).alignX !== "none" && (lt.meetOrSlice === "meet" && (X = z = z > X ? X : z), lt.meetOrSlice === "slice" && (X = z = z > X ? z : X), Et = yt.width - Z * z, Dt = yt.height - J * z, lt.alignX === "Mid" && (Et /= 2), lt.alignY === "Mid" && (Dt /= 2), lt.alignX === "Min" && (Et = 0), lt.alignY === "Min" && (Dt = 0)), z === 1 && X === 1 && M === 0 && B === 0 && ot === 0 && mt === 0) return yt;
      if ((ot || mt) && I.parentNode.nodeName !== "#document" && (Ot = " translate(" + r(ot) + " " + r(mt) + ") "), G = Ot + " matrix(" + z + " 0 0 " + X + " " + (M * z + Et) + " " + (B * X + Dt) + ") ", I.nodeName === "svg") {
        for (F = I.ownerDocument.createElementNS(a.svgNS, "g"); I.firstChild; ) F.appendChild(I.firstChild);
        I.appendChild(F);
      } else (F = I).removeAttribute("x"), F.removeAttribute("y"), G = F.getAttribute("transform") + G;
      return F.setAttribute("transform", G), yt;
    }
    function U(I, M) {
      var B = "xlink:href", Z = w(I, M.getAttribute(B).substr(1));
      if (Z && Z.getAttribute(B) && U(I, Z), ["gradientTransform", "x1", "x2", "y1", "y2", "gradientUnits", "cx", "cy", "r", "fx", "fy"].forEach(function(G) {
        Z && !M.hasAttribute(G) && Z.hasAttribute(G) && M.setAttribute(G, Z.getAttribute(G));
      }), !M.children.length) for (var J = Z.cloneNode(!0); J.firstChild; ) M.appendChild(J.firstChild);
      M.removeAttribute(B);
    }
    a.parseSVGDocument = function(I, M, B, Z) {
      if (I) {
        (function(ot) {
          for (var mt = T(ot, ["use", "svg:use"]), lt = 0; mt.length && lt < mt.length; ) {
            var dt = mt[lt], ft = dt.getAttribute("xlink:href") || dt.getAttribute("href");
            if (ft === null) return;
            var St, yt, Ot, Et, Dt = ft.substr(1), Zt = dt.getAttribute("x") || 0, Ut = dt.getAttribute("y") || 0, It = w(ot, Dt).cloneNode(!0), se = (It.getAttribute("transform") || "") + " translate(" + Zt + ", " + Ut + ")", Nt = mt.length, ne = a.svgNS;
            if (L(It), /^svg$/i.test(It.nodeName)) {
              var hi = It.ownerDocument.createElementNS(ne, "g");
              for (yt = 0, Et = (Ot = It.attributes).length; yt < Et; yt++) St = Ot.item(yt), hi.setAttributeNS(ne, St.nodeName, St.nodeValue);
              for (; It.firstChild; ) hi.appendChild(It.firstChild);
              It = hi;
            }
            for (yt = 0, Et = (Ot = dt.attributes).length; yt < Et; yt++) (St = Ot.item(yt)).nodeName !== "x" && St.nodeName !== "y" && St.nodeName !== "xlink:href" && St.nodeName !== "href" && (St.nodeName === "transform" ? se = St.nodeValue + " " + se : It.setAttribute(St.nodeName, St.nodeValue));
            It.setAttribute("transform", se), It.setAttribute("instantiated_by_use", "1"), It.removeAttribute("id"), dt.parentNode.replaceChild(It, dt), mt.length === Nt && lt++;
          }
        })(I);
        var J, G, F = a.Object.__uid++, q = L(I), z = a.util.toArray(I.getElementsByTagName("*"));
        if (q.crossOrigin = Z && Z.crossOrigin, q.svgUid = F, z.length === 0 && a.isLikelyNode) {
          var X = [];
          for (J = 0, G = (z = I.selectNodes('//*[name(.)!="svg"]')).length; J < G; J++) X[J] = z[J];
          z = X;
        }
        var et = z.filter(function(ot) {
          return L(ot), a.svgValidTagNamesRegEx.test(ot.nodeName.replace("svg:", "")) && !function(mt, lt) {
            for (; mt && (mt = mt.parentNode); ) if (mt.nodeName && lt.test(mt.nodeName.replace("svg:", "")) && !mt.getAttribute("instantiated_by_use")) return !0;
            return !1;
          }(ot, a.svgInvalidAncestorsRegEx);
        });
        if (!et || et && !et.length) M && M([], {});
        else {
          var ct = {};
          z.filter(function(ot) {
            return ot.nodeName.replace("svg:", "") === "clipPath";
          }).forEach(function(ot) {
            var mt = ot.getAttribute("id");
            ct[mt] = a.util.toArray(ot.getElementsByTagName("*")).filter(function(lt) {
              return a.svgValidTagNamesRegEx.test(lt.nodeName.replace("svg:", ""));
            });
          }), a.gradientDefs[F] = a.getGradientDefs(I), a.cssRules[F] = a.getCSSRules(I), a.clipPaths[F] = ct, a.parseElements(et, function(ot, mt) {
            M && (M(ot, q, mt, z), delete a.gradientDefs[F], delete a.cssRules[F], delete a.clipPaths[F]);
          }, f(q), B, Z);
        }
      }
    };
    var W = new RegExp("(normal|italic)?\\s*(normal|small-caps)?\\s*(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)?\\s*(" + a.reNum + "(?:px|cm|mm|em|pt|pc|in)*)(?:\\/(normal|" + a.reNum + "))?\\s+(.*)");
    c(a, { parseFontDeclaration: function(I, M) {
      var B = I.match(W);
      if (B) {
        var Z = B[1], J = B[3], G = B[4], F = B[5], q = B[6];
        Z && (M.fontStyle = Z), J && (M.fontWeight = isNaN(parseFloat(J)) ? J : parseFloat(J)), G && (M.fontSize = r(G)), q && (M.fontFamily = q), F && (M.lineHeight = F === "normal" ? 1 : F);
      }
    }, getGradientDefs: function(I) {
      var M, B = T(I, ["linearGradient", "radialGradient", "svg:linearGradient", "svg:radialGradient"]), Z = 0, J = {};
      for (Z = B.length; Z--; ) (M = B[Z]).getAttribute("xlink:href") && U(I, M), J[M.getAttribute("id")] = M;
      return J;
    }, parseAttributes: function(I, M, B) {
      if (I) {
        var Z, J, G, F = {};
        B === void 0 && (B = I.getAttribute("svgUid")), I.parentNode && a.svgValidParentsRegEx.test(I.parentNode.nodeName) && (F = a.parseAttributes(I.parentNode, M, B));
        var q = M.reduce(function(lt, dt) {
          return (Z = I.getAttribute(dt)) && (lt[dt] = Z), lt;
        }, {}), z = c(function(lt, dt) {
          var ft = {};
          for (var St in a.cssRules[dt]) if (D(lt, St.split(" "))) for (var yt in a.cssRules[dt][St]) ft[yt] = a.cssRules[dt][St][yt];
          return ft;
        }(I, B), a.parseStyleAttribute(I));
        q = c(q, z), z[m] && I.setAttribute(m, z[m]), J = G = F.fontSize || a.Text.DEFAULT_SVG_FONT_SIZE, q[p] && (q[p] = J = r(q[p], G));
        var X, et, ct = {};
        for (var ot in q) et = _(X = y(ot), q[ot], F, J), ct[X] = et;
        ct && ct.font && a.parseFontDeclaration(ct.font, ct);
        var mt = c(F, ct);
        return a.svgValidParentsRegEx.test(I.nodeName) ? mt : function(lt) {
          for (var dt in d) if (lt[d[dt]] !== void 0 && lt[dt] !== "") {
            if (lt[dt] === void 0) {
              if (!a.Object.prototype[dt]) continue;
              lt[dt] = a.Object.prototype[dt];
            }
            if (lt[dt].indexOf("url(") !== 0) {
              var ft = new a.Color(lt[dt]);
              lt[dt] = ft.setAlpha(i(ft.getAlpha() * lt[d[dt]], 2)).toRgba();
            }
          }
          return lt;
        }(mt);
      }
    }, parseElements: function(I, M, B, Z, J) {
      new a.ElementsParser(I, M, B, Z, J).parse();
    }, parseStyleAttribute: function(I) {
      var M = {}, B = I.getAttribute("style");
      return B && (typeof B == "string" ? function(Z, J) {
        var G, F;
        Z.replace(/;\s*$/, "").split(";").forEach(function(q) {
          var z = q.split(":");
          G = z[0].trim().toLowerCase(), F = z[1].trim(), J[G] = F;
        });
      }(B, M) : function(Z, J) {
        var G, F;
        for (var q in Z) Z[q] !== void 0 && (G = q.toLowerCase(), F = Z[q], J[G] = F);
      }(B, M)), M;
    }, parsePointsAttribute: function(I) {
      if (!I) return null;
      var M, B, Z = [];
      for (M = 0, B = (I = (I = I.replace(/,/g, " ").trim()).split(/\s+/)).length; M < B; M += 2) Z.push({ x: parseFloat(I[M]), y: parseFloat(I[M + 1]) });
      return Z;
    }, getCSSRules: function(I) {
      var M, B, Z = I.getElementsByTagName("style"), J = {};
      for (M = 0, B = Z.length; M < B; M++) {
        var G = Z[M].textContent;
        (G = G.replace(/\/\*[\s\S]*?\*\//g, "")).trim() !== "" && G.match(/[^{]*\{[\s\S]*?\}/g).map(function(F) {
          return F.trim();
        }).forEach(function(F) {
          var q = F.match(/([\s\S]*?)\s*\{([^}]*)\}/), z = {}, X = q[2].trim().replace(/;$/, "").split(/\s*;\s*/);
          for (M = 0, B = X.length; M < B; M++) {
            var et = X[M].split(/\s*:\s*/), ct = et[0], ot = et[1];
            z[ct] = ot;
          }
          (F = q[1]).split(",").forEach(function(mt) {
            (mt = mt.replace(/^svg/i, "").trim()) !== "" && (J[mt] ? a.util.object.extend(J[mt], z) : J[mt] = a.util.object.clone(z));
          });
        });
      }
      return J;
    }, loadSVGFromURL: function(I, M, B, Z) {
      I = I.replace(/^\n\s*/, "").trim(), new a.util.request(I, { method: "get", onComplete: function(J) {
        var G = J.responseXML;
        if (!G || !G.documentElement) return M && M(null), !1;
        a.parseSVGDocument(G.documentElement, function(F, q, z, X) {
          M && M(F, q, z, X);
        }, B, Z);
      } });
    }, loadSVGFromString: function(I, M, B, Z) {
      var J = new a.window.DOMParser().parseFromString(I.trim(), "text/xml");
      a.parseSVGDocument(J.documentElement, function(G, F, q, z) {
        M(G, F, q, z);
      }, B, Z);
    } });
  }(t), b.ElementsParser = function(l, a, c, f, i, r) {
    this.elements = l, this.callback = a, this.options = c, this.reviver = f, this.svgUid = c && c.svgUid || 0, this.parsingOptions = i, this.regexUrl = /^url\(['"]?#([^'"]+)['"]?\)/g, this.doc = r;
  }, (H = b.ElementsParser.prototype).parse = function() {
    this.instances = new Array(this.elements.length), this.numElements = this.elements.length, this.createObjects();
  }, H.createObjects = function() {
    var l = this;
    this.elements.forEach(function(a, c) {
      a.setAttribute("svgUid", l.svgUid), l.createObject(a, c);
    });
  }, H.findTag = function(l) {
    return b[b.util.string.capitalize(l.tagName.replace("svg:", ""))];
  }, H.createObject = function(l, a) {
    var c = this.findTag(l);
    if (c && c.fromElement) try {
      c.fromElement(l, this.createCallback(a, l), this.options);
    } catch (f) {
      b.log(f);
    }
    else this.checkIfDone();
  }, H.createCallback = function(l, a) {
    var c = this;
    return function(f) {
      var i;
      c.resolveGradient(f, a, "fill"), c.resolveGradient(f, a, "stroke"), f instanceof b.Image && f._originalElement && (i = f.parsePreserveAspectRatioAttribute(a)), f._removeTransformMatrix(i), c.resolveClipPath(f, a), c.reviver && c.reviver(a, f), c.instances[l] = f, c.checkIfDone();
    };
  }, H.extractPropertyDefinition = function(l, a, c) {
    var f = l[a], i = this.regexUrl;
    if (i.test(f)) {
      i.lastIndex = 0;
      var r = i.exec(f)[1];
      return i.lastIndex = 0, b[c][this.svgUid][r];
    }
  }, H.resolveGradient = function(l, a, c) {
    var f = this.extractPropertyDefinition(l, c, "gradientDefs");
    if (f) {
      var i = a.getAttribute(c + "-opacity"), r = b.Gradient.fromElement(f, l, i, this.options);
      l.set(c, r);
    }
  }, H.createClipPathCallback = function(l, a) {
    return function(c) {
      c._removeTransformMatrix(), c.fillRule = c.clipRule, a.push(c);
    };
  }, H.resolveClipPath = function(l, a) {
    var c, f, i, r, s = this.extractPropertyDefinition(l, "clipPath", "clipPaths");
    if (s) {
      i = [], f = b.util.invertTransform(l.calcTransformMatrix());
      for (var h = s[0].parentNode, d = a; d.parentNode && d.getAttribute("clip-path") !== l.clipPath; ) d = d.parentNode;
      d.parentNode.appendChild(h);
      for (var p = 0; p < s.length; p++) c = s[p], this.findTag(c).fromElement(c, this.createClipPathCallback(l, i), this.options);
      s = i.length === 1 ? i[0] : new b.Group(i), r = b.util.multiplyTransformMatrices(f, s.calcTransformMatrix()), s.clipPath && this.resolveClipPath(s, d);
      var m = b.util.qrDecompose(r);
      s.flipX = !1, s.flipY = !1, s.set("scaleX", m.scaleX), s.set("scaleY", m.scaleY), s.angle = m.angle, s.skewX = m.skewX, s.skewY = 0, s.setPositionByOrigin({ x: m.translateX, y: m.translateY }, "center", "center"), l.clipPath = s;
    } else delete l.clipPath;
  }, H.checkIfDone = function() {
    --this.numElements == 0 && (this.instances = this.instances.filter(function(l) {
      return l != null;
    }), this.callback(this.instances, this.elements));
  }, function(l) {
    var a = l.fabric || (l.fabric = {});
    function c(f, i) {
      this.x = f, this.y = i;
    }
    a.Point ? a.warn("fabric.Point is already defined") : (a.Point = c, c.prototype = { type: "point", constructor: c, add: function(f) {
      return new c(this.x + f.x, this.y + f.y);
    }, addEquals: function(f) {
      return this.x += f.x, this.y += f.y, this;
    }, scalarAdd: function(f) {
      return new c(this.x + f, this.y + f);
    }, scalarAddEquals: function(f) {
      return this.x += f, this.y += f, this;
    }, subtract: function(f) {
      return new c(this.x - f.x, this.y - f.y);
    }, subtractEquals: function(f) {
      return this.x -= f.x, this.y -= f.y, this;
    }, scalarSubtract: function(f) {
      return new c(this.x - f, this.y - f);
    }, scalarSubtractEquals: function(f) {
      return this.x -= f, this.y -= f, this;
    }, multiply: function(f) {
      return new c(this.x * f, this.y * f);
    }, multiplyEquals: function(f) {
      return this.x *= f, this.y *= f, this;
    }, divide: function(f) {
      return new c(this.x / f, this.y / f);
    }, divideEquals: function(f) {
      return this.x /= f, this.y /= f, this;
    }, eq: function(f) {
      return this.x === f.x && this.y === f.y;
    }, lt: function(f) {
      return this.x < f.x && this.y < f.y;
    }, lte: function(f) {
      return this.x <= f.x && this.y <= f.y;
    }, gt: function(f) {
      return this.x > f.x && this.y > f.y;
    }, gte: function(f) {
      return this.x >= f.x && this.y >= f.y;
    }, lerp: function(f, i) {
      return i === void 0 && (i = 0.5), i = Math.max(Math.min(1, i), 0), new c(this.x + (f.x - this.x) * i, this.y + (f.y - this.y) * i);
    }, distanceFrom: function(f) {
      var i = this.x - f.x, r = this.y - f.y;
      return Math.sqrt(i * i + r * r);
    }, midPointFrom: function(f) {
      return this.lerp(f);
    }, min: function(f) {
      return new c(Math.min(this.x, f.x), Math.min(this.y, f.y));
    }, max: function(f) {
      return new c(Math.max(this.x, f.x), Math.max(this.y, f.y));
    }, toString: function() {
      return this.x + "," + this.y;
    }, setXY: function(f, i) {
      return this.x = f, this.y = i, this;
    }, setX: function(f) {
      return this.x = f, this;
    }, setY: function(f) {
      return this.y = f, this;
    }, setFromPoint: function(f) {
      return this.x = f.x, this.y = f.y, this;
    }, swap: function(f) {
      var i = this.x, r = this.y;
      this.x = f.x, this.y = f.y, f.x = i, f.y = r;
    }, clone: function() {
      return new c(this.x, this.y);
    } });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    function c(f) {
      this.status = f, this.points = [];
    }
    a.Intersection ? a.warn("fabric.Intersection is already defined") : (a.Intersection = c, a.Intersection.prototype = { constructor: c, appendPoint: function(f) {
      return this.points.push(f), this;
    }, appendPoints: function(f) {
      return this.points = this.points.concat(f), this;
    } }, a.Intersection.intersectLineLine = function(f, i, r, s) {
      var h, d = (s.x - r.x) * (f.y - r.y) - (s.y - r.y) * (f.x - r.x), p = (i.x - f.x) * (f.y - r.y) - (i.y - f.y) * (f.x - r.x), m = (s.y - r.y) * (i.x - f.x) - (s.x - r.x) * (i.y - f.y);
      if (m !== 0) {
        var y = d / m, _ = p / m;
        0 <= y && y <= 1 && 0 <= _ && _ <= 1 ? (h = new c("Intersection")).appendPoint(new a.Point(f.x + y * (i.x - f.x), f.y + y * (i.y - f.y))) : h = new c();
      } else h = new c(d === 0 || p === 0 ? "Coincident" : "Parallel");
      return h;
    }, a.Intersection.intersectLinePolygon = function(f, i, r) {
      var s, h, d, p, m = new c(), y = r.length;
      for (p = 0; p < y; p++) s = r[p], h = r[(p + 1) % y], d = c.intersectLineLine(f, i, s, h), m.appendPoints(d.points);
      return m.points.length > 0 && (m.status = "Intersection"), m;
    }, a.Intersection.intersectPolygonPolygon = function(f, i) {
      var r, s = new c(), h = f.length;
      for (r = 0; r < h; r++) {
        var d = f[r], p = f[(r + 1) % h], m = c.intersectLinePolygon(d, p, i);
        s.appendPoints(m.points);
      }
      return s.points.length > 0 && (s.status = "Intersection"), s;
    }, a.Intersection.intersectPolygonRectangle = function(f, i, r) {
      var s = i.min(r), h = i.max(r), d = new a.Point(h.x, s.y), p = new a.Point(s.x, h.y), m = c.intersectLinePolygon(s, d, f), y = c.intersectLinePolygon(d, h, f), _ = c.intersectLinePolygon(h, p, f), k = c.intersectLinePolygon(p, s, f), T = new c();
      return T.appendPoints(m.points), T.appendPoints(y.points), T.appendPoints(_.points), T.appendPoints(k.points), T.points.length > 0 && (T.status = "Intersection"), T;
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    function c(i) {
      i ? this._tryParsingColor(i) : this.setSource([0, 0, 0, 1]);
    }
    function f(i, r, s) {
      return s < 0 && (s += 1), s > 1 && (s -= 1), s < 1 / 6 ? i + 6 * (r - i) * s : s < 0.5 ? r : s < 2 / 3 ? i + (r - i) * (2 / 3 - s) * 6 : i;
    }
    a.Color ? a.warn("fabric.Color is already defined.") : (a.Color = c, a.Color.prototype = { _tryParsingColor: function(i) {
      var r;
      i in c.colorNameMap && (i = c.colorNameMap[i]), i === "transparent" && (r = [255, 255, 255, 0]), r || (r = c.sourceFromHex(i)), r || (r = c.sourceFromRgb(i)), r || (r = c.sourceFromHsl(i)), r || (r = [0, 0, 0, 1]), r && this.setSource(r);
    }, _rgbToHsl: function(i, r, s) {
      i /= 255, r /= 255, s /= 255;
      var h, d, p, m = a.util.array.max([i, r, s]), y = a.util.array.min([i, r, s]);
      if (p = (m + y) / 2, m === y) h = d = 0;
      else {
        var _ = m - y;
        switch (d = p > 0.5 ? _ / (2 - m - y) : _ / (m + y), m) {
          case i:
            h = (r - s) / _ + (r < s ? 6 : 0);
            break;
          case r:
            h = (s - i) / _ + 2;
            break;
          case s:
            h = (i - r) / _ + 4;
        }
        h /= 6;
      }
      return [Math.round(360 * h), Math.round(100 * d), Math.round(100 * p)];
    }, getSource: function() {
      return this._source;
    }, setSource: function(i) {
      this._source = i;
    }, toRgb: function() {
      var i = this.getSource();
      return "rgb(" + i[0] + "," + i[1] + "," + i[2] + ")";
    }, toRgba: function() {
      var i = this.getSource();
      return "rgba(" + i[0] + "," + i[1] + "," + i[2] + "," + i[3] + ")";
    }, toHsl: function() {
      var i = this.getSource(), r = this._rgbToHsl(i[0], i[1], i[2]);
      return "hsl(" + r[0] + "," + r[1] + "%," + r[2] + "%)";
    }, toHsla: function() {
      var i = this.getSource(), r = this._rgbToHsl(i[0], i[1], i[2]);
      return "hsla(" + r[0] + "," + r[1] + "%," + r[2] + "%," + i[3] + ")";
    }, toHex: function() {
      var i, r, s, h = this.getSource();
      return i = (i = h[0].toString(16)).length === 1 ? "0" + i : i, r = (r = h[1].toString(16)).length === 1 ? "0" + r : r, s = (s = h[2].toString(16)).length === 1 ? "0" + s : s, i.toUpperCase() + r.toUpperCase() + s.toUpperCase();
    }, toHexa: function() {
      var i, r = this.getSource();
      return i = (i = (i = Math.round(255 * r[3])).toString(16)).length === 1 ? "0" + i : i, this.toHex() + i.toUpperCase();
    }, getAlpha: function() {
      return this.getSource()[3];
    }, setAlpha: function(i) {
      var r = this.getSource();
      return r[3] = i, this.setSource(r), this;
    }, toGrayscale: function() {
      var i = this.getSource(), r = parseInt((0.3 * i[0] + 0.59 * i[1] + 0.11 * i[2]).toFixed(0), 10), s = i[3];
      return this.setSource([r, r, r, s]), this;
    }, toBlackWhite: function(i) {
      var r = this.getSource(), s = (0.3 * r[0] + 0.59 * r[1] + 0.11 * r[2]).toFixed(0), h = r[3];
      return i = i || 127, s = Number(s) < Number(i) ? 0 : 255, this.setSource([s, s, s, h]), this;
    }, overlayWith: function(i) {
      i instanceof c || (i = new c(i));
      var r, s = [], h = this.getAlpha(), d = this.getSource(), p = i.getSource();
      for (r = 0; r < 3; r++) s.push(Math.round(0.5 * d[r] + 0.5 * p[r]));
      return s[3] = h, this.setSource(s), this;
    } }, a.Color.reRGBa = /^rgba?\(\s*(\d{1,3}(?:\.\d+)?\%?)\s*,\s*(\d{1,3}(?:\.\d+)?\%?)\s*,\s*(\d{1,3}(?:\.\d+)?\%?)\s*(?:\s*,\s*((?:\d*\.?\d+)?)\s*)?\)$/i, a.Color.reHSLa = /^hsla?\(\s*(\d{1,3})\s*,\s*(\d{1,3}\%)\s*,\s*(\d{1,3}\%)\s*(?:\s*,\s*(\d+(?:\.\d+)?)\s*)?\)$/i, a.Color.reHex = /^#?([0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})$/i, a.Color.colorNameMap = { aliceblue: "#F0F8FF", antiquewhite: "#FAEBD7", aqua: "#00FFFF", aquamarine: "#7FFFD4", azure: "#F0FFFF", beige: "#F5F5DC", bisque: "#FFE4C4", black: "#000000", blanchedalmond: "#FFEBCD", blue: "#0000FF", blueviolet: "#8A2BE2", brown: "#A52A2A", burlywood: "#DEB887", cadetblue: "#5F9EA0", chartreuse: "#7FFF00", chocolate: "#D2691E", coral: "#FF7F50", cornflowerblue: "#6495ED", cornsilk: "#FFF8DC", crimson: "#DC143C", cyan: "#00FFFF", darkblue: "#00008B", darkcyan: "#008B8B", darkgoldenrod: "#B8860B", darkgray: "#A9A9A9", darkgrey: "#A9A9A9", darkgreen: "#006400", darkkhaki: "#BDB76B", darkmagenta: "#8B008B", darkolivegreen: "#556B2F", darkorange: "#FF8C00", darkorchid: "#9932CC", darkred: "#8B0000", darksalmon: "#E9967A", darkseagreen: "#8FBC8F", darkslateblue: "#483D8B", darkslategray: "#2F4F4F", darkslategrey: "#2F4F4F", darkturquoise: "#00CED1", darkviolet: "#9400D3", deeppink: "#FF1493", deepskyblue: "#00BFFF", dimgray: "#696969", dimgrey: "#696969", dodgerblue: "#1E90FF", firebrick: "#B22222", floralwhite: "#FFFAF0", forestgreen: "#228B22", fuchsia: "#FF00FF", gainsboro: "#DCDCDC", ghostwhite: "#F8F8FF", gold: "#FFD700", goldenrod: "#DAA520", gray: "#808080", grey: "#808080", green: "#008000", greenyellow: "#ADFF2F", honeydew: "#F0FFF0", hotpink: "#FF69B4", indianred: "#CD5C5C", indigo: "#4B0082", ivory: "#FFFFF0", khaki: "#F0E68C", lavender: "#E6E6FA", lavenderblush: "#FFF0F5", lawngreen: "#7CFC00", lemonchiffon: "#FFFACD", lightblue: "#ADD8E6", lightcoral: "#F08080", lightcyan: "#E0FFFF", lightgoldenrodyellow: "#FAFAD2", lightgray: "#D3D3D3", lightgrey: "#D3D3D3", lightgreen: "#90EE90", lightpink: "#FFB6C1", lightsalmon: "#FFA07A", lightseagreen: "#20B2AA", lightskyblue: "#87CEFA", lightslategray: "#778899", lightslategrey: "#778899", lightsteelblue: "#B0C4DE", lightyellow: "#FFFFE0", lime: "#00FF00", limegreen: "#32CD32", linen: "#FAF0E6", magenta: "#FF00FF", maroon: "#800000", mediumaquamarine: "#66CDAA", mediumblue: "#0000CD", mediumorchid: "#BA55D3", mediumpurple: "#9370DB", mediumseagreen: "#3CB371", mediumslateblue: "#7B68EE", mediumspringgreen: "#00FA9A", mediumturquoise: "#48D1CC", mediumvioletred: "#C71585", midnightblue: "#191970", mintcream: "#F5FFFA", mistyrose: "#FFE4E1", moccasin: "#FFE4B5", navajowhite: "#FFDEAD", navy: "#000080", oldlace: "#FDF5E6", olive: "#808000", olivedrab: "#6B8E23", orange: "#FFA500", orangered: "#FF4500", orchid: "#DA70D6", palegoldenrod: "#EEE8AA", palegreen: "#98FB98", paleturquoise: "#AFEEEE", palevioletred: "#DB7093", papayawhip: "#FFEFD5", peachpuff: "#FFDAB9", peru: "#CD853F", pink: "#FFC0CB", plum: "#DDA0DD", powderblue: "#B0E0E6", purple: "#800080", rebeccapurple: "#663399", red: "#FF0000", rosybrown: "#BC8F8F", royalblue: "#4169E1", saddlebrown: "#8B4513", salmon: "#FA8072", sandybrown: "#F4A460", seagreen: "#2E8B57", seashell: "#FFF5EE", sienna: "#A0522D", silver: "#C0C0C0", skyblue: "#87CEEB", slateblue: "#6A5ACD", slategray: "#708090", slategrey: "#708090", snow: "#FFFAFA", springgreen: "#00FF7F", steelblue: "#4682B4", tan: "#D2B48C", teal: "#008080", thistle: "#D8BFD8", tomato: "#FF6347", turquoise: "#40E0D0", violet: "#EE82EE", wheat: "#F5DEB3", white: "#FFFFFF", whitesmoke: "#F5F5F5", yellow: "#FFFF00", yellowgreen: "#9ACD32" }, a.Color.fromRgb = function(i) {
      return c.fromSource(c.sourceFromRgb(i));
    }, a.Color.sourceFromRgb = function(i) {
      var r = i.match(c.reRGBa);
      if (r) {
        var s = parseInt(r[1], 10) / (/%$/.test(r[1]) ? 100 : 1) * (/%$/.test(r[1]) ? 255 : 1), h = parseInt(r[2], 10) / (/%$/.test(r[2]) ? 100 : 1) * (/%$/.test(r[2]) ? 255 : 1), d = parseInt(r[3], 10) / (/%$/.test(r[3]) ? 100 : 1) * (/%$/.test(r[3]) ? 255 : 1);
        return [parseInt(s, 10), parseInt(h, 10), parseInt(d, 10), r[4] ? parseFloat(r[4]) : 1];
      }
    }, a.Color.fromRgba = c.fromRgb, a.Color.fromHsl = function(i) {
      return c.fromSource(c.sourceFromHsl(i));
    }, a.Color.sourceFromHsl = function(i) {
      var r = i.match(c.reHSLa);
      if (r) {
        var s, h, d, p = (parseFloat(r[1]) % 360 + 360) % 360 / 360, m = parseFloat(r[2]) / (/%$/.test(r[2]) ? 100 : 1), y = parseFloat(r[3]) / (/%$/.test(r[3]) ? 100 : 1);
        if (m === 0) s = h = d = y;
        else {
          var _ = y <= 0.5 ? y * (m + 1) : y + m - y * m, k = 2 * y - _;
          s = f(k, _, p + 1 / 3), h = f(k, _, p), d = f(k, _, p - 1 / 3);
        }
        return [Math.round(255 * s), Math.round(255 * h), Math.round(255 * d), r[4] ? parseFloat(r[4]) : 1];
      }
    }, a.Color.fromHsla = c.fromHsl, a.Color.fromHex = function(i) {
      return c.fromSource(c.sourceFromHex(i));
    }, a.Color.sourceFromHex = function(i) {
      if (i.match(c.reHex)) {
        var r = i.slice(i.indexOf("#") + 1), s = r.length === 3 || r.length === 4, h = r.length === 8 || r.length === 4, d = s ? r.charAt(0) + r.charAt(0) : r.substring(0, 2), p = s ? r.charAt(1) + r.charAt(1) : r.substring(2, 4), m = s ? r.charAt(2) + r.charAt(2) : r.substring(4, 6), y = h ? s ? r.charAt(3) + r.charAt(3) : r.substring(6, 8) : "FF";
        return [parseInt(d, 16), parseInt(p, 16), parseInt(m, 16), parseFloat((parseInt(y, 16) / 255).toFixed(2))];
      }
    }, a.Color.fromSource = function(i) {
      var r = new c();
      return r.setSource(i), r;
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = ["e", "se", "s", "sw", "w", "nw", "n", "ne", "e"], f = ["ns", "nesw", "ew", "nwse"], i = {}, r = "left", s = "top", h = "right", d = "bottom", p = "center", m = { top: d, bottom: s, left: h, right: r, center: p }, y = a.util.radiansToDegrees, _ = Math.sign || function(G) {
      return (G > 0) - (G < 0) || +G;
    };
    function k(G, F) {
      var q = G.angle + y(Math.atan2(F.y, F.x)) + 360;
      return Math.round(q % 360 / 45);
    }
    function T(G, F) {
      var q = F.transform.target, z = q.canvas, X = a.util.object.clone(F);
      X.target = q, z && z.fire("object:" + G, X), q.fire(G, F);
    }
    function D(G, F) {
      var q = F.canvas, z = G[q.uniScaleKey];
      return q.uniformScaling && !z || !q.uniformScaling && z;
    }
    function j(G) {
      return G.originX === p && G.originY === p;
    }
    function w(G, F, q) {
      var z = G.lockScalingX, X = G.lockScalingY;
      return !(!z || !X) || !(F || !z && !X || !q) || !(!z || F !== "x") || !(!X || F !== "y");
    }
    function O(G, F, q, z) {
      return { e: G, transform: F, pointer: { x: q, y: z } };
    }
    function L(G) {
      return function(F, q, z, X) {
        var et = q.target, ct = et.getCenterPoint(), ot = et.translateToOriginPoint(ct, q.originX, q.originY), mt = G(F, q, z, X);
        return et.setPositionByOrigin(ot, q.originX, q.originY), mt;
      };
    }
    function U(G, F) {
      return function(q, z, X, et) {
        var ct = F(q, z, X, et);
        return ct && T(G, O(q, z, X, et)), ct;
      };
    }
    function W(G, F, q, z, X) {
      var et = G.target, ct = et.controls[G.corner], ot = et.canvas.getZoom(), mt = et.padding / ot, lt = et.toLocalPoint(new a.Point(z, X), F, q);
      return lt.x >= mt && (lt.x -= mt), lt.x <= -mt && (lt.x += mt), lt.y >= mt && (lt.y -= mt), lt.y <= mt && (lt.y += mt), lt.x -= ct.offsetX, lt.y -= ct.offsetY, lt;
    }
    function I(G) {
      return G.flipX !== G.flipY;
    }
    function M(G, F, q, z, X) {
      if (G[F] !== 0) {
        var et = X / G._getTransformedDimensions()[z] * G[q];
        G.set(q, et);
      }
    }
    function B(G, F, q, z) {
      var X, et = F.target, ct = et._getTransformedDimensions(0, et.skewY), ot = W(F, F.originX, F.originY, q, z), mt = Math.abs(2 * ot.x) - ct.x, lt = et.skewX;
      mt < 2 ? X = 0 : (X = y(Math.atan2(mt / et.scaleX, ct.y / et.scaleY)), F.originX === r && F.originY === d && (X = -X), F.originX === h && F.originY === s && (X = -X), I(et) && (X = -X));
      var dt = lt !== X;
      if (dt) {
        var ft = et._getTransformedDimensions().y;
        et.set("skewX", X), M(et, "skewY", "scaleY", "y", ft);
      }
      return dt;
    }
    function Z(G, F, q, z) {
      var X, et = F.target, ct = et._getTransformedDimensions(et.skewX, 0), ot = W(F, F.originX, F.originY, q, z), mt = Math.abs(2 * ot.y) - ct.y, lt = et.skewY;
      mt < 2 ? X = 0 : (X = y(Math.atan2(mt / et.scaleY, ct.x / et.scaleX)), F.originX === r && F.originY === d && (X = -X), F.originX === h && F.originY === s && (X = -X), I(et) && (X = -X));
      var dt = lt !== X;
      if (dt) {
        var ft = et._getTransformedDimensions().x;
        et.set("skewY", X), M(et, "skewX", "scaleX", "x", ft);
      }
      return dt;
    }
    function J(G, F, q, z, X) {
      X = X || {};
      var et, ct, ot, mt, lt, dt, ft = F.target, St = ft.lockScalingX, yt = ft.lockScalingY, Ot = X.by, Et = D(G, ft), Dt = w(ft, Ot, Et), Zt = F.gestureScale;
      if (Dt) return !1;
      if (Zt) ct = F.scaleX * Zt, ot = F.scaleY * Zt;
      else {
        if (et = W(F, F.originX, F.originY, q, z), lt = Ot !== "y" ? _(et.x) : 1, dt = Ot !== "x" ? _(et.y) : 1, F.signX || (F.signX = lt), F.signY || (F.signY = dt), ft.lockScalingFlip && (F.signX !== lt || F.signY !== dt)) return !1;
        if (mt = ft._getTransformedDimensions(), Et && !Ot) {
          var Ut = Math.abs(et.x) + Math.abs(et.y), It = F.original, se = Ut / (Math.abs(mt.x * It.scaleX / ft.scaleX) + Math.abs(mt.y * It.scaleY / ft.scaleY));
          ct = It.scaleX * se, ot = It.scaleY * se;
        } else ct = Math.abs(et.x * ft.scaleX / mt.x), ot = Math.abs(et.y * ft.scaleY / mt.y);
        j(F) && (ct *= 2, ot *= 2), F.signX !== lt && Ot !== "y" && (F.originX = m[F.originX], ct *= -1, F.signX = lt), F.signY !== dt && Ot !== "x" && (F.originY = m[F.originY], ot *= -1, F.signY = dt);
      }
      var Nt = ft.scaleX, ne = ft.scaleY;
      return Ot ? (Ot === "x" && ft.set("scaleX", ct), Ot === "y" && ft.set("scaleY", ot)) : (!St && ft.set("scaleX", ct), !yt && ft.set("scaleY", ot)), Nt !== ft.scaleX || ne !== ft.scaleY;
    }
    i.scaleCursorStyleHandler = function(G, F, q) {
      var z = D(G, q), X = "";
      if (F.x !== 0 && F.y === 0 ? X = "x" : F.x === 0 && F.y !== 0 && (X = "y"), w(q, X, z)) return "not-allowed";
      var et = k(q, F);
      return c[et] + "-resize";
    }, i.skewCursorStyleHandler = function(G, F, q) {
      var z = "not-allowed";
      if (F.x !== 0 && q.lockSkewingY || F.y !== 0 && q.lockSkewingX) return z;
      var X = k(q, F) % 4;
      return f[X] + "-resize";
    }, i.scaleSkewCursorStyleHandler = function(G, F, q) {
      return G[q.canvas.altActionKey] ? i.skewCursorStyleHandler(G, F, q) : i.scaleCursorStyleHandler(G, F, q);
    }, i.rotationWithSnapping = U("rotating", L(function(G, F, q, z) {
      var X = F, et = X.target, ct = et.translateToOriginPoint(et.getCenterPoint(), X.originX, X.originY);
      if (et.lockRotation) return !1;
      var ot, mt = Math.atan2(X.ey - ct.y, X.ex - ct.x), lt = Math.atan2(z - ct.y, q - ct.x), dt = y(lt - mt + X.theta);
      if (et.snapAngle > 0) {
        var ft = et.snapAngle, St = et.snapThreshold || ft, yt = Math.ceil(dt / ft) * ft, Ot = Math.floor(dt / ft) * ft;
        Math.abs(dt - Ot) < St ? dt = Ot : Math.abs(dt - yt) < St && (dt = yt);
      }
      return dt < 0 && (dt = 360 + dt), dt %= 360, ot = et.angle !== dt, et.angle = dt, ot;
    })), i.scalingEqually = U("scaling", L(function(G, F, q, z) {
      return J(G, F, q, z);
    })), i.scalingX = U("scaling", L(function(G, F, q, z) {
      return J(G, F, q, z, { by: "x" });
    })), i.scalingY = U("scaling", L(function(G, F, q, z) {
      return J(G, F, q, z, { by: "y" });
    })), i.scalingYOrSkewingX = function(G, F, q, z) {
      return G[F.target.canvas.altActionKey] ? i.skewHandlerX(G, F, q, z) : i.scalingY(G, F, q, z);
    }, i.scalingXOrSkewingY = function(G, F, q, z) {
      return G[F.target.canvas.altActionKey] ? i.skewHandlerY(G, F, q, z) : i.scalingX(G, F, q, z);
    }, i.changeWidth = U("resizing", L(function(G, F, q, z) {
      var X = F.target, et = W(F, F.originX, F.originY, q, z), ct = X.strokeWidth / (X.strokeUniform ? X.scaleX : 1), ot = j(F) ? 2 : 1, mt = X.width, lt = Math.abs(et.x * ot / X.scaleX) - ct;
      return X.set("width", Math.max(lt, 0)), mt !== lt;
    })), i.skewHandlerX = function(G, F, q, z) {
      var X, et = F.target, ct = et.skewX, ot = F.originY;
      return !et.lockSkewingX && (ct === 0 ? X = W(F, p, p, q, z).x > 0 ? r : h : (ct > 0 && (X = ot === s ? r : h), ct < 0 && (X = ot === s ? h : r), I(et) && (X = X === r ? h : r)), F.originX = X, U("skewing", L(B))(G, F, q, z));
    }, i.skewHandlerY = function(G, F, q, z) {
      var X, et = F.target, ct = et.skewY, ot = F.originX;
      return !et.lockSkewingY && (ct === 0 ? X = W(F, p, p, q, z).y > 0 ? s : d : (ct > 0 && (X = ot === r ? s : d), ct < 0 && (X = ot === r ? d : s), I(et) && (X = X === s ? d : s)), F.originY = X, U("skewing", L(Z))(G, F, q, z));
    }, i.dragHandler = function(G, F, q, z) {
      var X = F.target, et = q - F.offsetX, ct = z - F.offsetY, ot = !X.get("lockMovementX") && X.left !== et, mt = !X.get("lockMovementY") && X.top !== ct;
      return ot && X.set("left", et), mt && X.set("top", ct), (ot || mt) && T("moving", O(G, F, q, z)), ot || mt;
    }, i.scaleOrSkewActionName = function(G, F, q) {
      var z = G[q.canvas.altActionKey];
      return F.x === 0 ? z ? "skewX" : "scaleY" : F.y === 0 ? z ? "skewY" : "scaleX" : void 0;
    }, i.rotationStyleHandler = function(G, F, q) {
      return q.lockRotation ? "not-allowed" : F.cursorStyle;
    }, i.fireEvent = T, i.wrapWithFixedAnchor = L, i.wrapWithFireEvent = U, i.getLocalPoint = W, a.controlsUtils = i;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.degreesToRadians, f = a.controlsUtils;
    f.renderCircleControl = function(i, r, s, h, d) {
      h = h || {};
      var p, m = this.sizeX || h.cornerSize || d.cornerSize, y = this.sizeY || h.cornerSize || d.cornerSize, _ = h.transparentCorners !== void 0 ? h.transparentCorners : d.transparentCorners, k = _ ? "stroke" : "fill", T = !_ && (h.cornerStrokeColor || d.cornerStrokeColor), D = r, j = s;
      i.save(), i.fillStyle = h.cornerColor || d.cornerColor, i.strokeStyle = h.cornerStrokeColor || d.cornerStrokeColor, m > y ? (p = m, i.scale(1, y / m), j = s * m / y) : y > m ? (p = y, i.scale(m / y, 1), D = r * y / m) : p = m, i.lineWidth = 1, i.beginPath(), i.arc(D, j, p / 2, 0, 2 * Math.PI, !1), i[k](), T && i.stroke(), i.restore();
    }, f.renderSquareControl = function(i, r, s, h, d) {
      h = h || {};
      var p = this.sizeX || h.cornerSize || d.cornerSize, m = this.sizeY || h.cornerSize || d.cornerSize, y = h.transparentCorners !== void 0 ? h.transparentCorners : d.transparentCorners, _ = y ? "stroke" : "fill", k = !y && (h.cornerStrokeColor || d.cornerStrokeColor), T = p / 2, D = m / 2;
      i.save(), i.fillStyle = h.cornerColor || d.cornerColor, i.strokeStyle = h.cornerStrokeColor || d.cornerStrokeColor, i.lineWidth = 1, i.translate(r, s), i.rotate(c(d.angle)), i[_ + "Rect"](-T, -D, p, m), k && i.strokeRect(-T, -D, p, m), i.restore();
    };
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    a.Control = function(c) {
      for (var f in c) this[f] = c[f];
    }, a.Control.prototype = { visible: !0, actionName: "scale", angle: 0, x: 0, y: 0, offsetX: 0, offsetY: 0, sizeX: null, sizeY: null, touchSizeX: null, touchSizeY: null, cursorStyle: "crosshair", withConnection: !1, actionHandler: function() {
    }, mouseDownHandler: function() {
    }, mouseUpHandler: function() {
    }, getActionHandler: function() {
      return this.actionHandler;
    }, getMouseDownHandler: function() {
      return this.mouseDownHandler;
    }, getMouseUpHandler: function() {
      return this.mouseUpHandler;
    }, cursorStyleHandler: function(c, f) {
      return f.cursorStyle;
    }, getActionName: function(c, f) {
      return f.actionName;
    }, getVisibility: function(c, f) {
      var i = c._controlsVisibility;
      return i && i[f] !== void 0 ? i[f] : this.visible;
    }, setVisibility: function(c) {
      this.visible = c;
    }, positionHandler: function(c, f) {
      return a.util.transformPoint({ x: this.x * c.x + this.offsetX, y: this.y * c.y + this.offsetY }, f);
    }, calcCornerCoords: function(c, f, i, r, s) {
      var h, d, p, m, y = s ? this.touchSizeX : this.sizeX, _ = s ? this.touchSizeY : this.sizeY;
      if (y && _ && y !== _) {
        var k = Math.atan2(_, y), T = Math.sqrt(y * y + _ * _) / 2, D = k - a.util.degreesToRadians(c), j = Math.PI / 2 - k - a.util.degreesToRadians(c);
        h = T * a.util.cos(D), d = T * a.util.sin(D), p = T * a.util.cos(j), m = T * a.util.sin(j);
      } else
        T = 0.7071067812 * (y && _ ? y : f), D = a.util.degreesToRadians(45 - c), h = p = T * a.util.cos(D), d = m = T * a.util.sin(D);
      return { tl: { x: i - m, y: r - p }, tr: { x: i + h, y: r - d }, bl: { x: i - h, y: r + d }, br: { x: i + m, y: r + p } };
    }, render: function(c, f, i, r, s) {
      ((r = r || {}).cornerStyle || s.cornerStyle) === "circle" ? a.controlsUtils.renderCircleControl.call(this, c, f, i, r, s) : a.controlsUtils.renderSquareControl.call(this, c, f, i, r, s);
    } };
  }(t), function() {
    function l(c, f) {
      var i, r, s, h, d = c.getAttribute("style"), p = c.getAttribute("offset") || 0;
      if (p = (p = parseFloat(p) / (/%$/.test(p) ? 100 : 1)) < 0 ? 0 : p > 1 ? 1 : p, d) {
        var m = d.split(/\s*;\s*/);
        for (m[m.length - 1] === "" && m.pop(), h = m.length; h--; ) {
          var y = m[h].split(/\s*:\s*/), _ = y[0].trim(), k = y[1].trim();
          _ === "stop-color" ? i = k : _ === "stop-opacity" && (s = k);
        }
      }
      return i || (i = c.getAttribute("stop-color") || "rgb(0,0,0)"), s || (s = c.getAttribute("stop-opacity")), r = (i = new b.Color(i)).getAlpha(), s = isNaN(parseFloat(s)) ? 1 : parseFloat(s), s *= r * f, { offset: p, color: i.toRgb(), opacity: s };
    }
    var a = b.util.object.clone;
    b.Gradient = b.util.createClass({ offsetX: 0, offsetY: 0, gradientTransform: null, gradientUnits: "pixels", type: "linear", initialize: function(c) {
      c || (c = {}), c.coords || (c.coords = {});
      var f, i = this;
      Object.keys(c).forEach(function(r) {
        i[r] = c[r];
      }), this.id ? this.id += "_" + b.Object.__uid++ : this.id = b.Object.__uid++, f = { x1: c.coords.x1 || 0, y1: c.coords.y1 || 0, x2: c.coords.x2 || 0, y2: c.coords.y2 || 0 }, this.type === "radial" && (f.r1 = c.coords.r1 || 0, f.r2 = c.coords.r2 || 0), this.coords = f, this.colorStops = c.colorStops.slice();
    }, addColorStop: function(c) {
      for (var f in c) {
        var i = new b.Color(c[f]);
        this.colorStops.push({ offset: parseFloat(f), color: i.toRgb(), opacity: i.getAlpha() });
      }
      return this;
    }, toObject: function(c) {
      var f = { type: this.type, coords: this.coords, colorStops: this.colorStops, offsetX: this.offsetX, offsetY: this.offsetY, gradientUnits: this.gradientUnits, gradientTransform: this.gradientTransform ? this.gradientTransform.concat() : this.gradientTransform };
      return b.util.populateWithProperties(this, f, c), f;
    }, toSVG: function(c, f) {
      var i, r, s, h, d = a(this.coords, !0), p = (f = f || {}, a(this.colorStops, !0)), m = d.r1 > d.r2, y = this.gradientTransform ? this.gradientTransform.concat() : b.iMatrix.concat(), _ = -this.offsetX, k = -this.offsetY, T = !!f.additionalTransform, D = this.gradientUnits === "pixels" ? "userSpaceOnUse" : "objectBoundingBox";
      if (p.sort(function(L, U) {
        return L.offset - U.offset;
      }), D === "objectBoundingBox" ? (_ /= c.width, k /= c.height) : (_ += c.width / 2, k += c.height / 2), c.type === "path" && this.gradientUnits !== "percentage" && (_ -= c.pathOffset.x, k -= c.pathOffset.y), y[4] -= _, y[5] -= k, h = 'id="SVGID_' + this.id + '" gradientUnits="' + D + '"', h += ' gradientTransform="' + (T ? f.additionalTransform + " " : "") + b.util.matrixToSVG(y) + '" ', this.type === "linear" ? s = ["<linearGradient ", h, ' x1="', d.x1, '" y1="', d.y1, '" x2="', d.x2, '" y2="', d.y2, `">
`] : this.type === "radial" && (s = ["<radialGradient ", h, ' cx="', m ? d.x1 : d.x2, '" cy="', m ? d.y1 : d.y2, '" r="', m ? d.r1 : d.r2, '" fx="', m ? d.x2 : d.x1, '" fy="', m ? d.y2 : d.y1, `">
`]), this.type === "radial") {
        if (m) for ((p = p.concat()).reverse(), i = 0, r = p.length; i < r; i++) p[i].offset = 1 - p[i].offset;
        var j = Math.min(d.r1, d.r2);
        if (j > 0) {
          var w = j / Math.max(d.r1, d.r2);
          for (i = 0, r = p.length; i < r; i++) p[i].offset += w * (1 - p[i].offset);
        }
      }
      for (i = 0, r = p.length; i < r; i++) {
        var O = p[i];
        s.push("<stop ", 'offset="', 100 * O.offset + "%", '" style="stop-color:', O.color, O.opacity !== void 0 ? ";stop-opacity: " + O.opacity : ";", `"/>
`);
      }
      return s.push(this.type === "linear" ? `</linearGradient>
` : `</radialGradient>
`), s.join("");
    }, toLive: function(c) {
      var f, i, r, s = b.util.object.clone(this.coords);
      if (this.type) {
        for (this.type === "linear" ? f = c.createLinearGradient(s.x1, s.y1, s.x2, s.y2) : this.type === "radial" && (f = c.createRadialGradient(s.x1, s.y1, s.r1, s.x2, s.y2, s.r2)), i = 0, r = this.colorStops.length; i < r; i++) {
          var h = this.colorStops[i].color, d = this.colorStops[i].opacity, p = this.colorStops[i].offset;
          d !== void 0 && (h = new b.Color(h).setAlpha(d).toRgba()), f.addColorStop(p, h);
        }
        return f;
      }
    } }), b.util.object.extend(b.Gradient, { fromElement: function(c, f, i, r) {
      var s = parseFloat(i) / (/%$/.test(i) ? 100 : 1);
      s = s < 0 ? 0 : s > 1 ? 1 : s, isNaN(s) && (s = 1);
      var h, d, p, m, y = c.getElementsByTagName("stop"), _ = c.getAttribute("gradientUnits") === "userSpaceOnUse" ? "pixels" : "percentage", k = c.getAttribute("gradientTransform") || "", T = [], D = 0, j = 0;
      for (c.nodeName === "linearGradient" || c.nodeName === "LINEARGRADIENT" ? (h = "linear", d = function(w) {
        return { x1: w.getAttribute("x1") || 0, y1: w.getAttribute("y1") || 0, x2: w.getAttribute("x2") || "100%", y2: w.getAttribute("y2") || 0 };
      }(c)) : (h = "radial", d = function(w) {
        return { x1: w.getAttribute("fx") || w.getAttribute("cx") || "50%", y1: w.getAttribute("fy") || w.getAttribute("cy") || "50%", r1: 0, x2: w.getAttribute("cx") || "50%", y2: w.getAttribute("cy") || "50%", r2: w.getAttribute("r") || "50%" };
      }(c)), p = y.length; p--; ) T.push(l(y[p], s));
      return m = b.parseTransformAttribute(k), function(w, O, L, U) {
        var W, I;
        Object.keys(O).forEach(function(M) {
          (W = O[M]) === "Infinity" ? I = 1 : W === "-Infinity" ? I = 0 : (I = parseFloat(O[M], 10), typeof W == "string" && /^(\d+\.\d+)%|(\d+)%$/.test(W) && (I *= 0.01, U === "pixels" && (M !== "x1" && M !== "x2" && M !== "r2" || (I *= L.viewBoxWidth || L.width), M !== "y1" && M !== "y2" || (I *= L.viewBoxHeight || L.height)))), O[M] = I;
        });
      }(0, d, r, _), _ === "pixels" && (D = -f.left, j = -f.top), new b.Gradient({ id: c.getAttribute("id"), type: h, coords: d, colorStops: T, gradientUnits: _, gradientTransform: m, offsetX: D, offsetY: j });
    } });
  }(), R = b.util.toFixed, b.Pattern = b.util.createClass({ repeat: "repeat", offsetX: 0, offsetY: 0, crossOrigin: "", patternTransform: null, initialize: function(l, a) {
    if (l || (l = {}), this.id = b.Object.__uid++, this.setOptions(l), !l.source || l.source && typeof l.source != "string") a && a(this);
    else {
      var c = this;
      this.source = b.util.createImage(), b.util.loadImage(l.source, function(f, i) {
        c.source = f, a && a(c, i);
      }, null, this.crossOrigin);
    }
  }, toObject: function(l) {
    var a, c, f = b.Object.NUM_FRACTION_DIGITS;
    return typeof this.source.src == "string" ? a = this.source.src : typeof this.source == "object" && this.source.toDataURL && (a = this.source.toDataURL()), c = { type: "pattern", source: a, repeat: this.repeat, crossOrigin: this.crossOrigin, offsetX: R(this.offsetX, f), offsetY: R(this.offsetY, f), patternTransform: this.patternTransform ? this.patternTransform.concat() : null }, b.util.populateWithProperties(this, c, l), c;
  }, toSVG: function(l) {
    var a = typeof this.source == "function" ? this.source() : this.source, c = a.width / l.width, f = a.height / l.height, i = this.offsetX / l.width, r = this.offsetY / l.height, s = "";
    return this.repeat !== "repeat-x" && this.repeat !== "no-repeat" || (f = 1, r && (f += Math.abs(r))), this.repeat !== "repeat-y" && this.repeat !== "no-repeat" || (c = 1, i && (c += Math.abs(i))), a.src ? s = a.src : a.toDataURL && (s = a.toDataURL()), '<pattern id="SVGID_' + this.id + '" x="' + i + '" y="' + r + '" width="' + c + '" height="' + f + `">
<image x="0" y="0" width="` + a.width + '" height="' + a.height + '" xlink:href="' + s + `"></image>
</pattern>
`;
  }, setOptions: function(l) {
    for (var a in l) this[a] = l[a];
  }, toLive: function(l) {
    var a = this.source;
    return !a || a.src !== void 0 && (!a.complete || a.naturalWidth === 0 || a.naturalHeight === 0) ? "" : l.createPattern(a, this.repeat);
  } }), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.toFixed;
    a.Shadow ? a.warn("fabric.Shadow is already defined.") : (a.Shadow = a.util.createClass({ color: "rgb(0,0,0)", blur: 0, offsetX: 0, offsetY: 0, affectStroke: !1, includeDefaultValues: !0, nonScaling: !1, initialize: function(f) {
      for (var i in typeof f == "string" && (f = this._parseShadow(f)), f) this[i] = f[i];
      this.id = a.Object.__uid++;
    }, _parseShadow: function(f) {
      var i = f.trim(), r = a.Shadow.reOffsetsAndBlur.exec(i) || [];
      return { color: (i.replace(a.Shadow.reOffsetsAndBlur, "") || "rgb(0,0,0)").trim(), offsetX: parseFloat(r[1], 10) || 0, offsetY: parseFloat(r[2], 10) || 0, blur: parseFloat(r[3], 10) || 0 };
    }, toString: function() {
      return [this.offsetX, this.offsetY, this.blur, this.color].join("px ");
    }, toSVG: function(f) {
      var i = 40, r = 40, s = a.Object.NUM_FRACTION_DIGITS, h = a.util.rotateVector({ x: this.offsetX, y: this.offsetY }, a.util.degreesToRadians(-f.angle)), d = new a.Color(this.color);
      return f.width && f.height && (i = 100 * c((Math.abs(h.x) + this.blur) / f.width, s) + 20, r = 100 * c((Math.abs(h.y) + this.blur) / f.height, s) + 20), f.flipX && (h.x *= -1), f.flipY && (h.y *= -1), '<filter id="SVGID_' + this.id + '" y="-' + r + '%" height="' + (100 + 2 * r) + '%" x="-' + i + '%" width="' + (100 + 2 * i) + `%" >
	<feGaussianBlur in="SourceAlpha" stdDeviation="` + c(this.blur ? this.blur / 2 : 0, s) + `"></feGaussianBlur>
	<feOffset dx="` + c(h.x, s) + '" dy="' + c(h.y, s) + `" result="oBlur" ></feOffset>
	<feFlood flood-color="` + d.toRgb() + '" flood-opacity="' + d.getAlpha() + `"/>
	<feComposite in2="oBlur" operator="in" />
	<feMerge>
		<feMergeNode></feMergeNode>
		<feMergeNode in="SourceGraphic"></feMergeNode>
	</feMerge>
</filter>
`;
    }, toObject: function() {
      if (this.includeDefaultValues) return { color: this.color, blur: this.blur, offsetX: this.offsetX, offsetY: this.offsetY, affectStroke: this.affectStroke, nonScaling: this.nonScaling };
      var f = {}, i = a.Shadow.prototype;
      return ["color", "blur", "offsetX", "offsetY", "affectStroke", "nonScaling"].forEach(function(r) {
        this[r] !== i[r] && (f[r] = this[r]);
      }, this), f;
    } }), a.Shadow.reOffsetsAndBlur = /(?:\s|^)(-?\d+(?:\.\d*)?(?:px)?(?:\s?|$))?(-?\d+(?:\.\d*)?(?:px)?(?:\s?|$))?(\d+(?:\.\d*)?(?:px)?)?(?:\s?|$)(?:$|\s)/);
  }(t), function() {
    if (b.StaticCanvas) b.warn("fabric.StaticCanvas is already defined.");
    else {
      var l = b.util.object.extend, a = b.util.getElementOffset, c = b.util.removeFromArray, f = b.util.toFixed, i = b.util.transformPoint, r = b.util.invertTransform, s = b.util.getNodeCanvas, h = b.util.createCanvasElement, d = new Error("Could not initialize `canvas` element");
      b.StaticCanvas = b.util.createClass(b.CommonMethods, { initialize: function(p, m) {
        m || (m = {}), this.renderAndResetBound = this.renderAndReset.bind(this), this.requestRenderAllBound = this.requestRenderAll.bind(this), this._initStatic(p, m);
      }, backgroundColor: "", backgroundImage: null, overlayColor: "", overlayImage: null, includeDefaultValues: !0, stateful: !1, renderOnAddRemove: !0, controlsAboveOverlay: !1, allowTouchScrolling: !1, imageSmoothingEnabled: !0, viewportTransform: b.iMatrix.concat(), backgroundVpt: !0, overlayVpt: !0, enableRetinaScaling: !0, vptCoords: {}, skipOffscreen: !0, clipPath: void 0, _initStatic: function(p, m) {
        var y = this.requestRenderAllBound;
        this._objects = [], this._createLowerCanvas(p), this._initOptions(m), this.interactive || this._initRetinaScaling(), m.overlayImage && this.setOverlayImage(m.overlayImage, y), m.backgroundImage && this.setBackgroundImage(m.backgroundImage, y), m.backgroundColor && this.setBackgroundColor(m.backgroundColor, y), m.overlayColor && this.setOverlayColor(m.overlayColor, y), this.calcOffset();
      }, _isRetinaScaling: function() {
        return b.devicePixelRatio !== 1 && this.enableRetinaScaling;
      }, getRetinaScaling: function() {
        return this._isRetinaScaling() ? b.devicePixelRatio : 1;
      }, _initRetinaScaling: function() {
        if (this._isRetinaScaling()) {
          var p = b.devicePixelRatio;
          this.__initRetinaScaling(p, this.lowerCanvasEl, this.contextContainer), this.upperCanvasEl && this.__initRetinaScaling(p, this.upperCanvasEl, this.contextTop);
        }
      }, __initRetinaScaling: function(p, m, y) {
        m.setAttribute("width", this.width * p), m.setAttribute("height", this.height * p), y.scale(p, p);
      }, calcOffset: function() {
        return this._offset = a(this.lowerCanvasEl), this;
      }, setOverlayImage: function(p, m, y) {
        return this.__setBgOverlayImage("overlayImage", p, m, y);
      }, setBackgroundImage: function(p, m, y) {
        return this.__setBgOverlayImage("backgroundImage", p, m, y);
      }, setOverlayColor: function(p, m) {
        return this.__setBgOverlayColor("overlayColor", p, m);
      }, setBackgroundColor: function(p, m) {
        return this.__setBgOverlayColor("backgroundColor", p, m);
      }, __setBgOverlayImage: function(p, m, y, _) {
        return typeof m == "string" ? b.util.loadImage(m, function(k, T) {
          if (k) {
            var D = new b.Image(k, _);
            this[p] = D, D.canvas = this;
          }
          y && y(k, T);
        }, this, _ && _.crossOrigin) : (_ && m.setOptions(_), this[p] = m, m && (m.canvas = this), y && y(m, !1)), this;
      }, __setBgOverlayColor: function(p, m, y) {
        return this[p] = m, this._initGradient(m, p), this._initPattern(m, p, y), this;
      }, _createCanvasElement: function() {
        var p = h();
        if (!p || (p.style || (p.style = {}), p.getContext === void 0)) throw d;
        return p;
      }, _initOptions: function(p) {
        var m = this.lowerCanvasEl;
        this._setOptions(p), this.width = this.width || parseInt(m.width, 10) || 0, this.height = this.height || parseInt(m.height, 10) || 0, this.lowerCanvasEl.style && (m.width = this.width, m.height = this.height, m.style.width = this.width + "px", m.style.height = this.height + "px", this.viewportTransform = this.viewportTransform.slice());
      }, _createLowerCanvas: function(p) {
        p && p.getContext ? this.lowerCanvasEl = p : this.lowerCanvasEl = b.util.getById(p) || this._createCanvasElement(), b.util.addClass(this.lowerCanvasEl, "lower-canvas"), this._originalCanvasStyle = this.lowerCanvasEl.style, this.interactive && this._applyCanvasStyle(this.lowerCanvasEl), this.contextContainer = this.lowerCanvasEl.getContext("2d");
      }, getWidth: function() {
        return this.width;
      }, getHeight: function() {
        return this.height;
      }, setWidth: function(p, m) {
        return this.setDimensions({ width: p }, m);
      }, setHeight: function(p, m) {
        return this.setDimensions({ height: p }, m);
      }, setDimensions: function(p, m) {
        var y;
        for (var _ in m = m || {}, p) y = p[_], m.cssOnly || (this._setBackstoreDimension(_, p[_]), y += "px", this.hasLostContext = !0), m.backstoreOnly || this._setCssDimension(_, y);
        return this._isCurrentlyDrawing && this.freeDrawingBrush && this.freeDrawingBrush._setBrushStyles(), this._initRetinaScaling(), this.calcOffset(), m.cssOnly || this.requestRenderAll(), this;
      }, _setBackstoreDimension: function(p, m) {
        return this.lowerCanvasEl[p] = m, this.upperCanvasEl && (this.upperCanvasEl[p] = m), this.cacheCanvasEl && (this.cacheCanvasEl[p] = m), this[p] = m, this;
      }, _setCssDimension: function(p, m) {
        return this.lowerCanvasEl.style[p] = m, this.upperCanvasEl && (this.upperCanvasEl.style[p] = m), this.wrapperEl && (this.wrapperEl.style[p] = m), this;
      }, getZoom: function() {
        return this.viewportTransform[0];
      }, setViewportTransform: function(p) {
        var m, y, _, k = this._activeObject, T = this.backgroundImage, D = this.overlayImage;
        for (this.viewportTransform = p, y = 0, _ = this._objects.length; y < _; y++) (m = this._objects[y]).group || m.setCoords(!0);
        return k && k.setCoords(), T && T.setCoords(!0), D && D.setCoords(!0), this.calcViewportBoundaries(), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, zoomToPoint: function(p, m) {
        var y = p, _ = this.viewportTransform.slice(0);
        p = i(p, r(this.viewportTransform)), _[0] = m, _[3] = m;
        var k = i(p, _);
        return _[4] += y.x - k.x, _[5] += y.y - k.y, this.setViewportTransform(_);
      }, setZoom: function(p) {
        return this.zoomToPoint(new b.Point(0, 0), p), this;
      }, absolutePan: function(p) {
        var m = this.viewportTransform.slice(0);
        return m[4] = -p.x, m[5] = -p.y, this.setViewportTransform(m);
      }, relativePan: function(p) {
        return this.absolutePan(new b.Point(-p.x - this.viewportTransform[4], -p.y - this.viewportTransform[5]));
      }, getElement: function() {
        return this.lowerCanvasEl;
      }, _onObjectAdded: function(p) {
        this.stateful && p.setupState(), p._set("canvas", this), p.setCoords(), this.fire("object:added", { target: p }), p.fire("added");
      }, _onObjectRemoved: function(p) {
        this.fire("object:removed", { target: p }), p.fire("removed"), delete p.canvas;
      }, clearContext: function(p) {
        return p.clearRect(0, 0, this.width, this.height), this;
      }, getContext: function() {
        return this.contextContainer;
      }, clear: function() {
        return this.remove.apply(this, this.getObjects()), this.backgroundImage = null, this.overlayImage = null, this.backgroundColor = "", this.overlayColor = "", this._hasITextHandlers && (this.off("mouse:up", this._mouseUpITextHandler), this._iTextInstances = null, this._hasITextHandlers = !1), this.clearContext(this.contextContainer), this.fire("canvas:cleared"), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, renderAll: function() {
        var p = this.contextContainer;
        return this.renderCanvas(p, this._objects), this;
      }, renderAndReset: function() {
        this.isRendering = 0, this.renderAll();
      }, requestRenderAll: function() {
        return this.isRendering || (this.isRendering = b.util.requestAnimFrame(this.renderAndResetBound)), this;
      }, calcViewportBoundaries: function() {
        var p = {}, m = this.width, y = this.height, _ = r(this.viewportTransform);
        return p.tl = i({ x: 0, y: 0 }, _), p.br = i({ x: m, y }, _), p.tr = new b.Point(p.br.x, p.tl.y), p.bl = new b.Point(p.tl.x, p.br.y), this.vptCoords = p, p;
      }, cancelRequestedRender: function() {
        this.isRendering && (b.util.cancelAnimFrame(this.isRendering), this.isRendering = 0);
      }, renderCanvas: function(p, m) {
        var y = this.viewportTransform, _ = this.clipPath;
        this.cancelRequestedRender(), this.calcViewportBoundaries(), this.clearContext(p), b.util.setImageSmoothing(p, this.imageSmoothingEnabled), this.fire("before:render", { ctx: p }), this._renderBackground(p), p.save(), p.transform(y[0], y[1], y[2], y[3], y[4], y[5]), this._renderObjects(p, m), p.restore(), !this.controlsAboveOverlay && this.interactive && this.drawControls(p), _ && (_.canvas = this, _.shouldCache(), _._transformDone = !0, _.renderCache({ forClipping: !0 }), this.drawClipPathOnCanvas(p)), this._renderOverlay(p), this.controlsAboveOverlay && this.interactive && this.drawControls(p), this.fire("after:render", { ctx: p });
      }, drawClipPathOnCanvas: function(p) {
        var m = this.viewportTransform, y = this.clipPath;
        p.save(), p.transform(m[0], m[1], m[2], m[3], m[4], m[5]), p.globalCompositeOperation = "destination-in", y.transform(p), p.scale(1 / y.zoomX, 1 / y.zoomY), p.drawImage(y._cacheCanvas, -y.cacheTranslationX, -y.cacheTranslationY), p.restore();
      }, _renderObjects: function(p, m) {
        var y, _;
        for (y = 0, _ = m.length; y < _; ++y) m[y] && m[y].render(p);
      }, _renderBackgroundOrOverlay: function(p, m) {
        var y = this[m + "Color"], _ = this[m + "Image"], k = this.viewportTransform, T = this[m + "Vpt"];
        if (y || _) {
          if (y) {
            p.save(), p.beginPath(), p.moveTo(0, 0), p.lineTo(this.width, 0), p.lineTo(this.width, this.height), p.lineTo(0, this.height), p.closePath(), p.fillStyle = y.toLive ? y.toLive(p, this) : y, T && p.transform(k[0], k[1], k[2], k[3], k[4], k[5]), p.transform(1, 0, 0, 1, y.offsetX || 0, y.offsetY || 0);
            var D = y.gradientTransform || y.patternTransform;
            D && p.transform(D[0], D[1], D[2], D[3], D[4], D[5]), p.fill(), p.restore();
          }
          _ && (p.save(), T && p.transform(k[0], k[1], k[2], k[3], k[4], k[5]), _.render(p), p.restore());
        }
      }, _renderBackground: function(p) {
        this._renderBackgroundOrOverlay(p, "background");
      }, _renderOverlay: function(p) {
        this._renderBackgroundOrOverlay(p, "overlay");
      }, getCenter: function() {
        return { top: this.height / 2, left: this.width / 2 };
      }, centerObjectH: function(p) {
        return this._centerObject(p, new b.Point(this.getCenter().left, p.getCenterPoint().y));
      }, centerObjectV: function(p) {
        return this._centerObject(p, new b.Point(p.getCenterPoint().x, this.getCenter().top));
      }, centerObject: function(p) {
        var m = this.getCenter();
        return this._centerObject(p, new b.Point(m.left, m.top));
      }, viewportCenterObject: function(p) {
        var m = this.getVpCenter();
        return this._centerObject(p, m);
      }, viewportCenterObjectH: function(p) {
        var m = this.getVpCenter();
        return this._centerObject(p, new b.Point(m.x, p.getCenterPoint().y)), this;
      }, viewportCenterObjectV: function(p) {
        var m = this.getVpCenter();
        return this._centerObject(p, new b.Point(p.getCenterPoint().x, m.y));
      }, getVpCenter: function() {
        var p = this.getCenter(), m = r(this.viewportTransform);
        return i({ x: p.left, y: p.top }, m);
      }, _centerObject: function(p, m) {
        return p.setPositionByOrigin(m, "center", "center"), p.setCoords(), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, toDatalessJSON: function(p) {
        return this.toDatalessObject(p);
      }, toObject: function(p) {
        return this._toObjectMethod("toObject", p);
      }, toDatalessObject: function(p) {
        return this._toObjectMethod("toDatalessObject", p);
      }, _toObjectMethod: function(p, m) {
        var y = this.clipPath, _ = { version: b.version, objects: this._toObjects(p, m) };
        return y && !y.excludeFromExport && (_.clipPath = this._toObject(this.clipPath, p, m)), l(_, this.__serializeBgOverlay(p, m)), b.util.populateWithProperties(this, _, m), _;
      }, _toObjects: function(p, m) {
        return this._objects.filter(function(y) {
          return !y.excludeFromExport;
        }).map(function(y) {
          return this._toObject(y, p, m);
        }, this);
      }, _toObject: function(p, m, y) {
        var _;
        this.includeDefaultValues || (_ = p.includeDefaultValues, p.includeDefaultValues = !1);
        var k = p[m](y);
        return this.includeDefaultValues || (p.includeDefaultValues = _), k;
      }, __serializeBgOverlay: function(p, m) {
        var y = {}, _ = this.backgroundImage, k = this.overlayImage, T = this.backgroundColor, D = this.overlayColor;
        return T && T.toObject ? T.excludeFromExport || (y.background = T.toObject(m)) : T && (y.background = T), D && D.toObject ? D.excludeFromExport || (y.overlay = D.toObject(m)) : D && (y.overlay = D), _ && !_.excludeFromExport && (y.backgroundImage = this._toObject(_, p, m)), k && !k.excludeFromExport && (y.overlayImage = this._toObject(k, p, m)), y;
      }, svgViewportTransformation: !0, toSVG: function(p, m) {
        p || (p = {}), p.reviver = m;
        var y = [];
        return this._setSVGPreamble(y, p), this._setSVGHeader(y, p), this.clipPath && y.push('<g clip-path="url(#' + this.clipPath.clipPathId + `)" >
`), this._setSVGBgOverlayColor(y, "background"), this._setSVGBgOverlayImage(y, "backgroundImage", m), this._setSVGObjects(y, m), this.clipPath && y.push(`</g>
`), this._setSVGBgOverlayColor(y, "overlay"), this._setSVGBgOverlayImage(y, "overlayImage", m), y.push("</svg>"), y.join("");
      }, _setSVGPreamble: function(p, m) {
        m.suppressPreamble || p.push('<?xml version="1.0" encoding="', m.encoding || "UTF-8", `" standalone="no" ?>
`, '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" ', `"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
`);
      }, _setSVGHeader: function(p, m) {
        var y, _ = m.width || this.width, k = m.height || this.height, T = 'viewBox="0 0 ' + this.width + " " + this.height + '" ', D = b.Object.NUM_FRACTION_DIGITS;
        m.viewBox ? T = 'viewBox="' + m.viewBox.x + " " + m.viewBox.y + " " + m.viewBox.width + " " + m.viewBox.height + '" ' : this.svgViewportTransformation && (y = this.viewportTransform, T = 'viewBox="' + f(-y[4] / y[0], D) + " " + f(-y[5] / y[3], D) + " " + f(this.width / y[0], D) + " " + f(this.height / y[3], D) + '" '), p.push("<svg ", 'xmlns="http://www.w3.org/2000/svg" ', 'xmlns:xlink="http://www.w3.org/1999/xlink" ', 'version="1.1" ', 'width="', _, '" ', 'height="', k, '" ', T, `xml:space="preserve">
`, "<desc>Created with Fabric.js ", b.version, `</desc>
`, `<defs>
`, this.createSVGFontFacesMarkup(), this.createSVGRefElementsMarkup(), this.createSVGClipPathMarkup(m), `</defs>
`);
      }, createSVGClipPathMarkup: function(p) {
        var m = this.clipPath;
        return m ? (m.clipPathId = "CLIPPATH_" + b.Object.__uid++, '<clipPath id="' + m.clipPathId + `" >
` + this.clipPath.toClipPathSVG(p.reviver) + `</clipPath>
`) : "";
      }, createSVGRefElementsMarkup: function() {
        var p = this;
        return ["background", "overlay"].map(function(m) {
          var y = p[m + "Color"];
          if (y && y.toLive) {
            var _ = p[m + "Vpt"], k = p.viewportTransform, T = { width: p.width / (_ ? k[0] : 1), height: p.height / (_ ? k[3] : 1) };
            return y.toSVG(T, { additionalTransform: _ ? b.util.matrixToSVG(k) : "" });
          }
        }).join("");
      }, createSVGFontFacesMarkup: function() {
        var p, m, y, _, k, T, D, j, w = "", O = {}, L = b.fontPaths, U = [];
        for (this._objects.forEach(function I(M) {
          U.push(M), M._objects && M._objects.forEach(I);
        }), D = 0, j = U.length; D < j; D++) if (m = (p = U[D]).fontFamily, p.type.indexOf("text") !== -1 && !O[m] && L[m] && (O[m] = !0, p.styles)) for (k in y = p.styles) for (T in _ = y[k]) !O[m = _[T].fontFamily] && L[m] && (O[m] = !0);
        for (var W in O) w += [`		@font-face {
`, "			font-family: '", W, `';
`, "			src: url('", L[W], `');
`, `		}
`].join("");
        return w && (w = ['	<style type="text/css">', `<![CDATA[
`, w, "]]>", `</style>
`].join("")), w;
      }, _setSVGObjects: function(p, m) {
        var y, _, k, T = this._objects;
        for (_ = 0, k = T.length; _ < k; _++) (y = T[_]).excludeFromExport || this._setSVGObject(p, y, m);
      }, _setSVGObject: function(p, m, y) {
        p.push(m.toSVG(y));
      }, _setSVGBgOverlayImage: function(p, m, y) {
        this[m] && !this[m].excludeFromExport && this[m].toSVG && p.push(this[m].toSVG(y));
      }, _setSVGBgOverlayColor: function(p, m) {
        var y = this[m + "Color"], _ = this.viewportTransform, k = this.width, T = this.height;
        if (y) if (y.toLive) {
          var D = y.repeat, j = b.util.invertTransform(_), w = this[m + "Vpt"] ? b.util.matrixToSVG(j) : "";
          p.push('<rect transform="' + w + " translate(", k / 2, ",", T / 2, ')"', ' x="', y.offsetX - k / 2, '" y="', y.offsetY - T / 2, '" ', 'width="', D === "repeat-y" || D === "no-repeat" ? y.source.width : k, '" height="', D === "repeat-x" || D === "no-repeat" ? y.source.height : T, '" fill="url(#SVGID_' + y.id + ')"', `></rect>
`);
        } else p.push('<rect x="0" y="0" width="100%" height="100%" ', 'fill="', y, '"', `></rect>
`);
      }, sendToBack: function(p) {
        if (!p) return this;
        var m, y, _, k = this._activeObject;
        if (p === k && p.type === "activeSelection") for (m = (_ = k._objects).length; m--; ) y = _[m], c(this._objects, y), this._objects.unshift(y);
        else c(this._objects, p), this._objects.unshift(p);
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, bringToFront: function(p) {
        if (!p) return this;
        var m, y, _, k = this._activeObject;
        if (p === k && p.type === "activeSelection") for (_ = k._objects, m = 0; m < _.length; m++) y = _[m], c(this._objects, y), this._objects.push(y);
        else c(this._objects, p), this._objects.push(p);
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, sendBackwards: function(p, m) {
        if (!p) return this;
        var y, _, k, T, D, j = this._activeObject, w = 0;
        if (p === j && p.type === "activeSelection") for (D = j._objects, y = 0; y < D.length; y++) _ = D[y], (k = this._objects.indexOf(_)) > 0 + w && (T = k - 1, c(this._objects, _), this._objects.splice(T, 0, _)), w++;
        else (k = this._objects.indexOf(p)) !== 0 && (T = this._findNewLowerIndex(p, k, m), c(this._objects, p), this._objects.splice(T, 0, p));
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, _findNewLowerIndex: function(p, m, y) {
        var _, k;
        if (y) {
          for (_ = m, k = m - 1; k >= 0; --k)
            if (p.intersectsWithObject(this._objects[k]) || p.isContainedWithinObject(this._objects[k]) || this._objects[k].isContainedWithinObject(p)) {
              _ = k;
              break;
            }
        } else _ = m - 1;
        return _;
      }, bringForward: function(p, m) {
        if (!p) return this;
        var y, _, k, T, D, j = this._activeObject, w = 0;
        if (p === j && p.type === "activeSelection") for (y = (D = j._objects).length; y--; ) _ = D[y], (k = this._objects.indexOf(_)) < this._objects.length - 1 - w && (T = k + 1, c(this._objects, _), this._objects.splice(T, 0, _)), w++;
        else (k = this._objects.indexOf(p)) !== this._objects.length - 1 && (T = this._findNewUpperIndex(p, k, m), c(this._objects, p), this._objects.splice(T, 0, p));
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, _findNewUpperIndex: function(p, m, y) {
        var _, k, T;
        if (y) {
          for (_ = m, k = m + 1, T = this._objects.length; k < T; ++k)
            if (p.intersectsWithObject(this._objects[k]) || p.isContainedWithinObject(this._objects[k]) || this._objects[k].isContainedWithinObject(p)) {
              _ = k;
              break;
            }
        } else _ = m + 1;
        return _;
      }, moveTo: function(p, m) {
        return c(this._objects, p), this._objects.splice(m, 0, p), this.renderOnAddRemove && this.requestRenderAll();
      }, dispose: function() {
        return this.isRendering && (b.util.cancelAnimFrame(this.isRendering), this.isRendering = 0), this.forEachObject(function(p) {
          p.dispose && p.dispose();
        }), this._objects = [], this.backgroundImage && this.backgroundImage.dispose && this.backgroundImage.dispose(), this.backgroundImage = null, this.overlayImage && this.overlayImage.dispose && this.overlayImage.dispose(), this.overlayImage = null, this._iTextInstances = null, this.contextContainer = null, this.lowerCanvasEl.classList.remove("lower-canvas"), this.lowerCanvasEl.style = this._originalCanvasStyle, delete this._originalCanvasStyle, this.lowerCanvasEl.setAttribute("width", this.width), this.lowerCanvasEl.setAttribute("height", this.height), b.util.cleanUpJsdomNode(this.lowerCanvasEl), this.lowerCanvasEl = void 0, this;
      }, toString: function() {
        return "#<fabric.Canvas (" + this.complexity() + "): { objects: " + this._objects.length + " }>";
      } }), l(b.StaticCanvas.prototype, b.Observable), l(b.StaticCanvas.prototype, b.Collection), l(b.StaticCanvas.prototype, b.DataURLExporter), l(b.StaticCanvas, { EMPTY_JSON: '{"objects": [], "background": "white"}', supports: function(p) {
        var m = h();
        if (!m || !m.getContext) return null;
        var y = m.getContext("2d");
        return y && p === "setLineDash" ? y.setLineDash !== void 0 : null;
      } }), b.StaticCanvas.prototype.toJSON = b.StaticCanvas.prototype.toObject, b.isLikelyNode && (b.StaticCanvas.prototype.createPNGStream = function() {
        var p = s(this.lowerCanvasEl);
        return p && p.createPNGStream();
      }, b.StaticCanvas.prototype.createJPEGStream = function(p) {
        var m = s(this.lowerCanvasEl);
        return m && m.createJPEGStream(p);
      });
    }
  }(), b.BaseBrush = b.util.createClass({ color: "rgb(0, 0, 0)", width: 1, shadow: null, strokeLineCap: "round", strokeLineJoin: "round", strokeMiterLimit: 10, strokeDashArray: null, limitedToCanvasSize: !1, _setBrushStyles: function() {
    var l = this.canvas.contextTop;
    l.strokeStyle = this.color, l.lineWidth = this.width, l.lineCap = this.strokeLineCap, l.miterLimit = this.strokeMiterLimit, l.lineJoin = this.strokeLineJoin, l.setLineDash(this.strokeDashArray || []);
  }, _saveAndTransform: function(l) {
    var a = this.canvas.viewportTransform;
    l.save(), l.transform(a[0], a[1], a[2], a[3], a[4], a[5]);
  }, _setShadow: function() {
    if (this.shadow) {
      var l = this.canvas, a = this.shadow, c = l.contextTop, f = l.getZoom();
      l && l._isRetinaScaling() && (f *= b.devicePixelRatio), c.shadowColor = a.color, c.shadowBlur = a.blur * f, c.shadowOffsetX = a.offsetX * f, c.shadowOffsetY = a.offsetY * f;
    }
  }, needsFullRender: function() {
    return new b.Color(this.color).getAlpha() < 1 || !!this.shadow;
  }, _resetShadow: function() {
    var l = this.canvas.contextTop;
    l.shadowColor = "", l.shadowBlur = l.shadowOffsetX = l.shadowOffsetY = 0;
  }, _isOutSideCanvas: function(l) {
    return l.x < 0 || l.x > this.canvas.getWidth() || l.y < 0 || l.y > this.canvas.getHeight();
  } }), b.PencilBrush = b.util.createClass(b.BaseBrush, { decimate: 0.4, initialize: function(l) {
    this.canvas = l, this._points = [];
  }, _drawSegment: function(l, a, c) {
    var f = a.midPointFrom(c);
    return l.quadraticCurveTo(a.x, a.y, f.x, f.y), f;
  }, onMouseDown: function(l, a) {
    this.canvas._isMainEvent(a.e) && (this._prepareForDrawing(l), this._captureDrawingPath(l), this._render());
  }, onMouseMove: function(l, a) {
    if (this.canvas._isMainEvent(a.e) && (this.limitedToCanvasSize !== !0 || !this._isOutSideCanvas(l)) && this._captureDrawingPath(l) && this._points.length > 1) if (this.needsFullRender()) this.canvas.clearContext(this.canvas.contextTop), this._render();
    else {
      var c = this._points, f = c.length, i = this.canvas.contextTop;
      this._saveAndTransform(i), this.oldEnd && (i.beginPath(), i.moveTo(this.oldEnd.x, this.oldEnd.y)), this.oldEnd = this._drawSegment(i, c[f - 2], c[f - 1], !0), i.stroke(), i.restore();
    }
  }, onMouseUp: function(l) {
    return !this.canvas._isMainEvent(l.e) || (this.oldEnd = void 0, this._finalizeAndAddPath(), !1);
  }, _prepareForDrawing: function(l) {
    var a = new b.Point(l.x, l.y);
    this._reset(), this._addPoint(a), this.canvas.contextTop.moveTo(a.x, a.y);
  }, _addPoint: function(l) {
    return !(this._points.length > 1 && l.eq(this._points[this._points.length - 1]) || (this._points.push(l), 0));
  }, _reset: function() {
    this._points = [], this._setBrushStyles(), this._setShadow();
  }, _captureDrawingPath: function(l) {
    var a = new b.Point(l.x, l.y);
    return this._addPoint(a);
  }, _render: function() {
    var l, a, c = this.canvas.contextTop, f = this._points[0], i = this._points[1];
    if (this._saveAndTransform(c), c.beginPath(), this._points.length === 2 && f.x === i.x && f.y === i.y) {
      var r = this.width / 1e3;
      f = new b.Point(f.x, f.y), i = new b.Point(i.x, i.y), f.x -= r, i.x += r;
    }
    for (c.moveTo(f.x, f.y), l = 1, a = this._points.length; l < a; l++) this._drawSegment(c, f, i), f = this._points[l], i = this._points[l + 1];
    c.lineTo(f.x, f.y), c.stroke(), c.restore();
  }, convertPointsToSVGPath: function(l) {
    var a = this.width / 1e3;
    return b.util.getSmoothPathFromPoints(l, a);
  }, _isEmptySVGPath: function(l) {
    return b.util.joinPath(l) === "M 0 0 Q 0 0 0 0 L 0 0";
  }, createPath: function(l) {
    var a = new b.Path(l, { fill: null, stroke: this.color, strokeWidth: this.width, strokeLineCap: this.strokeLineCap, strokeMiterLimit: this.strokeMiterLimit, strokeLineJoin: this.strokeLineJoin, strokeDashArray: this.strokeDashArray });
    return this.shadow && (this.shadow.affectStroke = !0, a.shadow = new b.Shadow(this.shadow)), a;
  }, decimatePoints: function(l, a) {
    if (l.length <= 2) return l;
    var c, f = this.canvas.getZoom(), i = Math.pow(a / f, 2), r = l.length - 1, s = l[0], h = [s];
    for (c = 1; c < r - 1; c++) Math.pow(s.x - l[c].x, 2) + Math.pow(s.y - l[c].y, 2) >= i && (s = l[c], h.push(s));
    return h.push(l[r]), h;
  }, _finalizeAndAddPath: function() {
    this.canvas.contextTop.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate));
    var l = this.convertPointsToSVGPath(this._points);
    if (this._isEmptySVGPath(l)) this.canvas.requestRenderAll();
    else {
      var a = this.createPath(l);
      this.canvas.clearContext(this.canvas.contextTop), this.canvas.fire("before:path:created", { path: a }), this.canvas.add(a), this.canvas.requestRenderAll(), a.setCoords(), this._resetShadow(), this.canvas.fire("path:created", { path: a });
    }
  } }), b.CircleBrush = b.util.createClass(b.BaseBrush, { width: 10, initialize: function(l) {
    this.canvas = l, this.points = [];
  }, drawDot: function(l) {
    var a = this.addPoint(l), c = this.canvas.contextTop;
    this._saveAndTransform(c), this.dot(c, a), c.restore();
  }, dot: function(l, a) {
    l.fillStyle = a.fill, l.beginPath(), l.arc(a.x, a.y, a.radius, 0, 2 * Math.PI, !1), l.closePath(), l.fill();
  }, onMouseDown: function(l) {
    this.points.length = 0, this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.drawDot(l);
  }, _render: function() {
    var l, a, c = this.canvas.contextTop, f = this.points;
    for (this._saveAndTransform(c), l = 0, a = f.length; l < a; l++) this.dot(c, f[l]);
    c.restore();
  }, onMouseMove: function(l) {
    this.limitedToCanvasSize === !0 && this._isOutSideCanvas(l) || (this.needsFullRender() ? (this.canvas.clearContext(this.canvas.contextTop), this.addPoint(l), this._render()) : this.drawDot(l));
  }, onMouseUp: function() {
    var l, a, c = this.canvas.renderOnAddRemove;
    this.canvas.renderOnAddRemove = !1;
    var f = [];
    for (l = 0, a = this.points.length; l < a; l++) {
      var i = this.points[l], r = new b.Circle({ radius: i.radius, left: i.x, top: i.y, originX: "center", originY: "center", fill: i.fill });
      this.shadow && (r.shadow = new b.Shadow(this.shadow)), f.push(r);
    }
    var s = new b.Group(f);
    s.canvas = this.canvas, this.canvas.fire("before:path:created", { path: s }), this.canvas.add(s), this.canvas.fire("path:created", { path: s }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = c, this.canvas.requestRenderAll();
  }, addPoint: function(l) {
    var a = new b.Point(l.x, l.y), c = b.util.getRandomInt(Math.max(0, this.width - 20), this.width + 20) / 2, f = new b.Color(this.color).setAlpha(b.util.getRandomInt(0, 100) / 100).toRgba();
    return a.radius = c, a.fill = f, this.points.push(a), a;
  } }), b.SprayBrush = b.util.createClass(b.BaseBrush, { width: 10, density: 20, dotWidth: 1, dotWidthVariance: 1, randomOpacity: !1, optimizeOverlapping: !0, initialize: function(l) {
    this.canvas = l, this.sprayChunks = [];
  }, onMouseDown: function(l) {
    this.sprayChunks.length = 0, this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.addSprayChunk(l), this.render(this.sprayChunkPoints);
  }, onMouseMove: function(l) {
    this.limitedToCanvasSize === !0 && this._isOutSideCanvas(l) || (this.addSprayChunk(l), this.render(this.sprayChunkPoints));
  }, onMouseUp: function() {
    var l = this.canvas.renderOnAddRemove;
    this.canvas.renderOnAddRemove = !1;
    for (var a = [], c = 0, f = this.sprayChunks.length; c < f; c++) for (var i = this.sprayChunks[c], r = 0, s = i.length; r < s; r++) {
      var h = new b.Rect({ width: i[r].width, height: i[r].width, left: i[r].x + 1, top: i[r].y + 1, originX: "center", originY: "center", fill: this.color });
      a.push(h);
    }
    this.optimizeOverlapping && (a = this._getOptimizedRects(a));
    var d = new b.Group(a);
    this.shadow && d.set("shadow", new b.Shadow(this.shadow)), this.canvas.fire("before:path:created", { path: d }), this.canvas.add(d), this.canvas.fire("path:created", { path: d }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = l, this.canvas.requestRenderAll();
  }, _getOptimizedRects: function(l) {
    var a, c, f, i = {};
    for (c = 0, f = l.length; c < f; c++) i[a = l[c].left + "" + l[c].top] || (i[a] = l[c]);
    var r = [];
    for (a in i) r.push(i[a]);
    return r;
  }, render: function(l) {
    var a, c, f = this.canvas.contextTop;
    for (f.fillStyle = this.color, this._saveAndTransform(f), a = 0, c = l.length; a < c; a++) {
      var i = l[a];
      i.opacity !== void 0 && (f.globalAlpha = i.opacity), f.fillRect(i.x, i.y, i.width, i.width);
    }
    f.restore();
  }, _render: function() {
    var l, a, c = this.canvas.contextTop;
    for (c.fillStyle = this.color, this._saveAndTransform(c), l = 0, a = this.sprayChunks.length; l < a; l++) this.render(this.sprayChunks[l]);
    c.restore();
  }, addSprayChunk: function(l) {
    this.sprayChunkPoints = [];
    var a, c, f, i, r = this.width / 2;
    for (i = 0; i < this.density; i++) {
      a = b.util.getRandomInt(l.x - r, l.x + r), c = b.util.getRandomInt(l.y - r, l.y + r), f = this.dotWidthVariance ? b.util.getRandomInt(Math.max(1, this.dotWidth - this.dotWidthVariance), this.dotWidth + this.dotWidthVariance) : this.dotWidth;
      var s = new b.Point(a, c);
      s.width = f, this.randomOpacity && (s.opacity = b.util.getRandomInt(0, 100) / 100), this.sprayChunkPoints.push(s);
    }
    this.sprayChunks.push(this.sprayChunkPoints);
  } }), b.PatternBrush = b.util.createClass(b.PencilBrush, { getPatternSrc: function() {
    var l = b.util.createCanvasElement(), a = l.getContext("2d");
    return l.width = l.height = 25, a.fillStyle = this.color, a.beginPath(), a.arc(10, 10, 10, 0, 2 * Math.PI, !1), a.closePath(), a.fill(), l;
  }, getPatternSrcFunction: function() {
    return String(this.getPatternSrc).replace("this.color", '"' + this.color + '"');
  }, getPattern: function() {
    return this.canvas.contextTop.createPattern(this.source || this.getPatternSrc(), "repeat");
  }, _setBrushStyles: function() {
    this.callSuper("_setBrushStyles"), this.canvas.contextTop.strokeStyle = this.getPattern();
  }, createPath: function(l) {
    var a = this.callSuper("createPath", l), c = a._getLeftTopCoords().scalarAdd(a.strokeWidth / 2);
    return a.stroke = new b.Pattern({ source: this.source || this.getPatternSrcFunction(), offsetX: -c.x, offsetY: -c.y }), a;
  } }), function() {
    var l = b.util.getPointer, a = b.util.degreesToRadians, c = b.util.isTouchEvent;
    for (var f in b.Canvas = b.util.createClass(b.StaticCanvas, { initialize: function(i, r) {
      r || (r = {}), this.renderAndResetBound = this.renderAndReset.bind(this), this.requestRenderAllBound = this.requestRenderAll.bind(this), this._initStatic(i, r), this._initInteractive(), this._createCacheCanvas();
    }, uniformScaling: !0, uniScaleKey: "shiftKey", centeredScaling: !1, centeredRotation: !1, centeredKey: "altKey", altActionKey: "shiftKey", interactive: !0, selection: !0, selectionKey: "shiftKey", altSelectionKey: null, selectionColor: "rgba(100, 100, 255, 0.3)", selectionDashArray: [], selectionBorderColor: "rgba(255, 255, 255, 0.3)", selectionLineWidth: 1, selectionFullyContained: !1, hoverCursor: "move", moveCursor: "move", defaultCursor: "default", freeDrawingCursor: "crosshair", rotationCursor: "crosshair", notAllowedCursor: "not-allowed", containerClass: "canvas-container", perPixelTargetFind: !1, targetFindTolerance: 0, skipTargetFind: !1, isDrawingMode: !1, preserveObjectStacking: !1, snapAngle: 0, snapThreshold: null, stopContextMenu: !1, fireRightClick: !1, fireMiddleClick: !1, targets: [], _hoveredTarget: null, _hoveredTargets: [], _initInteractive: function() {
      this._currentTransform = null, this._groupSelector = null, this._initWrapperElement(), this._createUpperCanvas(), this._initEventListeners(), this._initRetinaScaling(), this.freeDrawingBrush = b.PencilBrush && new b.PencilBrush(this), this.calcOffset();
    }, _chooseObjectsToRender: function() {
      var i, r, s, h = this.getActiveObjects();
      if (h.length > 0 && !this.preserveObjectStacking) {
        r = [], s = [];
        for (var d = 0, p = this._objects.length; d < p; d++) i = this._objects[d], h.indexOf(i) === -1 ? r.push(i) : s.push(i);
        h.length > 1 && (this._activeObject._objects = s), r.push.apply(r, s);
      } else r = this._objects;
      return r;
    }, renderAll: function() {
      !this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), this.hasLostContext && this.renderTopLayer(this.contextTop);
      var i = this.contextContainer;
      return this.renderCanvas(i, this._chooseObjectsToRender()), this;
    }, renderTopLayer: function(i) {
      i.save(), this.isDrawingMode && this._isCurrentlyDrawing && (this.freeDrawingBrush && this.freeDrawingBrush._render(), this.contextTopDirty = !0), this.selection && this._groupSelector && (this._drawSelection(i), this.contextTopDirty = !0), i.restore();
    }, renderTop: function() {
      var i = this.contextTop;
      return this.clearContext(i), this.renderTopLayer(i), this.fire("after:render"), this;
    }, _normalizePointer: function(i, r) {
      var s = i.calcTransformMatrix(), h = b.util.invertTransform(s), d = this.restorePointerVpt(r);
      return b.util.transformPoint(d, h);
    }, isTargetTransparent: function(i, r, s) {
      if (i.shouldCache() && i._cacheCanvas && i !== this._activeObject) {
        var h = this._normalizePointer(i, { x: r, y: s }), d = Math.max(i.cacheTranslationX + h.x * i.zoomX, 0), p = Math.max(i.cacheTranslationY + h.y * i.zoomY, 0);
        return b.util.isTransparent(i._cacheContext, Math.round(d), Math.round(p), this.targetFindTolerance);
      }
      var m = this.contextCache, y = i.selectionBackgroundColor, _ = this.viewportTransform;
      return i.selectionBackgroundColor = "", this.clearContext(m), m.save(), m.transform(_[0], _[1], _[2], _[3], _[4], _[5]), i.render(m), m.restore(), i.selectionBackgroundColor = y, b.util.isTransparent(m, r, s, this.targetFindTolerance);
    }, _isSelectionKeyPressed: function(i) {
      return Object.prototype.toString.call(this.selectionKey) === "[object Array]" ? !!this.selectionKey.find(function(r) {
        return i[r] === !0;
      }) : i[this.selectionKey];
    }, _shouldClearSelection: function(i, r) {
      var s = this.getActiveObjects(), h = this._activeObject;
      return !r || r && h && s.length > 1 && s.indexOf(r) === -1 && h !== r && !this._isSelectionKeyPressed(i) || r && !r.evented || r && !r.selectable && h && h !== r;
    }, _shouldCenterTransform: function(i, r, s) {
      var h;
      if (i) return r === "scale" || r === "scaleX" || r === "scaleY" || r === "resizing" ? h = this.centeredScaling || i.centeredScaling : r === "rotate" && (h = this.centeredRotation || i.centeredRotation), h ? !s : s;
    }, _getOriginFromCorner: function(i, r) {
      var s = { x: i.originX, y: i.originY };
      return r === "ml" || r === "tl" || r === "bl" ? s.x = "right" : r !== "mr" && r !== "tr" && r !== "br" || (s.x = "left"), r === "tl" || r === "mt" || r === "tr" ? s.y = "bottom" : r !== "bl" && r !== "mb" && r !== "br" || (s.y = "top"), s;
    }, _getActionFromCorner: function(i, r, s, h) {
      if (!r || !i) return "drag";
      var d = h.controls[r];
      return d.getActionName(s, d, h);
    }, _setupCurrentTransform: function(i, r, s) {
      if (r) {
        var h = this.getPointer(i), d = r.__corner, p = r.controls[d], m = s && d ? p.getActionHandler(i, r, p) : b.controlsUtils.dragHandler, y = this._getActionFromCorner(s, d, i, r), _ = this._getOriginFromCorner(r, d), k = i[this.centeredKey], T = { target: r, action: y, actionHandler: m, corner: d, scaleX: r.scaleX, scaleY: r.scaleY, skewX: r.skewX, skewY: r.skewY, offsetX: h.x - r.left, offsetY: h.y - r.top, originX: _.x, originY: _.y, ex: h.x, ey: h.y, lastX: h.x, lastY: h.y, theta: a(r.angle), width: r.width * r.scaleX, shiftKey: i.shiftKey, altKey: k, original: b.util.saveObjectTransform(r) };
        this._shouldCenterTransform(r, y, k) && (T.originX = "center", T.originY = "center"), T.original.originX = _.x, T.original.originY = _.y, this._currentTransform = T, this._beforeTransform(i);
      }
    }, setCursor: function(i) {
      this.upperCanvasEl.style.cursor = i;
    }, _drawSelection: function(i) {
      var r = this._groupSelector, s = new b.Point(r.ex, r.ey), h = b.util.transformPoint(s, this.viewportTransform), d = new b.Point(r.ex + r.left, r.ey + r.top), p = b.util.transformPoint(d, this.viewportTransform), m = Math.min(h.x, p.x), y = Math.min(h.y, p.y), _ = Math.max(h.x, p.x), k = Math.max(h.y, p.y), T = this.selectionLineWidth / 2;
      this.selectionColor && (i.fillStyle = this.selectionColor, i.fillRect(m, y, _ - m, k - y)), this.selectionLineWidth && this.selectionBorderColor && (i.lineWidth = this.selectionLineWidth, i.strokeStyle = this.selectionBorderColor, m += T, y += T, _ -= T, k -= T, b.Object.prototype._setLineDash.call(this, i, this.selectionDashArray), i.strokeRect(m, y, _ - m, k - y));
    }, findTarget: function(i, r) {
      if (!this.skipTargetFind) {
        var s, h, d = this.getPointer(i, !0), p = this._activeObject, m = this.getActiveObjects(), y = c(i), _ = m.length > 1 && !r || m.length === 1;
        if (this.targets = [], _ && p._findTargetCorner(d, y) || m.length > 1 && !r && p === this._searchPossibleTargets([p], d)) return p;
        if (m.length === 1 && p === this._searchPossibleTargets([p], d)) {
          if (!this.preserveObjectStacking) return p;
          s = p, h = this.targets, this.targets = [];
        }
        var k = this._searchPossibleTargets(this._objects, d);
        return i[this.altSelectionKey] && k && s && k !== s && (k = s, this.targets = h), k;
      }
    }, _checkTarget: function(i, r, s) {
      if (r && r.visible && r.evented && r.containsPoint(i) && (!this.perPixelTargetFind && !r.perPixelTargetFind || r.isEditing || !this.isTargetTransparent(r, s.x, s.y)))
        return !0;
    }, _searchPossibleTargets: function(i, r) {
      for (var s, h, d = i.length; d--; ) {
        var p = i[d], m = p.group ? this._normalizePointer(p.group, r) : r;
        if (this._checkTarget(m, p, r)) {
          (s = i[d]).subTargetCheck && s instanceof b.Group && (h = this._searchPossibleTargets(s._objects, r)) && this.targets.push(h);
          break;
        }
      }
      return s;
    }, restorePointerVpt: function(i) {
      return b.util.transformPoint(i, b.util.invertTransform(this.viewportTransform));
    }, getPointer: function(i, r) {
      if (this._absolutePointer && !r) return this._absolutePointer;
      if (this._pointer && r) return this._pointer;
      var s, h = l(i), d = this.upperCanvasEl, p = d.getBoundingClientRect(), m = p.width || 0, y = p.height || 0;
      m && y || ("top" in p && "bottom" in p && (y = Math.abs(p.top - p.bottom)), "right" in p && "left" in p && (m = Math.abs(p.right - p.left))), this.calcOffset(), h.x = h.x - this._offset.left, h.y = h.y - this._offset.top, r || (h = this.restorePointerVpt(h));
      var _ = this.getRetinaScaling();
      return _ !== 1 && (h.x /= _, h.y /= _), s = m === 0 || y === 0 ? { width: 1, height: 1 } : { width: d.width / m, height: d.height / y }, { x: h.x * s.width, y: h.y * s.height };
    }, _createUpperCanvas: function() {
      var i = this.lowerCanvasEl.className.replace(/\s*lower-canvas\s*/, ""), r = this.lowerCanvasEl, s = this.upperCanvasEl;
      s ? s.className = "" : (s = this._createCanvasElement(), this.upperCanvasEl = s), b.util.addClass(s, "upper-canvas " + i), this.wrapperEl.appendChild(s), this._copyCanvasStyle(r, s), this._applyCanvasStyle(s), this.contextTop = s.getContext("2d");
    }, _createCacheCanvas: function() {
      this.cacheCanvasEl = this._createCanvasElement(), this.cacheCanvasEl.setAttribute("width", this.width), this.cacheCanvasEl.setAttribute("height", this.height), this.contextCache = this.cacheCanvasEl.getContext("2d");
    }, _initWrapperElement: function() {
      this.wrapperEl = b.util.wrapElement(this.lowerCanvasEl, "div", { class: this.containerClass }), b.util.setStyle(this.wrapperEl, { width: this.width + "px", height: this.height + "px", position: "relative" }), b.util.makeElementUnselectable(this.wrapperEl);
    }, _applyCanvasStyle: function(i) {
      var r = this.width || i.width, s = this.height || i.height;
      b.util.setStyle(i, { position: "absolute", width: r + "px", height: s + "px", left: 0, top: 0, "touch-action": this.allowTouchScrolling ? "manipulation" : "none", "-ms-touch-action": this.allowTouchScrolling ? "manipulation" : "none" }), i.width = r, i.height = s, b.util.makeElementUnselectable(i);
    }, _copyCanvasStyle: function(i, r) {
      r.style.cssText = i.style.cssText;
    }, getSelectionContext: function() {
      return this.contextTop;
    }, getSelectionElement: function() {
      return this.upperCanvasEl;
    }, getActiveObject: function() {
      return this._activeObject;
    }, getActiveObjects: function() {
      var i = this._activeObject;
      return i ? i.type === "activeSelection" && i._objects ? i._objects.slice(0) : [i] : [];
    }, _onObjectRemoved: function(i) {
      i === this._activeObject && (this.fire("before:selection:cleared", { target: i }), this._discardActiveObject(), this.fire("selection:cleared", { target: i }), i.fire("deselected")), i === this._hoveredTarget && (this._hoveredTarget = null, this._hoveredTargets = []), this.callSuper("_onObjectRemoved", i);
    }, _fireSelectionEvents: function(i, r) {
      var s = !1, h = this.getActiveObjects(), d = [], p = [];
      i.forEach(function(m) {
        h.indexOf(m) === -1 && (s = !0, m.fire("deselected", { e: r, target: m }), p.push(m));
      }), h.forEach(function(m) {
        i.indexOf(m) === -1 && (s = !0, m.fire("selected", { e: r, target: m }), d.push(m));
      }), i.length > 0 && h.length > 0 ? s && this.fire("selection:updated", { e: r, selected: d, deselected: p, updated: d[0] || p[0], target: this._activeObject }) : h.length > 0 ? this.fire("selection:created", { e: r, selected: d, target: this._activeObject }) : i.length > 0 && this.fire("selection:cleared", { e: r, deselected: p });
    }, setActiveObject: function(i, r) {
      var s = this.getActiveObjects();
      return this._setActiveObject(i, r), this._fireSelectionEvents(s, r), this;
    }, _setActiveObject: function(i, r) {
      return this._activeObject !== i && !!this._discardActiveObject(r, i) && !i.onSelect({ e: r }) && (this._activeObject = i, !0);
    }, _discardActiveObject: function(i, r) {
      var s = this._activeObject;
      if (s) {
        if (s.onDeselect({ e: i, object: r })) return !1;
        this._activeObject = null;
      }
      return !0;
    }, discardActiveObject: function(i) {
      var r = this.getActiveObjects(), s = this.getActiveObject();
      return r.length && this.fire("before:selection:cleared", { target: s, e: i }), this._discardActiveObject(i), this._fireSelectionEvents(r, i), this;
    }, dispose: function() {
      var i = this.wrapperEl;
      return this.removeListeners(), i.removeChild(this.upperCanvasEl), i.removeChild(this.lowerCanvasEl), this.contextCache = null, this.contextTop = null, ["upperCanvasEl", "cacheCanvasEl"].forEach((function(r) {
        b.util.cleanUpJsdomNode(this[r]), this[r] = void 0;
      }).bind(this)), i.parentNode && i.parentNode.replaceChild(this.lowerCanvasEl, this.wrapperEl), delete this.wrapperEl, b.StaticCanvas.prototype.dispose.call(this), this;
    }, clear: function() {
      return this.discardActiveObject(), this.clearContext(this.contextTop), this.callSuper("clear");
    }, drawControls: function(i) {
      var r = this._activeObject;
      r && r._renderControls(i);
    }, _toObject: function(i, r, s) {
      var h = this._realizeGroupTransformOnObject(i), d = this.callSuper("_toObject", i, r, s);
      return this._unwindGroupTransformOnObject(i, h), d;
    }, _realizeGroupTransformOnObject: function(i) {
      if (i.group && i.group.type === "activeSelection" && this._activeObject === i.group) {
        var r = {};
        return ["angle", "flipX", "flipY", "left", "scaleX", "scaleY", "skewX", "skewY", "top"].forEach(function(s) {
          r[s] = i[s];
        }), b.util.addTransformToObject(i, this._activeObject.calcOwnMatrix()), r;
      }
      return null;
    }, _unwindGroupTransformOnObject: function(i, r) {
      r && i.set(r);
    }, _setSVGObject: function(i, r, s) {
      var h = this._realizeGroupTransformOnObject(r);
      this.callSuper("_setSVGObject", i, r, s), this._unwindGroupTransformOnObject(r, h);
    }, setViewportTransform: function(i) {
      this.renderOnAddRemove && this._activeObject && this._activeObject.isEditing && this._activeObject.clearContextTop(), b.StaticCanvas.prototype.setViewportTransform.call(this, i);
    } }), b.StaticCanvas) f !== "prototype" && (b.Canvas[f] = b.StaticCanvas[f]);
  }(), function() {
    var l = b.util.addListener, a = b.util.removeListener, c = { passive: !1 };
    function f(i, r) {
      return i.button && i.button === r - 1;
    }
    b.util.object.extend(b.Canvas.prototype, { mainTouchId: null, _initEventListeners: function() {
      this.removeListeners(), this._bindEvents(), this.addOrRemove(l, "add");
    }, _getEventPrefix: function() {
      return this.enablePointerEvents ? "pointer" : "mouse";
    }, addOrRemove: function(i, r) {
      var s = this.upperCanvasEl, h = this._getEventPrefix();
      i(b.window, "resize", this._onResize), i(s, h + "down", this._onMouseDown), i(s, h + "move", this._onMouseMove, c), i(s, h + "out", this._onMouseOut), i(s, h + "enter", this._onMouseEnter), i(s, "wheel", this._onMouseWheel), i(s, "contextmenu", this._onContextMenu), i(s, "dblclick", this._onDoubleClick), i(s, "dragover", this._onDragOver), i(s, "dragenter", this._onDragEnter), i(s, "dragleave", this._onDragLeave), i(s, "drop", this._onDrop), this.enablePointerEvents || i(s, "touchstart", this._onTouchStart, c), P !== void 0 && r in P && (P[r](s, "gesture", this._onGesture), P[r](s, "drag", this._onDrag), P[r](s, "orientation", this._onOrientationChange), P[r](s, "shake", this._onShake), P[r](s, "longpress", this._onLongPress));
    }, removeListeners: function() {
      this.addOrRemove(a, "remove");
      var i = this._getEventPrefix();
      a(b.document, i + "up", this._onMouseUp), a(b.document, "touchend", this._onTouchEnd, c), a(b.document, i + "move", this._onMouseMove, c), a(b.document, "touchmove", this._onMouseMove, c);
    }, _bindEvents: function() {
      this.eventsBound || (this._onMouseDown = this._onMouseDown.bind(this), this._onTouchStart = this._onTouchStart.bind(this), this._onMouseMove = this._onMouseMove.bind(this), this._onMouseUp = this._onMouseUp.bind(this), this._onTouchEnd = this._onTouchEnd.bind(this), this._onResize = this._onResize.bind(this), this._onGesture = this._onGesture.bind(this), this._onDrag = this._onDrag.bind(this), this._onShake = this._onShake.bind(this), this._onLongPress = this._onLongPress.bind(this), this._onOrientationChange = this._onOrientationChange.bind(this), this._onMouseWheel = this._onMouseWheel.bind(this), this._onMouseOut = this._onMouseOut.bind(this), this._onMouseEnter = this._onMouseEnter.bind(this), this._onContextMenu = this._onContextMenu.bind(this), this._onDoubleClick = this._onDoubleClick.bind(this), this._onDragOver = this._onDragOver.bind(this), this._onDragEnter = this._simpleEventHandler.bind(this, "dragenter"), this._onDragLeave = this._simpleEventHandler.bind(this, "dragleave"), this._onDrop = this._simpleEventHandler.bind(this, "drop"), this.eventsBound = !0);
    }, _onGesture: function(i, r) {
      this.__onTransformGesture && this.__onTransformGesture(i, r);
    }, _onDrag: function(i, r) {
      this.__onDrag && this.__onDrag(i, r);
    }, _onMouseWheel: function(i) {
      this.__onMouseWheel(i);
    }, _onMouseOut: function(i) {
      var r = this._hoveredTarget;
      this.fire("mouse:out", { target: r, e: i }), this._hoveredTarget = null, r && r.fire("mouseout", { e: i });
      var s = this;
      this._hoveredTargets.forEach(function(h) {
        s.fire("mouse:out", { target: r, e: i }), h && r.fire("mouseout", { e: i });
      }), this._hoveredTargets = [], this._iTextInstances && this._iTextInstances.forEach(function(h) {
        h.isEditing && h.hiddenTextarea.focus();
      });
    }, _onMouseEnter: function(i) {
      this._currentTransform || this.findTarget(i) || (this.fire("mouse:over", { target: null, e: i }), this._hoveredTarget = null, this._hoveredTargets = []);
    }, _onOrientationChange: function(i, r) {
      this.__onOrientationChange && this.__onOrientationChange(i, r);
    }, _onShake: function(i, r) {
      this.__onShake && this.__onShake(i, r);
    }, _onLongPress: function(i, r) {
      this.__onLongPress && this.__onLongPress(i, r);
    }, _onDragOver: function(i) {
      i.preventDefault();
      var r = this._simpleEventHandler("dragover", i);
      this._fireEnterLeaveEvents(r, i);
    }, _onContextMenu: function(i) {
      return this.stopContextMenu && (i.stopPropagation(), i.preventDefault()), !1;
    }, _onDoubleClick: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "dblclick"), this._resetTransformEventData(i);
    }, getPointerId: function(i) {
      var r = i.changedTouches;
      return r ? r[0] && r[0].identifier : this.enablePointerEvents ? i.pointerId : -1;
    }, _isMainEvent: function(i) {
      return i.isPrimary === !0 || i.isPrimary !== !1 && (i.type === "touchend" && i.touches.length === 0 || !i.changedTouches || i.changedTouches[0].identifier === this.mainTouchId);
    }, _onTouchStart: function(i) {
      i.preventDefault(), this.mainTouchId === null && (this.mainTouchId = this.getPointerId(i)), this.__onMouseDown(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      l(b.document, "touchend", this._onTouchEnd, c), l(b.document, "touchmove", this._onMouseMove, c), a(r, s + "down", this._onMouseDown);
    }, _onMouseDown: function(i) {
      this.__onMouseDown(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      a(r, s + "move", this._onMouseMove, c), l(b.document, s + "up", this._onMouseUp), l(b.document, s + "move", this._onMouseMove, c);
    }, _onTouchEnd: function(i) {
      if (!(i.touches.length > 0)) {
        this.__onMouseUp(i), this._resetTransformEventData(), this.mainTouchId = null;
        var r = this._getEventPrefix();
        a(b.document, "touchend", this._onTouchEnd, c), a(b.document, "touchmove", this._onMouseMove, c);
        var s = this;
        this._willAddMouseDown && clearTimeout(this._willAddMouseDown), this._willAddMouseDown = setTimeout(function() {
          l(s.upperCanvasEl, r + "down", s._onMouseDown), s._willAddMouseDown = 0;
        }, 400);
      }
    }, _onMouseUp: function(i) {
      this.__onMouseUp(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      this._isMainEvent(i) && (a(b.document, s + "up", this._onMouseUp), a(b.document, s + "move", this._onMouseMove, c), l(r, s + "move", this._onMouseMove, c));
    }, _onMouseMove: function(i) {
      !this.allowTouchScrolling && i.preventDefault && i.preventDefault(), this.__onMouseMove(i);
    }, _onResize: function() {
      this.calcOffset();
    }, _shouldRender: function(i) {
      var r = this._activeObject;
      return !!(!!r != !!i || r && i && r !== i) || (r && r.isEditing, !1);
    }, __onMouseUp: function(i) {
      var r, s = this._currentTransform, h = this._groupSelector, d = !1, p = !h || h.left === 0 && h.top === 0;
      if (this._cacheTransformEventData(i), r = this._target, this._handleEvent(i, "up:before"), f(i, 3)) this.fireRightClick && this._handleEvent(i, "up", 3, p);
      else {
        if (f(i, 2)) return this.fireMiddleClick && this._handleEvent(i, "up", 2, p), void this._resetTransformEventData();
        if (this.isDrawingMode && this._isCurrentlyDrawing) this._onMouseUpInDrawingMode(i);
        else if (this._isMainEvent(i)) {
          if (s && (this._finalizeCurrentTransform(i), d = s.actionPerformed), !p) {
            var m = r === this._activeObject;
            this._maybeGroupObjects(i), d || (d = this._shouldRender(r) || !m && r === this._activeObject);
          }
          if (r) {
            if (r.selectable && r !== this._activeObject && r.activeOn === "up") this.setActiveObject(r, i), d = !0;
            else {
              var y = r._findTargetCorner(this.getPointer(i, !0), b.util.isTouchEvent(i)), _ = r.controls[y], k = _ && _.getMouseUpHandler(i, r, _);
              if (k) {
                var T = this.getPointer(i);
                k(i, s, T.x, T.y);
              }
            }
            r.isMoving = !1;
          }
          this._setCursorFromEvent(i, r), this._handleEvent(i, "up", 1, p), this._groupSelector = null, this._currentTransform = null, r && (r.__corner = 0), d ? this.requestRenderAll() : p || this.renderTop();
        }
      }
    }, _simpleEventHandler: function(i, r) {
      var s = this.findTarget(r), h = this.targets, d = { e: r, target: s, subTargets: h };
      if (this.fire(i, d), s && s.fire(i, d), !h) return s;
      for (var p = 0; p < h.length; p++) h[p].fire(i, d);
      return s;
    }, _handleEvent: function(i, r, s, h) {
      var d = this._target, p = this.targets || [], m = { e: i, target: d, subTargets: p, button: s || 1, isClick: h || !1, pointer: this._pointer, absolutePointer: this._absolutePointer, transform: this._currentTransform };
      r === "up" && (m.currentTarget = this.findTarget(i), m.currentSubTargets = this.targets), this.fire("mouse:" + r, m), d && d.fire("mouse" + r, m);
      for (var y = 0; y < p.length; y++) p[y].fire("mouse" + r, m);
    }, _finalizeCurrentTransform: function(i) {
      var r, s = this._currentTransform, h = s.target, d = { e: i, target: h, transform: s, action: s.action };
      h._scaling && (h._scaling = !1), h.setCoords(), (s.actionPerformed || this.stateful && h.hasStateChanged()) && (s.actionPerformed && (r = this._addEventOptions(d, s), this._fire(r, d)), this._fire("modified", d));
    }, _addEventOptions: function(i, r) {
      var s, h;
      switch (r.action) {
        case "scaleX":
          s = "scaled", h = "x";
          break;
        case "scaleY":
          s = "scaled", h = "y";
          break;
        case "skewX":
          s = "skewed", h = "x";
          break;
        case "skewY":
          s = "skewed", h = "y";
          break;
        case "scale":
          s = "scaled", h = "equally";
          break;
        case "rotate":
          s = "rotated";
          break;
        case "drag":
          s = "moved";
      }
      return i.by = h, s;
    }, _onMouseDownInDrawingMode: function(i) {
      this._isCurrentlyDrawing = !0, this.getActiveObject() && this.discardActiveObject(i).requestRenderAll();
      var r = this.getPointer(i);
      this.freeDrawingBrush.onMouseDown(r, { e: i, pointer: r }), this._handleEvent(i, "down");
    }, _onMouseMoveInDrawingMode: function(i) {
      if (this._isCurrentlyDrawing) {
        var r = this.getPointer(i);
        this.freeDrawingBrush.onMouseMove(r, { e: i, pointer: r });
      }
      this.setCursor(this.freeDrawingCursor), this._handleEvent(i, "move");
    }, _onMouseUpInDrawingMode: function(i) {
      var r = this.getPointer(i);
      this._isCurrentlyDrawing = this.freeDrawingBrush.onMouseUp({ e: i, pointer: r }), this._handleEvent(i, "up");
    }, __onMouseDown: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "down:before");
      var r = this._target;
      if (f(i, 3)) this.fireRightClick && this._handleEvent(i, "down", 3);
      else if (f(i, 2)) this.fireMiddleClick && this._handleEvent(i, "down", 2);
      else if (this.isDrawingMode) this._onMouseDownInDrawingMode(i);
      else if (this._isMainEvent(i) && !this._currentTransform) {
        var s = this._pointer;
        this._previousPointer = s;
        var h = this._shouldRender(r), d = this._shouldGroup(i, r);
        if (this._shouldClearSelection(i, r) ? this.discardActiveObject(i) : d && (this._handleGrouping(i, r), r = this._activeObject), !this.selection || r && (r.selectable || r.isEditing || r === this._activeObject) || (this._groupSelector = { ex: this._absolutePointer.x, ey: this._absolutePointer.y, top: 0, left: 0 }), r) {
          var p = r === this._activeObject;
          r.selectable && r.activeOn === "down" && this.setActiveObject(r, i);
          var m = r._findTargetCorner(this.getPointer(i, !0), b.util.isTouchEvent(i));
          if (r.__corner = m, r === this._activeObject && (m || !d)) {
            this._setupCurrentTransform(i, r, p);
            var y = r.controls[m], _ = (s = this.getPointer(i), y && y.getMouseDownHandler(i, r, y));
            _ && _(i, this._currentTransform, s.x, s.y);
          }
        }
        this._handleEvent(i, "down"), (h || d) && this.requestRenderAll();
      }
    }, _resetTransformEventData: function() {
      this._target = null, this._pointer = null, this._absolutePointer = null;
    }, _cacheTransformEventData: function(i) {
      this._resetTransformEventData(), this._pointer = this.getPointer(i, !0), this._absolutePointer = this.restorePointerVpt(this._pointer), this._target = this._currentTransform ? this._currentTransform.target : this.findTarget(i) || null;
    }, _beforeTransform: function(i) {
      var r = this._currentTransform;
      this.stateful && r.target.saveState(), this.fire("before:transform", { e: i, transform: r });
    }, __onMouseMove: function(i) {
      var r, s;
      if (this._handleEvent(i, "move:before"), this._cacheTransformEventData(i), this.isDrawingMode) this._onMouseMoveInDrawingMode(i);
      else if (this._isMainEvent(i)) {
        var h = this._groupSelector;
        h ? (s = this._absolutePointer, h.left = s.x - h.ex, h.top = s.y - h.ey, this.renderTop()) : this._currentTransform ? this._transformObject(i) : (r = this.findTarget(i) || null, this._setCursorFromEvent(i, r), this._fireOverOutEvents(r, i)), this._handleEvent(i, "move"), this._resetTransformEventData();
      }
    }, _fireOverOutEvents: function(i, r) {
      var s = this._hoveredTarget, h = this._hoveredTargets, d = this.targets, p = Math.max(h.length, d.length);
      this.fireSyntheticInOutEvents(i, r, { oldTarget: s, evtOut: "mouseout", canvasEvtOut: "mouse:out", evtIn: "mouseover", canvasEvtIn: "mouse:over" });
      for (var m = 0; m < p; m++) this.fireSyntheticInOutEvents(d[m], r, { oldTarget: h[m], evtOut: "mouseout", evtIn: "mouseover" });
      this._hoveredTarget = i, this._hoveredTargets = this.targets.concat();
    }, _fireEnterLeaveEvents: function(i, r) {
      var s = this._draggedoverTarget, h = this._hoveredTargets, d = this.targets, p = Math.max(h.length, d.length);
      this.fireSyntheticInOutEvents(i, r, { oldTarget: s, evtOut: "dragleave", evtIn: "dragenter" });
      for (var m = 0; m < p; m++) this.fireSyntheticInOutEvents(d[m], r, { oldTarget: h[m], evtOut: "dragleave", evtIn: "dragenter" });
      this._draggedoverTarget = i;
    }, fireSyntheticInOutEvents: function(i, r, s) {
      var h, d, p, m = s.oldTarget, y = m !== i, _ = s.canvasEvtIn, k = s.canvasEvtOut;
      y && (h = { e: r, target: i, previousTarget: m }, d = { e: r, target: m, nextTarget: i }), p = i && y, m && y && (k && this.fire(k, d), m.fire(s.evtOut, d)), p && (_ && this.fire(_, h), i.fire(s.evtIn, h));
    }, __onMouseWheel: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "wheel"), this._resetTransformEventData();
    }, _transformObject: function(i) {
      var r = this.getPointer(i), s = this._currentTransform;
      s.reset = !1, s.shiftKey = i.shiftKey, s.altKey = i[this.centeredKey], this._performTransformAction(i, s, r), s.actionPerformed && this.requestRenderAll();
    }, _performTransformAction: function(i, r, s) {
      var h = s.x, d = s.y, p = r.action, m = !1, y = r.actionHandler;
      y && (m = y(i, r, h, d)), p === "drag" && m && (r.target.isMoving = !0, this.setCursor(r.target.moveCursor || this.moveCursor)), r.actionPerformed = r.actionPerformed || m;
    }, _fire: b.controlsUtils.fireEvent, _setCursorFromEvent: function(i, r) {
      if (!r) return this.setCursor(this.defaultCursor), !1;
      var s = r.hoverCursor || this.hoverCursor, h = this._activeObject && this._activeObject.type === "activeSelection" ? this._activeObject : null, d = (!h || !h.contains(r)) && r._findTargetCorner(this.getPointer(i, !0));
      d ? this.setCursor(this.getCornerCursor(d, r, i)) : (r.subTargetCheck && this.targets.concat().reverse().map(function(p) {
        s = p.hoverCursor || s;
      }), this.setCursor(s));
    }, getCornerCursor: function(i, r, s) {
      var h = r.controls[i];
      return h.cursorStyleHandler(s, h, r);
    } });
  }(), N = Math.min, $ = Math.max, b.util.object.extend(b.Canvas.prototype, { _shouldGroup: function(l, a) {
    var c = this._activeObject;
    return c && this._isSelectionKeyPressed(l) && a && a.selectable && this.selection && (c !== a || c.type === "activeSelection") && !a.onSelect({ e: l });
  }, _handleGrouping: function(l, a) {
    var c = this._activeObject;
    c.__corner || (a !== c || (a = this.findTarget(l, !0)) && a.selectable) && (c && c.type === "activeSelection" ? this._updateActiveSelection(a, l) : this._createActiveSelection(a, l));
  }, _updateActiveSelection: function(l, a) {
    var c = this._activeObject, f = c._objects.slice(0);
    c.contains(l) ? (c.removeWithUpdate(l), this._hoveredTarget = l, this._hoveredTargets = this.targets.concat(), c.size() === 1 && this._setActiveObject(c.item(0), a)) : (c.addWithUpdate(l), this._hoveredTarget = c, this._hoveredTargets = this.targets.concat()), this._fireSelectionEvents(f, a);
  }, _createActiveSelection: function(l, a) {
    var c = this.getActiveObjects(), f = this._createGroup(l);
    this._hoveredTarget = f, this._setActiveObject(f, a), this._fireSelectionEvents(c, a);
  }, _createGroup: function(l) {
    var a = this._objects, c = a.indexOf(this._activeObject) < a.indexOf(l) ? [this._activeObject, l] : [l, this._activeObject];
    return this._activeObject.isEditing && this._activeObject.exitEditing(), new b.ActiveSelection(c, { canvas: this });
  }, _groupSelectedObjects: function(l) {
    var a, c = this._collectObjects(l);
    c.length === 1 ? this.setActiveObject(c[0], l) : c.length > 1 && (a = new b.ActiveSelection(c.reverse(), { canvas: this }), this.setActiveObject(a, l));
  }, _collectObjects: function(l) {
    for (var a, c = [], f = this._groupSelector.ex, i = this._groupSelector.ey, r = f + this._groupSelector.left, s = i + this._groupSelector.top, h = new b.Point(N(f, r), N(i, s)), d = new b.Point($(f, r), $(i, s)), p = !this.selectionFullyContained, m = f === r && i === s, y = this._objects.length; y-- && !((a = this._objects[y]) && a.selectable && a.visible && (p && a.intersectsWithRect(h, d, !0) || a.isContainedWithinRect(h, d, !0) || p && a.containsPoint(h, null, !0) || p && a.containsPoint(d, null, !0)) && (c.push(a), m)); ) ;
    return c.length > 1 && (c = c.filter(function(_) {
      return !_.onSelect({ e: l });
    })), c;
  }, _maybeGroupObjects: function(l) {
    this.selection && this._groupSelector && this._groupSelectedObjects(l), this.setCursor(this.defaultCursor), this._groupSelector = null;
  } }), b.util.object.extend(b.StaticCanvas.prototype, { toDataURL: function(l) {
    l || (l = {});
    var a = l.format || "png", c = l.quality || 1, f = (l.multiplier || 1) * (l.enableRetinaScaling ? this.getRetinaScaling() : 1), i = this.toCanvasElement(f, l);
    return b.util.toDataURL(i, a, c);
  }, toCanvasElement: function(l, a) {
    l = l || 1;
    var c = ((a = a || {}).width || this.width) * l, f = (a.height || this.height) * l, i = this.getZoom(), r = this.width, s = this.height, h = i * l, d = this.viewportTransform, p = (d[4] - (a.left || 0)) * l, m = (d[5] - (a.top || 0)) * l, y = this.interactive, _ = [h, 0, 0, h, p, m], k = this.enableRetinaScaling, T = b.util.createCanvasElement(), D = this.contextTop;
    return T.width = c, T.height = f, this.contextTop = null, this.enableRetinaScaling = !1, this.interactive = !1, this.viewportTransform = _, this.width = c, this.height = f, this.calcViewportBoundaries(), this.renderCanvas(T.getContext("2d"), this._objects), this.viewportTransform = d, this.width = r, this.height = s, this.calcViewportBoundaries(), this.interactive = y, this.enableRetinaScaling = k, this.contextTop = D, T;
  } }), b.util.object.extend(b.StaticCanvas.prototype, { loadFromJSON: function(l, a, c) {
    if (l) {
      var f = typeof l == "string" ? JSON.parse(l) : b.util.object.clone(l), i = this, r = f.clipPath, s = this.renderOnAddRemove;
      return this.renderOnAddRemove = !1, delete f.clipPath, this._enlivenObjects(f.objects, function(h) {
        i.clear(), i._setBgOverlay(f, function() {
          r ? i._enlivenObjects([r], function(d) {
            i.clipPath = d[0], i.__setupCanvas.call(i, f, h, s, a);
          }) : i.__setupCanvas.call(i, f, h, s, a);
        });
      }, c), this;
    }
  }, __setupCanvas: function(l, a, c, f) {
    var i = this;
    a.forEach(function(r, s) {
      i.insertAt(r, s);
    }), this.renderOnAddRemove = c, delete l.objects, delete l.backgroundImage, delete l.overlayImage, delete l.background, delete l.overlay, this._setOptions(l), this.renderAll(), f && f();
  }, _setBgOverlay: function(l, a) {
    var c = { backgroundColor: !1, overlayColor: !1, backgroundImage: !1, overlayImage: !1 };
    if (l.backgroundImage || l.overlayImage || l.background || l.overlay) {
      var f = function() {
        c.backgroundImage && c.overlayImage && c.backgroundColor && c.overlayColor && a && a();
      };
      this.__setBgOverlay("backgroundImage", l.backgroundImage, c, f), this.__setBgOverlay("overlayImage", l.overlayImage, c, f), this.__setBgOverlay("backgroundColor", l.background, c, f), this.__setBgOverlay("overlayColor", l.overlay, c, f);
    } else a && a();
  }, __setBgOverlay: function(l, a, c, f) {
    var i = this;
    if (!a) return c[l] = !0, void (f && f());
    l === "backgroundImage" || l === "overlayImage" ? b.util.enlivenObjects([a], function(r) {
      i[l] = r[0], c[l] = !0, f && f();
    }) : this["set" + b.util.string.capitalize(l, !0)](a, function() {
      c[l] = !0, f && f();
    });
  }, _enlivenObjects: function(l, a, c) {
    l && l.length !== 0 ? b.util.enlivenObjects(l, function(f) {
      a && a(f);
    }, null, c) : a && a([]);
  }, _toDataURL: function(l, a) {
    this.clone(function(c) {
      a(c.toDataURL(l));
    });
  }, _toDataURLWithMultiplier: function(l, a, c) {
    this.clone(function(f) {
      c(f.toDataURLWithMultiplier(l, a));
    });
  }, clone: function(l, a) {
    var c = JSON.stringify(this.toJSON(a));
    this.cloneWithoutData(function(f) {
      f.loadFromJSON(c, function() {
        l && l(f);
      });
    });
  }, cloneWithoutData: function(l) {
    var a = b.util.createCanvasElement();
    a.width = this.width, a.height = this.height;
    var c = new b.Canvas(a);
    this.backgroundImage ? (c.setBackgroundImage(this.backgroundImage.src, function() {
      c.renderAll(), l && l(c);
    }), c.backgroundImageOpacity = this.backgroundImageOpacity, c.backgroundImageStretch = this.backgroundImageStretch) : l && l(c);
  } }), at = b.util.degreesToRadians, it = b.util.radiansToDegrees, b.util.object.extend(b.Canvas.prototype, { __onTransformGesture: function(l, a) {
    if (!this.isDrawingMode && l.touches && l.touches.length === 2 && a.gesture === "gesture") {
      var c = this.findTarget(l);
      c !== void 0 && (this.__gesturesParams = { e: l, self: a, target: c }, this.__gesturesRenderer()), this.fire("touch:gesture", { target: c, e: l, self: a });
    }
  }, __gesturesParams: null, __gesturesRenderer: function() {
    if (this.__gesturesParams !== null && this._currentTransform !== null) {
      var l = this.__gesturesParams.self, a = this._currentTransform, c = this.__gesturesParams.e;
      a.action = "scale", a.originX = a.originY = "center", this._scaleObjectBy(l.scale, c), l.rotation !== 0 && (a.action = "rotate", this._rotateObjectByAngle(l.rotation, c)), this.requestRenderAll(), a.action = "drag";
    }
  }, __onDrag: function(l, a) {
    this.fire("touch:drag", { e: l, self: a });
  }, __onOrientationChange: function(l, a) {
    this.fire("touch:orientation", { e: l, self: a });
  }, __onShake: function(l, a) {
    this.fire("touch:shake", { e: l, self: a });
  }, __onLongPress: function(l, a) {
    this.fire("touch:longpress", { e: l, self: a });
  }, _scaleObjectBy: function(l, a) {
    var c = this._currentTransform, f = c.target;
    return c.gestureScale = l, f._scaling = !0, b.controlsUtils.scalingEqually(a, c, 0, 0);
  }, _rotateObjectByAngle: function(l, a) {
    var c = this._currentTransform;
    c.target.get("lockRotation") || (c.target.rotate(it(at(l) + c.theta)), this._fire("rotating", { target: c.target, e: a, transform: c }));
  } }), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.util.object.clone, i = a.util.toFixed, r = a.util.string.capitalize, s = a.util.degreesToRadians, h = !a.isLikelyNode;
    a.Object || (a.Object = a.util.createClass(a.CommonMethods, { type: "object", originX: "left", originY: "top", top: 0, left: 0, width: 0, height: 0, scaleX: 1, scaleY: 1, flipX: !1, flipY: !1, opacity: 1, angle: 0, skewX: 0, skewY: 0, cornerSize: 13, touchCornerSize: 24, transparentCorners: !0, hoverCursor: null, moveCursor: null, padding: 0, borderColor: "rgb(178,204,255)", borderDashArray: null, cornerColor: "rgb(178,204,255)", cornerStrokeColor: null, cornerStyle: "rect", cornerDashArray: null, centeredScaling: !1, centeredRotation: !0, fill: "rgb(0,0,0)", fillRule: "nonzero", globalCompositeOperation: "source-over", backgroundColor: "", selectionBackgroundColor: "", stroke: null, strokeWidth: 1, strokeDashArray: null, strokeDashOffset: 0, strokeLineCap: "butt", strokeLineJoin: "miter", strokeMiterLimit: 4, shadow: null, borderOpacityWhenMoving: 0.4, borderScaleFactor: 1, minScaleLimit: 0, selectable: !0, evented: !0, visible: !0, hasControls: !0, hasBorders: !0, perPixelTargetFind: !1, includeDefaultValues: !0, lockMovementX: !1, lockMovementY: !1, lockRotation: !1, lockScalingX: !1, lockScalingY: !1, lockSkewingX: !1, lockSkewingY: !1, lockScalingFlip: !1, excludeFromExport: !1, objectCaching: h, statefullCache: !1, noScaleCache: !0, strokeUniform: !1, dirty: !0, __corner: 0, paintFirst: "fill", activeOn: "down", stateProperties: "top left width height scaleX scaleY flipX flipY originX originY transformMatrix stroke strokeWidth strokeDashArray strokeLineCap strokeDashOffset strokeLineJoin strokeMiterLimit angle opacity fill globalCompositeOperation shadow visible backgroundColor skewX skewY fillRule paintFirst clipPath strokeUniform".split(" "), cacheProperties: "fill stroke strokeWidth strokeDashArray width height paintFirst strokeUniform strokeLineCap strokeDashOffset strokeLineJoin strokeMiterLimit backgroundColor clipPath".split(" "), colorProperties: "fill stroke backgroundColor".split(" "), clipPath: void 0, inverted: !1, absolutePositioned: !1, initialize: function(d) {
      d && this.setOptions(d);
    }, _createCacheCanvas: function() {
      this._cacheProperties = {}, this._cacheCanvas = a.util.createCanvasElement(), this._cacheContext = this._cacheCanvas.getContext("2d"), this._updateCacheCanvas(), this.dirty = !0;
    }, _limitCacheSize: function(d) {
      var p = a.perfLimitSizeTotal, m = d.width, y = d.height, _ = a.maxCacheSideLimit, k = a.minCacheSideLimit;
      if (m <= _ && y <= _ && m * y <= p) return m < k && (d.width = k), y < k && (d.height = k), d;
      var T = m / y, D = a.util.limitDimsByArea(T, p), j = a.util.capValue, w = j(k, D.x, _), O = j(k, D.y, _);
      return m > w && (d.zoomX /= m / w, d.width = w, d.capped = !0), y > O && (d.zoomY /= y / O, d.height = O, d.capped = !0), d;
    }, _getCacheCanvasDimensions: function() {
      var d = this.getTotalObjectScaling(), p = this._getTransformedDimensions(0, 0), m = p.x * d.scaleX / this.scaleX, y = p.y * d.scaleY / this.scaleY;
      return { width: m + 2, height: y + 2, zoomX: d.scaleX, zoomY: d.scaleY, x: m, y };
    }, _updateCacheCanvas: function() {
      var d = this.canvas;
      if (this.noScaleCache && d && d._currentTransform) {
        var p = d._currentTransform.target, m = d._currentTransform.action;
        if (this === p && m.slice && m.slice(0, 5) === "scale") return !1;
      }
      var y, _, k = this._cacheCanvas, T = this._limitCacheSize(this._getCacheCanvasDimensions()), D = a.minCacheSideLimit, j = T.width, w = T.height, O = T.zoomX, L = T.zoomY, U = j !== this.cacheWidth || w !== this.cacheHeight, W = this.zoomX !== O || this.zoomY !== L, I = U || W, M = 0, B = 0, Z = !1;
      if (U) {
        var J = this._cacheCanvas.width, G = this._cacheCanvas.height, F = j > J || w > G;
        Z = F || (j < 0.9 * J || w < 0.9 * G) && J > D && G > D, F && !T.capped && (j > D || w > D) && (M = 0.1 * j, B = 0.1 * w);
      }
      return this instanceof a.Text && this.path && (I = !0, Z = !0, M += this.getHeightOfLine(0) * this.zoomX, B += this.getHeightOfLine(0) * this.zoomY), !!I && (Z ? (k.width = Math.ceil(j + M), k.height = Math.ceil(w + B)) : (this._cacheContext.setTransform(1, 0, 0, 1, 0, 0), this._cacheContext.clearRect(0, 0, k.width, k.height)), y = T.x / 2, _ = T.y / 2, this.cacheTranslationX = Math.round(k.width / 2 - y) + y, this.cacheTranslationY = Math.round(k.height / 2 - _) + _, this.cacheWidth = j, this.cacheHeight = w, this._cacheContext.translate(this.cacheTranslationX, this.cacheTranslationY), this._cacheContext.scale(O, L), this.zoomX = O, this.zoomY = L, !0);
    }, setOptions: function(d) {
      this._setOptions(d), this._initGradient(d.fill, "fill"), this._initGradient(d.stroke, "stroke"), this._initPattern(d.fill, "fill"), this._initPattern(d.stroke, "stroke");
    }, transform: function(d) {
      var p = this.group && !this.group._transformDone || this.group && this.canvas && d === this.canvas.contextTop, m = this.calcTransformMatrix(!p);
      d.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
    }, toObject: function(d) {
      var p = a.Object.NUM_FRACTION_DIGITS, m = { type: this.type, version: a.version, originX: this.originX, originY: this.originY, left: i(this.left, p), top: i(this.top, p), width: i(this.width, p), height: i(this.height, p), fill: this.fill && this.fill.toObject ? this.fill.toObject() : this.fill, stroke: this.stroke && this.stroke.toObject ? this.stroke.toObject() : this.stroke, strokeWidth: i(this.strokeWidth, p), strokeDashArray: this.strokeDashArray ? this.strokeDashArray.concat() : this.strokeDashArray, strokeLineCap: this.strokeLineCap, strokeDashOffset: this.strokeDashOffset, strokeLineJoin: this.strokeLineJoin, strokeUniform: this.strokeUniform, strokeMiterLimit: i(this.strokeMiterLimit, p), scaleX: i(this.scaleX, p), scaleY: i(this.scaleY, p), angle: i(this.angle, p), flipX: this.flipX, flipY: this.flipY, opacity: i(this.opacity, p), shadow: this.shadow && this.shadow.toObject ? this.shadow.toObject() : this.shadow, visible: this.visible, backgroundColor: this.backgroundColor, fillRule: this.fillRule, paintFirst: this.paintFirst, globalCompositeOperation: this.globalCompositeOperation, skewX: i(this.skewX, p), skewY: i(this.skewY, p) };
      return this.clipPath && !this.clipPath.excludeFromExport && (m.clipPath = this.clipPath.toObject(d), m.clipPath.inverted = this.clipPath.inverted, m.clipPath.absolutePositioned = this.clipPath.absolutePositioned), a.util.populateWithProperties(this, m, d), this.includeDefaultValues || (m = this._removeDefaultValues(m)), m;
    }, toDatalessObject: function(d) {
      return this.toObject(d);
    }, _removeDefaultValues: function(d) {
      var p = a.util.getKlass(d.type).prototype;
      return p.stateProperties.forEach(function(m) {
        m !== "left" && m !== "top" && (d[m] === p[m] && delete d[m], Object.prototype.toString.call(d[m]) === "[object Array]" && Object.prototype.toString.call(p[m]) === "[object Array]" && d[m].length === 0 && p[m].length === 0 && delete d[m]);
      }), d;
    }, toString: function() {
      return "#<fabric." + r(this.type) + ">";
    }, getObjectScaling: function() {
      if (!this.group) return { scaleX: this.scaleX, scaleY: this.scaleY };
      var d = a.util.qrDecompose(this.calcTransformMatrix());
      return { scaleX: Math.abs(d.scaleX), scaleY: Math.abs(d.scaleY) };
    }, getTotalObjectScaling: function() {
      var d = this.getObjectScaling(), p = d.scaleX, m = d.scaleY;
      if (this.canvas) {
        var y = this.canvas.getZoom(), _ = this.canvas.getRetinaScaling();
        p *= y * _, m *= y * _;
      }
      return { scaleX: p, scaleY: m };
    }, getObjectOpacity: function() {
      var d = this.opacity;
      return this.group && (d *= this.group.getObjectOpacity()), d;
    }, _set: function(d, p) {
      var m = d === "scaleX" || d === "scaleY", y = this[d] !== p, _ = !1;
      return m && (p = this._constrainScale(p)), d === "scaleX" && p < 0 ? (this.flipX = !this.flipX, p *= -1) : d === "scaleY" && p < 0 ? (this.flipY = !this.flipY, p *= -1) : d !== "shadow" || !p || p instanceof a.Shadow ? d === "dirty" && this.group && this.group.set("dirty", p) : p = new a.Shadow(p), this[d] = p, y && (_ = this.group && this.group.isOnACache(), this.cacheProperties.indexOf(d) > -1 ? (this.dirty = !0, _ && this.group.set("dirty", !0)) : _ && this.stateProperties.indexOf(d) > -1 && this.group.set("dirty", !0)), this;
    }, setOnGroup: function() {
    }, getViewportTransform: function() {
      return this.canvas && this.canvas.viewportTransform ? this.canvas.viewportTransform : a.iMatrix.concat();
    }, isNotVisible: function() {
      return this.opacity === 0 || !this.width && !this.height && this.strokeWidth === 0 || !this.visible;
    }, render: function(d) {
      this.isNotVisible() || this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (d.save(), this._setupCompositeOperation(d), this.drawSelectionBackground(d), this.transform(d), this._setOpacity(d), this._setShadow(d, this), this.shouldCache() ? (this.renderCache(), this.drawCacheOnCanvas(d)) : (this._removeCacheCanvas(), this.dirty = !1, this.drawObject(d), this.objectCaching && this.statefullCache && this.saveState({ propertySet: "cacheProperties" })), d.restore());
    }, renderCache: function(d) {
      d = d || {}, this._cacheCanvas || this._createCacheCanvas(), this.isCacheDirty() && (this.statefullCache && this.saveState({ propertySet: "cacheProperties" }), this.drawObject(this._cacheContext, d.forClipping), this.dirty = !1);
    }, _removeCacheCanvas: function() {
      this._cacheCanvas = null, this.cacheWidth = 0, this.cacheHeight = 0;
    }, hasStroke: function() {
      return this.stroke && this.stroke !== "transparent" && this.strokeWidth !== 0;
    }, hasFill: function() {
      return this.fill && this.fill !== "transparent";
    }, needsItsOwnCache: function() {
      return !(this.paintFirst !== "stroke" || !this.hasFill() || !this.hasStroke() || typeof this.shadow != "object") || !!this.clipPath;
    }, shouldCache: function() {
      return this.ownCaching = this.needsItsOwnCache() || this.objectCaching && (!this.group || !this.group.isOnACache()), this.ownCaching;
    }, willDrawShadow: function() {
      return !!this.shadow && (this.shadow.offsetX !== 0 || this.shadow.offsetY !== 0);
    }, drawClipPathOnCache: function(d) {
      var p = this.clipPath;
      if (d.save(), p.inverted ? d.globalCompositeOperation = "destination-out" : d.globalCompositeOperation = "destination-in", p.absolutePositioned) {
        var m = a.util.invertTransform(this.calcTransformMatrix());
        d.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      }
      p.transform(d), d.scale(1 / p.zoomX, 1 / p.zoomY), d.drawImage(p._cacheCanvas, -p.cacheTranslationX, -p.cacheTranslationY), d.restore();
    }, drawObject: function(d, p) {
      var m = this.fill, y = this.stroke;
      p ? (this.fill = "black", this.stroke = "", this._setClippingProperties(d)) : this._renderBackground(d), this._render(d), this._drawClipPath(d), this.fill = m, this.stroke = y;
    }, _drawClipPath: function(d) {
      var p = this.clipPath;
      p && (p.canvas = this.canvas, p.shouldCache(), p._transformDone = !0, p.renderCache({ forClipping: !0 }), this.drawClipPathOnCache(d));
    }, drawCacheOnCanvas: function(d) {
      d.scale(1 / this.zoomX, 1 / this.zoomY), d.drawImage(this._cacheCanvas, -this.cacheTranslationX, -this.cacheTranslationY);
    }, isCacheDirty: function(d) {
      if (this.isNotVisible()) return !1;
      if (this._cacheCanvas && !d && this._updateCacheCanvas()) return !0;
      if (this.dirty || this.clipPath && this.clipPath.absolutePositioned || this.statefullCache && this.hasStateChanged("cacheProperties")) {
        if (this._cacheCanvas && !d) {
          var p = this.cacheWidth / this.zoomX, m = this.cacheHeight / this.zoomY;
          this._cacheContext.clearRect(-p / 2, -m / 2, p, m);
        }
        return !0;
      }
      return !1;
    }, _renderBackground: function(d) {
      if (this.backgroundColor) {
        var p = this._getNonTransformedDimensions();
        d.fillStyle = this.backgroundColor, d.fillRect(-p.x / 2, -p.y / 2, p.x, p.y), this._removeShadow(d);
      }
    }, _setOpacity: function(d) {
      this.group && !this.group._transformDone ? d.globalAlpha = this.getObjectOpacity() : d.globalAlpha *= this.opacity;
    }, _setStrokeStyles: function(d, p) {
      var m = p.stroke;
      m && (d.lineWidth = p.strokeWidth, d.lineCap = p.strokeLineCap, d.lineDashOffset = p.strokeDashOffset, d.lineJoin = p.strokeLineJoin, d.miterLimit = p.strokeMiterLimit, m.toLive ? m.gradientUnits === "percentage" || m.gradientTransform || m.patternTransform ? this._applyPatternForTransformedGradient(d, m) : (d.strokeStyle = m.toLive(d, this), this._applyPatternGradientTransform(d, m)) : d.strokeStyle = p.stroke);
    }, _setFillStyles: function(d, p) {
      var m = p.fill;
      m && (m.toLive ? (d.fillStyle = m.toLive(d, this), this._applyPatternGradientTransform(d, p.fill)) : d.fillStyle = m);
    }, _setClippingProperties: function(d) {
      d.globalAlpha = 1, d.strokeStyle = "transparent", d.fillStyle = "#000000";
    }, _setLineDash: function(d, p) {
      p && p.length !== 0 && (1 & p.length && p.push.apply(p, p), d.setLineDash(p));
    }, _renderControls: function(d, p) {
      var m, y, _, k = this.getViewportTransform(), T = this.calcTransformMatrix();
      y = (p = p || {}).hasBorders !== void 0 ? p.hasBorders : this.hasBorders, _ = p.hasControls !== void 0 ? p.hasControls : this.hasControls, T = a.util.multiplyTransformMatrices(k, T), m = a.util.qrDecompose(T), d.save(), d.translate(m.translateX, m.translateY), d.lineWidth = 1 * this.borderScaleFactor, this.group || (d.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1), d.rotate(s(m.angle)), p.forActiveSelection || this.group ? y && this.drawBordersInGroup(d, m, p) : y && this.drawBorders(d, p), _ && this.drawControls(d, p), d.restore();
    }, _setShadow: function(d) {
      if (this.shadow) {
        var p, m = this.shadow, y = this.canvas, _ = y && y.viewportTransform[0] || 1, k = y && y.viewportTransform[3] || 1;
        p = m.nonScaling ? { scaleX: 1, scaleY: 1 } : this.getObjectScaling(), y && y._isRetinaScaling() && (_ *= a.devicePixelRatio, k *= a.devicePixelRatio), d.shadowColor = m.color, d.shadowBlur = m.blur * a.browserShadowBlurConstant * (_ + k) * (p.scaleX + p.scaleY) / 4, d.shadowOffsetX = m.offsetX * _ * p.scaleX, d.shadowOffsetY = m.offsetY * k * p.scaleY;
      }
    }, _removeShadow: function(d) {
      this.shadow && (d.shadowColor = "", d.shadowBlur = d.shadowOffsetX = d.shadowOffsetY = 0);
    }, _applyPatternGradientTransform: function(d, p) {
      if (!p || !p.toLive) return { offsetX: 0, offsetY: 0 };
      var m = p.gradientTransform || p.patternTransform, y = -this.width / 2 + p.offsetX || 0, _ = -this.height / 2 + p.offsetY || 0;
      return p.gradientUnits === "percentage" ? d.transform(this.width, 0, 0, this.height, y, _) : d.transform(1, 0, 0, 1, y, _), m && d.transform(m[0], m[1], m[2], m[3], m[4], m[5]), { offsetX: y, offsetY: _ };
    }, _renderPaintInOrder: function(d) {
      this.paintFirst === "stroke" ? (this._renderStroke(d), this._renderFill(d)) : (this._renderFill(d), this._renderStroke(d));
    }, _render: function() {
    }, _renderFill: function(d) {
      this.fill && (d.save(), this._setFillStyles(d, this), this.fillRule === "evenodd" ? d.fill("evenodd") : d.fill(), d.restore());
    }, _renderStroke: function(d) {
      if (this.stroke && this.strokeWidth !== 0) {
        if (this.shadow && !this.shadow.affectStroke && this._removeShadow(d), d.save(), this.strokeUniform && this.group) {
          var p = this.getObjectScaling();
          d.scale(1 / p.scaleX, 1 / p.scaleY);
        } else this.strokeUniform && d.scale(1 / this.scaleX, 1 / this.scaleY);
        this._setLineDash(d, this.strokeDashArray), this._setStrokeStyles(d, this), d.stroke(), d.restore();
      }
    }, _applyPatternForTransformedGradient: function(d, p) {
      var m, y = this._limitCacheSize(this._getCacheCanvasDimensions()), _ = a.util.createCanvasElement(), k = this.canvas.getRetinaScaling(), T = y.x / this.scaleX / k, D = y.y / this.scaleY / k;
      _.width = T, _.height = D, (m = _.getContext("2d")).beginPath(), m.moveTo(0, 0), m.lineTo(T, 0), m.lineTo(T, D), m.lineTo(0, D), m.closePath(), m.translate(T / 2, D / 2), m.scale(y.zoomX / this.scaleX / k, y.zoomY / this.scaleY / k), this._applyPatternGradientTransform(m, p), m.fillStyle = p.toLive(d), m.fill(), d.translate(-this.width / 2 - this.strokeWidth / 2, -this.height / 2 - this.strokeWidth / 2), d.scale(k * this.scaleX / y.zoomX, k * this.scaleY / y.zoomY), d.strokeStyle = m.createPattern(_, "no-repeat");
    }, _findCenterFromElement: function() {
      return { x: this.left + this.width / 2, y: this.top + this.height / 2 };
    }, _assignTransformMatrixProps: function() {
      if (this.transformMatrix) {
        var d = a.util.qrDecompose(this.transformMatrix);
        this.flipX = !1, this.flipY = !1, this.set("scaleX", d.scaleX), this.set("scaleY", d.scaleY), this.angle = d.angle, this.skewX = d.skewX, this.skewY = 0;
      }
    }, _removeTransformMatrix: function(d) {
      var p = this._findCenterFromElement();
      this.transformMatrix && (this._assignTransformMatrixProps(), p = a.util.transformPoint(p, this.transformMatrix)), this.transformMatrix = null, d && (this.scaleX *= d.scaleX, this.scaleY *= d.scaleY, this.cropX = d.cropX, this.cropY = d.cropY, p.x += d.offsetLeft, p.y += d.offsetTop, this.width = d.width, this.height = d.height), this.setPositionByOrigin(p, "center", "center");
    }, clone: function(d, p) {
      var m = this.toObject(p);
      this.constructor.fromObject ? this.constructor.fromObject(m, d) : a.Object._fromObject("Object", m, d);
    }, cloneAsImage: function(d, p) {
      var m = this.toCanvasElement(p);
      return d && d(new a.Image(m)), this;
    }, toCanvasElement: function(d) {
      d || (d = {});
      var p = a.util, m = p.saveObjectTransform(this), y = this.group, _ = this.shadow, k = Math.abs, T = (d.multiplier || 1) * (d.enableRetinaScaling ? a.devicePixelRatio : 1);
      delete this.group, d.withoutTransform && p.resetObjectTransform(this), d.withoutShadow && (this.shadow = null);
      var D, j, w, O, L = a.util.createCanvasElement(), U = this.getBoundingRect(!0, !0), W = this.shadow, I = { x: 0, y: 0 };
      W && (j = W.blur, D = W.nonScaling ? { scaleX: 1, scaleY: 1 } : this.getObjectScaling(), I.x = 2 * Math.round(k(W.offsetX) + j) * k(D.scaleX), I.y = 2 * Math.round(k(W.offsetY) + j) * k(D.scaleY)), w = U.width + I.x, O = U.height + I.y, L.width = Math.ceil(w), L.height = Math.ceil(O);
      var M = new a.StaticCanvas(L, { enableRetinaScaling: !1, renderOnAddRemove: !1, skipOffscreen: !1 });
      d.format === "jpeg" && (M.backgroundColor = "#fff"), this.setPositionByOrigin(new a.Point(M.width / 2, M.height / 2), "center", "center");
      var B = this.canvas;
      M.add(this);
      var Z = M.toCanvasElement(T || 1, d);
      return this.shadow = _, this.set("canvas", B), y && (this.group = y), this.set(m).setCoords(), M._objects = [], M.dispose(), M = null, Z;
    }, toDataURL: function(d) {
      return d || (d = {}), a.util.toDataURL(this.toCanvasElement(d), d.format || "png", d.quality || 1);
    }, isType: function(d) {
      return this.type === d;
    }, complexity: function() {
      return 1;
    }, toJSON: function(d) {
      return this.toObject(d);
    }, rotate: function(d) {
      var p = (this.originX !== "center" || this.originY !== "center") && this.centeredRotation;
      return p && this._setOriginToCenter(), this.set("angle", d), p && this._resetOrigin(), this;
    }, centerH: function() {
      return this.canvas && this.canvas.centerObjectH(this), this;
    }, viewportCenterH: function() {
      return this.canvas && this.canvas.viewportCenterObjectH(this), this;
    }, centerV: function() {
      return this.canvas && this.canvas.centerObjectV(this), this;
    }, viewportCenterV: function() {
      return this.canvas && this.canvas.viewportCenterObjectV(this), this;
    }, center: function() {
      return this.canvas && this.canvas.centerObject(this), this;
    }, viewportCenter: function() {
      return this.canvas && this.canvas.viewportCenterObject(this), this;
    }, getLocalPointer: function(d, p) {
      p = p || this.canvas.getPointer(d);
      var m = new a.Point(p.x, p.y), y = this._getLeftTopCoords();
      return this.angle && (m = a.util.rotatePoint(m, y, s(-this.angle))), { x: m.x - y.x, y: m.y - y.y };
    }, _setupCompositeOperation: function(d) {
      this.globalCompositeOperation && (d.globalCompositeOperation = this.globalCompositeOperation);
    } }), a.util.createAccessors && a.util.createAccessors(a.Object), c(a.Object.prototype, a.Observable), a.Object.NUM_FRACTION_DIGITS = 2, a.Object._fromObject = function(d, p, m, y) {
      var _ = a[d];
      p = f(p, !0), a.util.enlivenPatterns([p.fill, p.stroke], function(k) {
        k[0] !== void 0 && (p.fill = k[0]), k[1] !== void 0 && (p.stroke = k[1]), a.util.enlivenObjects([p.clipPath], function(T) {
          p.clipPath = T[0];
          var D = y ? new _(p[y], p) : new _(p);
          m && m(D);
        });
      });
    }, a.Object.__uid = 0);
  }(t), function() {
    var l = b.util.degreesToRadians, a = { left: -0.5, center: 0, right: 0.5 }, c = { top: -0.5, center: 0, bottom: 0.5 };
    b.util.object.extend(b.Object.prototype, { translateToGivenOrigin: function(f, i, r, s, h) {
      var d, p, m, y = f.x, _ = f.y;
      return typeof i == "string" ? i = a[i] : i -= 0.5, typeof s == "string" ? s = a[s] : s -= 0.5, typeof r == "string" ? r = c[r] : r -= 0.5, typeof h == "string" ? h = c[h] : h -= 0.5, p = h - r, ((d = s - i) || p) && (m = this._getTransformedDimensions(), y = f.x + d * m.x, _ = f.y + p * m.y), new b.Point(y, _);
    }, translateToCenterPoint: function(f, i, r) {
      var s = this.translateToGivenOrigin(f, i, r, "center", "center");
      return this.angle ? b.util.rotatePoint(s, f, l(this.angle)) : s;
    }, translateToOriginPoint: function(f, i, r) {
      var s = this.translateToGivenOrigin(f, "center", "center", i, r);
      return this.angle ? b.util.rotatePoint(s, f, l(this.angle)) : s;
    }, getCenterPoint: function() {
      var f = new b.Point(this.left, this.top);
      return this.translateToCenterPoint(f, this.originX, this.originY);
    }, getPointByOrigin: function(f, i) {
      var r = this.getCenterPoint();
      return this.translateToOriginPoint(r, f, i);
    }, toLocalPoint: function(f, i, r) {
      var s, h, d = this.getCenterPoint();
      return s = i !== void 0 && r !== void 0 ? this.translateToGivenOrigin(d, "center", "center", i, r) : new b.Point(this.left, this.top), h = new b.Point(f.x, f.y), this.angle && (h = b.util.rotatePoint(h, d, -l(this.angle))), h.subtractEquals(s);
    }, setPositionByOrigin: function(f, i, r) {
      var s = this.translateToCenterPoint(f, i, r), h = this.translateToOriginPoint(s, this.originX, this.originY);
      this.set("left", h.x), this.set("top", h.y);
    }, adjustPosition: function(f) {
      var i, r, s = l(this.angle), h = this.getScaledWidth(), d = b.util.cos(s) * h, p = b.util.sin(s) * h;
      i = typeof this.originX == "string" ? a[this.originX] : this.originX - 0.5, r = typeof f == "string" ? a[f] : f - 0.5, this.left += d * (r - i), this.top += p * (r - i), this.setCoords(), this.originX = f;
    }, _setOriginToCenter: function() {
      this._originalOriginX = this.originX, this._originalOriginY = this.originY;
      var f = this.getCenterPoint();
      this.originX = "center", this.originY = "center", this.left = f.x, this.top = f.y;
    }, _resetOrigin: function() {
      var f = this.translateToOriginPoint(this.getCenterPoint(), this._originalOriginX, this._originalOriginY);
      this.originX = this._originalOriginX, this.originY = this._originalOriginY, this.left = f.x, this.top = f.y, this._originalOriginX = null, this._originalOriginY = null;
    }, _getLeftTopCoords: function() {
      return this.translateToOriginPoint(this.getCenterPoint(), "left", "top");
    } });
  }(), function() {
    var l = b.util, a = l.degreesToRadians, c = l.multiplyTransformMatrices, f = l.transformPoint;
    l.object.extend(b.Object.prototype, { oCoords: null, aCoords: null, lineCoords: null, ownMatrixCache: null, matrixCache: null, controls: {}, _getCoords: function(i, r) {
      return r ? i ? this.calcACoords() : this.calcLineCoords() : (this.aCoords && this.lineCoords || this.setCoords(!0), i ? this.aCoords : this.lineCoords);
    }, getCoords: function(i, r) {
      return s = this._getCoords(i, r), [new b.Point(s.tl.x, s.tl.y), new b.Point(s.tr.x, s.tr.y), new b.Point(s.br.x, s.br.y), new b.Point(s.bl.x, s.bl.y)];
      var s;
    }, intersectsWithRect: function(i, r, s, h) {
      var d = this.getCoords(s, h);
      return b.Intersection.intersectPolygonRectangle(d, i, r).status === "Intersection";
    }, intersectsWithObject: function(i, r, s) {
      return b.Intersection.intersectPolygonPolygon(this.getCoords(r, s), i.getCoords(r, s)).status === "Intersection" || i.isContainedWithinObject(this, r, s) || this.isContainedWithinObject(i, r, s);
    }, isContainedWithinObject: function(i, r, s) {
      for (var h = this.getCoords(r, s), d = r ? i.aCoords : i.lineCoords, p = 0, m = i._getImageLines(d); p < 4; p++) if (!i.containsPoint(h[p], m)) return !1;
      return !0;
    }, isContainedWithinRect: function(i, r, s, h) {
      var d = this.getBoundingRect(s, h);
      return d.left >= i.x && d.left + d.width <= r.x && d.top >= i.y && d.top + d.height <= r.y;
    }, containsPoint: function(i, r, s, h) {
      var d = this._getCoords(s, h), p = (r = r || this._getImageLines(d), this._findCrossPoints(i, r));
      return p !== 0 && p % 2 == 1;
    }, isOnScreen: function(i) {
      if (!this.canvas) return !1;
      var r = this.canvas.vptCoords.tl, s = this.canvas.vptCoords.br;
      return !!this.getCoords(!0, i).some(function(h) {
        return h.x <= s.x && h.x >= r.x && h.y <= s.y && h.y >= r.y;
      }) || !!this.intersectsWithRect(r, s, !0, i) || this._containsCenterOfCanvas(r, s, i);
    }, _containsCenterOfCanvas: function(i, r, s) {
      var h = { x: (i.x + r.x) / 2, y: (i.y + r.y) / 2 };
      return !!this.containsPoint(h, null, !0, s);
    }, isPartiallyOnScreen: function(i) {
      if (!this.canvas) return !1;
      var r = this.canvas.vptCoords.tl, s = this.canvas.vptCoords.br;
      return !!this.intersectsWithRect(r, s, !0, i) || this.getCoords(!0, i).every(function(h) {
        return (h.x >= s.x || h.x <= r.x) && (h.y >= s.y || h.y <= r.y);
      }) && this._containsCenterOfCanvas(r, s, i);
    }, _getImageLines: function(i) {
      return { topline: { o: i.tl, d: i.tr }, rightline: { o: i.tr, d: i.br }, bottomline: { o: i.br, d: i.bl }, leftline: { o: i.bl, d: i.tl } };
    }, _findCrossPoints: function(i, r) {
      var s, h, d, p = 0;
      for (var m in r) if (!((d = r[m]).o.y < i.y && d.d.y < i.y || d.o.y >= i.y && d.d.y >= i.y || (d.o.x === d.d.x && d.o.x >= i.x ? h = d.o.x : (s = (d.d.y - d.o.y) / (d.d.x - d.o.x), h = -(i.y - 0 * i.x - (d.o.y - s * d.o.x)) / (0 - s)), h >= i.x && (p += 1), p !== 2))) break;
      return p;
    }, getBoundingRect: function(i, r) {
      var s = this.getCoords(i, r);
      return l.makeBoundingBoxFromPoints(s);
    }, getScaledWidth: function() {
      return this._getTransformedDimensions().x;
    }, getScaledHeight: function() {
      return this._getTransformedDimensions().y;
    }, _constrainScale: function(i) {
      return Math.abs(i) < this.minScaleLimit ? i < 0 ? -this.minScaleLimit : this.minScaleLimit : i === 0 ? 1e-4 : i;
    }, scale: function(i) {
      return this._set("scaleX", i), this._set("scaleY", i), this.setCoords();
    }, scaleToWidth: function(i, r) {
      var s = this.getBoundingRect(r).width / this.getScaledWidth();
      return this.scale(i / this.width / s);
    }, scaleToHeight: function(i, r) {
      var s = this.getBoundingRect(r).height / this.getScaledHeight();
      return this.scale(i / this.height / s);
    }, calcCoords: function(i) {
      return i ? this.calcACoords() : this.calcOCoords();
    }, calcLineCoords: function() {
      var i = this.getViewportTransform(), r = this.padding, s = a(this.angle), h = l.cos(s) * r, d = l.sin(s) * r, p = h + d, m = h - d, y = this.calcACoords(), _ = { tl: f(y.tl, i), tr: f(y.tr, i), bl: f(y.bl, i), br: f(y.br, i) };
      return r && (_.tl.x -= m, _.tl.y -= p, _.tr.x += p, _.tr.y -= m, _.bl.x -= p, _.bl.y += m, _.br.x += m, _.br.y += p), _;
    }, calcOCoords: function() {
      var i = this._calcRotateMatrix(), r = this._calcTranslateMatrix(), s = this.getViewportTransform(), h = c(s, r), d = c(h, i), p = (d = c(d, [1 / s[0], 0, 0, 1 / s[3], 0, 0]), this._calculateCurrentDimensions()), m = {};
      return this.forEachControl(function(y, _, k) {
        m[_] = y.positionHandler(p, d, k);
      }), m;
    }, calcACoords: function() {
      var i = this._calcRotateMatrix(), r = this._calcTranslateMatrix(), s = c(r, i), h = this._getTransformedDimensions(), d = h.x / 2, p = h.y / 2;
      return { tl: f({ x: -d, y: -p }, s), tr: f({ x: d, y: -p }, s), bl: f({ x: -d, y: p }, s), br: f({ x: d, y: p }, s) };
    }, setCoords: function(i) {
      return this.aCoords = this.calcACoords(), this.lineCoords = this.group ? this.aCoords : this.calcLineCoords(), i || (this.oCoords = this.calcOCoords(), this._setCornerCoords && this._setCornerCoords()), this;
    }, _calcRotateMatrix: function() {
      return l.calcRotateMatrix(this);
    }, _calcTranslateMatrix: function() {
      var i = this.getCenterPoint();
      return [1, 0, 0, 1, i.x, i.y];
    }, transformMatrixKey: function(i) {
      var r = "_", s = "";
      return !i && this.group && (s = this.group.transformMatrixKey(i) + r), s + this.top + r + this.left + r + this.scaleX + r + this.scaleY + r + this.skewX + r + this.skewY + r + this.angle + r + this.originX + r + this.originY + r + this.width + r + this.height + r + this.strokeWidth + this.flipX + this.flipY;
    }, calcTransformMatrix: function(i) {
      var r = this.calcOwnMatrix();
      if (i || !this.group) return r;
      var s = this.transformMatrixKey(i), h = this.matrixCache || (this.matrixCache = {});
      return h.key === s ? h.value : (this.group && (r = c(this.group.calcTransformMatrix(!1), r)), h.key = s, h.value = r, r);
    }, calcOwnMatrix: function() {
      var i = this.transformMatrixKey(!0), r = this.ownMatrixCache || (this.ownMatrixCache = {});
      if (r.key === i) return r.value;
      var s = this._calcTranslateMatrix(), h = { angle: this.angle, translateX: s[4], translateY: s[5], scaleX: this.scaleX, scaleY: this.scaleY, skewX: this.skewX, skewY: this.skewY, flipX: this.flipX, flipY: this.flipY };
      return r.key = i, r.value = l.composeMatrix(h), r.value;
    }, _calcDimensionsTransformMatrix: function(i, r, s) {
      return l.calcDimensionsMatrix({ skewX: i, skewY: r, scaleX: this.scaleX * (s && this.flipX ? -1 : 1), scaleY: this.scaleY * (s && this.flipY ? -1 : 1) });
    }, _getNonTransformedDimensions: function() {
      var i = this.strokeWidth;
      return { x: this.width + i, y: this.height + i };
    }, _getTransformedDimensions: function(i, r) {
      i === void 0 && (i = this.skewX), r === void 0 && (r = this.skewY);
      var s, h, d, p = i === 0 && r === 0;
      if (this.strokeUniform ? (h = this.width, d = this.height) : (h = (s = this._getNonTransformedDimensions()).x, d = s.y), p) return this._finalizeDimensions(h * this.scaleX, d * this.scaleY);
      var m = l.sizeAfterTransform(h, d, { scaleX: this.scaleX, scaleY: this.scaleY, skewX: i, skewY: r });
      return this._finalizeDimensions(m.x, m.y);
    }, _finalizeDimensions: function(i, r) {
      return this.strokeUniform ? { x: i + this.strokeWidth, y: r + this.strokeWidth } : { x: i, y: r };
    }, _calculateCurrentDimensions: function() {
      var i = this.getViewportTransform(), r = this._getTransformedDimensions();
      return f(r, i, !0).scalarAdd(2 * this.padding);
    } });
  }(), b.util.object.extend(b.Object.prototype, { sendToBack: function() {
    return this.group ? b.StaticCanvas.prototype.sendToBack.call(this.group, this) : this.canvas && this.canvas.sendToBack(this), this;
  }, bringToFront: function() {
    return this.group ? b.StaticCanvas.prototype.bringToFront.call(this.group, this) : this.canvas && this.canvas.bringToFront(this), this;
  }, sendBackwards: function(l) {
    return this.group ? b.StaticCanvas.prototype.sendBackwards.call(this.group, this, l) : this.canvas && this.canvas.sendBackwards(this, l), this;
  }, bringForward: function(l) {
    return this.group ? b.StaticCanvas.prototype.bringForward.call(this.group, this, l) : this.canvas && this.canvas.bringForward(this, l), this;
  }, moveTo: function(l) {
    return this.group && this.group.type !== "activeSelection" ? b.StaticCanvas.prototype.moveTo.call(this.group, this, l) : this.canvas && this.canvas.moveTo(this, l), this;
  } }), function() {
    function l(c, f) {
      if (f) {
        if (f.toLive) return c + ": url(#SVGID_" + f.id + "); ";
        var i = new b.Color(f), r = c + ": " + i.toRgb() + "; ", s = i.getAlpha();
        return s !== 1 && (r += c + "-opacity: " + s.toString() + "; "), r;
      }
      return c + ": none; ";
    }
    var a = b.util.toFixed;
    b.util.object.extend(b.Object.prototype, { getSvgStyles: function(c) {
      var f = this.fillRule ? this.fillRule : "nonzero", i = this.strokeWidth ? this.strokeWidth : "0", r = this.strokeDashArray ? this.strokeDashArray.join(" ") : "none", s = this.strokeDashOffset ? this.strokeDashOffset : "0", h = this.strokeLineCap ? this.strokeLineCap : "butt", d = this.strokeLineJoin ? this.strokeLineJoin : "miter", p = this.strokeMiterLimit ? this.strokeMiterLimit : "4", m = this.opacity !== void 0 ? this.opacity : "1", y = this.visible ? "" : " visibility: hidden;", _ = c ? "" : this.getSvgFilter(), k = l("fill", this.fill);
      return [l("stroke", this.stroke), "stroke-width: ", i, "; ", "stroke-dasharray: ", r, "; ", "stroke-linecap: ", h, "; ", "stroke-dashoffset: ", s, "; ", "stroke-linejoin: ", d, "; ", "stroke-miterlimit: ", p, "; ", k, "fill-rule: ", f, "; ", "opacity: ", m, ";", _, y].join("");
    }, getSvgSpanStyles: function(c, f) {
      var i = "; ", r = c.fontFamily ? "font-family: " + (c.fontFamily.indexOf("'") === -1 && c.fontFamily.indexOf('"') === -1 ? "'" + c.fontFamily + "'" : c.fontFamily) + i : "", s = c.strokeWidth ? "stroke-width: " + c.strokeWidth + i : "", h = (r = r, c.fontSize ? "font-size: " + c.fontSize + "px" + i : ""), d = c.fontStyle ? "font-style: " + c.fontStyle + i : "", p = c.fontWeight ? "font-weight: " + c.fontWeight + i : "", m = c.fill ? l("fill", c.fill) : "", y = c.stroke ? l("stroke", c.stroke) : "", _ = this.getSvgTextDecoration(c);
      return _ && (_ = "text-decoration: " + _ + i), [y, s, r, h, d, p, _, m, c.deltaY ? "baseline-shift: " + -c.deltaY + "; " : "", f ? "white-space: pre; " : ""].join("");
    }, getSvgTextDecoration: function(c) {
      return ["overline", "underline", "line-through"].filter(function(f) {
        return c[f.replace("-", "")];
      }).join(" ");
    }, getSvgFilter: function() {
      return this.shadow ? "filter: url(#SVGID_" + this.shadow.id + ");" : "";
    }, getSvgCommons: function() {
      return [this.id ? 'id="' + this.id + '" ' : "", this.clipPath ? 'clip-path="url(#' + this.clipPath.clipPathId + ')" ' : ""].join("");
    }, getSvgTransform: function(c, f) {
      var i = c ? this.calcTransformMatrix() : this.calcOwnMatrix();
      return 'transform="' + b.util.matrixToSVG(i) + (f || "") + '" ';
    }, _setSVGBg: function(c) {
      if (this.backgroundColor) {
        var f = b.Object.NUM_FRACTION_DIGITS;
        c.push("		<rect ", this._getFillAttributes(this.backgroundColor), ' x="', a(-this.width / 2, f), '" y="', a(-this.height / 2, f), '" width="', a(this.width, f), '" height="', a(this.height, f), `"></rect>
`);
      }
    }, toSVG: function(c) {
      return this._createBaseSVGMarkup(this._toSVG(c), { reviver: c });
    }, toClipPathSVG: function(c) {
      return "	" + this._createBaseClipPathSVGMarkup(this._toSVG(c), { reviver: c });
    }, _createBaseClipPathSVGMarkup: function(c, f) {
      var i = (f = f || {}).reviver, r = f.additionalTransform || "", s = [this.getSvgTransform(!0, r), this.getSvgCommons()].join(""), h = c.indexOf("COMMON_PARTS");
      return c[h] = s, i ? i(c.join("")) : c.join("");
    }, _createBaseSVGMarkup: function(c, f) {
      var i, r, s = (f = f || {}).noStyle, h = f.reviver, d = s ? "" : 'style="' + this.getSvgStyles() + '" ', p = f.withShadow ? 'style="' + this.getSvgFilter() + '" ' : "", m = this.clipPath, y = this.strokeUniform ? 'vector-effect="non-scaling-stroke" ' : "", _ = m && m.absolutePositioned, k = this.stroke, T = this.fill, D = this.shadow, j = [], w = c.indexOf("COMMON_PARTS"), O = f.additionalTransform;
      return m && (m.clipPathId = "CLIPPATH_" + b.Object.__uid++, r = '<clipPath id="' + m.clipPathId + `" >
` + m.toClipPathSVG(h) + `</clipPath>
`), _ && j.push("<g ", p, this.getSvgCommons(), ` >
`), j.push("<g ", this.getSvgTransform(!1), _ ? "" : p + this.getSvgCommons(), ` >
`), i = [d, y, s ? "" : this.addPaintOrder(), " ", O ? 'transform="' + O + '" ' : ""].join(""), c[w] = i, T && T.toLive && j.push(T.toSVG(this)), k && k.toLive && j.push(k.toSVG(this)), D && j.push(D.toSVG(this)), m && j.push(r), j.push(c.join("")), j.push(`</g>
`), _ && j.push(`</g>
`), h ? h(j.join("")) : j.join("");
    }, addPaintOrder: function() {
      return this.paintFirst !== "fill" ? ' paint-order="' + this.paintFirst + '" ' : "";
    } });
  }(), function() {
    var l = b.util.object.extend, a = "stateProperties";
    function c(i, r, s) {
      var h = {};
      s.forEach(function(d) {
        h[d] = i[d];
      }), l(i[r], h, !0);
    }
    function f(i, r, s) {
      if (i === r) return !0;
      if (Array.isArray(i)) {
        if (!Array.isArray(r) || i.length !== r.length) return !1;
        for (var h = 0, d = i.length; h < d; h++) if (!f(i[h], r[h])) return !1;
        return !0;
      }
      if (i && typeof i == "object") {
        var p, m = Object.keys(i);
        if (!r || typeof r != "object" || !s && m.length !== Object.keys(r).length) return !1;
        for (h = 0, d = m.length; h < d; h++) if ((p = m[h]) !== "canvas" && p !== "group" && !f(i[p], r[p])) return !1;
        return !0;
      }
    }
    b.util.object.extend(b.Object.prototype, { hasStateChanged: function(i) {
      var r = "_" + (i = i || a);
      return Object.keys(this[r]).length < this[i].length || !f(this[r], this, !0);
    }, saveState: function(i) {
      var r = i && i.propertySet || a, s = "_" + r;
      return this[s] ? (c(this, s, this[r]), i && i.stateProperties && c(this, s, i.stateProperties), this) : this.setupState(i);
    }, setupState: function(i) {
      var r = (i = i || {}).propertySet || a;
      return i.propertySet = r, this["_" + r] = {}, this.saveState(i), this;
    } });
  }(), function() {
    var l = b.util.degreesToRadians;
    b.util.object.extend(b.Object.prototype, { _findTargetCorner: function(a, c) {
      if (!this.hasControls || this.group || !this.canvas || this.canvas._activeObject !== this) return !1;
      var f, i, r, s = a.x, h = a.y, d = Object.keys(this.oCoords), p = d.length - 1;
      for (this.__corner = 0; p >= 0; p--) if (r = d[p], this.isControlVisible(r) && (i = this._getImageLines(c ? this.oCoords[r].touchCorner : this.oCoords[r].corner), (f = this._findCrossPoints({ x: s, y: h }, i)) !== 0 && f % 2 == 1)) return this.__corner = r, r;
      return !1;
    }, forEachControl: function(a) {
      for (var c in this.controls) a(this.controls[c], c, this);
    }, _setCornerCoords: function() {
      var a = this.oCoords;
      for (var c in a) {
        var f = this.controls[c];
        a[c].corner = f.calcCornerCoords(this.angle, this.cornerSize, a[c].x, a[c].y, !1), a[c].touchCorner = f.calcCornerCoords(this.angle, this.touchCornerSize, a[c].x, a[c].y, !0);
      }
    }, drawSelectionBackground: function(a) {
      if (!this.selectionBackgroundColor || this.canvas && !this.canvas.interactive || this.canvas && this.canvas._activeObject !== this) return this;
      a.save();
      var c = this.getCenterPoint(), f = this._calculateCurrentDimensions(), i = this.canvas.viewportTransform;
      return a.translate(c.x, c.y), a.scale(1 / i[0], 1 / i[3]), a.rotate(l(this.angle)), a.fillStyle = this.selectionBackgroundColor, a.fillRect(-f.x / 2, -f.y / 2, f.x, f.y), a.restore(), this;
    }, drawBorders: function(a, c) {
      c = c || {};
      var f = this._calculateCurrentDimensions(), i = this.borderScaleFactor, r = f.x + i, s = f.y + i, h = c.hasControls !== void 0 ? c.hasControls : this.hasControls, d = !1;
      return a.save(), a.strokeStyle = c.borderColor || this.borderColor, this._setLineDash(a, c.borderDashArray || this.borderDashArray), a.strokeRect(-r / 2, -s / 2, r, s), h && (a.beginPath(), this.forEachControl(function(p, m, y) {
        p.withConnection && p.getVisibility(y, m) && (d = !0, a.moveTo(p.x * r, p.y * s), a.lineTo(p.x * r + p.offsetX, p.y * s + p.offsetY));
      }), d && a.stroke()), a.restore(), this;
    }, drawBordersInGroup: function(a, c, f) {
      f = f || {};
      var i = b.util.sizeAfterTransform(this.width, this.height, c), r = this.strokeWidth, s = this.strokeUniform, h = this.borderScaleFactor, d = i.x + r * (s ? this.canvas.getZoom() : c.scaleX) + h, p = i.y + r * (s ? this.canvas.getZoom() : c.scaleY) + h;
      return a.save(), this._setLineDash(a, f.borderDashArray || this.borderDashArray), a.strokeStyle = f.borderColor || this.borderColor, a.strokeRect(-d / 2, -p / 2, d, p), a.restore(), this;
    }, drawControls: function(a, c) {
      c = c || {}, a.save();
      var f, i, r = this.canvas.getRetinaScaling();
      return a.setTransform(r, 0, 0, r, 0, 0), a.strokeStyle = a.fillStyle = c.cornerColor || this.cornerColor, this.transparentCorners || (a.strokeStyle = c.cornerStrokeColor || this.cornerStrokeColor), this._setLineDash(a, c.cornerDashArray || this.cornerDashArray), this.setCoords(), this.group && (f = this.group.calcTransformMatrix()), this.forEachControl(function(s, h, d) {
        i = d.oCoords[h], s.getVisibility(d, h) && (f && (i = b.util.transformPoint(i, f)), s.render(a, i.x, i.y, c, d));
      }), a.restore(), this;
    }, isControlVisible: function(a) {
      return this.controls[a] && this.controls[a].getVisibility(this, a);
    }, setControlVisible: function(a, c) {
      return this._controlsVisibility || (this._controlsVisibility = {}), this._controlsVisibility[a] = c, this;
    }, setControlsVisibility: function(a) {
      for (var c in a || (a = {}), a) this.setControlVisible(c, a[c]);
      return this;
    }, onDeselect: function() {
    }, onSelect: function() {
    } });
  }(), b.util.object.extend(b.StaticCanvas.prototype, { FX_DURATION: 500, fxCenterObjectH: function(l, a) {
    var c = function() {
    }, f = (a = a || {}).onComplete || c, i = a.onChange || c, r = this;
    return b.util.animate({ startValue: l.left, endValue: this.getCenter().left, duration: this.FX_DURATION, onChange: function(s) {
      l.set("left", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      l.setCoords(), f();
    } }), this;
  }, fxCenterObjectV: function(l, a) {
    var c = function() {
    }, f = (a = a || {}).onComplete || c, i = a.onChange || c, r = this;
    return b.util.animate({ startValue: l.top, endValue: this.getCenter().top, duration: this.FX_DURATION, onChange: function(s) {
      l.set("top", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      l.setCoords(), f();
    } }), this;
  }, fxRemove: function(l, a) {
    var c = function() {
    }, f = (a = a || {}).onComplete || c, i = a.onChange || c, r = this;
    return b.util.animate({ startValue: l.opacity, endValue: 0, duration: this.FX_DURATION, onChange: function(s) {
      l.set("opacity", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      r.remove(l), f();
    } }), this;
  } }), b.util.object.extend(b.Object.prototype, { animate: function() {
    if (arguments[0] && typeof arguments[0] == "object") {
      var l, a, c = [];
      for (l in arguments[0]) c.push(l);
      for (var f = 0, i = c.length; f < i; f++) l = c[f], a = f !== i - 1, this._animate(l, arguments[0][l], arguments[1], a);
    } else this._animate.apply(this, arguments);
    return this;
  }, _animate: function(l, a, c, f) {
    var i, r = this;
    a = a.toString(), c = c ? b.util.object.clone(c) : {}, ~l.indexOf(".") && (i = l.split("."));
    var s = r.colorProperties.indexOf(l) > -1 || i && r.colorProperties.indexOf(i[1]) > -1, h = i ? this.get(i[0])[i[1]] : this.get(l);
    "from" in c || (c.from = h), s || (a = ~a.indexOf("=") ? h + parseFloat(a.replace("=", "")) : parseFloat(a));
    var d = { startValue: c.from, endValue: a, byValue: c.by, easing: c.easing, duration: c.duration, abort: c.abort && function(p, m, y) {
      return c.abort.call(r, p, m, y);
    }, onChange: function(p, m, y) {
      i ? r[i[0]][i[1]] = p : r.set(l, p), f || c.onChange && c.onChange(p, m, y);
    }, onComplete: function(p, m, y) {
      f || (r.setCoords(), c.onComplete && c.onComplete(p, m, y));
    } };
    return s ? b.util.animateColor(d.startValue, d.endValue, d.duration, d) : b.util.animate(d);
  } }), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.util.object.clone, i = { x1: 1, x2: 1, y1: 1, y2: 1 };
    function r(s, h) {
      var d = s.origin, p = s.axis1, m = s.axis2, y = s.dimension, _ = h.nearest, k = h.center, T = h.farthest;
      return function() {
        switch (this.get(d)) {
          case _:
            return Math.min(this.get(p), this.get(m));
          case k:
            return Math.min(this.get(p), this.get(m)) + 0.5 * this.get(y);
          case T:
            return Math.max(this.get(p), this.get(m));
        }
      };
    }
    a.Line ? a.warn("fabric.Line is already defined") : (a.Line = a.util.createClass(a.Object, { type: "line", x1: 0, y1: 0, x2: 0, y2: 0, cacheProperties: a.Object.prototype.cacheProperties.concat("x1", "x2", "y1", "y2"), initialize: function(s, h) {
      s || (s = [0, 0, 0, 0]), this.callSuper("initialize", h), this.set("x1", s[0]), this.set("y1", s[1]), this.set("x2", s[2]), this.set("y2", s[3]), this._setWidthHeight(h);
    }, _setWidthHeight: function(s) {
      s || (s = {}), this.width = Math.abs(this.x2 - this.x1), this.height = Math.abs(this.y2 - this.y1), this.left = "left" in s ? s.left : this._getLeftToOriginX(), this.top = "top" in s ? s.top : this._getTopToOriginY();
    }, _set: function(s, h) {
      return this.callSuper("_set", s, h), i[s] !== void 0 && this._setWidthHeight(), this;
    }, _getLeftToOriginX: r({ origin: "originX", axis1: "x1", axis2: "x2", dimension: "width" }, { nearest: "left", center: "center", farthest: "right" }), _getTopToOriginY: r({ origin: "originY", axis1: "y1", axis2: "y2", dimension: "height" }, { nearest: "top", center: "center", farthest: "bottom" }), _render: function(s) {
      s.beginPath();
      var h = this.calcLinePoints();
      s.moveTo(h.x1, h.y1), s.lineTo(h.x2, h.y2), s.lineWidth = this.strokeWidth;
      var d = s.strokeStyle;
      s.strokeStyle = this.stroke || s.fillStyle, this.stroke && this._renderStroke(s), s.strokeStyle = d;
    }, _findCenterFromElement: function() {
      return { x: (this.x1 + this.x2) / 2, y: (this.y1 + this.y2) / 2 };
    }, toObject: function(s) {
      return c(this.callSuper("toObject", s), this.calcLinePoints());
    }, _getNonTransformedDimensions: function() {
      var s = this.callSuper("_getNonTransformedDimensions");
      return this.strokeLineCap === "butt" && (this.width === 0 && (s.y -= this.strokeWidth), this.height === 0 && (s.x -= this.strokeWidth)), s;
    }, calcLinePoints: function() {
      var s = this.x1 <= this.x2 ? -1 : 1, h = this.y1 <= this.y2 ? -1 : 1, d = s * this.width * 0.5, p = h * this.height * 0.5;
      return { x1: d, x2: s * this.width * -0.5, y1: p, y2: h * this.height * -0.5 };
    }, _toSVG: function() {
      var s = this.calcLinePoints();
      return ["<line ", "COMMON_PARTS", 'x1="', s.x1, '" y1="', s.y1, '" x2="', s.x2, '" y2="', s.y2, `" />
`];
    } }), a.Line.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat("x1 y1 x2 y2".split(" ")), a.Line.fromElement = function(s, h, d) {
      d = d || {};
      var p = a.parseAttributes(s, a.Line.ATTRIBUTE_NAMES), m = [p.x1 || 0, p.y1 || 0, p.x2 || 0, p.y2 || 0];
      h(new a.Line(m, c(p, d)));
    }, a.Line.fromObject = function(s, h) {
      var d = f(s, !0);
      d.points = [s.x1, s.y1, s.x2, s.y2], a.Object._fromObject("Line", d, function(p) {
        delete p.points, h && h(p);
      }, "points");
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = Math.PI;
    a.Circle ? a.warn("fabric.Circle is already defined.") : (a.Circle = a.util.createClass(a.Object, { type: "circle", radius: 0, startAngle: 0, endAngle: 2 * c, cacheProperties: a.Object.prototype.cacheProperties.concat("radius", "startAngle", "endAngle"), _set: function(f, i) {
      return this.callSuper("_set", f, i), f === "radius" && this.setRadius(i), this;
    }, toObject: function(f) {
      return this.callSuper("toObject", ["radius", "startAngle", "endAngle"].concat(f));
    }, _toSVG: function() {
      var f, i = (this.endAngle - this.startAngle) % (2 * c);
      if (i === 0) f = ["<circle ", "COMMON_PARTS", 'cx="0" cy="0" ', 'r="', this.radius, `" />
`];
      else {
        var r = a.util.cos(this.startAngle) * this.radius, s = a.util.sin(this.startAngle) * this.radius, h = a.util.cos(this.endAngle) * this.radius, d = a.util.sin(this.endAngle) * this.radius, p = i > c ? "1" : "0";
        f = ['<path d="M ' + r + " " + s, " A " + this.radius + " " + this.radius, " 0 ", +p + " 1", " " + h + " " + d, '" ', "COMMON_PARTS", ` />
`];
      }
      return f;
    }, _render: function(f) {
      f.beginPath(), f.arc(0, 0, this.radius, this.startAngle, this.endAngle, !1), this._renderPaintInOrder(f);
    }, getRadiusX: function() {
      return this.get("radius") * this.get("scaleX");
    }, getRadiusY: function() {
      return this.get("radius") * this.get("scaleY");
    }, setRadius: function(f) {
      return this.radius = f, this.set("width", 2 * f).set("height", 2 * f);
    } }), a.Circle.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat("cx cy r".split(" ")), a.Circle.fromElement = function(f, i) {
      var r, s = a.parseAttributes(f, a.Circle.ATTRIBUTE_NAMES);
      if (!("radius" in (r = s) && r.radius >= 0)) throw new Error("value of `r` attribute is required and can not be negative");
      s.left = (s.left || 0) - s.radius, s.top = (s.top || 0) - s.radius, i(new a.Circle(s));
    }, a.Circle.fromObject = function(f, i) {
      a.Object._fromObject("Circle", f, i);
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    a.Triangle ? a.warn("fabric.Triangle is already defined") : (a.Triangle = a.util.createClass(a.Object, { type: "triangle", width: 100, height: 100, _render: function(c) {
      var f = this.width / 2, i = this.height / 2;
      c.beginPath(), c.moveTo(-f, i), c.lineTo(0, -i), c.lineTo(f, i), c.closePath(), this._renderPaintInOrder(c);
    }, _toSVG: function() {
      var c = this.width / 2, f = this.height / 2;
      return ["<polygon ", "COMMON_PARTS", 'points="', [-c + " " + f, "0 " + -f, c + " " + f].join(","), '" />'];
    } }), a.Triangle.fromObject = function(c, f) {
      return a.Object._fromObject("Triangle", c, f);
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = 2 * Math.PI;
    a.Ellipse ? a.warn("fabric.Ellipse is already defined.") : (a.Ellipse = a.util.createClass(a.Object, { type: "ellipse", rx: 0, ry: 0, cacheProperties: a.Object.prototype.cacheProperties.concat("rx", "ry"), initialize: function(f) {
      this.callSuper("initialize", f), this.set("rx", f && f.rx || 0), this.set("ry", f && f.ry || 0);
    }, _set: function(f, i) {
      switch (this.callSuper("_set", f, i), f) {
        case "rx":
          this.rx = i, this.set("width", 2 * i);
          break;
        case "ry":
          this.ry = i, this.set("height", 2 * i);
      }
      return this;
    }, getRx: function() {
      return this.get("rx") * this.get("scaleX");
    }, getRy: function() {
      return this.get("ry") * this.get("scaleY");
    }, toObject: function(f) {
      return this.callSuper("toObject", ["rx", "ry"].concat(f));
    }, _toSVG: function() {
      return ["<ellipse ", "COMMON_PARTS", 'cx="0" cy="0" ', 'rx="', this.rx, '" ry="', this.ry, `" />
`];
    }, _render: function(f) {
      f.beginPath(), f.save(), f.transform(1, 0, 0, this.ry / this.rx, 0, 0), f.arc(0, 0, this.rx, 0, c, !1), f.restore(), this._renderPaintInOrder(f);
    } }), a.Ellipse.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat("cx cy rx ry".split(" ")), a.Ellipse.fromElement = function(f, i) {
      var r = a.parseAttributes(f, a.Ellipse.ATTRIBUTE_NAMES);
      r.left = (r.left || 0) - r.rx, r.top = (r.top || 0) - r.ry, i(new a.Ellipse(r));
    }, a.Ellipse.fromObject = function(f, i) {
      a.Object._fromObject("Ellipse", f, i);
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend;
    a.Rect ? a.warn("fabric.Rect is already defined") : (a.Rect = a.util.createClass(a.Object, { stateProperties: a.Object.prototype.stateProperties.concat("rx", "ry"), type: "rect", rx: 0, ry: 0, cacheProperties: a.Object.prototype.cacheProperties.concat("rx", "ry"), initialize: function(f) {
      this.callSuper("initialize", f), this._initRxRy();
    }, _initRxRy: function() {
      this.rx && !this.ry ? this.ry = this.rx : this.ry && !this.rx && (this.rx = this.ry);
    }, _render: function(f) {
      var i = this.rx ? Math.min(this.rx, this.width / 2) : 0, r = this.ry ? Math.min(this.ry, this.height / 2) : 0, s = this.width, h = this.height, d = -this.width / 2, p = -this.height / 2, m = i !== 0 || r !== 0, y = 0.4477152502;
      f.beginPath(), f.moveTo(d + i, p), f.lineTo(d + s - i, p), m && f.bezierCurveTo(d + s - y * i, p, d + s, p + y * r, d + s, p + r), f.lineTo(d + s, p + h - r), m && f.bezierCurveTo(d + s, p + h - y * r, d + s - y * i, p + h, d + s - i, p + h), f.lineTo(d + i, p + h), m && f.bezierCurveTo(d + y * i, p + h, d, p + h - y * r, d, p + h - r), f.lineTo(d, p + r), m && f.bezierCurveTo(d, p + y * r, d + y * i, p, d + i, p), f.closePath(), this._renderPaintInOrder(f);
    }, toObject: function(f) {
      return this.callSuper("toObject", ["rx", "ry"].concat(f));
    }, _toSVG: function() {
      return ["<rect ", "COMMON_PARTS", 'x="', -this.width / 2, '" y="', -this.height / 2, '" rx="', this.rx, '" ry="', this.ry, '" width="', this.width, '" height="', this.height, `" />
`];
    } }), a.Rect.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat("x y rx ry width height".split(" ")), a.Rect.fromElement = function(f, i, r) {
      if (!f) return i(null);
      r = r || {};
      var s = a.parseAttributes(f, a.Rect.ATTRIBUTE_NAMES);
      s.left = s.left || 0, s.top = s.top || 0, s.height = s.height || 0, s.width = s.width || 0;
      var h = new a.Rect(c(r ? a.util.object.clone(r) : {}, s));
      h.visible = h.visible && h.width > 0 && h.height > 0, i(h);
    }, a.Rect.fromObject = function(f, i) {
      return a.Object._fromObject("Rect", f, i);
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.util.array.min, i = a.util.array.max, r = a.util.toFixed;
    a.Polyline ? a.warn("fabric.Polyline is already defined") : (a.Polyline = a.util.createClass(a.Object, { type: "polyline", points: null, cacheProperties: a.Object.prototype.cacheProperties.concat("points"), initialize: function(s, h) {
      h = h || {}, this.points = s || [], this.callSuper("initialize", h), this._setPositionDimensions(h);
    }, _setPositionDimensions: function(s) {
      var h, d = this._calcDimensions(s);
      this.width = d.width, this.height = d.height, s.fromSVG || (h = this.translateToGivenOrigin({ x: d.left - this.strokeWidth / 2, y: d.top - this.strokeWidth / 2 }, "left", "top", this.originX, this.originY)), s.left === void 0 && (this.left = s.fromSVG ? d.left : h.x), s.top === void 0 && (this.top = s.fromSVG ? d.top : h.y), this.pathOffset = { x: d.left + this.width / 2, y: d.top + this.height / 2 };
    }, _calcDimensions: function() {
      var s = this.points, h = f(s, "x") || 0, d = f(s, "y") || 0;
      return { left: h, top: d, width: (i(s, "x") || 0) - h, height: (i(s, "y") || 0) - d };
    }, toObject: function(s) {
      return c(this.callSuper("toObject", s), { points: this.points.concat() });
    }, _toSVG: function() {
      for (var s = [], h = this.pathOffset.x, d = this.pathOffset.y, p = a.Object.NUM_FRACTION_DIGITS, m = 0, y = this.points.length; m < y; m++) s.push(r(this.points[m].x - h, p), ",", r(this.points[m].y - d, p), " ");
      return ["<" + this.type + " ", "COMMON_PARTS", 'points="', s.join(""), `" />
`];
    }, commonRender: function(s) {
      var h, d = this.points.length, p = this.pathOffset.x, m = this.pathOffset.y;
      if (!d || isNaN(this.points[d - 1].y)) return !1;
      s.beginPath(), s.moveTo(this.points[0].x - p, this.points[0].y - m);
      for (var y = 0; y < d; y++) h = this.points[y], s.lineTo(h.x - p, h.y - m);
      return !0;
    }, _render: function(s) {
      this.commonRender(s) && this._renderPaintInOrder(s);
    }, complexity: function() {
      return this.get("points").length;
    } }), a.Polyline.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat(), a.Polyline.fromElementGenerator = function(s) {
      return function(h, d, p) {
        if (!h) return d(null);
        p || (p = {});
        var m = a.parsePointsAttribute(h.getAttribute("points")), y = a.parseAttributes(h, a[s].ATTRIBUTE_NAMES);
        y.fromSVG = !0, d(new a[s](m, c(y, p)));
      };
    }, a.Polyline.fromElement = a.Polyline.fromElementGenerator("Polyline"), a.Polyline.fromObject = function(s, h) {
      return a.Object._fromObject("Polyline", s, h, "points");
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    a.Polygon ? a.warn("fabric.Polygon is already defined") : (a.Polygon = a.util.createClass(a.Polyline, { type: "polygon", _render: function(c) {
      this.commonRender(c) && (c.closePath(), this._renderPaintInOrder(c));
    } }), a.Polygon.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat(), a.Polygon.fromElement = a.Polyline.fromElementGenerator("Polygon"), a.Polygon.fromObject = function(c, f) {
      a.Object._fromObject("Polygon", c, f, "points");
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.array.min, f = a.util.array.max, i = a.util.object.extend, r = Object.prototype.toString, s = a.util.toFixed;
    a.Path ? a.warn("fabric.Path is already defined") : (a.Path = a.util.createClass(a.Object, { type: "path", path: null, cacheProperties: a.Object.prototype.cacheProperties.concat("path", "fillRule"), stateProperties: a.Object.prototype.stateProperties.concat("path"), initialize: function(h, d) {
      d = d || {}, this.callSuper("initialize", d), h || (h = []);
      var p = r.call(h) === "[object Array]";
      this.path = a.util.makePathSimpler(p ? h : a.util.parsePath(h)), this.path && a.Polyline.prototype._setPositionDimensions.call(this, d);
    }, _renderPathCommands: function(h) {
      var d, p = 0, m = 0, y = 0, _ = 0, k = 0, T = 0, D = -this.pathOffset.x, j = -this.pathOffset.y;
      h.beginPath();
      for (var w = 0, O = this.path.length; w < O; ++w) switch ((d = this.path[w])[0]) {
        case "L":
          y = d[1], _ = d[2], h.lineTo(y + D, _ + j);
          break;
        case "M":
          p = y = d[1], m = _ = d[2], h.moveTo(y + D, _ + j);
          break;
        case "C":
          y = d[5], _ = d[6], k = d[3], T = d[4], h.bezierCurveTo(d[1] + D, d[2] + j, k + D, T + j, y + D, _ + j);
          break;
        case "Q":
          h.quadraticCurveTo(d[1] + D, d[2] + j, d[3] + D, d[4] + j), y = d[3], _ = d[4], k = d[1], T = d[2];
          break;
        case "z":
        case "Z":
          y = p, _ = m, h.closePath();
      }
    }, _render: function(h) {
      this._renderPathCommands(h), this._renderPaintInOrder(h);
    }, toString: function() {
      return "#<fabric.Path (" + this.complexity() + '): { "top": ' + this.top + ', "left": ' + this.left + " }>";
    }, toObject: function(h) {
      return i(this.callSuper("toObject", h), { path: this.path.map(function(d) {
        return d.slice();
      }) });
    }, toDatalessObject: function(h) {
      var d = this.toObject(["sourcePath"].concat(h));
      return d.sourcePath && delete d.path, d;
    }, _toSVG: function() {
      return ["<path ", "COMMON_PARTS", 'd="', a.util.joinPath(this.path), '" stroke-linecap="round" ', `/>
`];
    }, _getOffsetTransform: function() {
      var h = a.Object.NUM_FRACTION_DIGITS;
      return " translate(" + s(-this.pathOffset.x, h) + ", " + s(-this.pathOffset.y, h) + ")";
    }, toClipPathSVG: function(h) {
      var d = this._getOffsetTransform();
      return "	" + this._createBaseClipPathSVGMarkup(this._toSVG(), { reviver: h, additionalTransform: d });
    }, toSVG: function(h) {
      var d = this._getOffsetTransform();
      return this._createBaseSVGMarkup(this._toSVG(), { reviver: h, additionalTransform: d });
    }, complexity: function() {
      return this.path.length;
    }, _calcDimensions: function() {
      for (var h, d, p = [], m = [], y = 0, _ = 0, k = 0, T = 0, D = 0, j = this.path.length; D < j; ++D) {
        switch ((h = this.path[D])[0]) {
          case "L":
            k = h[1], T = h[2], d = [];
            break;
          case "M":
            y = k = h[1], _ = T = h[2], d = [];
            break;
          case "C":
            d = a.util.getBoundsOfCurve(k, T, h[1], h[2], h[3], h[4], h[5], h[6]), k = h[5], T = h[6];
            break;
          case "Q":
            d = a.util.getBoundsOfCurve(k, T, h[1], h[2], h[1], h[2], h[3], h[4]), k = h[3], T = h[4];
            break;
          case "z":
          case "Z":
            k = y, T = _;
        }
        d.forEach(function(L) {
          p.push(L.x), m.push(L.y);
        }), p.push(k), m.push(T);
      }
      var w = c(p) || 0, O = c(m) || 0;
      return { left: w, top: O, width: (f(p) || 0) - w, height: (f(m) || 0) - O };
    } }), a.Path.fromObject = function(h, d) {
      if (typeof h.sourcePath == "string") {
        var p = h.sourcePath;
        a.loadSVGFromURL(p, function(m) {
          var y = m[0];
          y.setOptions(h), d && d(y);
        });
      } else a.Object._fromObject("Path", h, d, "path");
    }, a.Path.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat(["d"]), a.Path.fromElement = function(h, d, p) {
      var m = a.parseAttributes(h, a.Path.ATTRIBUTE_NAMES);
      m.fromSVG = !0, d(new a.Path(m.d, i(m, p)));
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.array.min, f = a.util.array.max;
    a.Group || (a.Group = a.util.createClass(a.Object, a.Collection, { type: "group", strokeWidth: 0, subTargetCheck: !1, cacheProperties: [], useSetOnGroup: !1, initialize: function(i, r, s) {
      r = r || {}, this._objects = [], s && this.callSuper("initialize", r), this._objects = i || [];
      for (var h = this._objects.length; h--; ) this._objects[h].group = this;
      if (s) this._updateObjectsACoords();
      else {
        var d = r && r.centerPoint;
        r.originX !== void 0 && (this.originX = r.originX), r.originY !== void 0 && (this.originY = r.originY), d || this._calcBounds(), this._updateObjectsCoords(d), delete r.centerPoint, this.callSuper("initialize", r);
      }
      this.setCoords();
    }, _updateObjectsACoords: function() {
      for (var i = this._objects.length; i--; ) this._objects[i].setCoords(!0);
    }, _updateObjectsCoords: function(i) {
      i = i || this.getCenterPoint();
      for (var r = this._objects.length; r--; ) this._updateObjectCoords(this._objects[r], i);
    }, _updateObjectCoords: function(i, r) {
      var s = i.left, h = i.top;
      i.set({ left: s - r.x, top: h - r.y }), i.group = this, i.setCoords(!0);
    }, toString: function() {
      return "#<fabric.Group: (" + this.complexity() + ")>";
    }, addWithUpdate: function(i) {
      var r = !!this.group;
      return this._restoreObjectsState(), a.util.resetObjectTransform(this), i && (r && a.util.removeTransformFromObject(i, this.group.calcTransformMatrix()), this._objects.push(i), i.group = this, i._set("canvas", this.canvas)), this._calcBounds(), this._updateObjectsCoords(), this.dirty = !0, r ? this.group.addWithUpdate() : this.setCoords(), this;
    }, removeWithUpdate: function(i) {
      return this._restoreObjectsState(), a.util.resetObjectTransform(this), this.remove(i), this._calcBounds(), this._updateObjectsCoords(), this.setCoords(), this.dirty = !0, this;
    }, _onObjectAdded: function(i) {
      this.dirty = !0, i.group = this, i._set("canvas", this.canvas);
    }, _onObjectRemoved: function(i) {
      this.dirty = !0, delete i.group;
    }, _set: function(i, r) {
      var s = this._objects.length;
      if (this.useSetOnGroup) for (; s--; ) this._objects[s].setOnGroup(i, r);
      if (i === "canvas") for (; s--; ) this._objects[s]._set(i, r);
      a.Object.prototype._set.call(this, i, r);
    }, toObject: function(i) {
      var r = this.includeDefaultValues, s = this._objects.filter(function(d) {
        return !d.excludeFromExport;
      }).map(function(d) {
        var p = d.includeDefaultValues;
        d.includeDefaultValues = r;
        var m = d.toObject(i);
        return d.includeDefaultValues = p, m;
      }), h = a.Object.prototype.toObject.call(this, i);
      return h.objects = s, h;
    }, toDatalessObject: function(i) {
      var r, s = this.sourcePath;
      if (s) r = s;
      else {
        var h = this.includeDefaultValues;
        r = this._objects.map(function(p) {
          var m = p.includeDefaultValues;
          p.includeDefaultValues = h;
          var y = p.toDatalessObject(i);
          return p.includeDefaultValues = m, y;
        });
      }
      var d = a.Object.prototype.toDatalessObject.call(this, i);
      return d.objects = r, d;
    }, render: function(i) {
      this._transformDone = !0, this.callSuper("render", i), this._transformDone = !1;
    }, shouldCache: function() {
      var i = a.Object.prototype.shouldCache.call(this);
      if (i) {
        for (var r = 0, s = this._objects.length; r < s; r++) if (this._objects[r].willDrawShadow()) return this.ownCaching = !1, !1;
      }
      return i;
    }, willDrawShadow: function() {
      if (a.Object.prototype.willDrawShadow.call(this)) return !0;
      for (var i = 0, r = this._objects.length; i < r; i++) if (this._objects[i].willDrawShadow()) return !0;
      return !1;
    }, isOnACache: function() {
      return this.ownCaching || this.group && this.group.isOnACache();
    }, drawObject: function(i) {
      for (var r = 0, s = this._objects.length; r < s; r++) this._objects[r].render(i);
      this._drawClipPath(i);
    }, isCacheDirty: function(i) {
      if (this.callSuper("isCacheDirty", i)) return !0;
      if (!this.statefullCache) return !1;
      for (var r = 0, s = this._objects.length; r < s; r++) if (this._objects[r].isCacheDirty(!0)) {
        if (this._cacheCanvas) {
          var h = this.cacheWidth / this.zoomX, d = this.cacheHeight / this.zoomY;
          this._cacheContext.clearRect(-h / 2, -d / 2, h, d);
        }
        return !0;
      }
      return !1;
    }, _restoreObjectsState: function() {
      var i = this.calcOwnMatrix();
      return this._objects.forEach(function(r) {
        a.util.addTransformToObject(r, i), delete r.group, r.setCoords();
      }), this;
    }, realizeTransform: function(i, r) {
      return a.util.addTransformToObject(i, r), i;
    }, destroy: function() {
      return this._objects.forEach(function(i) {
        i.set("dirty", !0);
      }), this._restoreObjectsState();
    }, toActiveSelection: function() {
      if (this.canvas) {
        var i = this._objects, r = this.canvas;
        this._objects = [];
        var s = this.toObject();
        delete s.objects;
        var h = new a.ActiveSelection([]);
        return h.set(s), h.type = "activeSelection", r.remove(this), i.forEach(function(d) {
          d.group = h, d.dirty = !0, r.add(d);
        }), h.canvas = r, h._objects = i, r._activeObject = h, h.setCoords(), h;
      }
    }, ungroupOnCanvas: function() {
      return this._restoreObjectsState();
    }, setObjectsCoords: function() {
      return this.forEachObject(function(i) {
        i.setCoords(!0);
      }), this;
    }, _calcBounds: function(i) {
      for (var r, s, h, d, p = [], m = [], y = ["tr", "br", "bl", "tl"], _ = 0, k = this._objects.length, T = y.length; _ < k; ++_) {
        for (h = (r = this._objects[_]).calcACoords(), d = 0; d < T; d++) s = y[d], p.push(h[s].x), m.push(h[s].y);
        r.aCoords = h;
      }
      this._getBounds(p, m, i);
    }, _getBounds: function(i, r, s) {
      var h = new a.Point(c(i), c(r)), d = new a.Point(f(i), f(r)), p = h.y || 0, m = h.x || 0, y = d.x - h.x || 0, _ = d.y - h.y || 0;
      this.width = y, this.height = _, s || this.setPositionByOrigin({ x: m, y: p }, "left", "top");
    }, _toSVG: function(i) {
      for (var r = ["<g ", "COMMON_PARTS", ` >
`], s = 0, h = this._objects.length; s < h; s++) r.push("		", this._objects[s].toSVG(i));
      return r.push(`</g>
`), r;
    }, getSvgStyles: function() {
      var i = this.opacity !== void 0 && this.opacity !== 1 ? "opacity: " + this.opacity + ";" : "", r = this.visible ? "" : " visibility: hidden;";
      return [i, this.getSvgFilter(), r].join("");
    }, toClipPathSVG: function(i) {
      for (var r = [], s = 0, h = this._objects.length; s < h; s++) r.push("	", this._objects[s].toClipPathSVG(i));
      return this._createBaseClipPathSVGMarkup(r, { reviver: i });
    } }), a.Group.fromObject = function(i, r) {
      var s = i.objects, h = a.util.object.clone(i, !0);
      delete h.objects, typeof s != "string" ? a.util.enlivenObjects(s, function(d) {
        a.util.enlivenObjects([i.clipPath], function(p) {
          var m = a.util.object.clone(i, !0);
          m.clipPath = p[0], delete m.objects, r && r(new a.Group(d, m, !0));
        });
      }) : a.loadSVGFromURL(s, function(d) {
        var p = a.util.groupSVGElements(d, i, s);
        p.set(h), r && r(p);
      });
    });
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {});
    a.ActiveSelection || (a.ActiveSelection = a.util.createClass(a.Group, { type: "activeSelection", initialize: function(c, f) {
      f = f || {}, this._objects = c || [];
      for (var i = this._objects.length; i--; ) this._objects[i].group = this;
      f.originX && (this.originX = f.originX), f.originY && (this.originY = f.originY), this._calcBounds(), this._updateObjectsCoords(), a.Object.prototype.initialize.call(this, f), this.setCoords();
    }, toGroup: function() {
      var c = this._objects.concat();
      this._objects = [];
      var f = a.Object.prototype.toObject.call(this), i = new a.Group([]);
      if (delete f.type, i.set(f), c.forEach(function(s) {
        s.canvas.remove(s), s.group = i;
      }), i._objects = c, !this.canvas) return i;
      var r = this.canvas;
      return r.add(i), r._activeObject = i, i.setCoords(), i;
    }, onDeselect: function() {
      return this.destroy(), !1;
    }, toString: function() {
      return "#<fabric.ActiveSelection: (" + this.complexity() + ")>";
    }, shouldCache: function() {
      return !1;
    }, isOnACache: function() {
      return !1;
    }, _renderControls: function(c, f, i) {
      c.save(), c.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1, this.callSuper("_renderControls", c, f), (i = i || {}).hasControls === void 0 && (i.hasControls = !1), i.forActiveSelection = !0;
      for (var r = 0, s = this._objects.length; r < s; r++) this._objects[r]._renderControls(c, i);
      c.restore();
    } }), a.ActiveSelection.fromObject = function(c, f) {
      a.util.enlivenObjects(c.objects, function(i) {
        delete c.objects, f && f(new a.ActiveSelection(i, c, !0));
      });
    });
  }(t), function(l) {
    var a = b.util.object.extend;
    l.fabric || (l.fabric = {}), l.fabric.Image ? b.warn("fabric.Image is already defined.") : (b.Image = b.util.createClass(b.Object, { type: "image", strokeWidth: 0, srcFromAttribute: !1, _lastScaleX: 1, _lastScaleY: 1, _filterScalingX: 1, _filterScalingY: 1, minimumScaleTrigger: 0.5, stateProperties: b.Object.prototype.stateProperties.concat("cropX", "cropY"), cacheProperties: b.Object.prototype.cacheProperties.concat("cropX", "cropY"), cacheKey: "", cropX: 0, cropY: 0, imageSmoothing: !0, initialize: function(c, f) {
      f || (f = {}), this.filters = [], this.cacheKey = "texture" + b.Object.__uid++, this.callSuper("initialize", f), this._initElement(c, f);
    }, getElement: function() {
      return this._element || {};
    }, setElement: function(c, f) {
      return this.removeTexture(this.cacheKey), this.removeTexture(this.cacheKey + "_filtered"), this._element = c, this._originalElement = c, this._initConfig(f), this.filters.length !== 0 && this.applyFilters(), this.resizeFilter && this.applyResizeFilters(), this;
    }, removeTexture: function(c) {
      var f = b.filterBackend;
      f && f.evictCachesForKey && f.evictCachesForKey(c);
    }, dispose: function() {
      this.removeTexture(this.cacheKey), this.removeTexture(this.cacheKey + "_filtered"), this._cacheContext = void 0, ["_originalElement", "_element", "_filteredEl", "_cacheCanvas"].forEach((function(c) {
        b.util.cleanUpJsdomNode(this[c]), this[c] = void 0;
      }).bind(this));
    }, getCrossOrigin: function() {
      return this._originalElement && (this._originalElement.crossOrigin || null);
    }, getOriginalSize: function() {
      var c = this.getElement();
      return { width: c.naturalWidth || c.width, height: c.naturalHeight || c.height };
    }, _stroke: function(c) {
      if (this.stroke && this.strokeWidth !== 0) {
        var f = this.width / 2, i = this.height / 2;
        c.beginPath(), c.moveTo(-f, -i), c.lineTo(f, -i), c.lineTo(f, i), c.lineTo(-f, i), c.lineTo(-f, -i), c.closePath();
      }
    }, toObject: function(c) {
      var f = [];
      this.filters.forEach(function(r) {
        r && f.push(r.toObject());
      });
      var i = a(this.callSuper("toObject", ["cropX", "cropY"].concat(c)), { src: this.getSrc(), crossOrigin: this.getCrossOrigin(), filters: f });
      return this.resizeFilter && (i.resizeFilter = this.resizeFilter.toObject()), i;
    }, hasCrop: function() {
      return this.cropX || this.cropY || this.width < this._element.width || this.height < this._element.height;
    }, _toSVG: function() {
      var c, f = [], i = [], r = this._element, s = -this.width / 2, h = -this.height / 2, d = "", p = "";
      if (!r) return [];
      if (this.hasCrop()) {
        var m = b.Object.__uid++;
        f.push('<clipPath id="imageCrop_' + m + `">
`, '	<rect x="' + s + '" y="' + h + '" width="' + this.width + '" height="' + this.height + `" />
`, `</clipPath>
`), d = ' clip-path="url(#imageCrop_' + m + ')" ';
      }
      if (this.imageSmoothing || (p = '" image-rendering="optimizeSpeed'), i.push("	<image ", "COMMON_PARTS", 'xlink:href="', this.getSvgSrc(!0), '" x="', s - this.cropX, '" y="', h - this.cropY, '" width="', r.width || r.naturalWidth, '" height="', r.height || r.height, p, '"', d, `></image>
`), this.stroke || this.strokeDashArray) {
        var y = this.fill;
        this.fill = null, c = ["	<rect ", 'x="', s, '" y="', h, '" width="', this.width, '" height="', this.height, '" style="', this.getSvgStyles(), `"/>
`], this.fill = y;
      }
      return f = this.paintFirst !== "fill" ? f.concat(c, i) : f.concat(i, c);
    }, getSrc: function(c) {
      var f = c ? this._element : this._originalElement;
      return f ? f.toDataURL ? f.toDataURL() : this.srcFromAttribute ? f.getAttribute("src") : f.src : this.src || "";
    }, setSrc: function(c, f, i) {
      return b.util.loadImage(c, function(r, s) {
        this.setElement(r, i), this._setWidthHeight(), f && f(this, s);
      }, this, i && i.crossOrigin), this;
    }, toString: function() {
      return '#<fabric.Image: { src: "' + this.getSrc() + '" }>';
    }, applyResizeFilters: function() {
      var c = this.resizeFilter, f = this.minimumScaleTrigger, i = this.getTotalObjectScaling(), r = i.scaleX, s = i.scaleY, h = this._filteredEl || this._originalElement;
      if (this.group && this.set("dirty", !0), !c || r > f && s > f) return this._element = h, this._filterScalingX = 1, this._filterScalingY = 1, this._lastScaleX = r, void (this._lastScaleY = s);
      b.filterBackend || (b.filterBackend = b.initFilterBackend());
      var d = b.util.createCanvasElement(), p = this._filteredEl ? this.cacheKey + "_filtered" : this.cacheKey, m = h.width, y = h.height;
      d.width = m, d.height = y, this._element = d, this._lastScaleX = c.scaleX = r, this._lastScaleY = c.scaleY = s, b.filterBackend.applyFilters([c], h, m, y, this._element, p), this._filterScalingX = d.width / this._originalElement.width, this._filterScalingY = d.height / this._originalElement.height;
    }, applyFilters: function(c) {
      if (c = (c = c || this.filters || []).filter(function(h) {
        return h && !h.isNeutralState();
      }), this.set("dirty", !0), this.removeTexture(this.cacheKey + "_filtered"), c.length === 0) return this._element = this._originalElement, this._filteredEl = null, this._filterScalingX = 1, this._filterScalingY = 1, this;
      var f = this._originalElement, i = f.naturalWidth || f.width, r = f.naturalHeight || f.height;
      if (this._element === this._originalElement) {
        var s = b.util.createCanvasElement();
        s.width = i, s.height = r, this._element = s, this._filteredEl = s;
      } else this._element = this._filteredEl, this._filteredEl.getContext("2d").clearRect(0, 0, i, r), this._lastScaleX = 1, this._lastScaleY = 1;
      return b.filterBackend || (b.filterBackend = b.initFilterBackend()), b.filterBackend.applyFilters(c, this._originalElement, i, r, this._element, this.cacheKey), this._originalElement.width === this._element.width && this._originalElement.height === this._element.height || (this._filterScalingX = this._element.width / this._originalElement.width, this._filterScalingY = this._element.height / this._originalElement.height), this;
    }, _render: function(c) {
      b.util.setImageSmoothing(c, this.imageSmoothing), this.isMoving !== !0 && this.resizeFilter && this._needsResize() && this.applyResizeFilters(), this._stroke(c), this._renderPaintInOrder(c);
    }, drawCacheOnCanvas: function(c) {
      b.util.setImageSmoothing(c, this.imageSmoothing), b.Object.prototype.drawCacheOnCanvas.call(this, c);
    }, shouldCache: function() {
      return this.needsItsOwnCache();
    }, _renderFill: function(c) {
      var f = this._element;
      if (f) {
        var i = this._filterScalingX, r = this._filterScalingY, s = this.width, h = this.height, d = Math.min, p = Math.max, m = p(this.cropX, 0), y = p(this.cropY, 0), _ = f.naturalWidth || f.width, k = f.naturalHeight || f.height, T = m * i, D = y * r, j = d(s * i, _ - T), w = d(h * r, k - D), O = -s / 2, L = -h / 2, U = d(s, _ / i - m), W = d(h, k / r - y);
        f && c.drawImage(f, T, D, j, w, O, L, U, W);
      }
    }, _needsResize: function() {
      var c = this.getTotalObjectScaling();
      return c.scaleX !== this._lastScaleX || c.scaleY !== this._lastScaleY;
    }, _resetWidthHeight: function() {
      this.set(this.getOriginalSize());
    }, _initElement: function(c, f) {
      this.setElement(b.util.getById(c), f), b.util.addClass(this.getElement(), b.Image.CSS_CANVAS);
    }, _initConfig: function(c) {
      c || (c = {}), this.setOptions(c), this._setWidthHeight(c);
    }, _initFilters: function(c, f) {
      c && c.length ? b.util.enlivenObjects(c, function(i) {
        f && f(i);
      }, "fabric.Image.filters") : f && f();
    }, _setWidthHeight: function(c) {
      c || (c = {});
      var f = this.getElement();
      this.width = c.width || f.naturalWidth || f.width || 0, this.height = c.height || f.naturalHeight || f.height || 0;
    }, parsePreserveAspectRatioAttribute: function() {
      var c, f = b.util.parsePreserveAspectRatioAttribute(this.preserveAspectRatio || ""), i = this._element.width, r = this._element.height, s = 1, h = 1, d = 0, p = 0, m = 0, y = 0, _ = this.width, k = this.height, T = { width: _, height: k };
      return !f || f.alignX === "none" && f.alignY === "none" ? (s = _ / i, h = k / r) : (f.meetOrSlice === "meet" && (c = (_ - i * (s = h = b.util.findScaleToFit(this._element, T))) / 2, f.alignX === "Min" && (d = -c), f.alignX === "Max" && (d = c), c = (k - r * h) / 2, f.alignY === "Min" && (p = -c), f.alignY === "Max" && (p = c)), f.meetOrSlice === "slice" && (c = i - _ / (s = h = b.util.findScaleToCover(this._element, T)), f.alignX === "Mid" && (m = c / 2), f.alignX === "Max" && (m = c), c = r - k / h, f.alignY === "Mid" && (y = c / 2), f.alignY === "Max" && (y = c), i = _ / s, r = k / h)), { width: i, height: r, scaleX: s, scaleY: h, offsetLeft: d, offsetTop: p, cropX: m, cropY: y };
    } }), b.Image.CSS_CANVAS = "canvas-img", b.Image.prototype.getSvgSrc = b.Image.prototype.getSrc, b.Image.fromObject = function(c, f) {
      var i = b.util.object.clone(c);
      b.util.loadImage(i.src, function(r, s) {
        s ? f && f(null, !0) : b.Image.prototype._initFilters.call(i, i.filters, function(h) {
          i.filters = h || [], b.Image.prototype._initFilters.call(i, [i.resizeFilter], function(d) {
            i.resizeFilter = d[0], b.util.enlivenObjects([i.clipPath], function(p) {
              i.clipPath = p[0];
              var m = new b.Image(r, i);
              f(m, !1);
            });
          });
        });
      }, null, i.crossOrigin);
    }, b.Image.fromURL = function(c, f, i) {
      b.util.loadImage(c, function(r, s) {
        f && f(new b.Image(r, i), s);
      }, null, i && i.crossOrigin);
    }, b.Image.ATTRIBUTE_NAMES = b.SHARED_ATTRIBUTES.concat("x y width height preserveAspectRatio xlink:href crossOrigin image-rendering".split(" ")), b.Image.fromElement = function(c, f, i) {
      var r = b.parseAttributes(c, b.Image.ATTRIBUTE_NAMES);
      b.Image.fromURL(r["xlink:href"], f, a(i ? b.util.object.clone(i) : {}, r));
    });
  }(t), b.util.object.extend(b.Object.prototype, { _getAngleValueForStraighten: function() {
    var l = this.angle % 360;
    return l > 0 ? 90 * Math.round((l - 1) / 90) : 90 * Math.round(l / 90);
  }, straighten: function() {
    return this.rotate(this._getAngleValueForStraighten()), this;
  }, fxStraighten: function(l) {
    var a = function() {
    }, c = (l = l || {}).onComplete || a, f = l.onChange || a, i = this;
    return b.util.animate({ startValue: this.get("angle"), endValue: this._getAngleValueForStraighten(), duration: this.FX_DURATION, onChange: function(r) {
      i.rotate(r), f();
    }, onComplete: function() {
      i.setCoords(), c();
    } }), this;
  } }), b.util.object.extend(b.StaticCanvas.prototype, { straightenObject: function(l) {
    return l.straighten(), this.requestRenderAll(), this;
  }, fxStraightenObject: function(l) {
    return l.fxStraighten({ onChange: this.requestRenderAllBound }), this;
  } }), function() {
    function l(c, f) {
      var i = "precision " + f + ` float;
void main(){}`, r = c.createShader(c.FRAGMENT_SHADER);
      return c.shaderSource(r, i), c.compileShader(r), !!c.getShaderParameter(r, c.COMPILE_STATUS);
    }
    function a(c) {
      c && c.tileSize && (this.tileSize = c.tileSize), this.setupGLContext(this.tileSize, this.tileSize), this.captureGPUInfo();
    }
    b.isWebglSupported = function(c) {
      if (b.isLikelyNode) return !1;
      c = c || b.WebglFilterBackend.prototype.tileSize;
      var f = document.createElement("canvas"), i = f.getContext("webgl") || f.getContext("experimental-webgl"), r = !1;
      if (i) {
        b.maxTextureSize = i.getParameter(i.MAX_TEXTURE_SIZE), r = b.maxTextureSize >= c;
        for (var s = ["highp", "mediump", "lowp"], h = 0; h < 3; h++) if (l(i, s[h])) {
          b.webGlPrecision = s[h];
          break;
        }
      }
      return this.isSupported = r, r;
    }, b.WebglFilterBackend = a, a.prototype = { tileSize: 2048, resources: {}, setupGLContext: function(c, f) {
      this.dispose(), this.createWebGLCanvas(c, f), this.aPosition = new Float32Array([0, 0, 0, 1, 1, 0, 1, 1]), this.chooseFastestCopyGLTo2DMethod(c, f);
    }, chooseFastestCopyGLTo2DMethod: function(c, f) {
      var i, r = window.performance !== void 0;
      try {
        new ImageData(1, 1), i = !0;
      } catch {
        i = !1;
      }
      var s = typeof ArrayBuffer < "u", h = typeof Uint8ClampedArray < "u";
      if (r && i && s && h) {
        var d = b.util.createCanvasElement(), p = new ArrayBuffer(c * f * 4);
        if (b.forceGLPutImageData) return this.imageBuffer = p, void (this.copyGLTo2D = ht);
        var m, y, _ = { imageBuffer: p, destinationWidth: c, destinationHeight: f, targetCanvas: d };
        d.width = c, d.height = f, m = window.performance.now(), bt.call(_, this.gl, _), y = window.performance.now() - m, m = window.performance.now(), ht.call(_, this.gl, _), y > window.performance.now() - m ? (this.imageBuffer = p, this.copyGLTo2D = ht) : this.copyGLTo2D = bt;
      }
    }, createWebGLCanvas: function(c, f) {
      var i = b.util.createCanvasElement();
      i.width = c, i.height = f;
      var r = { alpha: !0, premultipliedAlpha: !1, depth: !1, stencil: !1, antialias: !1 }, s = i.getContext("webgl", r);
      s || (s = i.getContext("experimental-webgl", r)), s && (s.clearColor(0, 0, 0, 0), this.canvas = i, this.gl = s);
    }, applyFilters: function(c, f, i, r, s, h) {
      var d, p = this.gl;
      h && (d = this.getCachedTexture(h, f));
      var m = { originalWidth: f.width || f.originalWidth, originalHeight: f.height || f.originalHeight, sourceWidth: i, sourceHeight: r, destinationWidth: i, destinationHeight: r, context: p, sourceTexture: this.createTexture(p, i, r, !d && f), targetTexture: this.createTexture(p, i, r), originalTexture: d || this.createTexture(p, i, r, !d && f), passes: c.length, webgl: !0, aPosition: this.aPosition, programCache: this.programCache, pass: 0, filterBackend: this, targetCanvas: s }, y = p.createFramebuffer();
      return p.bindFramebuffer(p.FRAMEBUFFER, y), c.forEach(function(_) {
        _ && _.applyTo(m);
      }), function(_) {
        var k = _.targetCanvas, T = k.width, D = k.height, j = _.destinationWidth, w = _.destinationHeight;
        T === j && D === w || (k.width = j, k.height = w);
      }(m), this.copyGLTo2D(p, m), p.bindTexture(p.TEXTURE_2D, null), p.deleteTexture(m.sourceTexture), p.deleteTexture(m.targetTexture), p.deleteFramebuffer(y), s.getContext("2d").setTransform(1, 0, 0, 1, 0, 0), m;
    }, dispose: function() {
      this.canvas && (this.canvas = null, this.gl = null), this.clearWebGLCaches();
    }, clearWebGLCaches: function() {
      this.programCache = {}, this.textureCache = {};
    }, createTexture: function(c, f, i, r) {
      var s = c.createTexture();
      return c.bindTexture(c.TEXTURE_2D, s), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MAG_FILTER, c.NEAREST), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MIN_FILTER, c.NEAREST), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_S, c.CLAMP_TO_EDGE), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_T, c.CLAMP_TO_EDGE), r ? c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, c.RGBA, c.UNSIGNED_BYTE, r) : c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, f, i, 0, c.RGBA, c.UNSIGNED_BYTE, null), s;
    }, getCachedTexture: function(c, f) {
      if (this.textureCache[c]) return this.textureCache[c];
      var i = this.createTexture(this.gl, f.width, f.height, f);
      return this.textureCache[c] = i, i;
    }, evictCachesForKey: function(c) {
      this.textureCache[c] && (this.gl.deleteTexture(this.textureCache[c]), delete this.textureCache[c]);
    }, copyGLTo2D: bt, captureGPUInfo: function() {
      if (this.gpuInfo) return this.gpuInfo;
      var c = this.gl, f = { renderer: "", vendor: "" };
      if (!c) return f;
      var i = c.getExtension("WEBGL_debug_renderer_info");
      if (i) {
        var r = c.getParameter(i.UNMASKED_RENDERER_WEBGL), s = c.getParameter(i.UNMASKED_VENDOR_WEBGL);
        r && (f.renderer = r.toLowerCase()), s && (f.vendor = s.toLowerCase());
      }
      return this.gpuInfo = f, f;
    } };
  }(), function() {
    var l = function() {
    };
    function a() {
    }
    b.Canvas2dFilterBackend = a, a.prototype = { evictCachesForKey: l, dispose: l, clearWebGLCaches: l, resources: {}, applyFilters: function(c, f, i, r, s) {
      var h = s.getContext("2d");
      h.drawImage(f, 0, 0, i, r);
      var d = { sourceWidth: i, sourceHeight: r, imageData: h.getImageData(0, 0, i, r), originalEl: f, originalImageData: h.getImageData(0, 0, i, r), canvasEl: s, ctx: h, filterBackend: this };
      return c.forEach(function(p) {
        p.applyTo(d);
      }), d.imageData.width === i && d.imageData.height === r || (s.width = d.imageData.width, s.height = d.imageData.height), h.putImageData(d.imageData, 0, 0), d;
    } };
  }(), b.Image = b.Image || {}, b.Image.filters = b.Image.filters || {}, b.Image.filters.BaseFilter = b.util.createClass({ type: "BaseFilter", vertexSource: `attribute vec2 aPosition;
varying vec2 vTexCoord;
void main() {
vTexCoord = aPosition;
gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
}`, fragmentSource: `precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexture;
void main() {
gl_FragColor = texture2D(uTexture, vTexCoord);
}`, initialize: function(l) {
    l && this.setOptions(l);
  }, setOptions: function(l) {
    for (var a in l) this[a] = l[a];
  }, createProgram: function(l, a, c) {
    a = a || this.fragmentSource, c = c || this.vertexSource, b.webGlPrecision !== "highp" && (a = a.replace(/precision highp float/g, "precision " + b.webGlPrecision + " float"));
    var f = l.createShader(l.VERTEX_SHADER);
    if (l.shaderSource(f, c), l.compileShader(f), !l.getShaderParameter(f, l.COMPILE_STATUS)) throw new Error("Vertex shader compile error for " + this.type + ": " + l.getShaderInfoLog(f));
    var i = l.createShader(l.FRAGMENT_SHADER);
    if (l.shaderSource(i, a), l.compileShader(i), !l.getShaderParameter(i, l.COMPILE_STATUS)) throw new Error("Fragment shader compile error for " + this.type + ": " + l.getShaderInfoLog(i));
    var r = l.createProgram();
    if (l.attachShader(r, f), l.attachShader(r, i), l.linkProgram(r), !l.getProgramParameter(r, l.LINK_STATUS)) throw new Error('Shader link error for "${this.type}" ' + l.getProgramInfoLog(r));
    var s = this.getAttributeLocations(l, r), h = this.getUniformLocations(l, r) || {};
    return h.uStepW = l.getUniformLocation(r, "uStepW"), h.uStepH = l.getUniformLocation(r, "uStepH"), { program: r, attributeLocations: s, uniformLocations: h };
  }, getAttributeLocations: function(l, a) {
    return { aPosition: l.getAttribLocation(a, "aPosition") };
  }, getUniformLocations: function() {
    return {};
  }, sendAttributeData: function(l, a, c) {
    var f = a.aPosition, i = l.createBuffer();
    l.bindBuffer(l.ARRAY_BUFFER, i), l.enableVertexAttribArray(f), l.vertexAttribPointer(f, 2, l.FLOAT, !1, 0, 0), l.bufferData(l.ARRAY_BUFFER, c, l.STATIC_DRAW);
  }, _setupFrameBuffer: function(l) {
    var a, c, f = l.context;
    l.passes > 1 ? (a = l.destinationWidth, c = l.destinationHeight, l.sourceWidth === a && l.sourceHeight === c || (f.deleteTexture(l.targetTexture), l.targetTexture = l.filterBackend.createTexture(f, a, c)), f.framebufferTexture2D(f.FRAMEBUFFER, f.COLOR_ATTACHMENT0, f.TEXTURE_2D, l.targetTexture, 0)) : (f.bindFramebuffer(f.FRAMEBUFFER, null), f.finish());
  }, _swapTextures: function(l) {
    l.passes--, l.pass++;
    var a = l.targetTexture;
    l.targetTexture = l.sourceTexture, l.sourceTexture = a;
  }, isNeutralState: function() {
    var l = this.mainParameter, a = b.Image.filters[this.type].prototype;
    if (l) {
      if (Array.isArray(a[l])) {
        for (var c = a[l].length; c--; ) if (this[l][c] !== a[l][c]) return !1;
        return !0;
      }
      return a[l] === this[l];
    }
    return !1;
  }, applyTo: function(l) {
    l.webgl ? (this._setupFrameBuffer(l), this.applyToWebGL(l), this._swapTextures(l)) : this.applyTo2d(l);
  }, retrieveShader: function(l) {
    return l.programCache.hasOwnProperty(this.type) || (l.programCache[this.type] = this.createProgram(l.context)), l.programCache[this.type];
  }, applyToWebGL: function(l) {
    var a = l.context, c = this.retrieveShader(l);
    l.pass === 0 && l.originalTexture ? a.bindTexture(a.TEXTURE_2D, l.originalTexture) : a.bindTexture(a.TEXTURE_2D, l.sourceTexture), a.useProgram(c.program), this.sendAttributeData(a, c.attributeLocations, l.aPosition), a.uniform1f(c.uniformLocations.uStepW, 1 / l.sourceWidth), a.uniform1f(c.uniformLocations.uStepH, 1 / l.sourceHeight), this.sendUniformData(a, c.uniformLocations), a.viewport(0, 0, l.destinationWidth, l.destinationHeight), a.drawArrays(a.TRIANGLE_STRIP, 0, 4);
  }, bindAdditionalTexture: function(l, a, c) {
    l.activeTexture(c), l.bindTexture(l.TEXTURE_2D, a), l.activeTexture(l.TEXTURE0);
  }, unbindAdditionalTexture: function(l, a) {
    l.activeTexture(a), l.bindTexture(l.TEXTURE_2D, null), l.activeTexture(l.TEXTURE0);
  }, getMainParameter: function() {
    return this[this.mainParameter];
  }, setMainParameter: function(l) {
    this[this.mainParameter] = l;
  }, sendUniformData: function() {
  }, createHelpLayer: function(l) {
    if (!l.helpLayer) {
      var a = document.createElement("canvas");
      a.width = l.sourceWidth, a.height = l.sourceHeight, l.helpLayer = a;
    }
  }, toObject: function() {
    var l = { type: this.type }, a = this.mainParameter;
    return a && (l[a] = this[a]), l;
  }, toJSON: function() {
    return this.toObject();
  } }), b.Image.filters.BaseFilter.fromObject = function(l, a) {
    var c = new b.Image.filters[l.type](l);
    return a && a(c), c;
  }, function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.ColorMatrix = f(c.BaseFilter, { type: "ColorMatrix", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
uniform mat4 uColorMatrix;
uniform vec4 uConstants;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color *= uColorMatrix;
color += uConstants;
gl_FragColor = color;
}`, matrix: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0], mainParameter: "matrix", colorsOnly: !0, initialize: function(i) {
      this.callSuper("initialize", i), this.matrix = this.matrix.slice(0);
    }, applyTo2d: function(i) {
      var r, s, h, d, p, m = i.imageData.data, y = m.length, _ = this.matrix, k = this.colorsOnly;
      for (p = 0; p < y; p += 4) r = m[p], s = m[p + 1], h = m[p + 2], k ? (m[p] = r * _[0] + s * _[1] + h * _[2] + 255 * _[4], m[p + 1] = r * _[5] + s * _[6] + h * _[7] + 255 * _[9], m[p + 2] = r * _[10] + s * _[11] + h * _[12] + 255 * _[14]) : (d = m[p + 3], m[p] = r * _[0] + s * _[1] + h * _[2] + d * _[3] + 255 * _[4], m[p + 1] = r * _[5] + s * _[6] + h * _[7] + d * _[8] + 255 * _[9], m[p + 2] = r * _[10] + s * _[11] + h * _[12] + d * _[13] + 255 * _[14], m[p + 3] = r * _[15] + s * _[16] + h * _[17] + d * _[18] + 255 * _[19]);
    }, getUniformLocations: function(i, r) {
      return { uColorMatrix: i.getUniformLocation(r, "uColorMatrix"), uConstants: i.getUniformLocation(r, "uConstants") };
    }, sendUniformData: function(i, r) {
      var s = this.matrix, h = [s[0], s[1], s[2], s[3], s[5], s[6], s[7], s[8], s[10], s[11], s[12], s[13], s[15], s[16], s[17], s[18]], d = [s[4], s[9], s[14], s[19]];
      i.uniformMatrix4fv(r.uColorMatrix, !1, h), i.uniform4fv(r.uConstants, d);
    } }), a.Image.filters.ColorMatrix.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Brightness = f(c.BaseFilter, { type: "Brightness", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uBrightness;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color.rgb += uBrightness;
gl_FragColor = color;
}`, brightness: 0, mainParameter: "brightness", applyTo2d: function(i) {
      if (this.brightness !== 0) {
        var r, s = i.imageData.data, h = s.length, d = Math.round(255 * this.brightness);
        for (r = 0; r < h; r += 4) s[r] = s[r] + d, s[r + 1] = s[r + 1] + d, s[r + 2] = s[r + 2] + d;
      }
    }, getUniformLocations: function(i, r) {
      return { uBrightness: i.getUniformLocation(r, "uBrightness") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uBrightness, this.brightness);
    } }), a.Image.filters.Brightness.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.Image.filters, i = a.util.createClass;
    f.Convolute = i(f.BaseFilter, { type: "Convolute", opaque: !1, matrix: [0, 0, 0, 0, 1, 0, 0, 0, 0], fragmentSource: { Convolute_3_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[9];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 3.0; h+=1.0) {
for (float w = 0.0; w < 3.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 1), uStepH * (h - 1));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 3.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_3_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[9];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 3.0; h+=1.0) {
for (float w = 0.0; w < 3.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 1.0), uStepH * (h - 1.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 3.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_5_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[25];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 5.0; h+=1.0) {
for (float w = 0.0; w < 5.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 5.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_5_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[25];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 5.0; h+=1.0) {
for (float w = 0.0; w < 5.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 5.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_7_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[49];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 7.0; h+=1.0) {
for (float w = 0.0; w < 7.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 7.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_7_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[49];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 7.0; h+=1.0) {
for (float w = 0.0; w < 7.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 7.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_9_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[81];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 9.0; h+=1.0) {
for (float w = 0.0; w < 9.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 9.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_9_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[81];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 9.0; h+=1.0) {
for (float w = 0.0; w < 9.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 9.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}` }, retrieveShader: function(r) {
      var s = Math.sqrt(this.matrix.length), h = this.type + "_" + s + "_" + (this.opaque ? 1 : 0), d = this.fragmentSource[h];
      return r.programCache.hasOwnProperty(h) || (r.programCache[h] = this.createProgram(r.context, d)), r.programCache[h];
    }, applyTo2d: function(r) {
      var s, h, d, p, m, y, _, k, T, D, j, w, O, L = r.imageData, U = L.data, W = this.matrix, I = Math.round(Math.sqrt(W.length)), M = Math.floor(I / 2), B = L.width, Z = L.height, J = r.ctx.createImageData(B, Z), G = J.data, F = this.opaque ? 1 : 0;
      for (j = 0; j < Z; j++) for (D = 0; D < B; D++) {
        for (m = 4 * (j * B + D), s = 0, h = 0, d = 0, p = 0, O = 0; O < I; O++) for (w = 0; w < I; w++) y = D + w - M, (_ = j + O - M) < 0 || _ >= Z || y < 0 || y >= B || (k = 4 * (_ * B + y), T = W[O * I + w], s += U[k] * T, h += U[k + 1] * T, d += U[k + 2] * T, F || (p += U[k + 3] * T));
        G[m] = s, G[m + 1] = h, G[m + 2] = d, G[m + 3] = F ? U[m + 3] : p;
      }
      r.imageData = J;
    }, getUniformLocations: function(r, s) {
      return { uMatrix: r.getUniformLocation(s, "uMatrix"), uOpaque: r.getUniformLocation(s, "uOpaque"), uHalfSize: r.getUniformLocation(s, "uHalfSize"), uSize: r.getUniformLocation(s, "uSize") };
    }, sendUniformData: function(r, s) {
      r.uniform1fv(s.uMatrix, this.matrix);
    }, toObject: function() {
      return c(this.callSuper("toObject"), { opaque: this.opaque, matrix: this.matrix });
    } }), a.Image.filters.Convolute.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Grayscale = f(c.BaseFilter, { type: "Grayscale", fragmentSource: { average: `precision highp float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float average = (color.r + color.b + color.g) / 3.0;
gl_FragColor = vec4(average, average, average, color.a);
}`, lightness: `precision highp float;
uniform sampler2D uTexture;
uniform int uMode;
varying vec2 vTexCoord;
void main() {
vec4 col = texture2D(uTexture, vTexCoord);
float average = (max(max(col.r, col.g),col.b) + min(min(col.r, col.g),col.b)) / 2.0;
gl_FragColor = vec4(average, average, average, col.a);
}`, luminosity: `precision highp float;
uniform sampler2D uTexture;
uniform int uMode;
varying vec2 vTexCoord;
void main() {
vec4 col = texture2D(uTexture, vTexCoord);
float average = 0.21 * col.r + 0.72 * col.g + 0.07 * col.b;
gl_FragColor = vec4(average, average, average, col.a);
}` }, mode: "average", mainParameter: "mode", applyTo2d: function(i) {
      var r, s, h = i.imageData.data, d = h.length, p = this.mode;
      for (r = 0; r < d; r += 4) p === "average" ? s = (h[r] + h[r + 1] + h[r + 2]) / 3 : p === "lightness" ? s = (Math.min(h[r], h[r + 1], h[r + 2]) + Math.max(h[r], h[r + 1], h[r + 2])) / 2 : p === "luminosity" && (s = 0.21 * h[r] + 0.72 * h[r + 1] + 0.07 * h[r + 2]), h[r] = s, h[r + 1] = s, h[r + 2] = s;
    }, retrieveShader: function(i) {
      var r = this.type + "_" + this.mode;
      if (!i.programCache.hasOwnProperty(r)) {
        var s = this.fragmentSource[this.mode];
        i.programCache[r] = this.createProgram(i.context, s);
      }
      return i.programCache[r];
    }, getUniformLocations: function(i, r) {
      return { uMode: i.getUniformLocation(r, "uMode") };
    }, sendUniformData: function(i, r) {
      i.uniform1i(r.uMode, 1);
    }, isNeutralState: function() {
      return !1;
    } }), a.Image.filters.Grayscale.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Invert = f(c.BaseFilter, { type: "Invert", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform int uInvert;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
if (uInvert == 1) {
gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,color.a);
} else {
gl_FragColor = color;
}
}`, invert: !0, mainParameter: "invert", applyTo2d: function(i) {
      var r, s = i.imageData.data, h = s.length;
      for (r = 0; r < h; r += 4) s[r] = 255 - s[r], s[r + 1] = 255 - s[r + 1], s[r + 2] = 255 - s[r + 2];
    }, isNeutralState: function() {
      return !this.invert;
    }, getUniformLocations: function(i, r) {
      return { uInvert: i.getUniformLocation(r, "uInvert") };
    }, sendUniformData: function(i, r) {
      i.uniform1i(r.uInvert, this.invert);
    } }), a.Image.filters.Invert.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.Image.filters, i = a.util.createClass;
    f.Noise = i(f.BaseFilter, { type: "Noise", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uStepH;
uniform float uNoise;
uniform float uSeed;
varying vec2 vTexCoord;
float rand(vec2 co, float seed, float vScale) {
return fract(sin(dot(co.xy * vScale ,vec2(12.9898 , 78.233))) * 43758.5453 * (seed + 0.01) / 2.0);
}
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color.rgb += (0.5 - rand(vTexCoord, uSeed, 0.1 / uStepH)) * uNoise;
gl_FragColor = color;
}`, mainParameter: "noise", noise: 0, applyTo2d: function(r) {
      if (this.noise !== 0) {
        var s, h, d = r.imageData.data, p = d.length, m = this.noise;
        for (s = 0, p = d.length; s < p; s += 4) h = (0.5 - Math.random()) * m, d[s] += h, d[s + 1] += h, d[s + 2] += h;
      }
    }, getUniformLocations: function(r, s) {
      return { uNoise: r.getUniformLocation(s, "uNoise"), uSeed: r.getUniformLocation(s, "uSeed") };
    }, sendUniformData: function(r, s) {
      r.uniform1f(s.uNoise, this.noise / 255), r.uniform1f(s.uSeed, Math.random());
    }, toObject: function() {
      return c(this.callSuper("toObject"), { noise: this.noise });
    } }), a.Image.filters.Noise.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Pixelate = f(c.BaseFilter, { type: "Pixelate", blocksize: 4, mainParameter: "blocksize", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uBlocksize;
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
float blockW = uBlocksize * uStepW;
float blockH = uBlocksize * uStepW;
int posX = int(vTexCoord.x / blockW);
int posY = int(vTexCoord.y / blockH);
float fposX = float(posX);
float fposY = float(posY);
vec2 squareCoords = vec2(fposX * blockW, fposY * blockH);
vec4 color = texture2D(uTexture, squareCoords);
gl_FragColor = color;
}`, applyTo2d: function(i) {
      var r, s, h, d, p, m, y, _, k, T, D, j = i.imageData, w = j.data, O = j.height, L = j.width;
      for (s = 0; s < O; s += this.blocksize) for (h = 0; h < L; h += this.blocksize) for (d = w[r = 4 * s * L + 4 * h], p = w[r + 1], m = w[r + 2], y = w[r + 3], T = Math.min(s + this.blocksize, O), D = Math.min(h + this.blocksize, L), _ = s; _ < T; _++) for (k = h; k < D; k++) w[r = 4 * _ * L + 4 * k] = d, w[r + 1] = p, w[r + 2] = m, w[r + 3] = y;
    }, isNeutralState: function() {
      return this.blocksize === 1;
    }, getUniformLocations: function(i, r) {
      return { uBlocksize: i.getUniformLocation(r, "uBlocksize"), uStepW: i.getUniformLocation(r, "uStepW"), uStepH: i.getUniformLocation(r, "uStepH") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uBlocksize, this.blocksize);
    } }), a.Image.filters.Pixelate.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.extend, f = a.Image.filters, i = a.util.createClass;
    f.RemoveColor = i(f.BaseFilter, { type: "RemoveColor", color: "#FFFFFF", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec4 uLow;
uniform vec4 uHigh;
varying vec2 vTexCoord;
void main() {
gl_FragColor = texture2D(uTexture, vTexCoord);
if(all(greaterThan(gl_FragColor.rgb,uLow.rgb)) && all(greaterThan(uHigh.rgb,gl_FragColor.rgb))) {
gl_FragColor.a = 0.0;
}
}`, distance: 0.02, useAlpha: !1, applyTo2d: function(r) {
      var s, h, d, p, m = r.imageData.data, y = 255 * this.distance, _ = new a.Color(this.color).getSource(), k = [_[0] - y, _[1] - y, _[2] - y], T = [_[0] + y, _[1] + y, _[2] + y];
      for (s = 0; s < m.length; s += 4) h = m[s], d = m[s + 1], p = m[s + 2], h > k[0] && d > k[1] && p > k[2] && h < T[0] && d < T[1] && p < T[2] && (m[s + 3] = 0);
    }, getUniformLocations: function(r, s) {
      return { uLow: r.getUniformLocation(s, "uLow"), uHigh: r.getUniformLocation(s, "uHigh") };
    }, sendUniformData: function(r, s) {
      var h = new a.Color(this.color).getSource(), d = parseFloat(this.distance), p = [0 + h[0] / 255 - d, 0 + h[1] / 255 - d, 0 + h[2] / 255 - d, 1], m = [h[0] / 255 + d, h[1] / 255 + d, h[2] / 255 + d, 1];
      r.uniform4fv(s.uLow, p), r.uniform4fv(s.uHigh, m);
    }, toObject: function() {
      return c(this.callSuper("toObject"), { color: this.color, distance: this.distance });
    } }), a.Image.filters.RemoveColor.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass, i = { Brownie: [0.5997, 0.34553, -0.27082, 0, 0.186, -0.0377, 0.86095, 0.15059, 0, -0.1449, 0.24113, -0.07441, 0.44972, 0, -0.02965, 0, 0, 0, 1, 0], Vintage: [0.62793, 0.32021, -0.03965, 0, 0.03784, 0.02578, 0.64411, 0.03259, 0, 0.02926, 0.0466, -0.08512, 0.52416, 0, 0.02023, 0, 0, 0, 1, 0], Kodachrome: [1.12855, -0.39673, -0.03992, 0, 0.24991, -0.16404, 1.08352, -0.05498, 0, 0.09698, -0.16786, -0.56034, 1.60148, 0, 0.13972, 0, 0, 0, 1, 0], Technicolor: [1.91252, -0.85453, -0.09155, 0, 0.04624, -0.30878, 1.76589, -0.10601, 0, -0.27589, -0.2311, -0.75018, 1.84759, 0, 0.12137, 0, 0, 0, 1, 0], Polaroid: [1.438, -0.062, -0.062, 0, 0, -0.122, 1.378, -0.122, 0, 0, -0.016, -0.016, 1.483, 0, 0, 0, 0, 0, 1, 0], Sepia: [0.393, 0.769, 0.189, 0, 0, 0.349, 0.686, 0.168, 0, 0, 0.272, 0.534, 0.131, 0, 0, 0, 0, 0, 1, 0], BlackWhite: [1.5, 1.5, 1.5, 0, -1, 1.5, 1.5, 1.5, 0, -1, 1.5, 1.5, 1.5, 0, -1, 0, 0, 0, 1, 0] };
    for (var r in i) c[r] = f(c.ColorMatrix, { type: r, matrix: i[r], mainParameter: !1, colorsOnly: !0 }), a.Image.filters[r].fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric, c = a.Image.filters, f = a.util.createClass;
    c.BlendColor = f(c.BaseFilter, { type: "BlendColor", color: "#F95C63", mode: "multiply", alpha: 1, fragmentSource: { multiply: `gl_FragColor.rgb *= uColor.rgb;
`, screen: `gl_FragColor.rgb = 1.0 - (1.0 - gl_FragColor.rgb) * (1.0 - uColor.rgb);
`, add: `gl_FragColor.rgb += uColor.rgb;
`, diff: `gl_FragColor.rgb = abs(gl_FragColor.rgb - uColor.rgb);
`, subtract: `gl_FragColor.rgb -= uColor.rgb;
`, lighten: `gl_FragColor.rgb = max(gl_FragColor.rgb, uColor.rgb);
`, darken: `gl_FragColor.rgb = min(gl_FragColor.rgb, uColor.rgb);
`, exclusion: `gl_FragColor.rgb += uColor.rgb - 2.0 * (uColor.rgb * gl_FragColor.rgb);
`, overlay: `if (uColor.r < 0.5) {
gl_FragColor.r *= 2.0 * uColor.r;
} else {
gl_FragColor.r = 1.0 - 2.0 * (1.0 - gl_FragColor.r) * (1.0 - uColor.r);
}
if (uColor.g < 0.5) {
gl_FragColor.g *= 2.0 * uColor.g;
} else {
gl_FragColor.g = 1.0 - 2.0 * (1.0 - gl_FragColor.g) * (1.0 - uColor.g);
}
if (uColor.b < 0.5) {
gl_FragColor.b *= 2.0 * uColor.b;
} else {
gl_FragColor.b = 1.0 - 2.0 * (1.0 - gl_FragColor.b) * (1.0 - uColor.b);
}
`, tint: `gl_FragColor.rgb *= (1.0 - uColor.a);
gl_FragColor.rgb += uColor.rgb;
` }, buildSource: function(i) {
      return `precision highp float;
uniform sampler2D uTexture;
uniform vec4 uColor;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
gl_FragColor = color;
if (color.a > 0.0) {
` + this.fragmentSource[i] + `}
}`;
    }, retrieveShader: function(i) {
      var r, s = this.type + "_" + this.mode;
      return i.programCache.hasOwnProperty(s) || (r = this.buildSource(this.mode), i.programCache[s] = this.createProgram(i.context, r)), i.programCache[s];
    }, applyTo2d: function(i) {
      var r, s, h, d, p, m, y, _ = i.imageData.data, k = _.length, T = 1 - this.alpha;
      r = (y = new a.Color(this.color).getSource())[0] * this.alpha, s = y[1] * this.alpha, h = y[2] * this.alpha;
      for (var D = 0; D < k; D += 4) switch (d = _[D], p = _[D + 1], m = _[D + 2], this.mode) {
        case "multiply":
          _[D] = d * r / 255, _[D + 1] = p * s / 255, _[D + 2] = m * h / 255;
          break;
        case "screen":
          _[D] = 255 - (255 - d) * (255 - r) / 255, _[D + 1] = 255 - (255 - p) * (255 - s) / 255, _[D + 2] = 255 - (255 - m) * (255 - h) / 255;
          break;
        case "add":
          _[D] = d + r, _[D + 1] = p + s, _[D + 2] = m + h;
          break;
        case "diff":
        case "difference":
          _[D] = Math.abs(d - r), _[D + 1] = Math.abs(p - s), _[D + 2] = Math.abs(m - h);
          break;
        case "subtract":
          _[D] = d - r, _[D + 1] = p - s, _[D + 2] = m - h;
          break;
        case "darken":
          _[D] = Math.min(d, r), _[D + 1] = Math.min(p, s), _[D + 2] = Math.min(m, h);
          break;
        case "lighten":
          _[D] = Math.max(d, r), _[D + 1] = Math.max(p, s), _[D + 2] = Math.max(m, h);
          break;
        case "overlay":
          _[D] = r < 128 ? 2 * d * r / 255 : 255 - 2 * (255 - d) * (255 - r) / 255, _[D + 1] = s < 128 ? 2 * p * s / 255 : 255 - 2 * (255 - p) * (255 - s) / 255, _[D + 2] = h < 128 ? 2 * m * h / 255 : 255 - 2 * (255 - m) * (255 - h) / 255;
          break;
        case "exclusion":
          _[D] = r + d - 2 * r * d / 255, _[D + 1] = s + p - 2 * s * p / 255, _[D + 2] = h + m - 2 * h * m / 255;
          break;
        case "tint":
          _[D] = r + d * T, _[D + 1] = s + p * T, _[D + 2] = h + m * T;
      }
    }, getUniformLocations: function(i, r) {
      return { uColor: i.getUniformLocation(r, "uColor") };
    }, sendUniformData: function(i, r) {
      var s = new a.Color(this.color).getSource();
      s[0] = this.alpha * s[0] / 255, s[1] = this.alpha * s[1] / 255, s[2] = this.alpha * s[2] / 255, s[3] = this.alpha, i.uniform4fv(r.uColor, s);
    }, toObject: function() {
      return { type: this.type, color: this.color, mode: this.mode, alpha: this.alpha };
    } }), a.Image.filters.BlendColor.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric, c = a.Image.filters, f = a.util.createClass;
    c.BlendImage = f(c.BaseFilter, { type: "BlendImage", image: null, mode: "multiply", alpha: 1, vertexSource: `attribute vec2 aPosition;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
uniform mat3 uTransformMatrix;
void main() {
vTexCoord = aPosition;
vTexCoord2 = (uTransformMatrix * vec3(aPosition, 1.0)).xy;
gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
}`, fragmentSource: { multiply: `precision highp float;
uniform sampler2D uTexture;
uniform sampler2D uImage;
uniform vec4 uColor;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec4 color2 = texture2D(uImage, vTexCoord2);
color.rgba *= color2.rgba;
gl_FragColor = color;
}`, mask: `precision highp float;
uniform sampler2D uTexture;
uniform sampler2D uImage;
uniform vec4 uColor;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec4 color2 = texture2D(uImage, vTexCoord2);
color.a = color2.a;
gl_FragColor = color;
}` }, retrieveShader: function(i) {
      var r = this.type + "_" + this.mode, s = this.fragmentSource[this.mode];
      return i.programCache.hasOwnProperty(r) || (i.programCache[r] = this.createProgram(i.context, s)), i.programCache[r];
    }, applyToWebGL: function(i) {
      var r = i.context, s = this.createTexture(i.filterBackend, this.image);
      this.bindAdditionalTexture(r, s, r.TEXTURE1), this.callSuper("applyToWebGL", i), this.unbindAdditionalTexture(r, r.TEXTURE1);
    }, createTexture: function(i, r) {
      return i.getCachedTexture(r.cacheKey, r._element);
    }, calculateMatrix: function() {
      var i = this.image, r = i._element.width, s = i._element.height;
      return [1 / i.scaleX, 0, 0, 0, 1 / i.scaleY, 0, -i.left / r, -i.top / s, 1];
    }, applyTo2d: function(i) {
      var r, s, h, d, p, m, y, _, k, T, D, j = i.imageData, w = i.filterBackend.resources, O = j.data, L = O.length, U = j.width, W = j.height, I = this.image;
      w.blendImage || (w.blendImage = a.util.createCanvasElement()), T = (k = w.blendImage).getContext("2d"), k.width !== U || k.height !== W ? (k.width = U, k.height = W) : T.clearRect(0, 0, U, W), T.setTransform(I.scaleX, 0, 0, I.scaleY, I.left, I.top), T.drawImage(I._element, 0, 0, U, W), D = T.getImageData(0, 0, U, W).data;
      for (var M = 0; M < L; M += 4) switch (p = O[M], m = O[M + 1], y = O[M + 2], _ = O[M + 3], r = D[M], s = D[M + 1], h = D[M + 2], d = D[M + 3], this.mode) {
        case "multiply":
          O[M] = p * r / 255, O[M + 1] = m * s / 255, O[M + 2] = y * h / 255, O[M + 3] = _ * d / 255;
          break;
        case "mask":
          O[M + 3] = d;
      }
    }, getUniformLocations: function(i, r) {
      return { uTransformMatrix: i.getUniformLocation(r, "uTransformMatrix"), uImage: i.getUniformLocation(r, "uImage") };
    }, sendUniformData: function(i, r) {
      var s = this.calculateMatrix();
      i.uniform1i(r.uImage, 1), i.uniformMatrix3fv(r.uTransformMatrix, !1, s);
    }, toObject: function() {
      return { type: this.type, image: this.image && this.image.toObject(), mode: this.mode, alpha: this.alpha };
    } }), a.Image.filters.BlendImage.fromObject = function(i, r) {
      a.Image.fromObject(i.image, function(s) {
        var h = a.util.object.clone(i);
        h.image = s, r(new a.Image.filters.BlendImage(h));
      });
    };
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = Math.pow, f = Math.floor, i = Math.sqrt, r = Math.abs, s = Math.round, h = Math.sin, d = Math.ceil, p = a.Image.filters, m = a.util.createClass;
    p.Resize = m(p.BaseFilter, { type: "Resize", resizeType: "hermite", scaleX: 1, scaleY: 1, lanczosLobes: 3, getUniformLocations: function(y, _) {
      return { uDelta: y.getUniformLocation(_, "uDelta"), uTaps: y.getUniformLocation(_, "uTaps") };
    }, sendUniformData: function(y, _) {
      y.uniform2fv(_.uDelta, this.horizontal ? [1 / this.width, 0] : [0, 1 / this.height]), y.uniform1fv(_.uTaps, this.taps);
    }, retrieveShader: function(y) {
      var _ = this.getFilterWindow(), k = this.type + "_" + _;
      if (!y.programCache.hasOwnProperty(k)) {
        var T = this.generateShader(_);
        y.programCache[k] = this.createProgram(y.context, T);
      }
      return y.programCache[k];
    }, getFilterWindow: function() {
      var y = this.tempScale;
      return Math.ceil(this.lanczosLobes / y);
    }, getTaps: function() {
      for (var y = this.lanczosCreate(this.lanczosLobes), _ = this.tempScale, k = this.getFilterWindow(), T = new Array(k), D = 1; D <= k; D++) T[D - 1] = y(D * _);
      return T;
    }, generateShader: function(y) {
      for (var _ = new Array(y), k = this.fragmentSourceTOP, T = 1; T <= y; T++) _[T - 1] = T + ".0 * uDelta";
      return k += "uniform float uTaps[" + y + `];
`, k += `void main() {
`, k += `  vec4 color = texture2D(uTexture, vTexCoord);
`, k += `  float sum = 1.0;
`, _.forEach(function(D, j) {
        k += "  color += texture2D(uTexture, vTexCoord + " + D + ") * uTaps[" + j + `];
`, k += "  color += texture2D(uTexture, vTexCoord - " + D + ") * uTaps[" + j + `];
`, k += "  sum += 2.0 * uTaps[" + j + `];
`;
      }), k += `  gl_FragColor = color / sum;
`, k += "}";
    }, fragmentSourceTOP: `precision highp float;
uniform sampler2D uTexture;
uniform vec2 uDelta;
varying vec2 vTexCoord;
`, applyTo: function(y) {
      y.webgl ? (y.passes++, this.width = y.sourceWidth, this.horizontal = !0, this.dW = Math.round(this.width * this.scaleX), this.dH = y.sourceHeight, this.tempScale = this.dW / this.width, this.taps = this.getTaps(), y.destinationWidth = this.dW, this._setupFrameBuffer(y), this.applyToWebGL(y), this._swapTextures(y), y.sourceWidth = y.destinationWidth, this.height = y.sourceHeight, this.horizontal = !1, this.dH = Math.round(this.height * this.scaleY), this.tempScale = this.dH / this.height, this.taps = this.getTaps(), y.destinationHeight = this.dH, this._setupFrameBuffer(y), this.applyToWebGL(y), this._swapTextures(y), y.sourceHeight = y.destinationHeight) : this.applyTo2d(y);
    }, isNeutralState: function() {
      return this.scaleX === 1 && this.scaleY === 1;
    }, lanczosCreate: function(y) {
      return function(_) {
        if (_ >= y || _ <= -y) return 0;
        if (_ < 11920929e-14 && _ > -11920929e-14) return 1;
        var k = (_ *= Math.PI) / y;
        return h(_) / _ * h(k) / k;
      };
    }, applyTo2d: function(y) {
      var _ = y.imageData, k = this.scaleX, T = this.scaleY;
      this.rcpScaleX = 1 / k, this.rcpScaleY = 1 / T;
      var D, j = _.width, w = _.height, O = s(j * k), L = s(w * T);
      this.resizeType === "sliceHack" ? D = this.sliceByTwo(y, j, w, O, L) : this.resizeType === "hermite" ? D = this.hermiteFastResize(y, j, w, O, L) : this.resizeType === "bilinear" ? D = this.bilinearFiltering(y, j, w, O, L) : this.resizeType === "lanczos" && (D = this.lanczosResize(y, j, w, O, L)), y.imageData = D;
    }, sliceByTwo: function(y, _, k, T, D) {
      var j, w, O = y.imageData, L = 0.5, U = !1, W = !1, I = _ * L, M = k * L, B = a.filterBackend.resources, Z = 0, J = 0, G = _, F = 0;
      for (B.sliceByTwo || (B.sliceByTwo = document.createElement("canvas")), ((j = B.sliceByTwo).width < 1.5 * _ || j.height < k) && (j.width = 1.5 * _, j.height = k), (w = j.getContext("2d")).clearRect(0, 0, 1.5 * _, k), w.putImageData(O, 0, 0), T = f(T), D = f(D); !U || !W; ) _ = I, k = M, T < f(I * L) ? I = f(I * L) : (I = T, U = !0), D < f(M * L) ? M = f(M * L) : (M = D, W = !0), w.drawImage(j, Z, J, _, k, G, F, I, M), Z = G, J = F, F += M;
      return w.getImageData(Z, J, T, D);
    }, lanczosResize: function(y, _, k, T, D) {
      var j = y.imageData.data, w = y.ctx.createImageData(T, D), O = w.data, L = this.lanczosCreate(this.lanczosLobes), U = this.rcpScaleX, W = this.rcpScaleY, I = 2 / this.rcpScaleX, M = 2 / this.rcpScaleY, B = d(U * this.lanczosLobes / 2), Z = d(W * this.lanczosLobes / 2), J = {}, G = {}, F = {};
      return function q(z) {
        var X, et, ct, ot, mt, lt, dt, ft, St, yt, Ot;
        for (G.x = (z + 0.5) * U, F.x = f(G.x), X = 0; X < D; X++) {
          for (G.y = (X + 0.5) * W, F.y = f(G.y), mt = 0, lt = 0, dt = 0, ft = 0, St = 0, et = F.x - B; et <= F.x + B; et++) if (!(et < 0 || et >= _)) {
            yt = f(1e3 * r(et - G.x)), J[yt] || (J[yt] = {});
            for (var Et = F.y - Z; Et <= F.y + Z; Et++) Et < 0 || Et >= k || (Ot = f(1e3 * r(Et - G.y)), J[yt][Ot] || (J[yt][Ot] = L(i(c(yt * I, 2) + c(Ot * M, 2)) / 1e3)), (ct = J[yt][Ot]) > 0 && (mt += ct, lt += ct * j[ot = 4 * (Et * _ + et)], dt += ct * j[ot + 1], ft += ct * j[ot + 2], St += ct * j[ot + 3]));
          }
          O[ot = 4 * (X * T + z)] = lt / mt, O[ot + 1] = dt / mt, O[ot + 2] = ft / mt, O[ot + 3] = St / mt;
        }
        return ++z < T ? q(z) : w;
      }(0);
    }, bilinearFiltering: function(y, _, k, T, D) {
      var j, w, O, L, U, W, I, M, B, Z = 0, J = this.rcpScaleX, G = this.rcpScaleY, F = 4 * (_ - 1), q = y.imageData.data, z = y.ctx.createImageData(T, D), X = z.data;
      for (O = 0; O < D; O++) for (L = 0; L < T; L++) for (U = J * L - (j = f(J * L)), W = G * O - (w = f(G * O)), B = 4 * (w * _ + j), I = 0; I < 4; I++) M = q[B + I] * (1 - U) * (1 - W) + q[B + 4 + I] * U * (1 - W) + q[B + F + I] * W * (1 - U) + q[B + F + 4 + I] * U * W, X[Z++] = M;
      return z;
    }, hermiteFastResize: function(y, _, k, T, D) {
      for (var j = this.rcpScaleX, w = this.rcpScaleY, O = d(j / 2), L = d(w / 2), U = y.imageData.data, W = y.ctx.createImageData(T, D), I = W.data, M = 0; M < D; M++) for (var B = 0; B < T; B++) {
        for (var Z = 4 * (B + M * T), J = 0, G = 0, F = 0, q = 0, z = 0, X = 0, et = 0, ct = (M + 0.5) * w, ot = f(M * w); ot < (M + 1) * w; ot++) for (var mt = r(ct - (ot + 0.5)) / L, lt = (B + 0.5) * j, dt = mt * mt, ft = f(B * j); ft < (B + 1) * j; ft++) {
          var St = r(lt - (ft + 0.5)) / O, yt = i(dt + St * St);
          yt > 1 && yt < -1 || (J = 2 * yt * yt * yt - 3 * yt * yt + 1) > 0 && (et += J * U[(St = 4 * (ft + ot * _)) + 3], F += J, U[St + 3] < 255 && (J = J * U[St + 3] / 250), q += J * U[St], z += J * U[St + 1], X += J * U[St + 2], G += J);
        }
        I[Z] = q / G, I[Z + 1] = z / G, I[Z + 2] = X / G, I[Z + 3] = et / F;
      }
      return W;
    }, toObject: function() {
      return { type: this.type, scaleX: this.scaleX, scaleY: this.scaleY, resizeType: this.resizeType, lanczosLobes: this.lanczosLobes };
    } }), a.Image.filters.Resize.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Contrast = f(c.BaseFilter, { type: "Contrast", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uContrast;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float contrastF = 1.015 * (uContrast + 1.0) / (1.0 * (1.015 - uContrast));
color.rgb = contrastF * (color.rgb - 0.5) + 0.5;
gl_FragColor = color;
}`, contrast: 0, mainParameter: "contrast", applyTo2d: function(i) {
      if (this.contrast !== 0) {
        var r, s = i.imageData.data, h = s.length, d = Math.floor(255 * this.contrast), p = 259 * (d + 255) / (255 * (259 - d));
        for (r = 0; r < h; r += 4) s[r] = p * (s[r] - 128) + 128, s[r + 1] = p * (s[r + 1] - 128) + 128, s[r + 2] = p * (s[r + 2] - 128) + 128;
      }
    }, getUniformLocations: function(i, r) {
      return { uContrast: i.getUniformLocation(r, "uContrast") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uContrast, this.contrast);
    } }), a.Image.filters.Contrast.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Saturation = f(c.BaseFilter, { type: "Saturation", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uSaturation;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float rgMax = max(color.r, color.g);
float rgbMax = max(rgMax, color.b);
color.r += rgbMax != color.r ? (rgbMax - color.r) * uSaturation : 0.00;
color.g += rgbMax != color.g ? (rgbMax - color.g) * uSaturation : 0.00;
color.b += rgbMax != color.b ? (rgbMax - color.b) * uSaturation : 0.00;
gl_FragColor = color;
}`, saturation: 0, mainParameter: "saturation", applyTo2d: function(i) {
      if (this.saturation !== 0) {
        var r, s, h = i.imageData.data, d = h.length, p = -this.saturation;
        for (r = 0; r < d; r += 4) s = Math.max(h[r], h[r + 1], h[r + 2]), h[r] += s !== h[r] ? (s - h[r]) * p : 0, h[r + 1] += s !== h[r + 1] ? (s - h[r + 1]) * p : 0, h[r + 2] += s !== h[r + 2] ? (s - h[r + 2]) * p : 0;
      }
    }, getUniformLocations: function(i, r) {
      return { uSaturation: i.getUniformLocation(r, "uSaturation") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uSaturation, -this.saturation);
    } }), a.Image.filters.Saturation.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Vibrance = f(c.BaseFilter, { type: "Vibrance", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uVibrance;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float max = max(color.r, max(color.g, color.b));
float avg = (color.r + color.g + color.b) / 3.0;
float amt = (abs(max - avg) * 2.0) * uVibrance;
color.r += max != color.r ? (max - color.r) * amt : 0.00;
color.g += max != color.g ? (max - color.g) * amt : 0.00;
color.b += max != color.b ? (max - color.b) * amt : 0.00;
gl_FragColor = color;
}`, vibrance: 0, mainParameter: "vibrance", applyTo2d: function(i) {
      if (this.vibrance !== 0) {
        var r, s, h, d, p = i.imageData.data, m = p.length, y = -this.vibrance;
        for (r = 0; r < m; r += 4) s = Math.max(p[r], p[r + 1], p[r + 2]), h = (p[r] + p[r + 1] + p[r + 2]) / 3, d = 2 * Math.abs(s - h) / 255 * y, p[r] += s !== p[r] ? (s - p[r]) * d : 0, p[r + 1] += s !== p[r + 1] ? (s - p[r + 1]) * d : 0, p[r + 2] += s !== p[r + 2] ? (s - p[r + 2]) * d : 0;
      }
    }, getUniformLocations: function(i, r) {
      return { uVibrance: i.getUniformLocation(r, "uVibrance") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uVibrance, -this.vibrance);
    } }), a.Image.filters.Vibrance.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Blur = f(c.BaseFilter, { type: "Blur", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec2 uDelta;
varying vec2 vTexCoord;
const float nSamples = 15.0;
vec3 v3offset = vec3(12.9898, 78.233, 151.7182);
float random(vec3 scale) {
return fract(sin(dot(gl_FragCoord.xyz, scale)) * 43758.5453);
}
void main() {
vec4 color = vec4(0.0);
float total = 0.0;
float offset = random(v3offset);
for (float t = -nSamples; t <= nSamples; t++) {
float percent = (t + offset - 0.5) / nSamples;
float weight = 1.0 - abs(percent);
color += texture2D(uTexture, vTexCoord + uDelta * percent) * weight;
total += weight;
}
gl_FragColor = color / total;
}`, blur: 0, mainParameter: "blur", applyTo: function(i) {
      i.webgl ? (this.aspectRatio = i.sourceWidth / i.sourceHeight, i.passes++, this._setupFrameBuffer(i), this.horizontal = !0, this.applyToWebGL(i), this._swapTextures(i), this._setupFrameBuffer(i), this.horizontal = !1, this.applyToWebGL(i), this._swapTextures(i)) : this.applyTo2d(i);
    }, applyTo2d: function(i) {
      i.imageData = this.simpleBlur(i);
    }, simpleBlur: function(i) {
      var r, s, h = i.filterBackend.resources, d = i.imageData.width, p = i.imageData.height;
      h.blurLayer1 || (h.blurLayer1 = a.util.createCanvasElement(), h.blurLayer2 = a.util.createCanvasElement()), r = h.blurLayer1, s = h.blurLayer2, r.width === d && r.height === p || (s.width = r.width = d, s.height = r.height = p);
      var m, y, _, k, T = r.getContext("2d"), D = s.getContext("2d"), j = 15, w = 0.06 * this.blur * 0.5;
      for (T.putImageData(i.imageData, 0, 0), D.clearRect(0, 0, d, p), k = -15; k <= j; k++) _ = w * (y = k / j) * d + (m = (Math.random() - 0.5) / 4), D.globalAlpha = 1 - Math.abs(y), D.drawImage(r, _, m), T.drawImage(s, 0, 0), D.globalAlpha = 1, D.clearRect(0, 0, s.width, s.height);
      for (k = -15; k <= j; k++) _ = w * (y = k / j) * p + (m = (Math.random() - 0.5) / 4), D.globalAlpha = 1 - Math.abs(y), D.drawImage(r, m, _), T.drawImage(s, 0, 0), D.globalAlpha = 1, D.clearRect(0, 0, s.width, s.height);
      i.ctx.drawImage(r, 0, 0);
      var O = i.ctx.getImageData(0, 0, r.width, r.height);
      return T.globalAlpha = 1, T.clearRect(0, 0, r.width, r.height), O;
    }, getUniformLocations: function(i, r) {
      return { delta: i.getUniformLocation(r, "uDelta") };
    }, sendUniformData: function(i, r) {
      var s = this.chooseRightDelta();
      i.uniform2fv(r.delta, s);
    }, chooseRightDelta: function() {
      var i, r = 1, s = [0, 0];
      return this.horizontal ? this.aspectRatio > 1 && (r = 1 / this.aspectRatio) : this.aspectRatio < 1 && (r = this.aspectRatio), i = r * this.blur * 0.12, this.horizontal ? s[0] = i : s[1] = i, s;
    } }), c.Blur.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Gamma = f(c.BaseFilter, { type: "Gamma", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec3 uGamma;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec3 correction = (1.0 / uGamma);
color.r = pow(color.r, correction.r);
color.g = pow(color.g, correction.g);
color.b = pow(color.b, correction.b);
gl_FragColor = color;
gl_FragColor.rgb *= color.a;
}`, gamma: [1, 1, 1], mainParameter: "gamma", initialize: function(i) {
      this.gamma = [1, 1, 1], c.BaseFilter.prototype.initialize.call(this, i);
    }, applyTo2d: function(i) {
      var r, s = i.imageData.data, h = this.gamma, d = s.length, p = 1 / h[0], m = 1 / h[1], y = 1 / h[2];
      for (this.rVals || (this.rVals = new Uint8Array(256), this.gVals = new Uint8Array(256), this.bVals = new Uint8Array(256)), r = 0, d = 256; r < d; r++) this.rVals[r] = 255 * Math.pow(r / 255, p), this.gVals[r] = 255 * Math.pow(r / 255, m), this.bVals[r] = 255 * Math.pow(r / 255, y);
      for (r = 0, d = s.length; r < d; r += 4) s[r] = this.rVals[s[r]], s[r + 1] = this.gVals[s[r + 1]], s[r + 2] = this.bVals[s[r + 2]];
    }, getUniformLocations: function(i, r) {
      return { uGamma: i.getUniformLocation(r, "uGamma") };
    }, sendUniformData: function(i, r) {
      i.uniform3fv(r.uGamma, this.gamma);
    } }), a.Image.filters.Gamma.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.Composed = f(c.BaseFilter, { type: "Composed", subFilters: [], initialize: function(i) {
      this.callSuper("initialize", i), this.subFilters = this.subFilters.slice(0);
    }, applyTo: function(i) {
      i.passes += this.subFilters.length - 1, this.subFilters.forEach(function(r) {
        r.applyTo(i);
      });
    }, toObject: function() {
      return a.util.object.extend(this.callSuper("toObject"), { subFilters: this.subFilters.map(function(i) {
        return i.toObject();
      }) });
    }, isNeutralState: function() {
      return !this.subFilters.some(function(i) {
        return !i.isNeutralState();
      });
    } }), a.Image.filters.Composed.fromObject = function(i, r) {
      var s = (i.subFilters || []).map(function(d) {
        return new a.Image.filters[d.type](d);
      }), h = new a.Image.filters.Composed({ subFilters: s });
      return r && r(h), h;
    };
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.Image.filters, f = a.util.createClass;
    c.HueRotation = f(c.ColorMatrix, { type: "HueRotation", rotation: 0, mainParameter: "rotation", calculateMatrix: function() {
      var i = this.rotation * Math.PI, r = a.util.cos(i), s = a.util.sin(i), h = 1 / 3, d = Math.sqrt(h) * s, p = 1 - r;
      this.matrix = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0], this.matrix[0] = r + p / 3, this.matrix[1] = h * p - d, this.matrix[2] = h * p + d, this.matrix[5] = h * p + d, this.matrix[6] = r + h * p, this.matrix[7] = h * p - d, this.matrix[10] = h * p - d, this.matrix[11] = h * p + d, this.matrix[12] = r + h * p;
    }, isNeutralState: function(i) {
      return this.calculateMatrix(), c.BaseFilter.prototype.isNeutralState.call(this, i);
    }, applyTo: function(i) {
      this.calculateMatrix(), c.BaseFilter.prototype.applyTo.call(this, i);
    } }), a.Image.filters.HueRotation.fromObject = a.Image.filters.BaseFilter.fromObject;
  }(t), function(l) {
    var a = l.fabric || (l.fabric = {}), c = a.util.object.clone;
    if (a.Text) a.warn("fabric.Text is already defined");
    else {
      var f = "fontFamily fontWeight fontSize text underline overline linethrough textAlign fontStyle lineHeight textBackgroundColor charSpacing styles direction path pathStartOffset pathSide".split(" ");
      a.Text = a.util.createClass(a.Object, { _dimensionAffectingProps: ["fontSize", "fontWeight", "fontFamily", "fontStyle", "lineHeight", "text", "charSpacing", "textAlign", "styles", "path", "pathStartOffset", "pathSide"], _reNewline: /\r?\n/, _reSpacesAndTabs: /[ \t\r]/g, _reSpaceAndTab: /[ \t\r]/, _reWords: /\S+/g, type: "text", fontSize: 40, fontWeight: "normal", fontFamily: "Times New Roman", underline: !1, overline: !1, linethrough: !1, textAlign: "left", fontStyle: "normal", lineHeight: 1.16, superscript: { size: 0.6, baseline: -0.35 }, subscript: { size: 0.6, baseline: 0.11 }, textBackgroundColor: "", stateProperties: a.Object.prototype.stateProperties.concat(f), cacheProperties: a.Object.prototype.cacheProperties.concat(f), stroke: null, shadow: null, path: null, pathStartOffset: 0, pathSide: "left", _fontSizeFraction: 0.222, offsets: { underline: 0.1, linethrough: -0.315, overline: -0.88 }, _fontSizeMult: 1.13, charSpacing: 0, styles: null, _measuringContext: null, deltaY: 0, direction: "ltr", _styleProperties: ["stroke", "strokeWidth", "fill", "fontFamily", "fontSize", "fontWeight", "fontStyle", "underline", "overline", "linethrough", "deltaY", "textBackgroundColor"], __charBounds: [], CACHE_FONT_SIZE: 400, MIN_TEXT_WIDTH: 2, initialize: function(i, r) {
        this.styles = r && r.styles || {}, this.text = i, this.__skipDimension = !0, this.callSuper("initialize", r), this.path && this.setPathInfo(), this.__skipDimension = !1, this.initDimensions(), this.setCoords(), this.setupState({ propertySet: "_dimensionAffectingProps" });
      }, setPathInfo: function() {
        var i = this.path;
        i && (i.segmentsInfo = a.util.getPathSegmentsInfo(i.path));
      }, getMeasuringContext: function() {
        return a._measuringContext || (a._measuringContext = this.canvas && this.canvas.contextCache || a.util.createCanvasElement().getContext("2d")), a._measuringContext;
      }, _splitText: function() {
        var i = this._splitTextIntoLines(this.text);
        return this.textLines = i.lines, this._textLines = i.graphemeLines, this._unwrappedTextLines = i._unwrappedLines, this._text = i.graphemeText, i;
      }, initDimensions: function() {
        this.__skipDimension || (this._splitText(), this._clearCache(), this.path ? (this.width = this.path.width, this.height = this.path.height) : (this.width = this.calcTextWidth() || this.cursorWidth || this.MIN_TEXT_WIDTH, this.height = this.calcTextHeight()), this.textAlign.indexOf("justify") !== -1 && this.enlargeSpaces(), this.saveState({ propertySet: "_dimensionAffectingProps" }));
      }, enlargeSpaces: function() {
        for (var i, r, s, h, d, p, m, y = 0, _ = this._textLines.length; y < _; y++) if ((this.textAlign === "justify" || y !== _ - 1 && !this.isEndOfWrapping(y)) && (h = 0, d = this._textLines[y], (r = this.getLineWidth(y)) < this.width && (m = this.textLines[y].match(this._reSpacesAndTabs)))) {
          s = m.length, i = (this.width - r) / s;
          for (var k = 0, T = d.length; k <= T; k++) p = this.__charBounds[y][k], this._reSpaceAndTab.test(d[k]) ? (p.width += i, p.kernedWidth += i, p.left += h, h += i) : p.left += h;
        }
      }, isEndOfWrapping: function(i) {
        return i === this._textLines.length - 1;
      }, missingNewlineOffset: function() {
        return 1;
      }, toString: function() {
        return "#<fabric.Text (" + this.complexity() + '): { "text": "' + this.text + '", "fontFamily": "' + this.fontFamily + '" }>';
      }, _getCacheCanvasDimensions: function() {
        var i = this.callSuper("_getCacheCanvasDimensions"), r = this.fontSize;
        return i.width += r * i.zoomX, i.height += r * i.zoomY, i;
      }, _render: function(i) {
        var r = this.path;
        r && !r.isNotVisible() && r._render(i), this._setTextStyles(i), this._renderTextLinesBackground(i), this._renderTextDecoration(i, "underline"), this._renderText(i), this._renderTextDecoration(i, "overline"), this._renderTextDecoration(i, "linethrough");
      }, _renderText: function(i) {
        this.paintFirst === "stroke" ? (this._renderTextStroke(i), this._renderTextFill(i)) : (this._renderTextFill(i), this._renderTextStroke(i));
      }, _setTextStyles: function(i, r, s) {
        i.textBaseline = "alphabetic", i.font = this._getFontDeclaration(r, s);
      }, calcTextWidth: function() {
        for (var i = this.getLineWidth(0), r = 1, s = this._textLines.length; r < s; r++) {
          var h = this.getLineWidth(r);
          h > i && (i = h);
        }
        return i;
      }, _renderTextLine: function(i, r, s, h, d, p) {
        this._renderChars(i, r, s, h, d, p);
      }, _renderTextLinesBackground: function(i) {
        if (this.textBackgroundColor || this.styleHas("textBackgroundColor")) {
          for (var r, s, h, d, p, m, y, _ = i.fillStyle, k = this._getLeftOffset(), T = this._getTopOffset(), D = 0, j = 0, w = this.path, O = 0, L = this._textLines.length; O < L; O++) if (r = this.getHeightOfLine(O), this.textBackgroundColor || this.styleHas("textBackgroundColor", O)) {
            h = this._textLines[O], s = this._getLineLeftOffset(O), j = 0, D = 0, d = this.getValueOfPropertyAt(O, 0, "textBackgroundColor");
            for (var U = 0, W = h.length; U < W; U++) p = this.__charBounds[O][U], m = this.getValueOfPropertyAt(O, U, "textBackgroundColor"), w ? (i.save(), i.translate(p.renderLeft, p.renderTop), i.rotate(p.angle), i.fillStyle = m, m && i.fillRect(-p.width / 2, -r / this.lineHeight * (1 - this._fontSizeFraction), p.width, r / this.lineHeight), i.restore()) : m !== d ? (y = k + s + D, this.direction === "rtl" && (y = this.width - y - j), i.fillStyle = d, d && i.fillRect(y, T, j, r / this.lineHeight), D = p.left, j = p.width, d = m) : j += p.kernedWidth;
            m && !w && (y = k + s + D, this.direction === "rtl" && (y = this.width - y - j), i.fillStyle = m, i.fillRect(y, T, j, r / this.lineHeight)), T += r;
          } else T += r;
          i.fillStyle = _, this._removeShadow(i);
        }
      }, getFontCache: function(i) {
        var r = i.fontFamily.toLowerCase();
        a.charWidthsCache[r] || (a.charWidthsCache[r] = {});
        var s = a.charWidthsCache[r], h = i.fontStyle.toLowerCase() + "_" + (i.fontWeight + "").toLowerCase();
        return s[h] || (s[h] = {}), s[h];
      }, _measureChar: function(i, r, s, h) {
        var d, p, m, y, _ = this.getFontCache(r), k = s + i, T = this._getFontDeclaration(r) === this._getFontDeclaration(h), D = r.fontSize / this.CACHE_FONT_SIZE;
        if (s && _[s] !== void 0 && (m = _[s]), _[i] !== void 0 && (y = d = _[i]), T && _[k] !== void 0 && (y = (p = _[k]) - m), d === void 0 || m === void 0 || p === void 0) {
          var j = this.getMeasuringContext();
          this._setTextStyles(j, r, !0);
        }
        return d === void 0 && (y = d = j.measureText(i).width, _[i] = d), m === void 0 && T && s && (m = j.measureText(s).width, _[s] = m), T && p === void 0 && (p = j.measureText(k).width, _[k] = p, y = p - m), { width: d * D, kernedWidth: y * D };
      }, getHeightOfChar: function(i, r) {
        return this.getValueOfPropertyAt(i, r, "fontSize");
      }, measureLine: function(i) {
        var r = this._measureLine(i);
        return this.charSpacing !== 0 && (r.width -= this._getWidthOfCharSpacing()), r.width < 0 && (r.width = 0), r;
      }, _measureLine: function(i) {
        var r, s, h, d, p, m, y = 0, _ = this._textLines[i], k = new Array(_.length), T = 0, D = this.path, j = this.pathSide === "right";
        for (this.__charBounds[i] = k, r = 0; r < _.length; r++) s = _[r], d = this._getGraphemeBox(s, i, r, h), k[r] = d, y += d.kernedWidth, h = s;
        if (k[r] = { left: d ? d.left + d.width : 0, width: 0, kernedWidth: 0, height: this.fontSize }, D) {
          switch (m = D.segmentsInfo[D.segmentsInfo.length - 1].length, (p = a.util.getPointOnPath(D.path, 0, D.segmentsInfo)).x += D.pathOffset.x, p.y += D.pathOffset.y, this.textAlign) {
            case "left":
              T = j ? m - y : 0;
              break;
            case "center":
              T = (m - y) / 2;
              break;
            case "right":
              T = j ? 0 : m - y;
          }
          for (T += this.pathStartOffset * (j ? -1 : 1), r = j ? _.length - 1 : 0; j ? r >= 0 : r < _.length; j ? r-- : r++) d = k[r], T > m ? T %= m : T < 0 && (T += m), this._setGraphemeOnPath(T, d, p), T += d.kernedWidth;
        }
        return { width: y, numOfSpaces: 0 };
      }, _setGraphemeOnPath: function(i, r, s) {
        var h = i + r.kernedWidth / 2, d = this.path, p = a.util.getPointOnPath(d.path, h, d.segmentsInfo);
        r.renderLeft = p.x - s.x, r.renderTop = p.y - s.y, r.angle = p.angle + (this.pathSide === "right" ? Math.PI : 0);
      }, _getGraphemeBox: function(i, r, s, h, d) {
        var p, m = this.getCompleteStyleDeclaration(r, s), y = h ? this.getCompleteStyleDeclaration(r, s - 1) : {}, _ = this._measureChar(i, m, h, y), k = _.kernedWidth, T = _.width;
        this.charSpacing !== 0 && (T += p = this._getWidthOfCharSpacing(), k += p);
        var D = { width: T, left: 0, height: m.fontSize, kernedWidth: k, deltaY: m.deltaY };
        if (s > 0 && !d) {
          var j = this.__charBounds[r][s - 1];
          D.left = j.left + j.width + _.kernedWidth - _.width;
        }
        return D;
      }, getHeightOfLine: function(i) {
        if (this.__lineHeights[i]) return this.__lineHeights[i];
        for (var r = this._textLines[i], s = this.getHeightOfChar(i, 0), h = 1, d = r.length; h < d; h++) s = Math.max(this.getHeightOfChar(i, h), s);
        return this.__lineHeights[i] = s * this.lineHeight * this._fontSizeMult;
      }, calcTextHeight: function() {
        for (var i, r = 0, s = 0, h = this._textLines.length; s < h; s++) i = this.getHeightOfLine(s), r += s === h - 1 ? i / this.lineHeight : i;
        return r;
      }, _getLeftOffset: function() {
        return this.direction === "ltr" ? -this.width / 2 : this.width / 2;
      }, _getTopOffset: function() {
        return -this.height / 2;
      }, _renderTextCommon: function(i, r) {
        i.save();
        for (var s = 0, h = this._getLeftOffset(), d = this._getTopOffset(), p = 0, m = this._textLines.length; p < m; p++) {
          var y = this.getHeightOfLine(p), _ = y / this.lineHeight, k = this._getLineLeftOffset(p);
          this._renderTextLine(r, i, this._textLines[p], h + k, d + s + _, p), s += y;
        }
        i.restore();
      }, _renderTextFill: function(i) {
        (this.fill || this.styleHas("fill")) && this._renderTextCommon(i, "fillText");
      }, _renderTextStroke: function(i) {
        (this.stroke && this.strokeWidth !== 0 || !this.isEmptyStyles()) && (this.shadow && !this.shadow.affectStroke && this._removeShadow(i), i.save(), this._setLineDash(i, this.strokeDashArray), i.beginPath(), this._renderTextCommon(i, "strokeText"), i.closePath(), i.restore());
      }, _renderChars: function(i, r, s, h, d, p) {
        var m, y, _, k, T, D = this.getHeightOfLine(p), j = this.textAlign.indexOf("justify") !== -1, w = "", O = 0, L = this.path, U = !j && this.charSpacing === 0 && this.isEmptyStyles(p) && !L, W = this.direction === "ltr", I = this.direction === "ltr" ? 1 : -1;
        if (r.save(), d -= D * this._fontSizeFraction / this.lineHeight, U) return r.canvas.setAttribute("dir", W ? "ltr" : "rtl"), r.direction = W ? "ltr" : "rtl", r.textAlign = W ? "left" : "right", this._renderChar(i, r, p, 0, s.join(""), h, d, D), void r.restore();
        for (var M = 0, B = s.length - 1; M <= B; M++) k = M === B || this.charSpacing || L, w += s[M], _ = this.__charBounds[p][M], O === 0 ? (h += I * (_.kernedWidth - _.width), O += _.width) : O += _.kernedWidth, j && !k && this._reSpaceAndTab.test(s[M]) && (k = !0), k || (m = m || this.getCompleteStyleDeclaration(p, M), y = this.getCompleteStyleDeclaration(p, M + 1), k = this._hasStyleChanged(m, y)), k && (L ? (r.save(), r.translate(_.renderLeft, _.renderTop), r.rotate(_.angle), this._renderChar(i, r, p, M, w, -O / 2, 0, D), r.restore()) : (T = h, r.canvas.setAttribute("dir", W ? "ltr" : "rtl"), r.direction = W ? "ltr" : "rtl", r.textAlign = W ? "left" : "right", this._renderChar(i, r, p, M, w, T, d, D)), w = "", m = y, h += I * O, O = 0);
        r.restore();
      }, _applyPatternGradientTransformText: function(i) {
        var r, s = a.util.createCanvasElement(), h = this.width + this.strokeWidth, d = this.height + this.strokeWidth;
        return s.width = h, s.height = d, (r = s.getContext("2d")).beginPath(), r.moveTo(0, 0), r.lineTo(h, 0), r.lineTo(h, d), r.lineTo(0, d), r.closePath(), r.translate(h / 2, d / 2), r.fillStyle = i.toLive(r), this._applyPatternGradientTransform(r, i), r.fill(), r.createPattern(s, "no-repeat");
      }, handleFiller: function(i, r, s) {
        var h, d;
        return s.toLive ? s.gradientUnits === "percentage" || s.gradientTransform || s.patternTransform ? (h = -this.width / 2, d = -this.height / 2, i.translate(h, d), i[r] = this._applyPatternGradientTransformText(s), { offsetX: h, offsetY: d }) : (i[r] = s.toLive(i, this), this._applyPatternGradientTransform(i, s)) : (i[r] = s, { offsetX: 0, offsetY: 0 });
      }, _setStrokeStyles: function(i, r) {
        return i.lineWidth = r.strokeWidth, i.lineCap = this.strokeLineCap, i.lineDashOffset = this.strokeDashOffset, i.lineJoin = this.strokeLineJoin, i.miterLimit = this.strokeMiterLimit, this.handleFiller(i, "strokeStyle", r.stroke);
      }, _setFillStyles: function(i, r) {
        return this.handleFiller(i, "fillStyle", r.fill);
      }, _renderChar: function(i, r, s, h, d, p, m) {
        var y, _, k = this._getStyleDeclaration(s, h), T = this.getCompleteStyleDeclaration(s, h), D = i === "fillText" && T.fill, j = i === "strokeText" && T.stroke && T.strokeWidth;
        (j || D) && (r.save(), D && (y = this._setFillStyles(r, T)), j && (_ = this._setStrokeStyles(r, T)), r.font = this._getFontDeclaration(T), k && k.textBackgroundColor && this._removeShadow(r), k && k.deltaY && (m += k.deltaY), D && r.fillText(d, p - y.offsetX, m - y.offsetY), j && r.strokeText(d, p - _.offsetX, m - _.offsetY), r.restore());
      }, setSuperscript: function(i, r) {
        return this._setScript(i, r, this.superscript);
      }, setSubscript: function(i, r) {
        return this._setScript(i, r, this.subscript);
      }, _setScript: function(i, r, s) {
        var h = this.get2DCursorLocation(i, !0), d = this.getValueOfPropertyAt(h.lineIndex, h.charIndex, "fontSize"), p = this.getValueOfPropertyAt(h.lineIndex, h.charIndex, "deltaY"), m = { fontSize: d * s.size, deltaY: p + d * s.baseline };
        return this.setSelectionStyles(m, i, r), this;
      }, _hasStyleChanged: function(i, r) {
        return i.fill !== r.fill || i.stroke !== r.stroke || i.strokeWidth !== r.strokeWidth || i.fontSize !== r.fontSize || i.fontFamily !== r.fontFamily || i.fontWeight !== r.fontWeight || i.fontStyle !== r.fontStyle || i.deltaY !== r.deltaY;
      }, _hasStyleChangedForSvg: function(i, r) {
        return this._hasStyleChanged(i, r) || i.overline !== r.overline || i.underline !== r.underline || i.linethrough !== r.linethrough;
      }, _getLineLeftOffset: function(i) {
        var r = this.getLineWidth(i), s = this.width - r, h = this.textAlign, d = this.direction, p = 0, m = this.isEndOfWrapping(i);
        return h === "justify" || h === "justify-center" && !m || h === "justify-right" && !m || h === "justify-left" && !m ? 0 : (h === "center" && (p = s / 2), h === "right" && (p = s), h === "justify-center" && (p = s / 2), h === "justify-right" && (p = s), d === "rtl" && (p -= s), p);
      }, _clearCache: function() {
        this.__lineWidths = [], this.__lineHeights = [], this.__charBounds = [];
      }, _shouldClearDimensionCache: function() {
        var i = this._forceClearCache;
        return i || (i = this.hasStateChanged("_dimensionAffectingProps")), i && (this.dirty = !0, this._forceClearCache = !1), i;
      }, getLineWidth: function(i) {
        return this.__lineWidths[i] ? this.__lineWidths[i] : (r = this._textLines[i] === "" ? 0 : this.measureLine(i).width, this.__lineWidths[i] = r, r);
        var r;
      }, _getWidthOfCharSpacing: function() {
        return this.charSpacing !== 0 ? this.fontSize * this.charSpacing / 1e3 : 0;
      }, getValueOfPropertyAt: function(i, r, s) {
        var h = this._getStyleDeclaration(i, r);
        return h && h[s] !== void 0 ? h[s] : this[s];
      }, _renderTextDecoration: function(i, r) {
        if (this[r] || this.styleHas(r)) {
          for (var s, h, d, p, m, y, _, k, T, D, j, w, O, L, U, W, I = this._getLeftOffset(), M = this._getTopOffset(), B = this.path, Z = this._getWidthOfCharSpacing(), J = this.offsets[r], G = 0, F = this._textLines.length; G < F; G++) if (s = this.getHeightOfLine(G), this[r] || this.styleHas(r, G)) {
            _ = this._textLines[G], L = s / this.lineHeight, p = this._getLineLeftOffset(G), D = 0, j = 0, k = this.getValueOfPropertyAt(G, 0, r), W = this.getValueOfPropertyAt(G, 0, "fill"), T = M + L * (1 - this._fontSizeFraction), h = this.getHeightOfChar(G, 0), m = this.getValueOfPropertyAt(G, 0, "deltaY");
            for (var q = 0, z = _.length; q < z; q++) if (w = this.__charBounds[G][q], O = this.getValueOfPropertyAt(G, q, r), U = this.getValueOfPropertyAt(G, q, "fill"), d = this.getHeightOfChar(G, q), y = this.getValueOfPropertyAt(G, q, "deltaY"), B && O && U) i.save(), i.fillStyle = W, i.translate(w.renderLeft, w.renderTop), i.rotate(w.angle), i.fillRect(-w.kernedWidth / 2, J * d + y, w.kernedWidth, this.fontSize / 15), i.restore();
            else if ((O !== k || U !== W || d !== h || y !== m) && j > 0) {
              var X = I + p + D;
              this.direction === "rtl" && (X = this.width - X - j), k && W && (i.fillStyle = W, i.fillRect(X, T + J * h + m, j, this.fontSize / 15)), D = w.left, j = w.width, k = O, W = U, h = d, m = y;
            } else j += w.kernedWidth;
            X = I + p + D, this.direction === "rtl" && (X = this.width - X - j), i.fillStyle = U, O && U && i.fillRect(X, T + J * h + m, j - Z, this.fontSize / 15), M += s;
          } else M += s;
          this._removeShadow(i);
        }
      }, _getFontDeclaration: function(i, r) {
        var s = i || this, h = this.fontFamily, d = a.Text.genericFonts.indexOf(h.toLowerCase()) > -1, p = h === void 0 || h.indexOf("'") > -1 || h.indexOf(",") > -1 || h.indexOf('"') > -1 || d ? s.fontFamily : '"' + s.fontFamily + '"';
        return [a.isLikelyNode ? s.fontWeight : s.fontStyle, a.isLikelyNode ? s.fontStyle : s.fontWeight, r ? this.CACHE_FONT_SIZE + "px" : s.fontSize + "px", p].join(" ");
      }, render: function(i) {
        this.visible && (this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (this._shouldClearDimensionCache() && this.initDimensions(), this.callSuper("render", i)));
      }, _splitTextIntoLines: function(i) {
        for (var r = i.split(this._reNewline), s = new Array(r.length), h = [`
`], d = [], p = 0; p < r.length; p++) s[p] = a.util.string.graphemeSplit(r[p]), d = d.concat(s[p], h);
        return d.pop(), { _unwrappedLines: s, lines: r, graphemeText: d, graphemeLines: s };
      }, toObject: function(i) {
        var r = f.concat(i), s = this.callSuper("toObject", r);
        return s.styles = c(this.styles, !0), s.path && (s.path = this.path.toObject()), s;
      }, set: function(i, r) {
        this.callSuper("set", i, r);
        var s = !1, h = !1;
        if (typeof i == "object") for (var d in i) d === "path" && this.setPathInfo(), s = s || this._dimensionAffectingProps.indexOf(d) !== -1, h = h || d === "path";
        else s = this._dimensionAffectingProps.indexOf(i) !== -1, h = i === "path";
        return h && this.setPathInfo(), s && (this.initDimensions(), this.setCoords()), this;
      }, complexity: function() {
        return 1;
      } }), a.Text.ATTRIBUTE_NAMES = a.SHARED_ATTRIBUTES.concat("x y dx dy font-family font-style font-weight font-size letter-spacing text-decoration text-anchor".split(" ")), a.Text.DEFAULT_SVG_FONT_SIZE = 16, a.Text.fromElement = function(i, r, s) {
        if (!i) return r(null);
        var h = a.parseAttributes(i, a.Text.ATTRIBUTE_NAMES), d = h.textAnchor || "left";
        if ((s = a.util.object.extend(s ? c(s) : {}, h)).top = s.top || 0, s.left = s.left || 0, h.textDecoration) {
          var p = h.textDecoration;
          p.indexOf("underline") !== -1 && (s.underline = !0), p.indexOf("overline") !== -1 && (s.overline = !0), p.indexOf("line-through") !== -1 && (s.linethrough = !0), delete s.textDecoration;
        }
        "dx" in h && (s.left += h.dx), "dy" in h && (s.top += h.dy), "fontSize" in s || (s.fontSize = a.Text.DEFAULT_SVG_FONT_SIZE);
        var m = "";
        "textContent" in i ? m = i.textContent : "firstChild" in i && i.firstChild !== null && "data" in i.firstChild && i.firstChild.data !== null && (m = i.firstChild.data), m = m.replace(/^\s+|\s+$|\n+/g, "").replace(/\s+/g, " ");
        var y = s.strokeWidth;
        s.strokeWidth = 0;
        var _ = new a.Text(m, s), k = _.getScaledHeight() / _.height, T = ((_.height + _.strokeWidth) * _.lineHeight - _.height) * k, D = _.getScaledHeight() + T, j = 0;
        d === "center" && (j = _.getScaledWidth() / 2), d === "right" && (j = _.getScaledWidth()), _.set({ left: _.left - j, top: _.top - (D - _.fontSize * (0.07 + _._fontSizeFraction)) / _.lineHeight, strokeWidth: y !== void 0 ? y : 1 }), r(_);
      }, a.Text.fromObject = function(i, r) {
        var s = c(i), h = i.path;
        return delete s.path, a.Object._fromObject("Text", s, function(d) {
          h ? a.Object._fromObject("Path", h, function(p) {
            d.set("path", p), r(d);
          }, "path") : r(d);
        }, "text");
      }, a.Text.genericFonts = ["sans-serif", "serif", "cursive", "fantasy", "monospace"], a.util.createAccessors && a.util.createAccessors(a.Text);
    }
  }(t), b.util.object.extend(b.Text.prototype, { isEmptyStyles: function(l) {
    if (!this.styles || l !== void 0 && !this.styles[l]) return !0;
    var a = l === void 0 ? this.styles : { line: this.styles[l] };
    for (var c in a) for (var f in a[c]) for (var i in a[c][f]) return !1;
    return !0;
  }, styleHas: function(l, a) {
    if (!this.styles || !l || l === "" || a !== void 0 && !this.styles[a]) return !1;
    var c = a === void 0 ? this.styles : { 0: this.styles[a] };
    for (var f in c) for (var i in c[f]) if (c[f][i][l] !== void 0) return !0;
    return !1;
  }, cleanStyle: function(l) {
    if (!this.styles || !l || l === "") return !1;
    var a, c, f = this.styles, i = 0, r = !0, s = 0;
    for (var h in f) {
      for (var d in a = 0, f[h]) {
        var p;
        i++, (p = f[h][d]).hasOwnProperty(l) ? (c ? p[l] !== c && (r = !1) : c = p[l], p[l] === this[l] && delete p[l]) : r = !1, Object.keys(p).length !== 0 ? a++ : delete f[h][d];
      }
      a === 0 && delete f[h];
    }
    for (var m = 0; m < this._textLines.length; m++) s += this._textLines[m].length;
    r && i === s && (this[l] = c, this.removeStyle(l));
  }, removeStyle: function(l) {
    if (this.styles && l && l !== "") {
      var a, c, f, i = this.styles;
      for (c in i) {
        for (f in a = i[c]) delete a[f][l], Object.keys(a[f]).length === 0 && delete a[f];
        Object.keys(a).length === 0 && delete i[c];
      }
    }
  }, _extendStyles: function(l, a) {
    var c = this.get2DCursorLocation(l);
    this._getLineStyle(c.lineIndex) || this._setLineStyle(c.lineIndex), this._getStyleDeclaration(c.lineIndex, c.charIndex) || this._setStyleDeclaration(c.lineIndex, c.charIndex, {}), b.util.object.extend(this._getStyleDeclaration(c.lineIndex, c.charIndex), a);
  }, get2DCursorLocation: function(l, a) {
    l === void 0 && (l = this.selectionStart);
    for (var c = a ? this._unwrappedTextLines : this._textLines, f = c.length, i = 0; i < f; i++) {
      if (l <= c[i].length) return { lineIndex: i, charIndex: l };
      l -= c[i].length + this.missingNewlineOffset(i);
    }
    return { lineIndex: i - 1, charIndex: c[i - 1].length < l ? c[i - 1].length : l };
  }, getSelectionStyles: function(l, a, c) {
    l === void 0 && (l = this.selectionStart || 0), a === void 0 && (a = this.selectionEnd || l);
    for (var f = [], i = l; i < a; i++) f.push(this.getStyleAtPosition(i, c));
    return f;
  }, getStyleAtPosition: function(l, a) {
    var c = this.get2DCursorLocation(l);
    return (a ? this.getCompleteStyleDeclaration(c.lineIndex, c.charIndex) : this._getStyleDeclaration(c.lineIndex, c.charIndex)) || {};
  }, setSelectionStyles: function(l, a, c) {
    a === void 0 && (a = this.selectionStart || 0), c === void 0 && (c = this.selectionEnd || a);
    for (var f = a; f < c; f++) this._extendStyles(f, l);
    return this._forceClearCache = !0, this;
  }, _getStyleDeclaration: function(l, a) {
    var c = this.styles && this.styles[l];
    return c ? c[a] : null;
  }, getCompleteStyleDeclaration: function(l, a) {
    for (var c, f = this._getStyleDeclaration(l, a) || {}, i = {}, r = 0; r < this._styleProperties.length; r++) i[c = this._styleProperties[r]] = f[c] === void 0 ? this[c] : f[c];
    return i;
  }, _setStyleDeclaration: function(l, a, c) {
    this.styles[l][a] = c;
  }, _deleteStyleDeclaration: function(l, a) {
    delete this.styles[l][a];
  }, _getLineStyle: function(l) {
    return !!this.styles[l];
  }, _setLineStyle: function(l) {
    this.styles[l] = {};
  }, _deleteLineStyle: function(l) {
    delete this.styles[l];
  } }), function() {
    function l(a) {
      a.textDecoration && (a.textDecoration.indexOf("underline") > -1 && (a.underline = !0), a.textDecoration.indexOf("line-through") > -1 && (a.linethrough = !0), a.textDecoration.indexOf("overline") > -1 && (a.overline = !0), delete a.textDecoration);
    }
    b.IText = b.util.createClass(b.Text, b.Observable, { type: "i-text", selectionStart: 0, selectionEnd: 0, selectionColor: "rgba(17,119,255,0.3)", isEditing: !1, editable: !0, editingBorderColor: "rgba(102,153,255,0.25)", cursorWidth: 2, cursorColor: "", cursorDelay: 1e3, cursorDuration: 600, caching: !0, hiddenTextareaContainer: null, _reSpace: /\s|\n/, _currentCursorOpacity: 0, _selectionDirection: null, _abortCursorAnimation: !1, __widthOfSpace: [], inCompositionMode: !1, initialize: function(a, c) {
      this.callSuper("initialize", a, c), this.initBehavior();
    }, setSelectionStart: function(a) {
      a = Math.max(a, 0), this._updateAndFire("selectionStart", a);
    }, setSelectionEnd: function(a) {
      a = Math.min(a, this.text.length), this._updateAndFire("selectionEnd", a);
    }, _updateAndFire: function(a, c) {
      this[a] !== c && (this._fireSelectionChanged(), this[a] = c), this._updateTextarea();
    }, _fireSelectionChanged: function() {
      this.fire("selection:changed"), this.canvas && this.canvas.fire("text:selection:changed", { target: this });
    }, initDimensions: function() {
      this.isEditing && this.initDelayedCursor(), this.clearContextTop(), this.callSuper("initDimensions");
    }, render: function(a) {
      this.clearContextTop(), this.callSuper("render", a), this.cursorOffsetCache = {}, this.renderCursorOrSelection();
    }, _render: function(a) {
      this.callSuper("_render", a);
    }, clearContextTop: function(a) {
      if (this.isEditing && this.canvas && this.canvas.contextTop) {
        var c = this.canvas.contextTop, f = this.canvas.viewportTransform;
        c.save(), c.transform(f[0], f[1], f[2], f[3], f[4], f[5]), this.transform(c), this._clearTextArea(c), a || c.restore();
      }
    }, renderCursorOrSelection: function() {
      if (this.isEditing && this.canvas && this.canvas.contextTop) {
        var a = this._getCursorBoundaries(), c = this.canvas.contextTop;
        this.clearContextTop(!0), this.selectionStart === this.selectionEnd ? this.renderCursor(a, c) : this.renderSelection(a, c), c.restore();
      }
    }, _clearTextArea: function(a) {
      var c = this.width + 4, f = this.height + 4;
      a.clearRect(-c / 2, -f / 2, c, f);
    }, _getCursorBoundaries: function(a) {
      a === void 0 && (a = this.selectionStart);
      var c = this._getLeftOffset(), f = this._getTopOffset(), i = this._getCursorBoundariesOffsets(a);
      return { left: c, top: f, leftOffset: i.left, topOffset: i.top };
    }, _getCursorBoundariesOffsets: function(a) {
      if (this.cursorOffsetCache && "top" in this.cursorOffsetCache) return this.cursorOffsetCache;
      var c, f, i, r, s = 0, h = 0, d = this.get2DCursorLocation(a);
      i = d.charIndex, f = d.lineIndex;
      for (var p = 0; p < f; p++) s += this.getHeightOfLine(p);
      c = this._getLineLeftOffset(f);
      var m = this.__charBounds[f][i];
      return m && (h = m.left), this.charSpacing !== 0 && i === this._textLines[f].length && (h -= this._getWidthOfCharSpacing()), r = { top: s, left: c + (h > 0 ? h : 0) }, this.direction === "rtl" && (r.left *= -1), this.cursorOffsetCache = r, this.cursorOffsetCache;
    }, renderCursor: function(a, c) {
      var f = this.get2DCursorLocation(), i = f.lineIndex, r = f.charIndex > 0 ? f.charIndex - 1 : 0, s = this.getValueOfPropertyAt(i, r, "fontSize"), h = this.scaleX * this.canvas.getZoom(), d = this.cursorWidth / h, p = a.topOffset, m = this.getValueOfPropertyAt(i, r, "deltaY");
      p += (1 - this._fontSizeFraction) * this.getHeightOfLine(i) / this.lineHeight - s * (1 - this._fontSizeFraction), this.inCompositionMode && this.renderSelection(a, c), c.fillStyle = this.cursorColor || this.getValueOfPropertyAt(i, r, "fill"), c.globalAlpha = this.__isMousedown ? 1 : this._currentCursorOpacity, c.fillRect(a.left + a.leftOffset - d / 2, p + a.top + m, d, s);
    }, renderSelection: function(a, c) {
      for (var f = this.inCompositionMode ? this.hiddenTextarea.selectionStart : this.selectionStart, i = this.inCompositionMode ? this.hiddenTextarea.selectionEnd : this.selectionEnd, r = this.textAlign.indexOf("justify") !== -1, s = this.get2DCursorLocation(f), h = this.get2DCursorLocation(i), d = s.lineIndex, p = h.lineIndex, m = s.charIndex < 0 ? 0 : s.charIndex, y = h.charIndex < 0 ? 0 : h.charIndex, _ = d; _ <= p; _++) {
        var k, T = this._getLineLeftOffset(_) || 0, D = this.getHeightOfLine(_), j = 0, w = 0;
        if (_ === d && (j = this.__charBounds[d][m].left), _ >= d && _ < p) w = r && !this.isEndOfWrapping(_) ? this.width : this.getLineWidth(_) || 5;
        else if (_ === p) if (y === 0) w = this.__charBounds[p][y].left;
        else {
          var O = this._getWidthOfCharSpacing();
          w = this.__charBounds[p][y - 1].left + this.__charBounds[p][y - 1].width - O;
        }
        k = D, (this.lineHeight < 1 || _ === p && this.lineHeight > 1) && (D /= this.lineHeight);
        var L = a.left + T + j, U = w - j, W = D, I = 0;
        this.inCompositionMode ? (c.fillStyle = this.compositionColor || "black", W = 1, I = D) : c.fillStyle = this.selectionColor, this.direction === "rtl" && (L = this.width - L - U), c.fillRect(L, a.top + a.topOffset + I, U, W), a.topOffset += k;
      }
    }, getCurrentCharFontSize: function() {
      var a = this._getCurrentCharIndex();
      return this.getValueOfPropertyAt(a.l, a.c, "fontSize");
    }, getCurrentCharColor: function() {
      var a = this._getCurrentCharIndex();
      return this.getValueOfPropertyAt(a.l, a.c, "fill");
    }, _getCurrentCharIndex: function() {
      var a = this.get2DCursorLocation(this.selectionStart, !0), c = a.charIndex > 0 ? a.charIndex - 1 : 0;
      return { l: a.lineIndex, c };
    } }), b.IText.fromObject = function(a, c) {
      if (l(a), a.styles) for (var f in a.styles) for (var i in a.styles[f]) l(a.styles[f][i]);
      b.Object._fromObject("IText", a, c, "text");
    };
  }(), gt = b.util.object.clone, b.util.object.extend(b.IText.prototype, { initBehavior: function() {
    this.initAddedHandler(), this.initRemovedHandler(), this.initCursorSelectionHandlers(), this.initDoubleClickSimulation(), this.mouseMoveHandler = this.mouseMoveHandler.bind(this);
  }, onDeselect: function() {
    this.isEditing && this.exitEditing(), this.selected = !1;
  }, initAddedHandler: function() {
    var l = this;
    this.on("added", function() {
      var a = l.canvas;
      a && (a._hasITextHandlers || (a._hasITextHandlers = !0, l._initCanvasHandlers(a)), a._iTextInstances = a._iTextInstances || [], a._iTextInstances.push(l));
    });
  }, initRemovedHandler: function() {
    var l = this;
    this.on("removed", function() {
      var a = l.canvas;
      a && (a._iTextInstances = a._iTextInstances || [], b.util.removeFromArray(a._iTextInstances, l), a._iTextInstances.length === 0 && (a._hasITextHandlers = !1, l._removeCanvasHandlers(a)));
    });
  }, _initCanvasHandlers: function(l) {
    l._mouseUpITextHandler = function() {
      l._iTextInstances && l._iTextInstances.forEach(function(a) {
        a.__isMousedown = !1;
      });
    }, l.on("mouse:up", l._mouseUpITextHandler);
  }, _removeCanvasHandlers: function(l) {
    l.off("mouse:up", l._mouseUpITextHandler);
  }, _tick: function() {
    this._currentTickState = this._animateCursor(this, 1, this.cursorDuration, "_onTickComplete");
  }, _animateCursor: function(l, a, c, f) {
    var i;
    return i = { isAborted: !1, abort: function() {
      this.isAborted = !0;
    } }, l.animate("_currentCursorOpacity", a, { duration: c, onComplete: function() {
      i.isAborted || l[f]();
    }, onChange: function() {
      l.canvas && l.selectionStart === l.selectionEnd && l.renderCursorOrSelection();
    }, abort: function() {
      return i.isAborted;
    } }), i;
  }, _onTickComplete: function() {
    var l = this;
    this._cursorTimeout1 && clearTimeout(this._cursorTimeout1), this._cursorTimeout1 = setTimeout(function() {
      l._currentTickCompleteState = l._animateCursor(l, 0, this.cursorDuration / 2, "_tick");
    }, 100);
  }, initDelayedCursor: function(l) {
    var a = this, c = l ? 0 : this.cursorDelay;
    this.abortCursorAnimation(), this._currentCursorOpacity = 1, this._cursorTimeout2 = setTimeout(function() {
      a._tick();
    }, c);
  }, abortCursorAnimation: function() {
    var l = this._currentTickState || this._currentTickCompleteState, a = this.canvas;
    this._currentTickState && this._currentTickState.abort(), this._currentTickCompleteState && this._currentTickCompleteState.abort(), clearTimeout(this._cursorTimeout1), clearTimeout(this._cursorTimeout2), this._currentCursorOpacity = 0, l && a && a.clearContext(a.contextTop || a.contextContainer);
  }, selectAll: function() {
    return this.selectionStart = 0, this.selectionEnd = this._text.length, this._fireSelectionChanged(), this._updateTextarea(), this;
  }, getSelectedText: function() {
    return this._text.slice(this.selectionStart, this.selectionEnd).join("");
  }, findWordBoundaryLeft: function(l) {
    var a = 0, c = l - 1;
    if (this._reSpace.test(this._text[c])) for (; this._reSpace.test(this._text[c]); ) a++, c--;
    for (; /\S/.test(this._text[c]) && c > -1; ) a++, c--;
    return l - a;
  }, findWordBoundaryRight: function(l) {
    var a = 0, c = l;
    if (this._reSpace.test(this._text[c])) for (; this._reSpace.test(this._text[c]); ) a++, c++;
    for (; /\S/.test(this._text[c]) && c < this._text.length; ) a++, c++;
    return l + a;
  }, findLineBoundaryLeft: function(l) {
    for (var a = 0, c = l - 1; !/\n/.test(this._text[c]) && c > -1; ) a++, c--;
    return l - a;
  }, findLineBoundaryRight: function(l) {
    for (var a = 0, c = l; !/\n/.test(this._text[c]) && c < this._text.length; ) a++, c++;
    return l + a;
  }, searchWordBoundary: function(l, a) {
    for (var c = this._text, f = this._reSpace.test(c[l]) ? l - 1 : l, i = c[f], r = b.reNonWord; !r.test(i) && f > 0 && f < c.length; ) i = c[f += a];
    return r.test(i) && (f += a === 1 ? 0 : 1), f;
  }, selectWord: function(l) {
    l = l || this.selectionStart;
    var a = this.searchWordBoundary(l, -1), c = this.searchWordBoundary(l, 1);
    this.selectionStart = a, this.selectionEnd = c, this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection();
  }, selectLine: function(l) {
    l = l || this.selectionStart;
    var a = this.findLineBoundaryLeft(l), c = this.findLineBoundaryRight(l);
    return this.selectionStart = a, this.selectionEnd = c, this._fireSelectionChanged(), this._updateTextarea(), this;
  }, enterEditing: function(l) {
    if (!this.isEditing && this.editable) return this.canvas && (this.canvas.calcOffset(), this.exitEditingOnOthers(this.canvas)), this.isEditing = !0, this.initHiddenTextarea(l), this.hiddenTextarea.focus(), this.hiddenTextarea.value = this.text, this._updateTextarea(), this._saveEditingProps(), this._setEditingProps(), this._textBeforeEdit = this.text, this._tick(), this.fire("editing:entered"), this._fireSelectionChanged(), this.canvas ? (this.canvas.fire("text:editing:entered", { target: this }), this.initMouseMoveHandler(), this.canvas.requestRenderAll(), this) : this;
  }, exitEditingOnOthers: function(l) {
    l._iTextInstances && l._iTextInstances.forEach(function(a) {
      a.selected = !1, a.isEditing && a.exitEditing();
    });
  }, initMouseMoveHandler: function() {
    this.canvas.on("mouse:move", this.mouseMoveHandler);
  }, mouseMoveHandler: function(l) {
    if (this.__isMousedown && this.isEditing) {
      var a = this.getSelectionStartFromPointer(l.e), c = this.selectionStart, f = this.selectionEnd;
      (a === this.__selectionStartOnMouseDown && c !== f || c !== a && f !== a) && (a > this.__selectionStartOnMouseDown ? (this.selectionStart = this.__selectionStartOnMouseDown, this.selectionEnd = a) : (this.selectionStart = a, this.selectionEnd = this.__selectionStartOnMouseDown), this.selectionStart === c && this.selectionEnd === f || (this.restartCursorIfNeeded(), this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection()));
    }
  }, _setEditingProps: function() {
    this.hoverCursor = "text", this.canvas && (this.canvas.defaultCursor = this.canvas.moveCursor = "text"), this.borderColor = this.editingBorderColor, this.hasControls = this.selectable = !1, this.lockMovementX = this.lockMovementY = !0;
  }, fromStringToGraphemeSelection: function(l, a, c) {
    var f = c.slice(0, l), i = b.util.string.graphemeSplit(f).length;
    if (l === a) return { selectionStart: i, selectionEnd: i };
    var r = c.slice(l, a);
    return { selectionStart: i, selectionEnd: i + b.util.string.graphemeSplit(r).length };
  }, fromGraphemeToStringSelection: function(l, a, c) {
    var f = c.slice(0, l).join("").length;
    return l === a ? { selectionStart: f, selectionEnd: f } : { selectionStart: f, selectionEnd: f + c.slice(l, a).join("").length };
  }, _updateTextarea: function() {
    if (this.cursorOffsetCache = {}, this.hiddenTextarea) {
      if (!this.inCompositionMode) {
        var l = this.fromGraphemeToStringSelection(this.selectionStart, this.selectionEnd, this._text);
        this.hiddenTextarea.selectionStart = l.selectionStart, this.hiddenTextarea.selectionEnd = l.selectionEnd;
      }
      this.updateTextareaPosition();
    }
  }, updateFromTextArea: function() {
    if (this.hiddenTextarea) {
      this.cursorOffsetCache = {}, this.text = this.hiddenTextarea.value, this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords());
      var l = this.fromStringToGraphemeSelection(this.hiddenTextarea.selectionStart, this.hiddenTextarea.selectionEnd, this.hiddenTextarea.value);
      this.selectionEnd = this.selectionStart = l.selectionEnd, this.inCompositionMode || (this.selectionStart = l.selectionStart), this.updateTextareaPosition();
    }
  }, updateTextareaPosition: function() {
    if (this.selectionStart === this.selectionEnd) {
      var l = this._calcTextareaPosition();
      this.hiddenTextarea.style.left = l.left, this.hiddenTextarea.style.top = l.top;
    }
  }, _calcTextareaPosition: function() {
    if (!this.canvas) return { x: 1, y: 1 };
    var l = this.inCompositionMode ? this.compositionStart : this.selectionStart, a = this._getCursorBoundaries(l), c = this.get2DCursorLocation(l), f = c.lineIndex, i = c.charIndex, r = this.getValueOfPropertyAt(f, i, "fontSize") * this.lineHeight, s = a.leftOffset, h = this.calcTransformMatrix(), d = { x: a.left + s, y: a.top + a.topOffset + r }, p = this.canvas.getRetinaScaling(), m = this.canvas.upperCanvasEl, y = m.width / p, _ = m.height / p, k = y - r, T = _ - r, D = m.clientWidth / y, j = m.clientHeight / _;
    return d = b.util.transformPoint(d, h), (d = b.util.transformPoint(d, this.canvas.viewportTransform)).x *= D, d.y *= j, d.x < 0 && (d.x = 0), d.x > k && (d.x = k), d.y < 0 && (d.y = 0), d.y > T && (d.y = T), d.x += this.canvas._offset.left, d.y += this.canvas._offset.top, { left: d.x + "px", top: d.y + "px", fontSize: r + "px", charHeight: r };
  }, _saveEditingProps: function() {
    this._savedProps = { hasControls: this.hasControls, borderColor: this.borderColor, lockMovementX: this.lockMovementX, lockMovementY: this.lockMovementY, hoverCursor: this.hoverCursor, selectable: this.selectable, defaultCursor: this.canvas && this.canvas.defaultCursor, moveCursor: this.canvas && this.canvas.moveCursor };
  }, _restoreEditingProps: function() {
    this._savedProps && (this.hoverCursor = this._savedProps.hoverCursor, this.hasControls = this._savedProps.hasControls, this.borderColor = this._savedProps.borderColor, this.selectable = this._savedProps.selectable, this.lockMovementX = this._savedProps.lockMovementX, this.lockMovementY = this._savedProps.lockMovementY, this.canvas && (this.canvas.defaultCursor = this._savedProps.defaultCursor, this.canvas.moveCursor = this._savedProps.moveCursor));
  }, exitEditing: function() {
    var l = this._textBeforeEdit !== this.text, a = this.hiddenTextarea;
    return this.selected = !1, this.isEditing = !1, this.selectionEnd = this.selectionStart, a && (a.blur && a.blur(), a.parentNode && a.parentNode.removeChild(a)), this.hiddenTextarea = null, this.abortCursorAnimation(), this._restoreEditingProps(), this._currentCursorOpacity = 0, this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this.fire("editing:exited"), l && this.fire("modified"), this.canvas && (this.canvas.off("mouse:move", this.mouseMoveHandler), this.canvas.fire("text:editing:exited", { target: this }), l && this.canvas.fire("object:modified", { target: this })), this;
  }, _removeExtraneousStyles: function() {
    for (var l in this.styles) this._textLines[l] || delete this.styles[l];
  }, removeStyleFromTo: function(l, a) {
    var c, f, i = this.get2DCursorLocation(l, !0), r = this.get2DCursorLocation(a, !0), s = i.lineIndex, h = i.charIndex, d = r.lineIndex, p = r.charIndex;
    if (s !== d) {
      if (this.styles[s]) for (c = h; c < this._unwrappedTextLines[s].length; c++) delete this.styles[s][c];
      if (this.styles[d]) for (c = p; c < this._unwrappedTextLines[d].length; c++) (f = this.styles[d][c]) && (this.styles[s] || (this.styles[s] = {}), this.styles[s][h + c - p] = f);
      for (c = s + 1; c <= d; c++) delete this.styles[c];
      this.shiftLineStyles(d, s - d);
    } else if (this.styles[s]) {
      f = this.styles[s];
      var m, y, _ = p - h;
      for (c = h; c < p; c++) delete f[c];
      for (y in this.styles[s]) (m = parseInt(y, 10)) >= p && (f[m - _] = f[y], delete f[y]);
    }
  }, shiftLineStyles: function(l, a) {
    var c = gt(this.styles);
    for (var f in this.styles) {
      var i = parseInt(f, 10);
      i > l && (this.styles[i + a] = c[i], c[i - a] || delete this.styles[i]);
    }
  }, restartCursorIfNeeded: function() {
    this._currentTickState && !this._currentTickState.isAborted && this._currentTickCompleteState && !this._currentTickCompleteState.isAborted || this.initDelayedCursor();
  }, insertNewlineStyleObject: function(l, a, c, f) {
    var i, r = {}, s = !1, h = this._unwrappedTextLines[l].length === a;
    for (var d in c || (c = 1), this.shiftLineStyles(l, c), this.styles[l] && (i = this.styles[l][a === 0 ? a : a - 1]), this.styles[l]) {
      var p = parseInt(d, 10);
      p >= a && (s = !0, r[p - a] = this.styles[l][d], h && a === 0 || delete this.styles[l][d]);
    }
    var m = !1;
    for (s && !h && (this.styles[l + c] = r, m = !0), m && c--; c > 0; ) f && f[c - 1] ? this.styles[l + c] = { 0: gt(f[c - 1]) } : i ? this.styles[l + c] = { 0: gt(i) } : delete this.styles[l + c], c--;
    this._forceClearCache = !0;
  }, insertCharStyleObject: function(l, a, c, f) {
    this.styles || (this.styles = {});
    var i = this.styles[l], r = i ? gt(i) : {};
    for (var s in c || (c = 1), r) {
      var h = parseInt(s, 10);
      h >= a && (i[h + c] = r[h], r[h - c] || delete i[h]);
    }
    if (this._forceClearCache = !0, f) for (; c--; ) Object.keys(f[c]).length && (this.styles[l] || (this.styles[l] = {}), this.styles[l][a + c] = gt(f[c]));
    else if (i) for (var d = i[a ? a - 1 : 1]; d && c--; ) this.styles[l][a + c] = gt(d);
  }, insertNewStyleBlock: function(l, a, c) {
    for (var f = this.get2DCursorLocation(a, !0), i = [0], r = 0, s = 0; s < l.length; s++) l[s] === `
` ? i[++r] = 0 : i[r]++;
    for (i[0] > 0 && (this.insertCharStyleObject(f.lineIndex, f.charIndex, i[0], c), c = c && c.slice(i[0] + 1)), r && this.insertNewlineStyleObject(f.lineIndex, f.charIndex + i[0], r), s = 1; s < r; s++) i[s] > 0 ? this.insertCharStyleObject(f.lineIndex + s, 0, i[s], c) : c && (this.styles[f.lineIndex + s][0] = c[0]), c = c && c.slice(i[s] + 1);
    i[s] > 0 && this.insertCharStyleObject(f.lineIndex + s, 0, i[s], c);
  }, setSelectionStartEndWithShift: function(l, a, c) {
    c <= l ? (a === l ? this._selectionDirection = "left" : this._selectionDirection === "right" && (this._selectionDirection = "left", this.selectionEnd = l), this.selectionStart = c) : c > l && c < a ? this._selectionDirection === "right" ? this.selectionEnd = c : this.selectionStart = c : (a === l ? this._selectionDirection = "right" : this._selectionDirection === "left" && (this._selectionDirection = "right", this.selectionStart = a), this.selectionEnd = c);
  }, setSelectionInBoundaries: function() {
    var l = this.text.length;
    this.selectionStart > l ? this.selectionStart = l : this.selectionStart < 0 && (this.selectionStart = 0), this.selectionEnd > l ? this.selectionEnd = l : this.selectionEnd < 0 && (this.selectionEnd = 0);
  } }), b.util.object.extend(b.IText.prototype, { initDoubleClickSimulation: function() {
    this.__lastClickTime = +/* @__PURE__ */ new Date(), this.__lastLastClickTime = +/* @__PURE__ */ new Date(), this.__lastPointer = {}, this.on("mousedown", this.onMouseDown);
  }, onMouseDown: function(l) {
    if (this.canvas) {
      this.__newClickTime = +/* @__PURE__ */ new Date();
      var a = l.pointer;
      this.isTripleClick(a) && (this.fire("tripleclick", l), this._stopEvent(l.e)), this.__lastLastClickTime = this.__lastClickTime, this.__lastClickTime = this.__newClickTime, this.__lastPointer = a, this.__lastIsEditing = this.isEditing, this.__lastSelected = this.selected;
    }
  }, isTripleClick: function(l) {
    return this.__newClickTime - this.__lastClickTime < 500 && this.__lastClickTime - this.__lastLastClickTime < 500 && this.__lastPointer.x === l.x && this.__lastPointer.y === l.y;
  }, _stopEvent: function(l) {
    l.preventDefault && l.preventDefault(), l.stopPropagation && l.stopPropagation();
  }, initCursorSelectionHandlers: function() {
    this.initMousedownHandler(), this.initMouseupHandler(), this.initClicks();
  }, doubleClickHandler: function(l) {
    this.isEditing && this.selectWord(this.getSelectionStartFromPointer(l.e));
  }, tripleClickHandler: function(l) {
    this.isEditing && this.selectLine(this.getSelectionStartFromPointer(l.e));
  }, initClicks: function() {
    this.on("mousedblclick", this.doubleClickHandler), this.on("tripleclick", this.tripleClickHandler);
  }, _mouseDownHandler: function(l) {
    !this.canvas || !this.editable || l.e.button && l.e.button !== 1 || (this.__isMousedown = !0, this.selected && (this.inCompositionMode = !1, this.setCursorByClick(l.e)), this.isEditing && (this.__selectionStartOnMouseDown = this.selectionStart, this.selectionStart === this.selectionEnd && this.abortCursorAnimation(), this.renderCursorOrSelection()));
  }, _mouseDownHandlerBefore: function(l) {
    !this.canvas || !this.editable || l.e.button && l.e.button !== 1 || (this.selected = this === this.canvas._activeObject);
  }, initMousedownHandler: function() {
    this.on("mousedown", this._mouseDownHandler), this.on("mousedown:before", this._mouseDownHandlerBefore);
  }, initMouseupHandler: function() {
    this.on("mouseup", this.mouseUpHandler);
  }, mouseUpHandler: function(l) {
    if (this.__isMousedown = !1, !(!this.editable || this.group || l.transform && l.transform.actionPerformed || l.e.button && l.e.button !== 1)) {
      if (this.canvas) {
        var a = this.canvas._activeObject;
        if (a && a !== this) return;
      }
      this.__lastSelected && !this.__corner ? (this.selected = !1, this.__lastSelected = !1, this.enterEditing(l.e), this.selectionStart === this.selectionEnd ? this.initDelayedCursor(!0) : this.renderCursorOrSelection()) : this.selected = !0;
    }
  }, setCursorByClick: function(l) {
    var a = this.getSelectionStartFromPointer(l), c = this.selectionStart, f = this.selectionEnd;
    l.shiftKey ? this.setSelectionStartEndWithShift(c, f, a) : (this.selectionStart = a, this.selectionEnd = a), this.isEditing && (this._fireSelectionChanged(), this._updateTextarea());
  }, getSelectionStartFromPointer: function(l) {
    for (var a, c = this.getLocalPointer(l), f = 0, i = 0, r = 0, s = 0, h = 0, d = 0, p = this._textLines.length; d < p && r <= c.y; d++) r += this.getHeightOfLine(d) * this.scaleY, h = d, d > 0 && (s += this._textLines[d - 1].length + this.missingNewlineOffset(d - 1));
    i = this._getLineLeftOffset(h) * this.scaleX, a = this._textLines[h], this.direction === "rtl" && (c.x = this.width * this.scaleX - c.x + i);
    for (var m = 0, y = a.length; m < y && (f = i, (i += this.__charBounds[h][m].kernedWidth * this.scaleX) <= c.x); m++) s++;
    return this._getNewSelectionStartFromOffset(c, f, i, s, y);
  }, _getNewSelectionStartFromOffset: function(l, a, c, f, i) {
    var r = l.x - a, s = c - l.x, h = f + (s > r || s < 0 ? 0 : 1);
    return this.flipX && (h = i - h), h > this._text.length && (h = this._text.length), h;
  } }), b.util.object.extend(b.IText.prototype, { initHiddenTextarea: function() {
    this.hiddenTextarea = b.document.createElement("textarea"), this.hiddenTextarea.setAttribute("autocapitalize", "off"), this.hiddenTextarea.setAttribute("autocorrect", "off"), this.hiddenTextarea.setAttribute("autocomplete", "off"), this.hiddenTextarea.setAttribute("spellcheck", "false"), this.hiddenTextarea.setAttribute("data-fabric-hiddentextarea", ""), this.hiddenTextarea.setAttribute("wrap", "off");
    var l = this._calcTextareaPosition();
    this.hiddenTextarea.style.cssText = "position: absolute; top: " + l.top + "; left: " + l.left + "; z-index: -999; opacity: 0; width: 1px; height: 1px; font-size: 1px; paddingｰtop: " + l.fontSize + ";", this.hiddenTextareaContainer ? this.hiddenTextareaContainer.appendChild(this.hiddenTextarea) : b.document.body.appendChild(this.hiddenTextarea), b.util.addListener(this.hiddenTextarea, "keydown", this.onKeyDown.bind(this)), b.util.addListener(this.hiddenTextarea, "keyup", this.onKeyUp.bind(this)), b.util.addListener(this.hiddenTextarea, "input", this.onInput.bind(this)), b.util.addListener(this.hiddenTextarea, "copy", this.copy.bind(this)), b.util.addListener(this.hiddenTextarea, "cut", this.copy.bind(this)), b.util.addListener(this.hiddenTextarea, "paste", this.paste.bind(this)), b.util.addListener(this.hiddenTextarea, "compositionstart", this.onCompositionStart.bind(this)), b.util.addListener(this.hiddenTextarea, "compositionupdate", this.onCompositionUpdate.bind(this)), b.util.addListener(this.hiddenTextarea, "compositionend", this.onCompositionEnd.bind(this)), !this._clickHandlerInitialized && this.canvas && (b.util.addListener(this.canvas.upperCanvasEl, "click", this.onClick.bind(this)), this._clickHandlerInitialized = !0);
  }, keysMap: { 9: "exitEditing", 27: "exitEditing", 33: "moveCursorUp", 34: "moveCursorDown", 35: "moveCursorRight", 36: "moveCursorLeft", 37: "moveCursorLeft", 38: "moveCursorUp", 39: "moveCursorRight", 40: "moveCursorDown" }, keysMapRtl: { 9: "exitEditing", 27: "exitEditing", 33: "moveCursorUp", 34: "moveCursorDown", 35: "moveCursorLeft", 36: "moveCursorRight", 37: "moveCursorRight", 38: "moveCursorUp", 39: "moveCursorLeft", 40: "moveCursorDown" }, ctrlKeysMapUp: { 67: "copy", 88: "cut" }, ctrlKeysMapDown: { 65: "selectAll" }, onClick: function() {
    this.hiddenTextarea && this.hiddenTextarea.focus();
  }, onKeyDown: function(l) {
    if (this.isEditing) {
      var a = this.direction === "rtl" ? this.keysMapRtl : this.keysMap;
      if (l.keyCode in a) this[a[l.keyCode]](l);
      else {
        if (!(l.keyCode in this.ctrlKeysMapDown) || !l.ctrlKey && !l.metaKey) return;
        this[this.ctrlKeysMapDown[l.keyCode]](l);
      }
      l.stopImmediatePropagation(), l.preventDefault(), l.keyCode >= 33 && l.keyCode <= 40 ? (this.inCompositionMode = !1, this.clearContextTop(), this.renderCursorOrSelection()) : this.canvas && this.canvas.requestRenderAll();
    }
  }, onKeyUp: function(l) {
    !this.isEditing || this._copyDone || this.inCompositionMode ? this._copyDone = !1 : l.keyCode in this.ctrlKeysMapUp && (l.ctrlKey || l.metaKey) && (this[this.ctrlKeysMapUp[l.keyCode]](l), l.stopImmediatePropagation(), l.preventDefault(), this.canvas && this.canvas.requestRenderAll());
  }, onInput: function(l) {
    var a = this.fromPaste;
    if (this.fromPaste = !1, l && l.stopPropagation(), this.isEditing) {
      var c, f, i, r, s, h = this._splitTextIntoLines(this.hiddenTextarea.value).graphemeText, d = this._text.length, p = h.length, m = p - d, y = this.selectionStart, _ = this.selectionEnd, k = y !== _;
      if (this.hiddenTextarea.value === "") return this.styles = {}, this.updateFromTextArea(), this.fire("changed"), void (this.canvas && (this.canvas.fire("text:changed", { target: this }), this.canvas.requestRenderAll()));
      var T = this.fromStringToGraphemeSelection(this.hiddenTextarea.selectionStart, this.hiddenTextarea.selectionEnd, this.hiddenTextarea.value), D = y > T.selectionStart;
      k ? (c = this._text.slice(y, _), m += _ - y) : p < d && (c = D ? this._text.slice(_ + m, _) : this._text.slice(y, y - m)), f = h.slice(T.selectionEnd - m, T.selectionEnd), c && c.length && (f.length && (i = this.getSelectionStyles(y, y + 1, !1), i = f.map(function() {
        return i[0];
      })), k ? (r = y, s = _) : D ? (r = _ - c.length, s = _) : (r = _, s = _ + c.length), this.removeStyleFromTo(r, s)), f.length && (a && f.join("") === b.copiedText && !b.disableStyleCopyPaste && (i = b.copiedTextStyle), this.insertNewStyleBlock(f, y, i)), this.updateFromTextArea(), this.fire("changed"), this.canvas && (this.canvas.fire("text:changed", { target: this }), this.canvas.requestRenderAll());
    }
  }, onCompositionStart: function() {
    this.inCompositionMode = !0;
  }, onCompositionEnd: function() {
    this.inCompositionMode = !1;
  }, onCompositionUpdate: function(l) {
    this.compositionStart = l.target.selectionStart, this.compositionEnd = l.target.selectionEnd, this.updateTextareaPosition();
  }, copy: function() {
    this.selectionStart !== this.selectionEnd && (b.copiedText = this.getSelectedText(), b.disableStyleCopyPaste ? b.copiedTextStyle = null : b.copiedTextStyle = this.getSelectionStyles(this.selectionStart, this.selectionEnd, !0), this._copyDone = !0);
  }, paste: function() {
    this.fromPaste = !0;
  }, _getClipboardData: function(l) {
    return l && l.clipboardData || b.window.clipboardData;
  }, _getWidthBeforeCursor: function(l, a) {
    var c, f = this._getLineLeftOffset(l);
    return a > 0 && (f += (c = this.__charBounds[l][a - 1]).left + c.width), f;
  }, getDownCursorOffset: function(l, a) {
    var c = this._getSelectionForOffset(l, a), f = this.get2DCursorLocation(c), i = f.lineIndex;
    if (i === this._textLines.length - 1 || l.metaKey || l.keyCode === 34) return this._text.length - c;
    var r = f.charIndex, s = this._getWidthBeforeCursor(i, r), h = this._getIndexOnLine(i + 1, s);
    return this._textLines[i].slice(r).length + h + 1 + this.missingNewlineOffset(i);
  }, _getSelectionForOffset: function(l, a) {
    return l.shiftKey && this.selectionStart !== this.selectionEnd && a ? this.selectionEnd : this.selectionStart;
  }, getUpCursorOffset: function(l, a) {
    var c = this._getSelectionForOffset(l, a), f = this.get2DCursorLocation(c), i = f.lineIndex;
    if (i === 0 || l.metaKey || l.keyCode === 33) return -c;
    var r = f.charIndex, s = this._getWidthBeforeCursor(i, r), h = this._getIndexOnLine(i - 1, s), d = this._textLines[i].slice(0, r), p = this.missingNewlineOffset(i - 1);
    return -this._textLines[i - 1].length + h - d.length + (1 - p);
  }, _getIndexOnLine: function(l, a) {
    for (var c, f, i = this._textLines[l], r = this._getLineLeftOffset(l), s = 0, h = 0, d = i.length; h < d; h++) if ((r += c = this.__charBounds[l][h].width) > a) {
      f = !0;
      var p = r - c, m = r, y = Math.abs(p - a);
      s = Math.abs(m - a) < y ? h : h - 1;
      break;
    }
    return f || (s = i.length - 1), s;
  }, moveCursorDown: function(l) {
    this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorUpOrDown("Down", l);
  }, moveCursorUp: function(l) {
    this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorUpOrDown("Up", l);
  }, _moveCursorUpOrDown: function(l, a) {
    var c = this["get" + l + "CursorOffset"](a, this._selectionDirection === "right");
    a.shiftKey ? this.moveCursorWithShift(c) : this.moveCursorWithoutShift(c), c !== 0 && (this.setSelectionInBoundaries(), this.abortCursorAnimation(), this._currentCursorOpacity = 1, this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
  }, moveCursorWithShift: function(l) {
    var a = this._selectionDirection === "left" ? this.selectionStart + l : this.selectionEnd + l;
    return this.setSelectionStartEndWithShift(this.selectionStart, this.selectionEnd, a), l !== 0;
  }, moveCursorWithoutShift: function(l) {
    return l < 0 ? (this.selectionStart += l, this.selectionEnd = this.selectionStart) : (this.selectionEnd += l, this.selectionStart = this.selectionEnd), l !== 0;
  }, moveCursorLeft: function(l) {
    this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorLeftOrRight("Left", l);
  }, _move: function(l, a, c) {
    var f;
    if (l.altKey) f = this["findWordBoundary" + c](this[a]);
    else {
      if (!l.metaKey && l.keyCode !== 35 && l.keyCode !== 36) return this[a] += c === "Left" ? -1 : 1, !0;
      f = this["findLineBoundary" + c](this[a]);
    }
    if (typeof f !== void 0 && this[a] !== f) return this[a] = f, !0;
  }, _moveLeft: function(l, a) {
    return this._move(l, a, "Left");
  }, _moveRight: function(l, a) {
    return this._move(l, a, "Right");
  }, moveCursorLeftWithoutShift: function(l) {
    var a = !0;
    return this._selectionDirection = "left", this.selectionEnd === this.selectionStart && this.selectionStart !== 0 && (a = this._moveLeft(l, "selectionStart")), this.selectionEnd = this.selectionStart, a;
  }, moveCursorLeftWithShift: function(l) {
    return this._selectionDirection === "right" && this.selectionStart !== this.selectionEnd ? this._moveLeft(l, "selectionEnd") : this.selectionStart !== 0 ? (this._selectionDirection = "left", this._moveLeft(l, "selectionStart")) : void 0;
  }, moveCursorRight: function(l) {
    this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorLeftOrRight("Right", l);
  }, _moveCursorLeftOrRight: function(l, a) {
    var c = "moveCursor" + l + "With";
    this._currentCursorOpacity = 1, a.shiftKey ? c += "Shift" : c += "outShift", this[c](a) && (this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
  }, moveCursorRightWithShift: function(l) {
    return this._selectionDirection === "left" && this.selectionStart !== this.selectionEnd ? this._moveRight(l, "selectionStart") : this.selectionEnd !== this._text.length ? (this._selectionDirection = "right", this._moveRight(l, "selectionEnd")) : void 0;
  }, moveCursorRightWithoutShift: function(l) {
    var a = !0;
    return this._selectionDirection = "right", this.selectionStart === this.selectionEnd ? (a = this._moveRight(l, "selectionStart"), this.selectionEnd = this.selectionStart) : this.selectionStart = this.selectionEnd, a;
  }, removeChars: function(l, a) {
    a === void 0 && (a = l + 1), this.removeStyleFromTo(l, a), this._text.splice(l, a - l), this.text = this._text.join(""), this.set("dirty", !0), this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this._removeExtraneousStyles();
  }, insertChars: function(l, a, c, f) {
    f === void 0 && (f = c), f > c && this.removeStyleFromTo(c, f);
    var i = b.util.string.graphemeSplit(l);
    this.insertNewStyleBlock(i, c, a), this._text = [].concat(this._text.slice(0, c), i, this._text.slice(f)), this.text = this._text.join(""), this.set("dirty", !0), this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this._removeExtraneousStyles();
  } }), function() {
    var l = b.util.toFixed, a = /  +/g;
    b.util.object.extend(b.Text.prototype, { _toSVG: function() {
      var c = this._getSVGLeftTopOffsets(), f = this._getSVGTextAndBg(c.textTop, c.textLeft);
      return this._wrapSVGTextAndBg(f);
    }, toSVG: function(c) {
      return this._createBaseSVGMarkup(this._toSVG(), { reviver: c, noStyle: !0, withShadow: !0 });
    }, _getSVGLeftTopOffsets: function() {
      return { textLeft: -this.width / 2, textTop: -this.height / 2, lineTop: this.getHeightOfLine(0) };
    }, _wrapSVGTextAndBg: function(c) {
      var f = this.getSvgTextDecoration(this);
      return [c.textBgRects.join(""), '		<text xml:space="preserve" ', this.fontFamily ? 'font-family="' + this.fontFamily.replace(/"/g, "'") + '" ' : "", this.fontSize ? 'font-size="' + this.fontSize + '" ' : "", this.fontStyle ? 'font-style="' + this.fontStyle + '" ' : "", this.fontWeight ? 'font-weight="' + this.fontWeight + '" ' : "", f ? 'text-decoration="' + f + '" ' : "", 'style="', this.getSvgStyles(!0), '"', this.addPaintOrder(), " >", c.textSpans.join(""), `</text>
`];
    }, _getSVGTextAndBg: function(c, f) {
      var i, r = [], s = [], h = c;
      this._setSVGBg(s);
      for (var d = 0, p = this._textLines.length; d < p; d++) i = this._getLineLeftOffset(d), (this.textBackgroundColor || this.styleHas("textBackgroundColor", d)) && this._setSVGTextLineBg(s, d, f + i, h), this._setSVGTextLineText(r, d, f + i, h), h += this.getHeightOfLine(d);
      return { textSpans: r, textBgRects: s };
    }, _createTextCharSpan: function(c, f, i, r) {
      var s = c !== c.trim() || c.match(a), h = this.getSvgSpanStyles(f, s), d = h ? 'style="' + h + '"' : "", p = f.deltaY, m = "", y = b.Object.NUM_FRACTION_DIGITS;
      return p && (m = ' dy="' + l(p, y) + '" '), ['<tspan x="', l(i, y), '" y="', l(r, y), '" ', m, d, ">", b.util.string.escapeXml(c), "</tspan>"].join("");
    }, _setSVGTextLineText: function(c, f, i, r) {
      var s, h, d, p, m, y = this.getHeightOfLine(f), _ = this.textAlign.indexOf("justify") !== -1, k = "", T = 0, D = this._textLines[f];
      r += y * (1 - this._fontSizeFraction) / this.lineHeight;
      for (var j = 0, w = D.length - 1; j <= w; j++) m = j === w || this.charSpacing, k += D[j], d = this.__charBounds[f][j], T === 0 ? (i += d.kernedWidth - d.width, T += d.width) : T += d.kernedWidth, _ && !m && this._reSpaceAndTab.test(D[j]) && (m = !0), m || (s = s || this.getCompleteStyleDeclaration(f, j), h = this.getCompleteStyleDeclaration(f, j + 1), m = this._hasStyleChangedForSvg(s, h)), m && (p = this._getStyleDeclaration(f, j) || {}, c.push(this._createTextCharSpan(k, p, i, r)), k = "", s = h, i += T, T = 0);
    }, _pushTextBgRect: function(c, f, i, r, s, h) {
      var d = b.Object.NUM_FRACTION_DIGITS;
      c.push("		<rect ", this._getFillAttributes(f), ' x="', l(i, d), '" y="', l(r, d), '" width="', l(s, d), '" height="', l(h, d), `"></rect>
`);
    }, _setSVGTextLineBg: function(c, f, i, r) {
      for (var s, h, d = this._textLines[f], p = this.getHeightOfLine(f) / this.lineHeight, m = 0, y = 0, _ = this.getValueOfPropertyAt(f, 0, "textBackgroundColor"), k = 0, T = d.length; k < T; k++) s = this.__charBounds[f][k], (h = this.getValueOfPropertyAt(f, k, "textBackgroundColor")) !== _ ? (_ && this._pushTextBgRect(c, _, i + y, r, m, p), y = s.left, m = s.width, _ = h) : m += s.kernedWidth;
      h && this._pushTextBgRect(c, h, i + y, r, m, p);
    }, _getFillAttributes: function(c) {
      var f = c && typeof c == "string" ? new b.Color(c) : "";
      return f && f.getSource() && f.getAlpha() !== 1 ? 'opacity="' + f.getAlpha() + '" fill="' + f.setAlpha(1).toRgb() + '"' : 'fill="' + c + '"';
    }, _getSVGLineTopOffset: function(c) {
      for (var f, i = 0, r = 0; r < c; r++) i += this.getHeightOfLine(r);
      return f = this.getHeightOfLine(r), { lineTop: i, offset: (this._fontSizeMult - this._fontSizeFraction) * f / (this.lineHeight * this._fontSizeMult) };
    }, getSvgStyles: function(c) {
      return b.Object.prototype.getSvgStyles.call(this, c) + " white-space: pre;";
    } });
  }(), function(l) {
    var a = l.fabric || (l.fabric = {});
    a.Textbox = a.util.createClass(a.IText, a.Observable, { type: "textbox", minWidth: 20, dynamicMinWidth: 2, __cachedLines: null, lockScalingFlip: !0, noScaleCache: !1, _dimensionAffectingProps: a.Text.prototype._dimensionAffectingProps.concat("width"), _wordJoiners: /[ \t\r]/, splitByGrapheme: !1, initDimensions: function() {
      this.__skipDimension || (this.isEditing && this.initDelayedCursor(), this.clearContextTop(), this._clearCache(), this.dynamicMinWidth = 0, this._styleMap = this._generateStyleMap(this._splitText()), this.dynamicMinWidth > this.width && this._set("width", this.dynamicMinWidth), this.textAlign.indexOf("justify") !== -1 && this.enlargeSpaces(), this.height = this.calcTextHeight(), this.saveState({ propertySet: "_dimensionAffectingProps" }));
    }, _generateStyleMap: function(c) {
      for (var f = 0, i = 0, r = 0, s = {}, h = 0; h < c.graphemeLines.length; h++) c.graphemeText[r] === `
` && h > 0 ? (i = 0, r++, f++) : !this.splitByGrapheme && this._reSpaceAndTab.test(c.graphemeText[r]) && h > 0 && (i++, r++), s[h] = { line: f, offset: i }, r += c.graphemeLines[h].length, i += c.graphemeLines[h].length;
      return s;
    }, styleHas: function(c, f) {
      if (this._styleMap && !this.isWrapping) {
        var i = this._styleMap[f];
        i && (f = i.line);
      }
      return a.Text.prototype.styleHas.call(this, c, f);
    }, isEmptyStyles: function(c) {
      if (!this.styles) return !0;
      var f, i, r = 0, s = !1, h = this._styleMap[c], d = this._styleMap[c + 1];
      for (var p in h && (c = h.line, r = h.offset), d && (s = d.line === c, f = d.offset), i = c === void 0 ? this.styles : { line: this.styles[c] }) for (var m in i[p]) if (m >= r && (!s || m < f)) for (var y in i[p][m]) return !1;
      return !0;
    }, _getStyleDeclaration: function(c, f) {
      if (this._styleMap && !this.isWrapping) {
        var i = this._styleMap[c];
        if (!i) return null;
        c = i.line, f = i.offset + f;
      }
      return this.callSuper("_getStyleDeclaration", c, f);
    }, _setStyleDeclaration: function(c, f, i) {
      var r = this._styleMap[c];
      c = r.line, f = r.offset + f, this.styles[c][f] = i;
    }, _deleteStyleDeclaration: function(c, f) {
      var i = this._styleMap[c];
      c = i.line, f = i.offset + f, delete this.styles[c][f];
    }, _getLineStyle: function(c) {
      var f = this._styleMap[c];
      return !!this.styles[f.line];
    }, _setLineStyle: function(c) {
      var f = this._styleMap[c];
      this.styles[f.line] = {};
    }, _wrapText: function(c, f) {
      var i, r = [];
      for (this.isWrapping = !0, i = 0; i < c.length; i++) r = r.concat(this._wrapLine(c[i], i, f));
      return this.isWrapping = !1, r;
    }, _measureWord: function(c, f, i) {
      var r, s = 0;
      i = i || 0;
      for (var h = 0, d = c.length; h < d; h++)
        s += this._getGraphemeBox(c[h], f, h + i, r, !0).kernedWidth, r = c[h];
      return s;
    }, _wrapLine: function(c, f, i, r) {
      var s = 0, h = this.splitByGrapheme, d = [], p = [], m = h ? a.util.string.graphemeSplit(c) : c.split(this._wordJoiners), y = "", _ = 0, k = h ? "" : " ", T = 0, D = 0, j = 0, w = !0, O = this._getWidthOfCharSpacing();
      r = r || 0, m.length === 0 && m.push([]), i -= r;
      for (var L = 0; L < m.length; L++) y = h ? m[L] : a.util.string.graphemeSplit(m[L]), T = this._measureWord(y, f, _), _ += y.length, (s += D + T - O) > i && !w ? (d.push(p), p = [], s = T, w = !0) : s += O, w || h || p.push(k), p = p.concat(y), D = h ? 0 : this._measureWord([k], f, _), _++, w = !1, T > j && (j = T);
      return L && d.push(p), j + r > this.dynamicMinWidth && (this.dynamicMinWidth = j - O + r), d;
    }, isEndOfWrapping: function(c) {
      return !this._styleMap[c + 1] || this._styleMap[c + 1].line !== this._styleMap[c].line;
    }, missingNewlineOffset: function(c) {
      return this.splitByGrapheme ? this.isEndOfWrapping(c) ? 1 : 0 : 1;
    }, _splitTextIntoLines: function(c) {
      for (var f = a.Text.prototype._splitTextIntoLines.call(this, c), i = this._wrapText(f.lines, this.width), r = new Array(i.length), s = 0; s < i.length; s++) r[s] = i[s].join("");
      return f.lines = r, f.graphemeLines = i, f;
    }, getMinWidth: function() {
      return Math.max(this.minWidth, this.dynamicMinWidth);
    }, _removeExtraneousStyles: function() {
      var c = {};
      for (var f in this._styleMap) this._textLines[f] && (c[this._styleMap[f].line] = 1);
      for (var f in this.styles) c[f] || delete this.styles[f];
    }, toObject: function(c) {
      return this.callSuper("toObject", ["minWidth", "splitByGrapheme"].concat(c));
    } }), a.Textbox.fromObject = function(c, f) {
      return a.Object._fromObject("Textbox", c, f, "text");
    };
  }(t), function() {
    var l = b.controlsUtils, a = l.scaleSkewCursorStyleHandler, c = l.scaleCursorStyleHandler, f = l.scalingEqually, i = l.scalingYOrSkewingX, r = l.scalingXOrSkewingY, s = l.scaleOrSkewActionName, h = b.Object.prototype.controls;
    if (h.ml = new b.Control({ x: -0.5, y: 0, cursorStyleHandler: a, actionHandler: r, getActionName: s }), h.mr = new b.Control({ x: 0.5, y: 0, cursorStyleHandler: a, actionHandler: r, getActionName: s }), h.mb = new b.Control({ x: 0, y: 0.5, cursorStyleHandler: a, actionHandler: i, getActionName: s }), h.mt = new b.Control({ x: 0, y: -0.5, cursorStyleHandler: a, actionHandler: i, getActionName: s }), h.tl = new b.Control({ x: -0.5, y: -0.5, cursorStyleHandler: c, actionHandler: f }), h.tr = new b.Control({ x: 0.5, y: -0.5, cursorStyleHandler: c, actionHandler: f }), h.bl = new b.Control({ x: -0.5, y: 0.5, cursorStyleHandler: c, actionHandler: f }), h.br = new b.Control({ x: 0.5, y: 0.5, cursorStyleHandler: c, actionHandler: f }), h.mtr = new b.Control({ x: 0, y: -0.5, actionHandler: l.rotationWithSnapping, cursorStyleHandler: l.rotationStyleHandler, offsetY: -40, withConnection: !0, actionName: "rotate" }), b.Textbox) {
      var d = b.Textbox.prototype.controls = {};
      d.mtr = h.mtr, d.tr = h.tr, d.br = h.br, d.tl = h.tl, d.bl = h.bl, d.mt = h.mt, d.mb = h.mb, d.mr = new b.Control({ x: 0.5, y: 0, actionHandler: l.changeWidth, cursorStyleHandler: a, actionName: "resizing" }), d.ml = new b.Control({ x: -0.5, y: 0, actionHandler: l.changeWidth, cursorStyleHandler: a, actionName: "resizing" });
    }
  }(), function() {
    var l = b.Object.prototype._set, a = b.Object.prototype.render, c = b.Object.prototype.toObject, f = b.Object.prototype._createBaseSVGMarkup;
    b.util.object.extend(b.Object.prototype, { erasable: !0, getEraser: function() {
      return this.clipPath && this.clipPath.eraser ? this.clipPath : void 0;
    }, getClipPath: function() {
      var h = this.getEraser();
      return h ? h._objects[0].clipPath : this.clipPath;
    }, setClipPath: function(h) {
      var d = this.getEraser();
      (d ? d._objects[0] : this).set("clipPath", h), this.set("dirty", !0);
    }, _updateEraserDimensions: function(h, d) {
      var p = this.getEraser();
      if (p) {
        var m = p._objects[0], y = { width: m.width, height: m.height }, _ = this._getNonTransformedDimensions(), k = b.util.object.extend({ width: _.x, height: _.y }, h);
        if (y.width === k.width && y.height === k.height) return;
        var T = new b.Point((y.width - k.width) / 2, (y.height - k.height) / 2);
        p.set(k), p.setPositionByOrigin(new b.Point(0, 0), "center", "center"), m.set(k), p.set("dirty", !0), d || p.getObjects("path").forEach(function(D) {
          D.setPositionByOrigin(D.getCenterPoint().add(T), "center", "center");
        }), this.setCoords();
      }
    }, _set: function(h, d) {
      return l.call(this, h, d), h !== "width" && h !== "height" || this._updateEraserDimensions(), this;
    }, render: function(h) {
      this._updateEraserDimensions(), a.call(this, h);
    }, toObject: function(h) {
      return c.call(this, ["erasable"].concat(h));
    }, eraserToSVG: function(h) {
      var d = this.getEraser();
      if (d) {
        var p = d._objects[0].fill;
        d._objects[0].fill = "white", d.clipPathId = "CLIPPATH_" + b.Object.__uid++;
        var m = ["<defs>", "<mask " + ['id="' + d.clipPathId + '"'].join(" ") + " >", d.toSVG(h.reviver), "</mask>", "</defs>"];
        return d._objects[0].fill = p, m.join(`
`);
      }
      return "";
    }, _createBaseSVGMarkup: function(h, d) {
      var p = this.getEraser();
      if (p) {
        var m = this.eraserToSVG(d);
        this.clipPath = null;
        var y = f.call(this, h, d);
        return this.clipPath = p, [m, y.replace(">", 'mask="url(#' + p.clipPathId + ')" >')].join(`
`);
      }
      return f.call(this, h, d);
    } });
    var i = b.Group.prototype._restoreObjectsState, r = b.Group.prototype.toObject, s = b.Group.prototype._getBounds;
    b.util.object.extend(b.Group.prototype, { _getBounds: function(h, d, p) {
      if (this.eraser) return this.width = this._objects[0].width, void (this.height = this._objects[0].height);
      s.call(this, h, d, p);
    }, _addEraserPathToObjects: function(h) {
      this._objects.forEach(function(d) {
        b.EraserBrush.prototype._addPathToObjectEraser.call(b.EraserBrush.prototype, d, h);
      });
    }, applyEraserToObjects: function() {
      var h = this;
      if (this.getEraser()) {
        var d = h.calcTransformMatrix();
        h.getEraser().clone(function(p) {
          var m = p._objects[0].clipPath;
          h.clipPath = m || void 0, p.getObjects("path").forEach(function(y) {
            var _ = b.util.multiplyTransformMatrices(d, y.calcTransformMatrix());
            b.util.applyTransformToObject(y, _), m ? m.clone(function(k) {
              b.EraserBrush.prototype.applyClipPathToPath.call(b.EraserBrush.prototype, y, k, d), h._addEraserPathToObjects(y);
            }) : h._addEraserPathToObjects(y);
          });
        });
      }
    }, _restoreObjectsState: function() {
      return this.erasable === !0 && this.applyEraserToObjects(), i.call(this);
    }, toObject: function(h) {
      return r.call(this, ["eraser"].concat(h));
    } }), b.util.object.extend(b.Canvas.prototype, { isErasing: function() {
      return this.isDrawingMode && this.freeDrawingBrush && this.freeDrawingBrush.type === "eraser" && this.freeDrawingBrush._isErasing;
    }, renderAll: function() {
      if (!this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), !this.isErasing()) {
        this.hasLostContext && this.renderTopLayer(this.contextTop);
        var h = this.contextContainer;
        return this.renderCanvas(h, this._chooseObjectsToRender()), this;
      }
      this.freeDrawingBrush._render();
    } }), b.EraserBrush = b.util.createClass(b.PencilBrush, { type: "eraser", _ready: !1, _drawOverlayOnTop: !1, _isErasing: !1, initialize: function(h) {
      this.callSuper("initialize", h), this._renderBound = this._render.bind(this), this.render = this.render.bind(this);
    }, hideObject: function(h) {
      h && (h._originalOpacity = h.opacity, h.set({ opacity: 0 }));
    }, restoreObjectVisibility: function(h) {
      h && h._originalOpacity && (h.set({ opacity: h._originalOpacity }), h._originalOpacity = void 0);
    }, _isErasable: function(h) {
      return h.erasable !== !1;
    }, prepareCanvasBackgroundForLayer: function(h) {
      if (h !== "overlay") {
        var d = this.canvas.backgroundImage, p = h === "top";
        d && this._isErasable(d) === !p && this.hideObject(d);
      }
    }, prepareCanvasOverlayForLayer: function(h) {
      var d = this.canvas, p = d.overlayImage, m = !!d.overlayColor;
      if (d.overlayColor && h !== "overlay" && (this.__overlayColor = d.overlayColor, delete d.overlayColor), h === "bottom") return this.hideObject(p), !1;
      var y = h === "top", _ = p && !this._isErasable(p) || m;
      return p && this._isErasable(p) === !y && this.hideObject(p), _;
    }, restoreCanvasDrawables: function() {
      var h = this.canvas;
      this.__overlayColor && (h.overlayColor = this.__overlayColor, delete this.__overlayColor), this.restoreObjectVisibility(h.backgroundImage), this.restoreObjectVisibility(h.overlayImage);
    }, prepareCollectionTraversal: function(h) {
      var d = this;
      h.forEachObject(function(p) {
        p.forEachObject && p.erasable === "deep" ? d.prepareCollectionTraversal(p) : p.erasable && d.hideObject(p);
      });
    }, restoreCollectionTraversal: function(h) {
      var d = this;
      h.forEachObject(function(p) {
        p.forEachObject && p.erasable === "deep" ? d.restoreCollectionTraversal(p) : d.restoreObjectVisibility(p);
      });
    }, prepareCanvasObjectsForLayer: function(h) {
      h === "bottom" && this.prepareCollectionTraversal(this.canvas);
    }, restoreCanvasObjectsFromLayer: function(h) {
      h === "bottom" && this.restoreCollectionTraversal(this.canvas);
    }, prepareCanvasForLayer: function(h) {
      return this.prepareCanvasBackgroundForLayer(h), this.prepareCanvasObjectsForLayer(h), this.prepareCanvasOverlayForLayer(h);
    }, restoreCanvasFromLayer: function(h) {
      this.restoreCanvasDrawables(), this.restoreCanvasObjectsFromLayer(h);
    }, renderBottomLayer: function() {
      var h = this.canvas;
      this.prepareCanvasForLayer("bottom"), h.renderCanvas(h.getContext(), h.getObjects().filter(function(d) {
        return !d.erasable || d.forEachObject;
      })), this.restoreCanvasFromLayer("bottom");
    }, renderTopLayer: function() {
      var h = this.canvas;
      this._drawOverlayOnTop = this.prepareCanvasForLayer("top"), h.renderCanvas(h.contextTop, h.getObjects()), this.callSuper("_render"), this.restoreCanvasFromLayer("top");
    }, renderOverlay: function() {
      this.prepareCanvasForLayer("overlay");
      var h = this.canvas, d = h.contextTop;
      h._renderOverlay(d), this.restoreCanvasFromLayer("overlay");
    }, _saveAndTransform: function(h) {
      this.callSuper("_saveAndTransform", h), h.globalCompositeOperation = "destination-out";
    }, needsFullRender: function() {
      return this.callSuper("needsFullRender") || this._drawOverlayOnTop;
    }, onMouseDown: function(h, d) {
      this.canvas._isMainEvent(d.e) && (this._prepareForDrawing(h), this._captureDrawingPath(h), this._isErasing = !0, this.canvas.fire("erasing:start"), this._ready = !0, this._render());
    }, _render: function() {
      this._ready && (this.isRendering = 1, this.renderBottomLayer(), this.renderTopLayer(), this.renderOverlay(), this.isRendering = 0);
    }, render: function() {
      return !!this._isErasing && (this.isRendering ? this.isRendering = b.util.requestAnimFrame(this._renderBound) : this._render(), !0);
    }, applyClipPathToPath: function(h, d, p) {
      var m = h.calcTransformMatrix(), y = d.calcTransformMatrix(), _ = b.util.multiplyTransformMatrices(b.util.invertTransform(m), p);
      return b.util.applyTransformToObject(d, b.util.multiplyTransformMatrices(_, y)), h.clipPath = d, h;
    }, clonePathWithClipPath: function(h, d, p) {
      var m = d.calcTransformMatrix(), y = d.getClipPath(), _ = this;
      h.clone(function(k) {
        y.clone(function(T) {
          p(_.applyClipPathToPath(k, T, m));
        });
      });
    }, _addPathToObjectEraser: function(h, d) {
      var p, m = this;
      if (h.forEachObject && h.erasable === "deep") {
        var y = h._objects.filter(function(T) {
          return T.erasable;
        });
        y.length > 0 && h.clipPath ? this.clonePathWithClipPath(d, h, function(T) {
          y.forEach(function(D) {
            m._addPathToObjectEraser(D, T);
          });
        }) : y.length > 0 && y.forEach(function(T) {
          m._addPathToObjectEraser(T, d);
        });
      } else {
        if (h.getEraser()) p = h.clipPath;
        else {
          var _ = h._getNonTransformedDimensions(), k = new b.Rect({ fill: "rgb(0,0,0)", width: _.x, height: _.y, clipPath: h.clipPath, originX: "center", originY: "center" });
          p = new b.Group([k], { eraser: !0 });
        }
        d.clone(function(T) {
          T.globalCompositeOperation = "destination-out";
          var D = b.util.multiplyTransformMatrices(b.util.invertTransform(h.calcTransformMatrix()), T.calcTransformMatrix());
          b.util.applyTransformToObject(T, D), p.addWithUpdate(T), h.set({ clipPath: p, dirty: !0 }), h.fire("erasing:end", { path: T }), h.group && Array.isArray(m.__subTargets) && m.__subTargets.push(h);
        });
      }
    }, applyEraserToCanvas: function(h) {
      var d = this.canvas, p = {};
      return ["backgroundImage", "overlayImage"].forEach(function(m) {
        var y = d[m];
        y && y.erasable && (this._addPathToObjectEraser(y, h), p[m] = y);
      }, this), p;
    }, _finalizeAndAddPath: function() {
      var h = this.canvas.contextTop, d = this.canvas;
      h.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate)), d.clearContext(d.contextTop), this._isErasing = !1;
      var p = this._points && this._points.length > 1 ? this.convertPointsToSVGPath(this._points) : null;
      if (!p || this._isEmptySVGPath(p)) return d.fire("erasing:end"), void d.requestRenderAll();
      var m = this.createPath(p);
      m.setCoords(), d.fire("before:path:created", { path: m });
      var y = this.applyEraserToCanvas(m), _ = this;
      this.__subTargets = [];
      var k = [];
      d.forEachObject(function(T) {
        T.erasable && T.intersectsWithObject(m, !0, !0) && (_._addPathToObjectEraser(T, m), k.push(T));
      }), d.fire("erasing:end", { path: m, targets: k, subTargets: this.__subTargets, drawables: y }), delete this.__subTargets, d.requestRenderAll(), m.setCoords(), this._resetShadow(), d.fire("path:created", { path: m });
    } });
  }();
})(Jp);
var re = Jp.fabric;
const e3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721638678524, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 6714, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M955.769524 734.466768c-0.13917 0-4.313236-8.118911-9.275247-18.036795L816.444339 456.344422c-4.962012-9.923-18.093077-18.035772-29.181623-18.030655l-107.787912 0.033769c-11.089569 0.004093-20.163225 9.080819-20.163225 20.174482l0 34.266431c0 11.089569 9.073656 20.170388 20.163225 20.181645l34.267455 0.023536c11.094686 0.002047 24.193005 8.146541 29.116131 18.085914l92.175329 186.263218c4.916986 9.943466-0.128937 18.077727-11.224646 18.077727L677.409772 735.420489c-11.094686 0-20.169365 9.075703-20.169365 20.164249l0 105.501846c0 11.089569-9.074679 20.163225-20.167319 20.163225L383.359666 881.249809c-11.093662 0-20.169365-9.073656-20.169365-20.163225L363.190301 755.585761c0-11.088546-9.074679-20.164249-20.163225-20.164249L193.657116 735.421512c-11.094686 0-16.003486-8.066723-10.918677-17.923208l96.398514-186.870038c5.087878-9.856485 18.319228-17.911952 29.408797-17.906835l33.378202 0.022513c11.095709 0.005117 20.169365-9.063423 20.169365-20.151969l0-33.967626c0-11.095709-9.073656-20.164249-20.169365-20.164249l-107.283422 0.039909c-11.094686 0-24.242124 8.112772-29.226648 18.024515L74.71926 716.616214c-4.978385 9.907651-8.933463 18.014282-8.792247 18.014282 0.14224 0 0.260943 9.074679 0.260943 20.169365l0 183.128831c0 11.094686 9.067516 20.169365 20.162202 20.169365l849.507874 0c11.096732 0 20.169365-9.074679 20.169365-20.169365L956.027397 754.629993C956.020234 743.532237 955.908694 734.466768 955.769524 734.466768L955.769524 734.466768zM326.291926 294.249651l110.674659 0L436.966585 659.44205 585.181231 659.44205 585.181231 294.249651l116.595508 0c11.097756 0 14.150278-6.79373 6.794753-15.093766L524.899286 71.90875c-7.355525-8.299013-19.308765-8.226359-26.567076 0.158612L319.322188 278.997272C312.063877 287.388383 315.20338 294.249651 326.291926 294.249651L326.291926 294.249651zM326.291926 294.249651", "p-id": 6715 })), $p = C.forwardRef(e3), n3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 576 512", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M234.7 42.7L197 56.8c-3 1.1-5 4-5 7.2s2 6.1 5 7.2l37.7 14.1L248.8 123c1.1 3 4 5 7.2 5s6.1-2 7.2-5l14.1-37.7L315 71.2c3-1.1 5-4 5-7.2s-2-6.1-5-7.2L277.3 42.7 263.2 5c-1.1-3-4-5-7.2-5s-6.1 2-7.2 5L234.7 42.7zM46.1 395.4c-18.7 18.7-18.7 49.1 0 67.9l34.6 34.6c18.7 18.7 49.1 18.7 67.9 0L529.9 116.5c18.7-18.7 18.7-49.1 0-67.9L495.3 14.1c-18.7-18.7-49.1-18.7-67.9 0L46.1 395.4zM484.6 82.6l-105 105-23.3-23.3 105-105 23.3 23.3zM7.5 117.2C3 118.9 0 123.2 0 128s3 9.1 7.5 10.8L64 160l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L128 160l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L128 96 106.8 39.5C105.1 35 100.8 32 96 32s-9.1 3-10.8 7.5L64 96 7.5 117.2zm352 256c-4.5 1.7-7.5 6-7.5 10.8s3 9.1 7.5 10.8L416 416l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L480 416l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L480 352l-21.2-56.5c-1.7-4.5-6-7.5-10.8-7.5s-9.1 3-10.8 7.5L416 352l-56.5 21.2z" }));
C.forwardRef(n3);
const i3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1744981807847, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4678, xmlnsXlink: "http://www.w3.org/1999/xlink", width: 200, height: 200, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M853.3 128a42.7 42.7 0 0 1 42.7 42.7v682.7a42.7 42.7 0 0 1-42.7 42.7H170.7a42.7 42.7 0 0 1-42.7-42.7V170.7a42.7 42.7 0 0 1 42.7-42.7h682.7zM477.4 561.4L213.3 608v202.7h308l-43.9-249.3z m333.3-348.1h-308L608 810.6h202.7V213.3z m-394.7 0H213.3v308l249.3-43.9L416 213.3z", "p-id": 4679 }));
C.forwardRef(i3);
const r3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721704033853, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4365, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M512 324.266667V136.533333c0-6.826667-3.413333-13.653333-10.24-13.653333-6.826667-3.413333-13.653333-3.413333-17.066667 0l-477.866666 307.2c-3.413333 3.413333-6.826667 6.826667-6.826667 13.653333s3.413333 10.24 6.826667 13.653334l477.866666 341.333333c6.826667 3.413333 13.653333 3.413333 17.066667 0 6.826667-3.413333 10.24-10.24 10.24-13.653333v-187.733334c249.173333 10.24 474.453333 235.52 477.866667 290.133334 0 10.24 6.826667 17.066667 17.066666 17.066666s17.066667-6.826667 17.066667-17.066666c-3.413333-225.28-170.666667-552.96-512-563.2z", "p-id": 4366 })), a3 = C.forwardRef(r3), o3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721704049355, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4547, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M1017.173333 430.08l-477.866666-307.2c-6.826667-3.413333-13.653333-3.413333-17.066667 0-6.826667 3.413333-10.24 6.826667-10.24 13.653333v187.733334C170.666667 334.506667 3.413333 662.186667 0 887.466667v3.413333c0 6.826667 6.826667 13.653333 17.066667 13.653333s17.066667-6.826667 17.066666-17.066666c3.413333-51.2 228.693333-279.893333 477.866667-290.133334V785.066667c0 6.826667 3.413333 13.653333 10.24 13.653333 6.826667 3.413333 13.653333 3.413333 17.066667 0l477.866666-341.333333c3.413333-3.413333 6.826667-10.24 6.826667-13.653334s-3.413333-10.24-6.826667-13.653333z", "p-id": 4548 })), s3 = C.forwardRef(o3), l3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721712684369, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1463, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M369.792 704.32L930.304 128 1024 223.616 369.984 896l-20.288-20.864-0.128 0.128L0 516.8 96.128 423.68l273.664 280.64z", "p-id": 1464 })), c3 = C.forwardRef(l3), u3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721712695744, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4043, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M960 154.24L869.76 64 512 421.76 154.24 64 64 154.24 421.76 512 64 869.76 154.24 960 512 602.24 869.76 960 960 869.76 602.24 512z", "p-id": 4044 })), h3 = C.forwardRef(u3), d3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1722477182503, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 8793, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72z", "p-id": 8794 }), /* @__PURE__ */ C.createElement("path", { d: "M864 256H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z", "p-id": 8795 })), Ns = C.forwardRef(d3), f3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1722477192628, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 8976, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M942.3 486.4l-0.1-0.1-0.1-0.1c-36.4-76.7-80-138.7-130.7-186L760.7 351c43.7 40.2 81.5 93.7 114.1 160.9C791.5 684.2 673.4 766 512 766c-51.3 0-98.3-8.3-141.2-25.1l-54.7 54.7C374.6 823.8 439.8 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0.1-51.3zM878.3 154.2l-42.4-42.4c-3.1-3.1-8.2-3.1-11.3 0L707.8 228.5C649.4 200.2 584.2 186 512 186c-192.2 0-335.4 100.5-430.2 300.3v0.1c-7.7 16.2-7.7 35.2 0 51.5 36.4 76.7 80 138.7 130.7 186.1L111.8 824.5c-3.1 3.1-3.1 8.2 0 11.3l42.4 42.4c3.1 3.1 8.2 3.1 11.3 0l712.8-712.8c3.1-3 3.1-8.1 0-11.2zM398.9 537.4c-1.9-8.2-2.9-16.7-2.9-25.4 0-61.9 50.1-112 112-112 8.7 0 17.3 1 25.4 2.9L398.9 537.4z m184.5-184.5C560.5 342.1 535 336 508 336c-97.2 0-176 78.8-176 176 0 27 6.1 52.5 16.9 75.4L263.3 673c-43.7-40.2-81.5-93.7-114.1-160.9C232.6 339.8 350.7 258 512 258c51.3 0 98.3 8.3 141.2 25.1l-69.8 69.8z", "p-id": 8977 }), /* @__PURE__ */ C.createElement("path", { d: "M508 624c-6.4 0-12.7-0.5-18.8-1.6l-51.1 51.1c21.4 9.3 45.1 14.4 69.9 14.4 97.2 0 176-78.8 176-176 0-24.8-5.1-48.5-14.4-69.9l-51.1 51.1c1 6.1 1.6 12.4 1.6 18.8C620 573.9 569.9 624 508 624z", "p-id": 8978 })), p3 = C.forwardRef(f3), g3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1722154899261, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1632, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M512 74.666667c-17.066667 0-32 14.933333-32 32v149.333333c0 17.066667 14.933333 32 32 32s32-14.933333 32-32V106.666667c0-17.066667-14.933333-32-32-32zM693.333333 362.666667c8.533333 0 17.066667-2.133333 23.466667-8.533334l104.533333-104.533333c12.8-12.8 12.8-32 0-44.8-12.8-12.8-32-12.8-44.8 0l-104.533333 104.533333c-12.8 12.8-12.8 32 0 44.8 4.266667 6.4 12.8 8.533333 21.333333 8.533334zM917.333333 480h-149.333333c-17.066667 0-32 14.933333-32 32s14.933333 32 32 32h149.333333c17.066667 0 32-14.933333 32-32s-14.933333-32-32-32zM714.666667 669.866667c-12.8-12.8-32-12.8-44.8 0s-12.8 32 0 44.8l104.533333 104.533333c6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333c12.8-12.8 12.8-32 0-44.8l-106.666666-104.533333zM512 736c-17.066667 0-32 14.933333-32 32v149.333333c0 17.066667 14.933333 32 32 32s32-14.933333 32-32v-149.333333c0-17.066667-14.933333-32-32-32zM309.333333 669.866667l-104.533333 104.533333c-12.8 12.8-12.8 32 0 44.8 6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333l104.533334-104.533333c12.8-12.8 12.8-32 0-44.8s-36.266667-12.8-46.933334 0zM288 512c0-17.066667-14.933333-32-32-32H106.666667c-17.066667 0-32 14.933333-32 32s14.933333 32 32 32h149.333333c17.066667 0 32-14.933333 32-32zM247.466667 202.666667c-12.8-12.8-32-12.8-44.8 0-12.8 12.8-12.8 32 0 44.8l104.533333 104.533333c6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333c12.8-12.8 12.8-32 0-44.8l-106.666666-104.533333z", "p-id": 1633 })), t0 = C.forwardRef(g3), m3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1732524822270, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 5255, width: 200, height: 200, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M213.333333 810.666667h597.333334a42.666667 42.666667 0 0 1 0 85.333333H213.333333a42.666667 42.666667 0 0 1 0-85.333333z m341.333334-248.533334l138.368-138.325333 60.330666 60.330667L512 725.504l-241.365333-241.365333 60.330666-60.330667L469.333333 562.133333V85.333333h85.333334v476.8z", "p-id": 5256 })), v3 = C.forwardRef(m3), y3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1754034311077, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1474, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M421.504 511.872L322.645333 413.013333A170.666667 170.666667 0 1 1 413.141333 322.56L512 421.333333l271.957333-271.957333a85.333333 85.333333 0 0 1 120.704 0l30.165334 30.165333L413.141333 701.226667a170.666667 170.666667 0 1 1-90.496-90.496l98.858667-98.858667zM256 341.205333a85.333333 85.333333 0 1 0 0-170.666666 85.333333 85.333333 0 0 0 0 170.666666z m0 512a85.333333 85.333333 0 1 0 0-170.666666 85.333333 85.333333 0 0 0 0 170.666666z m406.826667-281.045333l272 272-30.165334 30.165333a85.333333 85.333333 0 0 1-120.704 0l-211.626666-211.626666 90.453333-90.538667zM682.666667 469.205333h85.333333v85.333334h-85.333333v-85.333334z m170.666666 0h85.333334v85.333334h-85.333334v-85.333334z m-597.333333 0h85.333333v85.333334H256v-85.333334z m-170.666667 0h85.333334v85.333334H85.333333v-85.333334z", "p-id": 1475 })), e0 = C.forwardRef(y3), b3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("style", null, `
        .small {
        font: 280px sans-serif;
        font-weight: bold;
        }
    `), /* @__PURE__ */ C.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ C.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ C.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ C.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ C.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ C.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ C.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ C.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ C.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ C.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ C.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ C.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ C.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ C.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ C.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ C.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ C.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ C.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ C.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ C.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ C.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ C.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ C.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ C.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ C.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ C.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ C.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ C.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ C.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ C.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ C.createElement("text", { x: 440, y: 960, className: "small" }, "RGB")), x3 = C.forwardRef(b3), _3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ C.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ C.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ C.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ C.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ C.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ C.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ C.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ C.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ C.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ C.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ C.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ C.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ C.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ C.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ C.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ C.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ C.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ C.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ C.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ C.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ C.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ C.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ C.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ C.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ C.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ C.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ C.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ C.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ C.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ C.createElement("rect", { x: 770, y: 610, width: 120, height: 360 }), /* @__PURE__ */ C.createElement("rect", { x: 650, y: 730, width: 360, height: 120 })), w3 = C.forwardRef(_3), S3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ C.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ C.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ C.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ C.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ C.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ C.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ C.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ C.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ C.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ C.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ C.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ C.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ C.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ C.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ C.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ C.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ C.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ C.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ C.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ C.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ C.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ C.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ C.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ C.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ C.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ C.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ C.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ C.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ C.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ C.createElement("circle", { cx: 850, cy: 800, r: 100 })), C3 = C.forwardRef(S3), k3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ C.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ C.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ C.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ C.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ C.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ C.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ C.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ C.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ C.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ C.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ C.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ C.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ C.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ C.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ C.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ C.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ C.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ C.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ C.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ C.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ C.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ C.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ C.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ C.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ C.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ C.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ C.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ C.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ C.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ C.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ C.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ C.createElement("rect", { x: 650, y: 730, width: 360, height: 120 })), E3 = C.forwardRef(k3), T3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1720327293062, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 2436, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M128 938.666667c-25.6 0-42.666667-17.066667-42.666667-42.666667s17.066667-42.666667 42.666667-42.666667h132.266667l-140.8-140.8c-34.133333-34.133333-34.133333-85.333333 0-119.466666L601.6 110.933333c34.133333-34.133333 85.333333-34.133333 119.466667 0l179.2 179.2c34.133333 34.133333 34.133333 85.333333 0 119.466667L460.8 853.333333H896c25.6 0 42.666667 17.066667 42.666667 42.666667s-17.066667 42.666667-42.666667 42.666667H128z m68.266667-298.666667c-8.533333 8.533333-8.533333 21.333333 0 29.866667l106.666666 106.666666c34.133333 34.133333 85.333333 34.133333 119.466667 0l119.466667-119.466666-179.2-179.2L196.266667 640z", "p-id": 2437 })), n0 = C.forwardRef(T3), O3 = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1721638183200, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1448, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M607.274667 612.992l88.661333 190.122667a21.333333 21.333333 0 0 1-10.325333 28.373333l-77.312 36.053333a21.333333 21.333333 0 0 1-28.373334-10.325333l-90.666666-194.474667-111.488 111.488A21.333333 21.333333 0 0 1 341.333333 759.168V218.88a21.333333 21.333333 0 0 1 35.669334-15.786667l397.056 360.96a21.333333 21.333333 0 0 1-12.714667 37.077334l-154.069333 11.861333z", "p-id": 1449 })), M3 = C.forwardRef(O3), P3 = [
  { title: "Load", icon: $p, disabledInMode: [] },
  { title: "Fill Brush", icon: C3, disabledInMode: ["COLOR", "EDGE"] },
  { title: "Add Edge Brush", icon: w3, disabledInMode: ["FILL", "COLOR"] },
  { title: "Remove Edge Brush", icon: E3, disabledInMode: ["FILL", "COLOR"] },
  { title: "Color Brush", icon: x3, disabledInMode: ["FILL", "EDGE"] },
  { title: "Erase", icon: n0, disabledInMode: ["TEXT"] },
  { title: "Select", icon: M3, disabledInMode: [] },
  { title: "SAM", icon: e0, disabledInMode: ["COLOR", "EDGE", "PROP", "FILL"] }
], Yl = (t, e = 1) => {
  let n = t.match(/[^#]./g);
  return n ? `rgba(${n.map((o) => parseInt(o, 16)).join(", ")}, ${e})` : t;
}, i0 = (t) => t.elementType === "BRUSH" && t.brushType === "Color Brush", A3 = (t) => function(e, n, o, u, g) {
  var v = this.cornerSize;
  e.save(), e.translate(n, o), e.rotate(fabric.util.degreesToRadians(g.angle)), e.drawImage(t, -v / 2, -v / 2, v, v), e.restore();
};
var r0 = { exports: {} }, j3 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED", D3 = j3, L3 = D3;
function a0() {
}
function o0() {
}
o0.resetWarningCache = a0;
var R3 = function() {
  function t(o, u, g, v, x, S) {
    if (S !== L3) {
      var E = new Error(
        "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
      );
      throw E.name = "Invariant Violation", E;
    }
  }
  t.isRequired = t;
  function e() {
    return t;
  }
  var n = {
    array: t,
    bigint: t,
    bool: t,
    func: t,
    number: t,
    object: t,
    string: t,
    symbol: t,
    any: t,
    arrayOf: e,
    element: t,
    elementType: t,
    instanceOf: e,
    node: t,
    objectOf: e,
    oneOf: e,
    oneOfType: e,
    shape: e,
    exact: e,
    checkPropTypes: o0,
    resetWarningCache: a0
  };
  return n.PropTypes = n, n;
};
r0.exports = R3();
var I3 = r0.exports;
const Vt = /* @__PURE__ */ Zl(I3);
function Pi(t, e, n, o) {
  function u(g) {
    return g instanceof n ? g : new n(function(v) {
      v(g);
    });
  }
  return new (n || (n = Promise))(function(g, v) {
    function x(A) {
      try {
        E(o.next(A));
      } catch (Y) {
        v(Y);
      }
    }
    function S(A) {
      try {
        E(o.throw(A));
      } catch (Y) {
        v(Y);
      }
    }
    function E(A) {
      A.done ? g(A.value) : u(A.value).then(x, S);
    }
    E((o = o.apply(t, [])).next());
  });
}
const F3 = /* @__PURE__ */ new Map([
  // https://github.com/guzzle/psr7/blob/2d9260799e713f1c475d3c5fdc3d6561ff7441b2/src/MimeType.php
  ["1km", "application/vnd.1000minds.decision-model+xml"],
  ["3dml", "text/vnd.in3d.3dml"],
  ["3ds", "image/x-3ds"],
  ["3g2", "video/3gpp2"],
  ["3gp", "video/3gp"],
  ["3gpp", "video/3gpp"],
  ["3mf", "model/3mf"],
  ["7z", "application/x-7z-compressed"],
  ["7zip", "application/x-7z-compressed"],
  ["123", "application/vnd.lotus-1-2-3"],
  ["aab", "application/x-authorware-bin"],
  ["aac", "audio/x-acc"],
  ["aam", "application/x-authorware-map"],
  ["aas", "application/x-authorware-seg"],
  ["abw", "application/x-abiword"],
  ["ac", "application/vnd.nokia.n-gage.ac+xml"],
  ["ac3", "audio/ac3"],
  ["acc", "application/vnd.americandynamics.acc"],
  ["ace", "application/x-ace-compressed"],
  ["acu", "application/vnd.acucobol"],
  ["acutc", "application/vnd.acucorp"],
  ["adp", "audio/adpcm"],
  ["aep", "application/vnd.audiograph"],
  ["afm", "application/x-font-type1"],
  ["afp", "application/vnd.ibm.modcap"],
  ["ahead", "application/vnd.ahead.space"],
  ["ai", "application/pdf"],
  ["aif", "audio/x-aiff"],
  ["aifc", "audio/x-aiff"],
  ["aiff", "audio/x-aiff"],
  ["air", "application/vnd.adobe.air-application-installer-package+zip"],
  ["ait", "application/vnd.dvb.ait"],
  ["ami", "application/vnd.amiga.ami"],
  ["amr", "audio/amr"],
  ["apk", "application/vnd.android.package-archive"],
  ["apng", "image/apng"],
  ["appcache", "text/cache-manifest"],
  ["application", "application/x-ms-application"],
  ["apr", "application/vnd.lotus-approach"],
  ["arc", "application/x-freearc"],
  ["arj", "application/x-arj"],
  ["asc", "application/pgp-signature"],
  ["asf", "video/x-ms-asf"],
  ["asm", "text/x-asm"],
  ["aso", "application/vnd.accpac.simply.aso"],
  ["asx", "video/x-ms-asf"],
  ["atc", "application/vnd.acucorp"],
  ["atom", "application/atom+xml"],
  ["atomcat", "application/atomcat+xml"],
  ["atomdeleted", "application/atomdeleted+xml"],
  ["atomsvc", "application/atomsvc+xml"],
  ["atx", "application/vnd.antix.game-component"],
  ["au", "audio/x-au"],
  ["avi", "video/x-msvideo"],
  ["avif", "image/avif"],
  ["aw", "application/applixware"],
  ["azf", "application/vnd.airzip.filesecure.azf"],
  ["azs", "application/vnd.airzip.filesecure.azs"],
  ["azv", "image/vnd.airzip.accelerator.azv"],
  ["azw", "application/vnd.amazon.ebook"],
  ["b16", "image/vnd.pco.b16"],
  ["bat", "application/x-msdownload"],
  ["bcpio", "application/x-bcpio"],
  ["bdf", "application/x-font-bdf"],
  ["bdm", "application/vnd.syncml.dm+wbxml"],
  ["bdoc", "application/x-bdoc"],
  ["bed", "application/vnd.realvnc.bed"],
  ["bh2", "application/vnd.fujitsu.oasysprs"],
  ["bin", "application/octet-stream"],
  ["blb", "application/x-blorb"],
  ["blorb", "application/x-blorb"],
  ["bmi", "application/vnd.bmi"],
  ["bmml", "application/vnd.balsamiq.bmml+xml"],
  ["bmp", "image/bmp"],
  ["book", "application/vnd.framemaker"],
  ["box", "application/vnd.previewsystems.box"],
  ["boz", "application/x-bzip2"],
  ["bpk", "application/octet-stream"],
  ["bpmn", "application/octet-stream"],
  ["bsp", "model/vnd.valve.source.compiled-map"],
  ["btif", "image/prs.btif"],
  ["buffer", "application/octet-stream"],
  ["bz", "application/x-bzip"],
  ["bz2", "application/x-bzip2"],
  ["c", "text/x-c"],
  ["c4d", "application/vnd.clonk.c4group"],
  ["c4f", "application/vnd.clonk.c4group"],
  ["c4g", "application/vnd.clonk.c4group"],
  ["c4p", "application/vnd.clonk.c4group"],
  ["c4u", "application/vnd.clonk.c4group"],
  ["c11amc", "application/vnd.cluetrust.cartomobile-config"],
  ["c11amz", "application/vnd.cluetrust.cartomobile-config-pkg"],
  ["cab", "application/vnd.ms-cab-compressed"],
  ["caf", "audio/x-caf"],
  ["cap", "application/vnd.tcpdump.pcap"],
  ["car", "application/vnd.curl.car"],
  ["cat", "application/vnd.ms-pki.seccat"],
  ["cb7", "application/x-cbr"],
  ["cba", "application/x-cbr"],
  ["cbr", "application/x-cbr"],
  ["cbt", "application/x-cbr"],
  ["cbz", "application/x-cbr"],
  ["cc", "text/x-c"],
  ["cco", "application/x-cocoa"],
  ["cct", "application/x-director"],
  ["ccxml", "application/ccxml+xml"],
  ["cdbcmsg", "application/vnd.contact.cmsg"],
  ["cda", "application/x-cdf"],
  ["cdf", "application/x-netcdf"],
  ["cdfx", "application/cdfx+xml"],
  ["cdkey", "application/vnd.mediastation.cdkey"],
  ["cdmia", "application/cdmi-capability"],
  ["cdmic", "application/cdmi-container"],
  ["cdmid", "application/cdmi-domain"],
  ["cdmio", "application/cdmi-object"],
  ["cdmiq", "application/cdmi-queue"],
  ["cdr", "application/cdr"],
  ["cdx", "chemical/x-cdx"],
  ["cdxml", "application/vnd.chemdraw+xml"],
  ["cdy", "application/vnd.cinderella"],
  ["cer", "application/pkix-cert"],
  ["cfs", "application/x-cfs-compressed"],
  ["cgm", "image/cgm"],
  ["chat", "application/x-chat"],
  ["chm", "application/vnd.ms-htmlhelp"],
  ["chrt", "application/vnd.kde.kchart"],
  ["cif", "chemical/x-cif"],
  ["cii", "application/vnd.anser-web-certificate-issue-initiation"],
  ["cil", "application/vnd.ms-artgalry"],
  ["cjs", "application/node"],
  ["cla", "application/vnd.claymore"],
  ["class", "application/octet-stream"],
  ["clkk", "application/vnd.crick.clicker.keyboard"],
  ["clkp", "application/vnd.crick.clicker.palette"],
  ["clkt", "application/vnd.crick.clicker.template"],
  ["clkw", "application/vnd.crick.clicker.wordbank"],
  ["clkx", "application/vnd.crick.clicker"],
  ["clp", "application/x-msclip"],
  ["cmc", "application/vnd.cosmocaller"],
  ["cmdf", "chemical/x-cmdf"],
  ["cml", "chemical/x-cml"],
  ["cmp", "application/vnd.yellowriver-custom-menu"],
  ["cmx", "image/x-cmx"],
  ["cod", "application/vnd.rim.cod"],
  ["coffee", "text/coffeescript"],
  ["com", "application/x-msdownload"],
  ["conf", "text/plain"],
  ["cpio", "application/x-cpio"],
  ["cpp", "text/x-c"],
  ["cpt", "application/mac-compactpro"],
  ["crd", "application/x-mscardfile"],
  ["crl", "application/pkix-crl"],
  ["crt", "application/x-x509-ca-cert"],
  ["crx", "application/x-chrome-extension"],
  ["cryptonote", "application/vnd.rig.cryptonote"],
  ["csh", "application/x-csh"],
  ["csl", "application/vnd.citationstyles.style+xml"],
  ["csml", "chemical/x-csml"],
  ["csp", "application/vnd.commonspace"],
  ["csr", "application/octet-stream"],
  ["css", "text/css"],
  ["cst", "application/x-director"],
  ["csv", "text/csv"],
  ["cu", "application/cu-seeme"],
  ["curl", "text/vnd.curl"],
  ["cww", "application/prs.cww"],
  ["cxt", "application/x-director"],
  ["cxx", "text/x-c"],
  ["dae", "model/vnd.collada+xml"],
  ["daf", "application/vnd.mobius.daf"],
  ["dart", "application/vnd.dart"],
  ["dataless", "application/vnd.fdsn.seed"],
  ["davmount", "application/davmount+xml"],
  ["dbf", "application/vnd.dbf"],
  ["dbk", "application/docbook+xml"],
  ["dcr", "application/x-director"],
  ["dcurl", "text/vnd.curl.dcurl"],
  ["dd2", "application/vnd.oma.dd2+xml"],
  ["ddd", "application/vnd.fujixerox.ddd"],
  ["ddf", "application/vnd.syncml.dmddf+xml"],
  ["dds", "image/vnd.ms-dds"],
  ["deb", "application/x-debian-package"],
  ["def", "text/plain"],
  ["deploy", "application/octet-stream"],
  ["der", "application/x-x509-ca-cert"],
  ["dfac", "application/vnd.dreamfactory"],
  ["dgc", "application/x-dgc-compressed"],
  ["dic", "text/x-c"],
  ["dir", "application/x-director"],
  ["dis", "application/vnd.mobius.dis"],
  ["disposition-notification", "message/disposition-notification"],
  ["dist", "application/octet-stream"],
  ["distz", "application/octet-stream"],
  ["djv", "image/vnd.djvu"],
  ["djvu", "image/vnd.djvu"],
  ["dll", "application/octet-stream"],
  ["dmg", "application/x-apple-diskimage"],
  ["dmn", "application/octet-stream"],
  ["dmp", "application/vnd.tcpdump.pcap"],
  ["dms", "application/octet-stream"],
  ["dna", "application/vnd.dna"],
  ["doc", "application/msword"],
  ["docm", "application/vnd.ms-word.template.macroEnabled.12"],
  ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
  ["dot", "application/msword"],
  ["dotm", "application/vnd.ms-word.template.macroEnabled.12"],
  ["dotx", "application/vnd.openxmlformats-officedocument.wordprocessingml.template"],
  ["dp", "application/vnd.osgi.dp"],
  ["dpg", "application/vnd.dpgraph"],
  ["dra", "audio/vnd.dra"],
  ["drle", "image/dicom-rle"],
  ["dsc", "text/prs.lines.tag"],
  ["dssc", "application/dssc+der"],
  ["dtb", "application/x-dtbook+xml"],
  ["dtd", "application/xml-dtd"],
  ["dts", "audio/vnd.dts"],
  ["dtshd", "audio/vnd.dts.hd"],
  ["dump", "application/octet-stream"],
  ["dvb", "video/vnd.dvb.file"],
  ["dvi", "application/x-dvi"],
  ["dwd", "application/atsc-dwd+xml"],
  ["dwf", "model/vnd.dwf"],
  ["dwg", "image/vnd.dwg"],
  ["dxf", "image/vnd.dxf"],
  ["dxp", "application/vnd.spotfire.dxp"],
  ["dxr", "application/x-director"],
  ["ear", "application/java-archive"],
  ["ecelp4800", "audio/vnd.nuera.ecelp4800"],
  ["ecelp7470", "audio/vnd.nuera.ecelp7470"],
  ["ecelp9600", "audio/vnd.nuera.ecelp9600"],
  ["ecma", "application/ecmascript"],
  ["edm", "application/vnd.novadigm.edm"],
  ["edx", "application/vnd.novadigm.edx"],
  ["efif", "application/vnd.picsel"],
  ["ei6", "application/vnd.pg.osasli"],
  ["elc", "application/octet-stream"],
  ["emf", "image/emf"],
  ["eml", "message/rfc822"],
  ["emma", "application/emma+xml"],
  ["emotionml", "application/emotionml+xml"],
  ["emz", "application/x-msmetafile"],
  ["eol", "audio/vnd.digital-winds"],
  ["eot", "application/vnd.ms-fontobject"],
  ["eps", "application/postscript"],
  ["epub", "application/epub+zip"],
  ["es", "application/ecmascript"],
  ["es3", "application/vnd.eszigno3+xml"],
  ["esa", "application/vnd.osgi.subsystem"],
  ["esf", "application/vnd.epson.esf"],
  ["et3", "application/vnd.eszigno3+xml"],
  ["etx", "text/x-setext"],
  ["eva", "application/x-eva"],
  ["evy", "application/x-envoy"],
  ["exe", "application/octet-stream"],
  ["exi", "application/exi"],
  ["exp", "application/express"],
  ["exr", "image/aces"],
  ["ext", "application/vnd.novadigm.ext"],
  ["ez", "application/andrew-inset"],
  ["ez2", "application/vnd.ezpix-album"],
  ["ez3", "application/vnd.ezpix-package"],
  ["f", "text/x-fortran"],
  ["f4v", "video/mp4"],
  ["f77", "text/x-fortran"],
  ["f90", "text/x-fortran"],
  ["fbs", "image/vnd.fastbidsheet"],
  ["fcdt", "application/vnd.adobe.formscentral.fcdt"],
  ["fcs", "application/vnd.isac.fcs"],
  ["fdf", "application/vnd.fdf"],
  ["fdt", "application/fdt+xml"],
  ["fe_launch", "application/vnd.denovo.fcselayout-link"],
  ["fg5", "application/vnd.fujitsu.oasysgp"],
  ["fgd", "application/x-director"],
  ["fh", "image/x-freehand"],
  ["fh4", "image/x-freehand"],
  ["fh5", "image/x-freehand"],
  ["fh7", "image/x-freehand"],
  ["fhc", "image/x-freehand"],
  ["fig", "application/x-xfig"],
  ["fits", "image/fits"],
  ["flac", "audio/x-flac"],
  ["fli", "video/x-fli"],
  ["flo", "application/vnd.micrografx.flo"],
  ["flv", "video/x-flv"],
  ["flw", "application/vnd.kde.kivio"],
  ["flx", "text/vnd.fmi.flexstor"],
  ["fly", "text/vnd.fly"],
  ["fm", "application/vnd.framemaker"],
  ["fnc", "application/vnd.frogans.fnc"],
  ["fo", "application/vnd.software602.filler.form+xml"],
  ["for", "text/x-fortran"],
  ["fpx", "image/vnd.fpx"],
  ["frame", "application/vnd.framemaker"],
  ["fsc", "application/vnd.fsc.weblaunch"],
  ["fst", "image/vnd.fst"],
  ["ftc", "application/vnd.fluxtime.clip"],
  ["fti", "application/vnd.anser-web-funds-transfer-initiation"],
  ["fvt", "video/vnd.fvt"],
  ["fxp", "application/vnd.adobe.fxp"],
  ["fxpl", "application/vnd.adobe.fxp"],
  ["fzs", "application/vnd.fuzzysheet"],
  ["g2w", "application/vnd.geoplan"],
  ["g3", "image/g3fax"],
  ["g3w", "application/vnd.geospace"],
  ["gac", "application/vnd.groove-account"],
  ["gam", "application/x-tads"],
  ["gbr", "application/rpki-ghostbusters"],
  ["gca", "application/x-gca-compressed"],
  ["gdl", "model/vnd.gdl"],
  ["gdoc", "application/vnd.google-apps.document"],
  ["geo", "application/vnd.dynageo"],
  ["geojson", "application/geo+json"],
  ["gex", "application/vnd.geometry-explorer"],
  ["ggb", "application/vnd.geogebra.file"],
  ["ggt", "application/vnd.geogebra.tool"],
  ["ghf", "application/vnd.groove-help"],
  ["gif", "image/gif"],
  ["gim", "application/vnd.groove-identity-message"],
  ["glb", "model/gltf-binary"],
  ["gltf", "model/gltf+json"],
  ["gml", "application/gml+xml"],
  ["gmx", "application/vnd.gmx"],
  ["gnumeric", "application/x-gnumeric"],
  ["gpg", "application/gpg-keys"],
  ["gph", "application/vnd.flographit"],
  ["gpx", "application/gpx+xml"],
  ["gqf", "application/vnd.grafeq"],
  ["gqs", "application/vnd.grafeq"],
  ["gram", "application/srgs"],
  ["gramps", "application/x-gramps-xml"],
  ["gre", "application/vnd.geometry-explorer"],
  ["grv", "application/vnd.groove-injector"],
  ["grxml", "application/srgs+xml"],
  ["gsf", "application/x-font-ghostscript"],
  ["gsheet", "application/vnd.google-apps.spreadsheet"],
  ["gslides", "application/vnd.google-apps.presentation"],
  ["gtar", "application/x-gtar"],
  ["gtm", "application/vnd.groove-tool-message"],
  ["gtw", "model/vnd.gtw"],
  ["gv", "text/vnd.graphviz"],
  ["gxf", "application/gxf"],
  ["gxt", "application/vnd.geonext"],
  ["gz", "application/gzip"],
  ["gzip", "application/gzip"],
  ["h", "text/x-c"],
  ["h261", "video/h261"],
  ["h263", "video/h263"],
  ["h264", "video/h264"],
  ["hal", "application/vnd.hal+xml"],
  ["hbci", "application/vnd.hbci"],
  ["hbs", "text/x-handlebars-template"],
  ["hdd", "application/x-virtualbox-hdd"],
  ["hdf", "application/x-hdf"],
  ["heic", "image/heic"],
  ["heics", "image/heic-sequence"],
  ["heif", "image/heif"],
  ["heifs", "image/heif-sequence"],
  ["hej2", "image/hej2k"],
  ["held", "application/atsc-held+xml"],
  ["hh", "text/x-c"],
  ["hjson", "application/hjson"],
  ["hlp", "application/winhlp"],
  ["hpgl", "application/vnd.hp-hpgl"],
  ["hpid", "application/vnd.hp-hpid"],
  ["hps", "application/vnd.hp-hps"],
  ["hqx", "application/mac-binhex40"],
  ["hsj2", "image/hsj2"],
  ["htc", "text/x-component"],
  ["htke", "application/vnd.kenameaapp"],
  ["htm", "text/html"],
  ["html", "text/html"],
  ["hvd", "application/vnd.yamaha.hv-dic"],
  ["hvp", "application/vnd.yamaha.hv-voice"],
  ["hvs", "application/vnd.yamaha.hv-script"],
  ["i2g", "application/vnd.intergeo"],
  ["icc", "application/vnd.iccprofile"],
  ["ice", "x-conference/x-cooltalk"],
  ["icm", "application/vnd.iccprofile"],
  ["ico", "image/x-icon"],
  ["ics", "text/calendar"],
  ["ief", "image/ief"],
  ["ifb", "text/calendar"],
  ["ifm", "application/vnd.shana.informed.formdata"],
  ["iges", "model/iges"],
  ["igl", "application/vnd.igloader"],
  ["igm", "application/vnd.insors.igm"],
  ["igs", "model/iges"],
  ["igx", "application/vnd.micrografx.igx"],
  ["iif", "application/vnd.shana.informed.interchange"],
  ["img", "application/octet-stream"],
  ["imp", "application/vnd.accpac.simply.imp"],
  ["ims", "application/vnd.ms-ims"],
  ["in", "text/plain"],
  ["ini", "text/plain"],
  ["ink", "application/inkml+xml"],
  ["inkml", "application/inkml+xml"],
  ["install", "application/x-install-instructions"],
  ["iota", "application/vnd.astraea-software.iota"],
  ["ipfix", "application/ipfix"],
  ["ipk", "application/vnd.shana.informed.package"],
  ["irm", "application/vnd.ibm.rights-management"],
  ["irp", "application/vnd.irepository.package+xml"],
  ["iso", "application/x-iso9660-image"],
  ["itp", "application/vnd.shana.informed.formtemplate"],
  ["its", "application/its+xml"],
  ["ivp", "application/vnd.immervision-ivp"],
  ["ivu", "application/vnd.immervision-ivu"],
  ["jad", "text/vnd.sun.j2me.app-descriptor"],
  ["jade", "text/jade"],
  ["jam", "application/vnd.jam"],
  ["jar", "application/java-archive"],
  ["jardiff", "application/x-java-archive-diff"],
  ["java", "text/x-java-source"],
  ["jhc", "image/jphc"],
  ["jisp", "application/vnd.jisp"],
  ["jls", "image/jls"],
  ["jlt", "application/vnd.hp-jlyt"],
  ["jng", "image/x-jng"],
  ["jnlp", "application/x-java-jnlp-file"],
  ["joda", "application/vnd.joost.joda-archive"],
  ["jp2", "image/jp2"],
  ["jpe", "image/jpeg"],
  ["jpeg", "image/jpeg"],
  ["jpf", "image/jpx"],
  ["jpg", "image/jpeg"],
  ["jpg2", "image/jp2"],
  ["jpgm", "video/jpm"],
  ["jpgv", "video/jpeg"],
  ["jph", "image/jph"],
  ["jpm", "video/jpm"],
  ["jpx", "image/jpx"],
  ["js", "application/javascript"],
  ["json", "application/json"],
  ["json5", "application/json5"],
  ["jsonld", "application/ld+json"],
  // https://jsonlines.org/
  ["jsonl", "application/jsonl"],
  ["jsonml", "application/jsonml+json"],
  ["jsx", "text/jsx"],
  ["jxr", "image/jxr"],
  ["jxra", "image/jxra"],
  ["jxrs", "image/jxrs"],
  ["jxs", "image/jxs"],
  ["jxsc", "image/jxsc"],
  ["jxsi", "image/jxsi"],
  ["jxss", "image/jxss"],
  ["kar", "audio/midi"],
  ["karbon", "application/vnd.kde.karbon"],
  ["kdb", "application/octet-stream"],
  ["kdbx", "application/x-keepass2"],
  ["key", "application/x-iwork-keynote-sffkey"],
  ["kfo", "application/vnd.kde.kformula"],
  ["kia", "application/vnd.kidspiration"],
  ["kml", "application/vnd.google-earth.kml+xml"],
  ["kmz", "application/vnd.google-earth.kmz"],
  ["kne", "application/vnd.kinar"],
  ["knp", "application/vnd.kinar"],
  ["kon", "application/vnd.kde.kontour"],
  ["kpr", "application/vnd.kde.kpresenter"],
  ["kpt", "application/vnd.kde.kpresenter"],
  ["kpxx", "application/vnd.ds-keypoint"],
  ["ksp", "application/vnd.kde.kspread"],
  ["ktr", "application/vnd.kahootz"],
  ["ktx", "image/ktx"],
  ["ktx2", "image/ktx2"],
  ["ktz", "application/vnd.kahootz"],
  ["kwd", "application/vnd.kde.kword"],
  ["kwt", "application/vnd.kde.kword"],
  ["lasxml", "application/vnd.las.las+xml"],
  ["latex", "application/x-latex"],
  ["lbd", "application/vnd.llamagraphics.life-balance.desktop"],
  ["lbe", "application/vnd.llamagraphics.life-balance.exchange+xml"],
  ["les", "application/vnd.hhe.lesson-player"],
  ["less", "text/less"],
  ["lgr", "application/lgr+xml"],
  ["lha", "application/octet-stream"],
  ["link66", "application/vnd.route66.link66+xml"],
  ["list", "text/plain"],
  ["list3820", "application/vnd.ibm.modcap"],
  ["listafp", "application/vnd.ibm.modcap"],
  ["litcoffee", "text/coffeescript"],
  ["lnk", "application/x-ms-shortcut"],
  ["log", "text/plain"],
  ["lostxml", "application/lost+xml"],
  ["lrf", "application/octet-stream"],
  ["lrm", "application/vnd.ms-lrm"],
  ["ltf", "application/vnd.frogans.ltf"],
  ["lua", "text/x-lua"],
  ["luac", "application/x-lua-bytecode"],
  ["lvp", "audio/vnd.lucent.voice"],
  ["lwp", "application/vnd.lotus-wordpro"],
  ["lzh", "application/octet-stream"],
  ["m1v", "video/mpeg"],
  ["m2a", "audio/mpeg"],
  ["m2v", "video/mpeg"],
  ["m3a", "audio/mpeg"],
  ["m3u", "text/plain"],
  ["m3u8", "application/vnd.apple.mpegurl"],
  ["m4a", "audio/x-m4a"],
  ["m4p", "application/mp4"],
  ["m4s", "video/iso.segment"],
  ["m4u", "application/vnd.mpegurl"],
  ["m4v", "video/x-m4v"],
  ["m13", "application/x-msmediaview"],
  ["m14", "application/x-msmediaview"],
  ["m21", "application/mp21"],
  ["ma", "application/mathematica"],
  ["mads", "application/mads+xml"],
  ["maei", "application/mmt-aei+xml"],
  ["mag", "application/vnd.ecowin.chart"],
  ["maker", "application/vnd.framemaker"],
  ["man", "text/troff"],
  ["manifest", "text/cache-manifest"],
  ["map", "application/json"],
  ["mar", "application/octet-stream"],
  ["markdown", "text/markdown"],
  ["mathml", "application/mathml+xml"],
  ["mb", "application/mathematica"],
  ["mbk", "application/vnd.mobius.mbk"],
  ["mbox", "application/mbox"],
  ["mc1", "application/vnd.medcalcdata"],
  ["mcd", "application/vnd.mcd"],
  ["mcurl", "text/vnd.curl.mcurl"],
  ["md", "text/markdown"],
  ["mdb", "application/x-msaccess"],
  ["mdi", "image/vnd.ms-modi"],
  ["mdx", "text/mdx"],
  ["me", "text/troff"],
  ["mesh", "model/mesh"],
  ["meta4", "application/metalink4+xml"],
  ["metalink", "application/metalink+xml"],
  ["mets", "application/mets+xml"],
  ["mfm", "application/vnd.mfmp"],
  ["mft", "application/rpki-manifest"],
  ["mgp", "application/vnd.osgeo.mapguide.package"],
  ["mgz", "application/vnd.proteus.magazine"],
  ["mid", "audio/midi"],
  ["midi", "audio/midi"],
  ["mie", "application/x-mie"],
  ["mif", "application/vnd.mif"],
  ["mime", "message/rfc822"],
  ["mj2", "video/mj2"],
  ["mjp2", "video/mj2"],
  ["mjs", "application/javascript"],
  ["mk3d", "video/x-matroska"],
  ["mka", "audio/x-matroska"],
  ["mkd", "text/x-markdown"],
  ["mks", "video/x-matroska"],
  ["mkv", "video/x-matroska"],
  ["mlp", "application/vnd.dolby.mlp"],
  ["mmd", "application/vnd.chipnuts.karaoke-mmd"],
  ["mmf", "application/vnd.smaf"],
  ["mml", "text/mathml"],
  ["mmr", "image/vnd.fujixerox.edmics-mmr"],
  ["mng", "video/x-mng"],
  ["mny", "application/x-msmoney"],
  ["mobi", "application/x-mobipocket-ebook"],
  ["mods", "application/mods+xml"],
  ["mov", "video/quicktime"],
  ["movie", "video/x-sgi-movie"],
  ["mp2", "audio/mpeg"],
  ["mp2a", "audio/mpeg"],
  ["mp3", "audio/mpeg"],
  ["mp4", "video/mp4"],
  ["mp4a", "audio/mp4"],
  ["mp4s", "application/mp4"],
  ["mp4v", "video/mp4"],
  ["mp21", "application/mp21"],
  ["mpc", "application/vnd.mophun.certificate"],
  ["mpd", "application/dash+xml"],
  ["mpe", "video/mpeg"],
  ["mpeg", "video/mpeg"],
  ["mpg", "video/mpeg"],
  ["mpg4", "video/mp4"],
  ["mpga", "audio/mpeg"],
  ["mpkg", "application/vnd.apple.installer+xml"],
  ["mpm", "application/vnd.blueice.multipass"],
  ["mpn", "application/vnd.mophun.application"],
  ["mpp", "application/vnd.ms-project"],
  ["mpt", "application/vnd.ms-project"],
  ["mpy", "application/vnd.ibm.minipay"],
  ["mqy", "application/vnd.mobius.mqy"],
  ["mrc", "application/marc"],
  ["mrcx", "application/marcxml+xml"],
  ["ms", "text/troff"],
  ["mscml", "application/mediaservercontrol+xml"],
  ["mseed", "application/vnd.fdsn.mseed"],
  ["mseq", "application/vnd.mseq"],
  ["msf", "application/vnd.epson.msf"],
  ["msg", "application/vnd.ms-outlook"],
  ["msh", "model/mesh"],
  ["msi", "application/x-msdownload"],
  ["msl", "application/vnd.mobius.msl"],
  ["msm", "application/octet-stream"],
  ["msp", "application/octet-stream"],
  ["msty", "application/vnd.muvee.style"],
  ["mtl", "model/mtl"],
  ["mts", "model/vnd.mts"],
  ["mus", "application/vnd.musician"],
  ["musd", "application/mmt-usd+xml"],
  ["musicxml", "application/vnd.recordare.musicxml+xml"],
  ["mvb", "application/x-msmediaview"],
  ["mvt", "application/vnd.mapbox-vector-tile"],
  ["mwf", "application/vnd.mfer"],
  ["mxf", "application/mxf"],
  ["mxl", "application/vnd.recordare.musicxml"],
  ["mxmf", "audio/mobile-xmf"],
  ["mxml", "application/xv+xml"],
  ["mxs", "application/vnd.triscape.mxs"],
  ["mxu", "video/vnd.mpegurl"],
  ["n-gage", "application/vnd.nokia.n-gage.symbian.install"],
  ["n3", "text/n3"],
  ["nb", "application/mathematica"],
  ["nbp", "application/vnd.wolfram.player"],
  ["nc", "application/x-netcdf"],
  ["ncx", "application/x-dtbncx+xml"],
  ["nfo", "text/x-nfo"],
  ["ngdat", "application/vnd.nokia.n-gage.data"],
  ["nitf", "application/vnd.nitf"],
  ["nlu", "application/vnd.neurolanguage.nlu"],
  ["nml", "application/vnd.enliven"],
  ["nnd", "application/vnd.noblenet-directory"],
  ["nns", "application/vnd.noblenet-sealer"],
  ["nnw", "application/vnd.noblenet-web"],
  ["npx", "image/vnd.net-fpx"],
  ["nq", "application/n-quads"],
  ["nsc", "application/x-conference"],
  ["nsf", "application/vnd.lotus-notes"],
  ["nt", "application/n-triples"],
  ["ntf", "application/vnd.nitf"],
  ["numbers", "application/x-iwork-numbers-sffnumbers"],
  ["nzb", "application/x-nzb"],
  ["oa2", "application/vnd.fujitsu.oasys2"],
  ["oa3", "application/vnd.fujitsu.oasys3"],
  ["oas", "application/vnd.fujitsu.oasys"],
  ["obd", "application/x-msbinder"],
  ["obgx", "application/vnd.openblox.game+xml"],
  ["obj", "model/obj"],
  ["oda", "application/oda"],
  ["odb", "application/vnd.oasis.opendocument.database"],
  ["odc", "application/vnd.oasis.opendocument.chart"],
  ["odf", "application/vnd.oasis.opendocument.formula"],
  ["odft", "application/vnd.oasis.opendocument.formula-template"],
  ["odg", "application/vnd.oasis.opendocument.graphics"],
  ["odi", "application/vnd.oasis.opendocument.image"],
  ["odm", "application/vnd.oasis.opendocument.text-master"],
  ["odp", "application/vnd.oasis.opendocument.presentation"],
  ["ods", "application/vnd.oasis.opendocument.spreadsheet"],
  ["odt", "application/vnd.oasis.opendocument.text"],
  ["oga", "audio/ogg"],
  ["ogex", "model/vnd.opengex"],
  ["ogg", "audio/ogg"],
  ["ogv", "video/ogg"],
  ["ogx", "application/ogg"],
  ["omdoc", "application/omdoc+xml"],
  ["onepkg", "application/onenote"],
  ["onetmp", "application/onenote"],
  ["onetoc", "application/onenote"],
  ["onetoc2", "application/onenote"],
  ["opf", "application/oebps-package+xml"],
  ["opml", "text/x-opml"],
  ["oprc", "application/vnd.palm"],
  ["opus", "audio/ogg"],
  ["org", "text/x-org"],
  ["osf", "application/vnd.yamaha.openscoreformat"],
  ["osfpvg", "application/vnd.yamaha.openscoreformat.osfpvg+xml"],
  ["osm", "application/vnd.openstreetmap.data+xml"],
  ["otc", "application/vnd.oasis.opendocument.chart-template"],
  ["otf", "font/otf"],
  ["otg", "application/vnd.oasis.opendocument.graphics-template"],
  ["oth", "application/vnd.oasis.opendocument.text-web"],
  ["oti", "application/vnd.oasis.opendocument.image-template"],
  ["otp", "application/vnd.oasis.opendocument.presentation-template"],
  ["ots", "application/vnd.oasis.opendocument.spreadsheet-template"],
  ["ott", "application/vnd.oasis.opendocument.text-template"],
  ["ova", "application/x-virtualbox-ova"],
  ["ovf", "application/x-virtualbox-ovf"],
  ["owl", "application/rdf+xml"],
  ["oxps", "application/oxps"],
  ["oxt", "application/vnd.openofficeorg.extension"],
  ["p", "text/x-pascal"],
  ["p7a", "application/x-pkcs7-signature"],
  ["p7b", "application/x-pkcs7-certificates"],
  ["p7c", "application/pkcs7-mime"],
  ["p7m", "application/pkcs7-mime"],
  ["p7r", "application/x-pkcs7-certreqresp"],
  ["p7s", "application/pkcs7-signature"],
  ["p8", "application/pkcs8"],
  ["p10", "application/x-pkcs10"],
  ["p12", "application/x-pkcs12"],
  ["pac", "application/x-ns-proxy-autoconfig"],
  ["pages", "application/x-iwork-pages-sffpages"],
  ["pas", "text/x-pascal"],
  ["paw", "application/vnd.pawaafile"],
  ["pbd", "application/vnd.powerbuilder6"],
  ["pbm", "image/x-portable-bitmap"],
  ["pcap", "application/vnd.tcpdump.pcap"],
  ["pcf", "application/x-font-pcf"],
  ["pcl", "application/vnd.hp-pcl"],
  ["pclxl", "application/vnd.hp-pclxl"],
  ["pct", "image/x-pict"],
  ["pcurl", "application/vnd.curl.pcurl"],
  ["pcx", "image/x-pcx"],
  ["pdb", "application/x-pilot"],
  ["pde", "text/x-processing"],
  ["pdf", "application/pdf"],
  ["pem", "application/x-x509-user-cert"],
  ["pfa", "application/x-font-type1"],
  ["pfb", "application/x-font-type1"],
  ["pfm", "application/x-font-type1"],
  ["pfr", "application/font-tdpfr"],
  ["pfx", "application/x-pkcs12"],
  ["pgm", "image/x-portable-graymap"],
  ["pgn", "application/x-chess-pgn"],
  ["pgp", "application/pgp"],
  ["php", "application/x-httpd-php"],
  ["php3", "application/x-httpd-php"],
  ["php4", "application/x-httpd-php"],
  ["phps", "application/x-httpd-php-source"],
  ["phtml", "application/x-httpd-php"],
  ["pic", "image/x-pict"],
  ["pkg", "application/octet-stream"],
  ["pki", "application/pkixcmp"],
  ["pkipath", "application/pkix-pkipath"],
  ["pkpass", "application/vnd.apple.pkpass"],
  ["pl", "application/x-perl"],
  ["plb", "application/vnd.3gpp.pic-bw-large"],
  ["plc", "application/vnd.mobius.plc"],
  ["plf", "application/vnd.pocketlearn"],
  ["pls", "application/pls+xml"],
  ["pm", "application/x-perl"],
  ["pml", "application/vnd.ctc-posml"],
  ["png", "image/png"],
  ["pnm", "image/x-portable-anymap"],
  ["portpkg", "application/vnd.macports.portpkg"],
  ["pot", "application/vnd.ms-powerpoint"],
  ["potm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12"],
  ["potx", "application/vnd.openxmlformats-officedocument.presentationml.template"],
  ["ppa", "application/vnd.ms-powerpoint"],
  ["ppam", "application/vnd.ms-powerpoint.addin.macroEnabled.12"],
  ["ppd", "application/vnd.cups-ppd"],
  ["ppm", "image/x-portable-pixmap"],
  ["pps", "application/vnd.ms-powerpoint"],
  ["ppsm", "application/vnd.ms-powerpoint.slideshow.macroEnabled.12"],
  ["ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow"],
  ["ppt", "application/powerpoint"],
  ["pptm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12"],
  ["pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
  ["pqa", "application/vnd.palm"],
  ["prc", "application/x-pilot"],
  ["pre", "application/vnd.lotus-freelance"],
  ["prf", "application/pics-rules"],
  ["provx", "application/provenance+xml"],
  ["ps", "application/postscript"],
  ["psb", "application/vnd.3gpp.pic-bw-small"],
  ["psd", "application/x-photoshop"],
  ["psf", "application/x-font-linux-psf"],
  ["pskcxml", "application/pskc+xml"],
  ["pti", "image/prs.pti"],
  ["ptid", "application/vnd.pvi.ptid1"],
  ["pub", "application/x-mspublisher"],
  ["pvb", "application/vnd.3gpp.pic-bw-var"],
  ["pwn", "application/vnd.3m.post-it-notes"],
  ["pya", "audio/vnd.ms-playready.media.pya"],
  ["pyv", "video/vnd.ms-playready.media.pyv"],
  ["qam", "application/vnd.epson.quickanime"],
  ["qbo", "application/vnd.intu.qbo"],
  ["qfx", "application/vnd.intu.qfx"],
  ["qps", "application/vnd.publishare-delta-tree"],
  ["qt", "video/quicktime"],
  ["qwd", "application/vnd.quark.quarkxpress"],
  ["qwt", "application/vnd.quark.quarkxpress"],
  ["qxb", "application/vnd.quark.quarkxpress"],
  ["qxd", "application/vnd.quark.quarkxpress"],
  ["qxl", "application/vnd.quark.quarkxpress"],
  ["qxt", "application/vnd.quark.quarkxpress"],
  ["ra", "audio/x-realaudio"],
  ["ram", "audio/x-pn-realaudio"],
  ["raml", "application/raml+yaml"],
  ["rapd", "application/route-apd+xml"],
  ["rar", "application/x-rar"],
  ["ras", "image/x-cmu-raster"],
  ["rcprofile", "application/vnd.ipunplugged.rcprofile"],
  ["rdf", "application/rdf+xml"],
  ["rdz", "application/vnd.data-vision.rdz"],
  ["relo", "application/p2p-overlay+xml"],
  ["rep", "application/vnd.businessobjects"],
  ["res", "application/x-dtbresource+xml"],
  ["rgb", "image/x-rgb"],
  ["rif", "application/reginfo+xml"],
  ["rip", "audio/vnd.rip"],
  ["ris", "application/x-research-info-systems"],
  ["rl", "application/resource-lists+xml"],
  ["rlc", "image/vnd.fujixerox.edmics-rlc"],
  ["rld", "application/resource-lists-diff+xml"],
  ["rm", "audio/x-pn-realaudio"],
  ["rmi", "audio/midi"],
  ["rmp", "audio/x-pn-realaudio-plugin"],
  ["rms", "application/vnd.jcp.javame.midlet-rms"],
  ["rmvb", "application/vnd.rn-realmedia-vbr"],
  ["rnc", "application/relax-ng-compact-syntax"],
  ["rng", "application/xml"],
  ["roa", "application/rpki-roa"],
  ["roff", "text/troff"],
  ["rp9", "application/vnd.cloanto.rp9"],
  ["rpm", "audio/x-pn-realaudio-plugin"],
  ["rpss", "application/vnd.nokia.radio-presets"],
  ["rpst", "application/vnd.nokia.radio-preset"],
  ["rq", "application/sparql-query"],
  ["rs", "application/rls-services+xml"],
  ["rsa", "application/x-pkcs7"],
  ["rsat", "application/atsc-rsat+xml"],
  ["rsd", "application/rsd+xml"],
  ["rsheet", "application/urc-ressheet+xml"],
  ["rss", "application/rss+xml"],
  ["rtf", "text/rtf"],
  ["rtx", "text/richtext"],
  ["run", "application/x-makeself"],
  ["rusd", "application/route-usd+xml"],
  ["rv", "video/vnd.rn-realvideo"],
  ["s", "text/x-asm"],
  ["s3m", "audio/s3m"],
  ["saf", "application/vnd.yamaha.smaf-audio"],
  ["sass", "text/x-sass"],
  ["sbml", "application/sbml+xml"],
  ["sc", "application/vnd.ibm.secure-container"],
  ["scd", "application/x-msschedule"],
  ["scm", "application/vnd.lotus-screencam"],
  ["scq", "application/scvp-cv-request"],
  ["scs", "application/scvp-cv-response"],
  ["scss", "text/x-scss"],
  ["scurl", "text/vnd.curl.scurl"],
  ["sda", "application/vnd.stardivision.draw"],
  ["sdc", "application/vnd.stardivision.calc"],
  ["sdd", "application/vnd.stardivision.impress"],
  ["sdkd", "application/vnd.solent.sdkm+xml"],
  ["sdkm", "application/vnd.solent.sdkm+xml"],
  ["sdp", "application/sdp"],
  ["sdw", "application/vnd.stardivision.writer"],
  ["sea", "application/octet-stream"],
  ["see", "application/vnd.seemail"],
  ["seed", "application/vnd.fdsn.seed"],
  ["sema", "application/vnd.sema"],
  ["semd", "application/vnd.semd"],
  ["semf", "application/vnd.semf"],
  ["senmlx", "application/senml+xml"],
  ["sensmlx", "application/sensml+xml"],
  ["ser", "application/java-serialized-object"],
  ["setpay", "application/set-payment-initiation"],
  ["setreg", "application/set-registration-initiation"],
  ["sfd-hdstx", "application/vnd.hydrostatix.sof-data"],
  ["sfs", "application/vnd.spotfire.sfs"],
  ["sfv", "text/x-sfv"],
  ["sgi", "image/sgi"],
  ["sgl", "application/vnd.stardivision.writer-global"],
  ["sgm", "text/sgml"],
  ["sgml", "text/sgml"],
  ["sh", "application/x-sh"],
  ["shar", "application/x-shar"],
  ["shex", "text/shex"],
  ["shf", "application/shf+xml"],
  ["shtml", "text/html"],
  ["sid", "image/x-mrsid-image"],
  ["sieve", "application/sieve"],
  ["sig", "application/pgp-signature"],
  ["sil", "audio/silk"],
  ["silo", "model/mesh"],
  ["sis", "application/vnd.symbian.install"],
  ["sisx", "application/vnd.symbian.install"],
  ["sit", "application/x-stuffit"],
  ["sitx", "application/x-stuffitx"],
  ["siv", "application/sieve"],
  ["skd", "application/vnd.koan"],
  ["skm", "application/vnd.koan"],
  ["skp", "application/vnd.koan"],
  ["skt", "application/vnd.koan"],
  ["sldm", "application/vnd.ms-powerpoint.slide.macroenabled.12"],
  ["sldx", "application/vnd.openxmlformats-officedocument.presentationml.slide"],
  ["slim", "text/slim"],
  ["slm", "text/slim"],
  ["sls", "application/route-s-tsid+xml"],
  ["slt", "application/vnd.epson.salt"],
  ["sm", "application/vnd.stepmania.stepchart"],
  ["smf", "application/vnd.stardivision.math"],
  ["smi", "application/smil"],
  ["smil", "application/smil"],
  ["smv", "video/x-smv"],
  ["smzip", "application/vnd.stepmania.package"],
  ["snd", "audio/basic"],
  ["snf", "application/x-font-snf"],
  ["so", "application/octet-stream"],
  ["spc", "application/x-pkcs7-certificates"],
  ["spdx", "text/spdx"],
  ["spf", "application/vnd.yamaha.smaf-phrase"],
  ["spl", "application/x-futuresplash"],
  ["spot", "text/vnd.in3d.spot"],
  ["spp", "application/scvp-vp-response"],
  ["spq", "application/scvp-vp-request"],
  ["spx", "audio/ogg"],
  ["sql", "application/x-sql"],
  ["src", "application/x-wais-source"],
  ["srt", "application/x-subrip"],
  ["sru", "application/sru+xml"],
  ["srx", "application/sparql-results+xml"],
  ["ssdl", "application/ssdl+xml"],
  ["sse", "application/vnd.kodak-descriptor"],
  ["ssf", "application/vnd.epson.ssf"],
  ["ssml", "application/ssml+xml"],
  ["sst", "application/octet-stream"],
  ["st", "application/vnd.sailingtracker.track"],
  ["stc", "application/vnd.sun.xml.calc.template"],
  ["std", "application/vnd.sun.xml.draw.template"],
  ["stf", "application/vnd.wt.stf"],
  ["sti", "application/vnd.sun.xml.impress.template"],
  ["stk", "application/hyperstudio"],
  ["stl", "model/stl"],
  ["stpx", "model/step+xml"],
  ["stpxz", "model/step-xml+zip"],
  ["stpz", "model/step+zip"],
  ["str", "application/vnd.pg.format"],
  ["stw", "application/vnd.sun.xml.writer.template"],
  ["styl", "text/stylus"],
  ["stylus", "text/stylus"],
  ["sub", "text/vnd.dvb.subtitle"],
  ["sus", "application/vnd.sus-calendar"],
  ["susp", "application/vnd.sus-calendar"],
  ["sv4cpio", "application/x-sv4cpio"],
  ["sv4crc", "application/x-sv4crc"],
  ["svc", "application/vnd.dvb.service"],
  ["svd", "application/vnd.svd"],
  ["svg", "image/svg+xml"],
  ["svgz", "image/svg+xml"],
  ["swa", "application/x-director"],
  ["swf", "application/x-shockwave-flash"],
  ["swi", "application/vnd.aristanetworks.swi"],
  ["swidtag", "application/swid+xml"],
  ["sxc", "application/vnd.sun.xml.calc"],
  ["sxd", "application/vnd.sun.xml.draw"],
  ["sxg", "application/vnd.sun.xml.writer.global"],
  ["sxi", "application/vnd.sun.xml.impress"],
  ["sxm", "application/vnd.sun.xml.math"],
  ["sxw", "application/vnd.sun.xml.writer"],
  ["t", "text/troff"],
  ["t3", "application/x-t3vm-image"],
  ["t38", "image/t38"],
  ["taglet", "application/vnd.mynfc"],
  ["tao", "application/vnd.tao.intent-module-archive"],
  ["tap", "image/vnd.tencent.tap"],
  ["tar", "application/x-tar"],
  ["tcap", "application/vnd.3gpp2.tcap"],
  ["tcl", "application/x-tcl"],
  ["td", "application/urc-targetdesc+xml"],
  ["teacher", "application/vnd.smart.teacher"],
  ["tei", "application/tei+xml"],
  ["teicorpus", "application/tei+xml"],
  ["tex", "application/x-tex"],
  ["texi", "application/x-texinfo"],
  ["texinfo", "application/x-texinfo"],
  ["text", "text/plain"],
  ["tfi", "application/thraud+xml"],
  ["tfm", "application/x-tex-tfm"],
  ["tfx", "image/tiff-fx"],
  ["tga", "image/x-tga"],
  ["tgz", "application/x-tar"],
  ["thmx", "application/vnd.ms-officetheme"],
  ["tif", "image/tiff"],
  ["tiff", "image/tiff"],
  ["tk", "application/x-tcl"],
  ["tmo", "application/vnd.tmobile-livetv"],
  ["toml", "application/toml"],
  ["torrent", "application/x-bittorrent"],
  ["tpl", "application/vnd.groove-tool-template"],
  ["tpt", "application/vnd.trid.tpt"],
  ["tr", "text/troff"],
  ["tra", "application/vnd.trueapp"],
  ["trig", "application/trig"],
  ["trm", "application/x-msterminal"],
  ["ts", "video/mp2t"],
  ["tsd", "application/timestamped-data"],
  ["tsv", "text/tab-separated-values"],
  ["ttc", "font/collection"],
  ["ttf", "font/ttf"],
  ["ttl", "text/turtle"],
  ["ttml", "application/ttml+xml"],
  ["twd", "application/vnd.simtech-mindmapper"],
  ["twds", "application/vnd.simtech-mindmapper"],
  ["txd", "application/vnd.genomatix.tuxedo"],
  ["txf", "application/vnd.mobius.txf"],
  ["txt", "text/plain"],
  ["u8dsn", "message/global-delivery-status"],
  ["u8hdr", "message/global-headers"],
  ["u8mdn", "message/global-disposition-notification"],
  ["u8msg", "message/global"],
  ["u32", "application/x-authorware-bin"],
  ["ubj", "application/ubjson"],
  ["udeb", "application/x-debian-package"],
  ["ufd", "application/vnd.ufdl"],
  ["ufdl", "application/vnd.ufdl"],
  ["ulx", "application/x-glulx"],
  ["umj", "application/vnd.umajin"],
  ["unityweb", "application/vnd.unity"],
  ["uoml", "application/vnd.uoml+xml"],
  ["uri", "text/uri-list"],
  ["uris", "text/uri-list"],
  ["urls", "text/uri-list"],
  ["usdz", "model/vnd.usdz+zip"],
  ["ustar", "application/x-ustar"],
  ["utz", "application/vnd.uiq.theme"],
  ["uu", "text/x-uuencode"],
  ["uva", "audio/vnd.dece.audio"],
  ["uvd", "application/vnd.dece.data"],
  ["uvf", "application/vnd.dece.data"],
  ["uvg", "image/vnd.dece.graphic"],
  ["uvh", "video/vnd.dece.hd"],
  ["uvi", "image/vnd.dece.graphic"],
  ["uvm", "video/vnd.dece.mobile"],
  ["uvp", "video/vnd.dece.pd"],
  ["uvs", "video/vnd.dece.sd"],
  ["uvt", "application/vnd.dece.ttml+xml"],
  ["uvu", "video/vnd.uvvu.mp4"],
  ["uvv", "video/vnd.dece.video"],
  ["uvva", "audio/vnd.dece.audio"],
  ["uvvd", "application/vnd.dece.data"],
  ["uvvf", "application/vnd.dece.data"],
  ["uvvg", "image/vnd.dece.graphic"],
  ["uvvh", "video/vnd.dece.hd"],
  ["uvvi", "image/vnd.dece.graphic"],
  ["uvvm", "video/vnd.dece.mobile"],
  ["uvvp", "video/vnd.dece.pd"],
  ["uvvs", "video/vnd.dece.sd"],
  ["uvvt", "application/vnd.dece.ttml+xml"],
  ["uvvu", "video/vnd.uvvu.mp4"],
  ["uvvv", "video/vnd.dece.video"],
  ["uvvx", "application/vnd.dece.unspecified"],
  ["uvvz", "application/vnd.dece.zip"],
  ["uvx", "application/vnd.dece.unspecified"],
  ["uvz", "application/vnd.dece.zip"],
  ["vbox", "application/x-virtualbox-vbox"],
  ["vbox-extpack", "application/x-virtualbox-vbox-extpack"],
  ["vcard", "text/vcard"],
  ["vcd", "application/x-cdlink"],
  ["vcf", "text/x-vcard"],
  ["vcg", "application/vnd.groove-vcard"],
  ["vcs", "text/x-vcalendar"],
  ["vcx", "application/vnd.vcx"],
  ["vdi", "application/x-virtualbox-vdi"],
  ["vds", "model/vnd.sap.vds"],
  ["vhd", "application/x-virtualbox-vhd"],
  ["vis", "application/vnd.visionary"],
  ["viv", "video/vnd.vivo"],
  ["vlc", "application/videolan"],
  ["vmdk", "application/x-virtualbox-vmdk"],
  ["vob", "video/x-ms-vob"],
  ["vor", "application/vnd.stardivision.writer"],
  ["vox", "application/x-authorware-bin"],
  ["vrml", "model/vrml"],
  ["vsd", "application/vnd.visio"],
  ["vsf", "application/vnd.vsf"],
  ["vss", "application/vnd.visio"],
  ["vst", "application/vnd.visio"],
  ["vsw", "application/vnd.visio"],
  ["vtf", "image/vnd.valve.source.texture"],
  ["vtt", "text/vtt"],
  ["vtu", "model/vnd.vtu"],
  ["vxml", "application/voicexml+xml"],
  ["w3d", "application/x-director"],
  ["wad", "application/x-doom"],
  ["wadl", "application/vnd.sun.wadl+xml"],
  ["war", "application/java-archive"],
  ["wasm", "application/wasm"],
  ["wav", "audio/x-wav"],
  ["wax", "audio/x-ms-wax"],
  ["wbmp", "image/vnd.wap.wbmp"],
  ["wbs", "application/vnd.criticaltools.wbs+xml"],
  ["wbxml", "application/wbxml"],
  ["wcm", "application/vnd.ms-works"],
  ["wdb", "application/vnd.ms-works"],
  ["wdp", "image/vnd.ms-photo"],
  ["weba", "audio/webm"],
  ["webapp", "application/x-web-app-manifest+json"],
  ["webm", "video/webm"],
  ["webmanifest", "application/manifest+json"],
  ["webp", "image/webp"],
  ["wg", "application/vnd.pmi.widget"],
  ["wgt", "application/widget"],
  ["wks", "application/vnd.ms-works"],
  ["wm", "video/x-ms-wm"],
  ["wma", "audio/x-ms-wma"],
  ["wmd", "application/x-ms-wmd"],
  ["wmf", "image/wmf"],
  ["wml", "text/vnd.wap.wml"],
  ["wmlc", "application/wmlc"],
  ["wmls", "text/vnd.wap.wmlscript"],
  ["wmlsc", "application/vnd.wap.wmlscriptc"],
  ["wmv", "video/x-ms-wmv"],
  ["wmx", "video/x-ms-wmx"],
  ["wmz", "application/x-msmetafile"],
  ["woff", "font/woff"],
  ["woff2", "font/woff2"],
  ["word", "application/msword"],
  ["wpd", "application/vnd.wordperfect"],
  ["wpl", "application/vnd.ms-wpl"],
  ["wps", "application/vnd.ms-works"],
  ["wqd", "application/vnd.wqd"],
  ["wri", "application/x-mswrite"],
  ["wrl", "model/vrml"],
  ["wsc", "message/vnd.wfa.wsc"],
  ["wsdl", "application/wsdl+xml"],
  ["wspolicy", "application/wspolicy+xml"],
  ["wtb", "application/vnd.webturbo"],
  ["wvx", "video/x-ms-wvx"],
  ["x3d", "model/x3d+xml"],
  ["x3db", "model/x3d+fastinfoset"],
  ["x3dbz", "model/x3d+binary"],
  ["x3dv", "model/x3d-vrml"],
  ["x3dvz", "model/x3d+vrml"],
  ["x3dz", "model/x3d+xml"],
  ["x32", "application/x-authorware-bin"],
  ["x_b", "model/vnd.parasolid.transmit.binary"],
  ["x_t", "model/vnd.parasolid.transmit.text"],
  ["xaml", "application/xaml+xml"],
  ["xap", "application/x-silverlight-app"],
  ["xar", "application/vnd.xara"],
  ["xav", "application/xcap-att+xml"],
  ["xbap", "application/x-ms-xbap"],
  ["xbd", "application/vnd.fujixerox.docuworks.binder"],
  ["xbm", "image/x-xbitmap"],
  ["xca", "application/xcap-caps+xml"],
  ["xcs", "application/calendar+xml"],
  ["xdf", "application/xcap-diff+xml"],
  ["xdm", "application/vnd.syncml.dm+xml"],
  ["xdp", "application/vnd.adobe.xdp+xml"],
  ["xdssc", "application/dssc+xml"],
  ["xdw", "application/vnd.fujixerox.docuworks"],
  ["xel", "application/xcap-el+xml"],
  ["xenc", "application/xenc+xml"],
  ["xer", "application/patch-ops-error+xml"],
  ["xfdf", "application/vnd.adobe.xfdf"],
  ["xfdl", "application/vnd.xfdl"],
  ["xht", "application/xhtml+xml"],
  ["xhtml", "application/xhtml+xml"],
  ["xhvml", "application/xv+xml"],
  ["xif", "image/vnd.xiff"],
  ["xl", "application/excel"],
  ["xla", "application/vnd.ms-excel"],
  ["xlam", "application/vnd.ms-excel.addin.macroEnabled.12"],
  ["xlc", "application/vnd.ms-excel"],
  ["xlf", "application/xliff+xml"],
  ["xlm", "application/vnd.ms-excel"],
  ["xls", "application/vnd.ms-excel"],
  ["xlsb", "application/vnd.ms-excel.sheet.binary.macroEnabled.12"],
  ["xlsm", "application/vnd.ms-excel.sheet.macroEnabled.12"],
  ["xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
  ["xlt", "application/vnd.ms-excel"],
  ["xltm", "application/vnd.ms-excel.template.macroEnabled.12"],
  ["xltx", "application/vnd.openxmlformats-officedocument.spreadsheetml.template"],
  ["xlw", "application/vnd.ms-excel"],
  ["xm", "audio/xm"],
  ["xml", "application/xml"],
  ["xns", "application/xcap-ns+xml"],
  ["xo", "application/vnd.olpc-sugar"],
  ["xop", "application/xop+xml"],
  ["xpi", "application/x-xpinstall"],
  ["xpl", "application/xproc+xml"],
  ["xpm", "image/x-xpixmap"],
  ["xpr", "application/vnd.is-xpr"],
  ["xps", "application/vnd.ms-xpsdocument"],
  ["xpw", "application/vnd.intercon.formnet"],
  ["xpx", "application/vnd.intercon.formnet"],
  ["xsd", "application/xml"],
  ["xsl", "application/xml"],
  ["xslt", "application/xslt+xml"],
  ["xsm", "application/vnd.syncml+xml"],
  ["xspf", "application/xspf+xml"],
  ["xul", "application/vnd.mozilla.xul+xml"],
  ["xvm", "application/xv+xml"],
  ["xvml", "application/xv+xml"],
  ["xwd", "image/x-xwindowdump"],
  ["xyz", "chemical/x-xyz"],
  ["xz", "application/x-xz"],
  ["yaml", "text/yaml"],
  ["yang", "application/yang"],
  ["yin", "application/yin+xml"],
  ["yml", "text/yaml"],
  ["ymp", "text/x-suse-ymp"],
  ["z", "application/x-compress"],
  ["z1", "application/x-zmachine"],
  ["z2", "application/x-zmachine"],
  ["z3", "application/x-zmachine"],
  ["z4", "application/x-zmachine"],
  ["z5", "application/x-zmachine"],
  ["z6", "application/x-zmachine"],
  ["z7", "application/x-zmachine"],
  ["z8", "application/x-zmachine"],
  ["zaz", "application/vnd.zzazz.deck+xml"],
  ["zip", "application/zip"],
  ["zir", "application/vnd.zul"],
  ["zirz", "application/vnd.zul"],
  ["zmm", "application/vnd.handheld-entertainment+xml"],
  ["zsh", "text/x-scriptzsh"]
]);
function ur(t, e, n) {
  const o = B3(t), { webkitRelativePath: u } = t, g = typeof e == "string" ? e : typeof u == "string" && u.length > 0 ? u : `./${t.name}`;
  return typeof o.path != "string" && Hh(o, "path", g), Hh(o, "relativePath", g), o;
}
function B3(t) {
  const { name: e } = t;
  if (e && e.lastIndexOf(".") !== -1 && !t.type) {
    const n = e.split(".").pop().toLowerCase(), o = F3.get(n);
    o && Object.defineProperty(t, "type", {
      value: o,
      writable: !1,
      configurable: !1,
      enumerable: !0
    });
  }
  return t;
}
function Hh(t, e, n) {
  Object.defineProperty(t, e, {
    value: n,
    writable: !1,
    configurable: !1,
    enumerable: !0
  });
}
const z3 = [
  // Thumbnail cache files for macOS and Windows
  ".DS_Store",
  // macOs
  "Thumbs.db"
  // Windows
];
function N3(t) {
  return Pi(this, void 0, void 0, function* () {
    return Ro(t) && U3(t.dataTransfer) ? G3(t.dataTransfer, t.type) : W3(t) ? Y3(t) : Array.isArray(t) && t.every((e) => "getFile" in e && typeof e.getFile == "function") ? V3(t) : [];
  });
}
function U3(t) {
  return Ro(t);
}
function W3(t) {
  return Ro(t) && Ro(t.target);
}
function Ro(t) {
  return typeof t == "object" && t !== null;
}
function Y3(t) {
  return Vl(t.target.files).map((e) => ur(e));
}
function V3(t) {
  return Pi(this, void 0, void 0, function* () {
    return (yield Promise.all(t.map((e) => e.getFile()))).map((e) => ur(e));
  });
}
function G3(t, e) {
  return Pi(this, void 0, void 0, function* () {
    if (t.items) {
      const n = Vl(t.items).filter((u) => u.kind === "file");
      if (e !== "drop")
        return n;
      const o = yield Promise.all(n.map(H3));
      return Xh(s0(o));
    }
    return Xh(Vl(t.files).map((n) => ur(n)));
  });
}
function Xh(t) {
  return t.filter((e) => z3.indexOf(e.name) === -1);
}
function Vl(t) {
  if (t === null)
    return [];
  const e = [];
  for (let n = 0; n < t.length; n++) {
    const o = t[n];
    e.push(o);
  }
  return e;
}
function H3(t) {
  if (typeof t.webkitGetAsEntry != "function")
    return qh(t);
  const e = t.webkitGetAsEntry();
  return e && e.isDirectory ? l0(e) : qh(t, e);
}
function s0(t) {
  return t.reduce((e, n) => [
    ...e,
    ...Array.isArray(n) ? s0(n) : [n]
  ], []);
}
function qh(t, e) {
  var n;
  if (typeof t.getAsFileSystemHandle == "function")
    return t.getAsFileSystemHandle().then((g) => Pi(this, void 0, void 0, function* () {
      const v = yield g.getFile();
      return v.handle = g, ur(v);
    }));
  const o = t.getAsFile();
  if (!o)
    return Promise.reject(`${t} is not a File`);
  const u = ur(o, (n = e == null ? void 0 : e.fullPath) !== null && n !== void 0 ? n : void 0);
  return Promise.resolve(u);
}
function X3(t) {
  return Pi(this, void 0, void 0, function* () {
    return t.isDirectory ? l0(t) : q3(t);
  });
}
function l0(t) {
  const e = t.createReader();
  return new Promise((n, o) => {
    const u = [];
    function g() {
      e.readEntries((v) => Pi(this, void 0, void 0, function* () {
        if (v.length) {
          const x = Promise.all(v.map(X3));
          u.push(x), g();
        } else
          try {
            const x = yield Promise.all(u);
            n(x);
          } catch (x) {
            o(x);
          }
      }), (v) => {
        o(v);
      });
    }
    g();
  });
}
function q3(t) {
  return Pi(this, void 0, void 0, function* () {
    return new Promise((e, n) => {
      t.file((o) => {
        const u = ur(o, t.fullPath);
        e(u);
      }, (o) => {
        n(o);
      });
    });
  });
}
var Us = function(t, e) {
  if (t && e) {
    var n = Array.isArray(e) ? e : e.split(",");
    if (n.length === 0)
      return !0;
    var o = t.name || "", u = (t.type || "").toLowerCase(), g = u.replace(/\/.*$/, "");
    return n.some(function(v) {
      var x = v.trim().toLowerCase();
      return x.charAt(0) === "." ? o.toLowerCase().endsWith(x) : x.endsWith("/*") ? g === x.replace(/\/.*$/, "") : u === x;
    });
  }
  return !0;
};
function Zh(t) {
  return Q3(t) || K3(t) || u0(t) || Z3();
}
function Z3() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function K3(t) {
  if (typeof Symbol < "u" && t[Symbol.iterator] != null || t["@@iterator"] != null) return Array.from(t);
}
function Q3(t) {
  if (Array.isArray(t)) return Gl(t);
}
function Kh(t, e) {
  var n = Object.keys(t);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(t);
    e && (o = o.filter(function(u) {
      return Object.getOwnPropertyDescriptor(t, u).enumerable;
    })), n.push.apply(n, o);
  }
  return n;
}
function Qh(t) {
  for (var e = 1; e < arguments.length; e++) {
    var n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? Kh(Object(n), !0).forEach(function(o) {
      c0(t, o, n[o]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Kh(Object(n)).forEach(function(o) {
      Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
    });
  }
  return t;
}
function c0(t, e, n) {
  return e in t ? Object.defineProperty(t, e, { value: n, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = n, t;
}
function la(t, e) {
  return ty(t) || $3(t, e) || u0(t, e) || J3();
}
function J3() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function u0(t, e) {
  if (t) {
    if (typeof t == "string") return Gl(t, e);
    var n = Object.prototype.toString.call(t).slice(8, -1);
    if (n === "Object" && t.constructor && (n = t.constructor.name), n === "Map" || n === "Set") return Array.from(t);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Gl(t, e);
  }
}
function Gl(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var n = 0, o = new Array(e); n < e; n++)
    o[n] = t[n];
  return o;
}
function $3(t, e) {
  var n = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
  if (n != null) {
    var o = [], u = !0, g = !1, v, x;
    try {
      for (n = n.call(t); !(u = (v = n.next()).done) && (o.push(v.value), !(e && o.length === e)); u = !0)
        ;
    } catch (S) {
      g = !0, x = S;
    } finally {
      try {
        !u && n.return != null && n.return();
      } finally {
        if (g) throw x;
      }
    }
    return o;
  }
}
function ty(t) {
  if (Array.isArray(t)) return t;
}
var ey = typeof Us == "function" ? Us : Us.default, ny = "file-invalid-type", iy = "file-too-large", ry = "file-too-small", ay = "too-many-files", oy = function() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", e = t.split(","), n = e.length > 1 ? "one of ".concat(e.join(", ")) : e[0];
  return {
    code: ny,
    message: "File type must be ".concat(n)
  };
}, Jh = function(t) {
  return {
    code: iy,
    message: "File is larger than ".concat(t, " ").concat(t === 1 ? "byte" : "bytes")
  };
}, $h = function(t) {
  return {
    code: ry,
    message: "File is smaller than ".concat(t, " ").concat(t === 1 ? "byte" : "bytes")
  };
}, sy = {
  code: ay,
  message: "Too many files"
};
function h0(t, e) {
  var n = t.type === "application/x-moz-file" || ey(t, e);
  return [n, n ? null : oy(e)];
}
function d0(t, e, n) {
  if (mi(t.size))
    if (mi(e) && mi(n)) {
      if (t.size > n) return [!1, Jh(n)];
      if (t.size < e) return [!1, $h(e)];
    } else {
      if (mi(e) && t.size < e) return [!1, $h(e)];
      if (mi(n) && t.size > n) return [!1, Jh(n)];
    }
  return [!0, null];
}
function mi(t) {
  return t != null;
}
function ly(t) {
  var e = t.files, n = t.accept, o = t.minSize, u = t.maxSize, g = t.multiple, v = t.maxFiles, x = t.validator;
  return !g && e.length > 1 || g && v >= 1 && e.length > v ? !1 : e.every(function(S) {
    var E = h0(S, n), A = la(E, 1), Y = A[0], V = d0(S, o, u), Q = la(V, 1), tt = Q[0], rt = x ? x(S) : null;
    return Y && tt && !rt;
  });
}
function Io(t) {
  return typeof t.isPropagationStopped == "function" ? t.isPropagationStopped() : typeof t.cancelBubble < "u" ? t.cancelBubble : !1;
}
function Va(t) {
  return t.dataTransfer ? Array.prototype.some.call(t.dataTransfer.types, function(e) {
    return e === "Files" || e === "application/x-moz-file";
  }) : !!t.target && !!t.target.files;
}
function td(t) {
  t.preventDefault();
}
function cy(t) {
  return t.indexOf("MSIE") !== -1 || t.indexOf("Trident/") !== -1;
}
function uy(t) {
  return t.indexOf("Edge/") !== -1;
}
function hy() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : window.navigator.userAgent;
  return cy(t) || uy(t);
}
function wn() {
  for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++)
    e[n] = arguments[n];
  return function(o) {
    for (var u = arguments.length, g = new Array(u > 1 ? u - 1 : 0), v = 1; v < u; v++)
      g[v - 1] = arguments[v];
    return e.some(function(x) {
      return !Io(o) && x && x.apply(void 0, [o].concat(g)), Io(o);
    });
  };
}
function dy() {
  return "showOpenFilePicker" in window;
}
function fy(t) {
  if (mi(t)) {
    var e = Object.entries(t).filter(function(n) {
      var o = la(n, 2), u = o[0], g = o[1], v = !0;
      return f0(u) || (console.warn('Skipped "'.concat(u, '" because it is not a valid MIME type. Check https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types for a list of valid MIME types.')), v = !1), (!Array.isArray(g) || !g.every(p0)) && (console.warn('Skipped "'.concat(u, '" because an invalid file extension was provided.')), v = !1), v;
    }).reduce(function(n, o) {
      var u = la(o, 2), g = u[0], v = u[1];
      return Qh(Qh({}, n), {}, c0({}, g, v));
    }, {});
    return [{
      // description is required due to https://crbug.com/1264708
      description: "Files",
      accept: e
    }];
  }
  return t;
}
function py(t) {
  if (mi(t))
    return Object.entries(t).reduce(function(e, n) {
      var o = la(n, 2), u = o[0], g = o[1];
      return [].concat(Zh(e), [u], Zh(g));
    }, []).filter(function(e) {
      return f0(e) || p0(e);
    }).join(",");
}
function gy(t) {
  return t instanceof DOMException && (t.name === "AbortError" || t.code === t.ABORT_ERR);
}
function my(t) {
  return t instanceof DOMException && (t.name === "SecurityError" || t.code === t.SECURITY_ERR);
}
function f0(t) {
  return t === "audio/*" || t === "video/*" || t === "image/*" || t === "text/*" || t === "application/*" || /\w+\/[-+.\w]+/g.test(t);
}
function p0(t) {
  return /^.*\.[\w]+$/.test(t);
}
var vy = ["children"], yy = ["open"], by = ["refKey", "role", "onKeyDown", "onFocus", "onBlur", "onClick", "onDragEnter", "onDragOver", "onDragLeave", "onDrop"], xy = ["refKey", "onChange", "onClick"];
function _y(t) {
  return Cy(t) || Sy(t) || g0(t) || wy();
}
function wy() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Sy(t) {
  if (typeof Symbol < "u" && t[Symbol.iterator] != null || t["@@iterator"] != null) return Array.from(t);
}
function Cy(t) {
  if (Array.isArray(t)) return Hl(t);
}
function Ws(t, e) {
  return Ty(t) || Ey(t, e) || g0(t, e) || ky();
}
function ky() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function g0(t, e) {
  if (t) {
    if (typeof t == "string") return Hl(t, e);
    var n = Object.prototype.toString.call(t).slice(8, -1);
    if (n === "Object" && t.constructor && (n = t.constructor.name), n === "Map" || n === "Set") return Array.from(t);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Hl(t, e);
  }
}
function Hl(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var n = 0, o = new Array(e); n < e; n++)
    o[n] = t[n];
  return o;
}
function Ey(t, e) {
  var n = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
  if (n != null) {
    var o = [], u = !0, g = !1, v, x;
    try {
      for (n = n.call(t); !(u = (v = n.next()).done) && (o.push(v.value), !(e && o.length === e)); u = !0)
        ;
    } catch (S) {
      g = !0, x = S;
    } finally {
      try {
        !u && n.return != null && n.return();
      } finally {
        if (g) throw x;
      }
    }
    return o;
  }
}
function Ty(t) {
  if (Array.isArray(t)) return t;
}
function ed(t, e) {
  var n = Object.keys(t);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(t);
    e && (o = o.filter(function(u) {
      return Object.getOwnPropertyDescriptor(t, u).enumerable;
    })), n.push.apply(n, o);
  }
  return n;
}
function Qt(t) {
  for (var e = 1; e < arguments.length; e++) {
    var n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? ed(Object(n), !0).forEach(function(o) {
      Xl(t, o, n[o]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : ed(Object(n)).forEach(function(o) {
      Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
    });
  }
  return t;
}
function Xl(t, e, n) {
  return e in t ? Object.defineProperty(t, e, { value: n, enumerable: !0, configurable: !0, writable: !0 }) : t[e] = n, t;
}
function Fo(t, e) {
  if (t == null) return {};
  var n = Oy(t, e), o, u;
  if (Object.getOwnPropertySymbols) {
    var g = Object.getOwnPropertySymbols(t);
    for (u = 0; u < g.length; u++)
      o = g[u], !(e.indexOf(o) >= 0) && Object.prototype.propertyIsEnumerable.call(t, o) && (n[o] = t[o]);
  }
  return n;
}
function Oy(t, e) {
  if (t == null) return {};
  var n = {}, o = Object.keys(t), u, g;
  for (g = 0; g < o.length; g++)
    u = o[g], !(e.indexOf(u) >= 0) && (n[u] = t[u]);
  return n;
}
var Hc = /* @__PURE__ */ C.forwardRef(function(t, e) {
  var n = t.children, o = Fo(t, vy), u = v0(o), g = u.open, v = Fo(u, yy);
  return C.useImperativeHandle(e, function() {
    return {
      open: g
    };
  }, [g]), /* @__PURE__ */ so.createElement(C.Fragment, null, n(Qt(Qt({}, v), {}, {
    open: g
  })));
});
Hc.displayName = "Dropzone";
var m0 = {
  disabled: !1,
  getFilesFromEvent: N3,
  maxSize: 1 / 0,
  minSize: 0,
  multiple: !0,
  maxFiles: 0,
  preventDropOnDocument: !0,
  noClick: !1,
  noKeyboard: !1,
  noDrag: !1,
  noDragEventsBubbling: !1,
  validator: null,
  useFsAccessApi: !1,
  autoFocus: !1
};
Hc.defaultProps = m0;
Hc.propTypes = {
  /**
   * Render function that exposes the dropzone state and prop getter fns
   *
   * @param {object} params
   * @param {Function} params.getRootProps Returns the props you should apply to the root drop container you render
   * @param {Function} params.getInputProps Returns the props you should apply to hidden file input you render
   * @param {Function} params.open Open the native file selection dialog
   * @param {boolean} params.isFocused Dropzone area is in focus
   * @param {boolean} params.isFileDialogActive File dialog is opened
   * @param {boolean} params.isDragActive Active drag is in progress
   * @param {boolean} params.isDragAccept Dragged files are accepted
   * @param {boolean} params.isDragReject Some dragged files are rejected
   * @param {File[]} params.acceptedFiles Accepted files
   * @param {FileRejection[]} params.fileRejections Rejected files and why they were rejected
   */
  children: Vt.func,
  /**
   * Set accepted file types.
   * Checkout https://developer.mozilla.org/en-US/docs/Web/API/window/showOpenFilePicker types option for more information.
   * Keep in mind that mime type determination is not reliable across platforms. CSV files,
   * for example, are reported as text/plain under macOS but as application/vnd.ms-excel under
   * Windows. In some cases there might not be a mime type set at all (https://github.com/react-dropzone/react-dropzone/issues/276).
   */
  accept: Vt.objectOf(Vt.arrayOf(Vt.string)),
  /**
   * Allow drag 'n' drop (or selection from the file dialog) of multiple files
   */
  multiple: Vt.bool,
  /**
   * If false, allow dropped items to take over the current browser window
   */
  preventDropOnDocument: Vt.bool,
  /**
   * If true, disables click to open the native file selection dialog
   */
  noClick: Vt.bool,
  /**
   * If true, disables SPACE/ENTER to open the native file selection dialog.
   * Note that it also stops tracking the focus state.
   */
  noKeyboard: Vt.bool,
  /**
   * If true, disables drag 'n' drop
   */
  noDrag: Vt.bool,
  /**
   * If true, stops drag event propagation to parents
   */
  noDragEventsBubbling: Vt.bool,
  /**
   * Minimum file size (in bytes)
   */
  minSize: Vt.number,
  /**
   * Maximum file size (in bytes)
   */
  maxSize: Vt.number,
  /**
   * Maximum accepted number of files
   * The default value is 0 which means there is no limitation to how many files are accepted.
   */
  maxFiles: Vt.number,
  /**
   * Enable/disable the dropzone
   */
  disabled: Vt.bool,
  /**
   * Use this to provide a custom file aggregator
   *
   * @param {(DragEvent|Event)} event A drag event or input change event (if files were selected via the file dialog)
   */
  getFilesFromEvent: Vt.func,
  /**
   * Cb for when closing the file dialog with no selection
   */
  onFileDialogCancel: Vt.func,
  /**
   * Cb for when opening the file dialog
   */
  onFileDialogOpen: Vt.func,
  /**
   * Set to true to use the https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API
   * to open the file picker instead of using an `<input type="file">` click event.
   */
  useFsAccessApi: Vt.bool,
  /**
   * Set to true to focus the root element on render
   */
  autoFocus: Vt.bool,
  /**
   * Cb for when the `dragenter` event occurs.
   *
   * @param {DragEvent} event
   */
  onDragEnter: Vt.func,
  /**
   * Cb for when the `dragleave` event occurs
   *
   * @param {DragEvent} event
   */
  onDragLeave: Vt.func,
  /**
   * Cb for when the `dragover` event occurs
   *
   * @param {DragEvent} event
   */
  onDragOver: Vt.func,
  /**
   * Cb for when the `drop` event occurs.
   * Note that this callback is invoked after the `getFilesFromEvent` callback is done.
   *
   * Files are accepted or rejected based on the `accept`, `multiple`, `minSize` and `maxSize` props.
   * `accept` must be a valid [MIME type](http://www.iana.org/assignments/media-types/media-types.xhtml) according to [input element specification](https://www.w3.org/wiki/HTML/Elements/input/file) or a valid file extension.
   * If `multiple` is set to false and additional files are dropped,
   * all files besides the first will be rejected.
   * Any file which does not have a size in the [`minSize`, `maxSize`] range, will be rejected as well.
   *
   * Note that the `onDrop` callback will always be invoked regardless if the dropped files were accepted or rejected.
   * If you'd like to react to a specific scenario, use the `onDropAccepted`/`onDropRejected` props.
   *
   * `onDrop` will provide you with an array of [File](https://developer.mozilla.org/en-US/docs/Web/API/File) objects which you can then process and send to a server.
   * For example, with [SuperAgent](https://github.com/visionmedia/superagent) as a http/ajax library:
   *
   * ```js
   * function onDrop(acceptedFiles) {
   *   const req = request.post('/upload')
   *   acceptedFiles.forEach(file => {
   *     req.attach(file.name, file)
   *   })
   *   req.end(callback)
   * }
   * ```
   *
   * @param {File[]} acceptedFiles
   * @param {FileRejection[]} fileRejections
   * @param {(DragEvent|Event)} event A drag event or input change event (if files were selected via the file dialog)
   */
  onDrop: Vt.func,
  /**
   * Cb for when the `drop` event occurs.
   * Note that if no files are accepted, this callback is not invoked.
   *
   * @param {File[]} files
   * @param {(DragEvent|Event)} event
   */
  onDropAccepted: Vt.func,
  /**
   * Cb for when the `drop` event occurs.
   * Note that if no files are rejected, this callback is not invoked.
   *
   * @param {FileRejection[]} fileRejections
   * @param {(DragEvent|Event)} event
   */
  onDropRejected: Vt.func,
  /**
   * Cb for when there's some error from any of the promises.
   *
   * @param {Error} error
   */
  onError: Vt.func,
  /**
   * Custom validation function. It must return null if there's no errors.
   * @param {File} file
   * @returns {FileError|FileError[]|null}
   */
  validator: Vt.func
};
var ql = {
  isFocused: !1,
  isFileDialogActive: !1,
  isDragActive: !1,
  isDragAccept: !1,
  isDragReject: !1,
  acceptedFiles: [],
  fileRejections: []
};
function v0() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, e = Qt(Qt({}, m0), t), n = e.accept, o = e.disabled, u = e.getFilesFromEvent, g = e.maxSize, v = e.minSize, x = e.multiple, S = e.maxFiles, E = e.onDragEnter, A = e.onDragLeave, Y = e.onDragOver, V = e.onDrop, Q = e.onDropAccepted, tt = e.onDropRejected, rt = e.onFileDialogCancel, ut = e.onFileDialogOpen, H = e.useFsAccessApi, R = e.autoFocus, N = e.preventDropOnDocument, $ = e.noClick, at = e.noKeyboard, it = e.noDrag, gt = e.noDragEventsBubbling, b = e.onError, Pt = e.validator, P = C.useMemo(function() {
    return py(n);
  }, [n]), nt = C.useMemo(function() {
    return fy(n);
  }, [n]), bt = C.useMemo(function() {
    return typeof ut == "function" ? ut : nd;
  }, [ut]), ht = C.useMemo(function() {
    return typeof rt == "function" ? rt : nd;
  }, [rt]), l = C.useRef(null), a = C.useRef(null), c = C.useReducer(My, ql), f = Ws(c, 2), i = f[0], r = f[1], s = i.isFocused, h = i.isFileDialogActive, d = C.useRef(typeof window < "u" && window.isSecureContext && H && dy()), p = function() {
    !d.current && h && setTimeout(function() {
      if (a.current) {
        var z = a.current.files;
        z.length || (r({
          type: "closeDialog"
        }), ht());
      }
    }, 300);
  };
  C.useEffect(function() {
    return window.addEventListener("focus", p, !1), function() {
      window.removeEventListener("focus", p, !1);
    };
  }, [a, h, ht, d]);
  var m = C.useRef([]), y = function(z) {
    l.current && l.current.contains(z.target) || (z.preventDefault(), m.current = []);
  };
  C.useEffect(function() {
    return N && (document.addEventListener("dragover", td, !1), document.addEventListener("drop", y, !1)), function() {
      N && (document.removeEventListener("dragover", td), document.removeEventListener("drop", y));
    };
  }, [l, N]), C.useEffect(function() {
    return !o && R && l.current && l.current.focus(), function() {
    };
  }, [l, R, o]);
  var _ = C.useCallback(function(z) {
    b ? b(z) : console.error(z);
  }, [b]), k = C.useCallback(function(z) {
    z.preventDefault(), z.persist(), J(z), m.current = [].concat(_y(m.current), [z.target]), Va(z) && Promise.resolve(u(z)).then(function(X) {
      if (!(Io(z) && !gt)) {
        var et = X.length, ct = et > 0 && ly({
          files: X,
          accept: P,
          minSize: v,
          maxSize: g,
          multiple: x,
          maxFiles: S,
          validator: Pt
        }), ot = et > 0 && !ct;
        r({
          isDragAccept: ct,
          isDragReject: ot,
          isDragActive: !0,
          type: "setDraggedFiles"
        }), E && E(z);
      }
    }).catch(function(X) {
      return _(X);
    });
  }, [u, E, _, gt, P, v, g, x, S, Pt]), T = C.useCallback(function(z) {
    z.preventDefault(), z.persist(), J(z);
    var X = Va(z);
    if (X && z.dataTransfer)
      try {
        z.dataTransfer.dropEffect = "copy";
      } catch {
      }
    return X && Y && Y(z), !1;
  }, [Y, gt]), D = C.useCallback(function(z) {
    z.preventDefault(), z.persist(), J(z);
    var X = m.current.filter(function(ct) {
      return l.current && l.current.contains(ct);
    }), et = X.indexOf(z.target);
    et !== -1 && X.splice(et, 1), m.current = X, !(X.length > 0) && (r({
      type: "setDraggedFiles",
      isDragActive: !1,
      isDragAccept: !1,
      isDragReject: !1
    }), Va(z) && A && A(z));
  }, [l, A, gt]), j = C.useCallback(function(z, X) {
    var et = [], ct = [];
    z.forEach(function(ot) {
      var mt = h0(ot, P), lt = Ws(mt, 2), dt = lt[0], ft = lt[1], St = d0(ot, v, g), yt = Ws(St, 2), Ot = yt[0], Et = yt[1], Dt = Pt ? Pt(ot) : null;
      if (dt && Ot && !Dt)
        et.push(ot);
      else {
        var Zt = [ft, Et];
        Dt && (Zt = Zt.concat(Dt)), ct.push({
          file: ot,
          errors: Zt.filter(function(Ut) {
            return Ut;
          })
        });
      }
    }), (!x && et.length > 1 || x && S >= 1 && et.length > S) && (et.forEach(function(ot) {
      ct.push({
        file: ot,
        errors: [sy]
      });
    }), et.splice(0)), r({
      acceptedFiles: et,
      fileRejections: ct,
      isDragReject: ct.length > 0,
      type: "setFiles"
    }), V && V(et, ct, X), ct.length > 0 && tt && tt(ct, X), et.length > 0 && Q && Q(et, X);
  }, [r, x, P, v, g, S, V, Q, tt, Pt]), w = C.useCallback(function(z) {
    z.preventDefault(), z.persist(), J(z), m.current = [], Va(z) && Promise.resolve(u(z)).then(function(X) {
      Io(z) && !gt || j(X, z);
    }).catch(function(X) {
      return _(X);
    }), r({
      type: "reset"
    });
  }, [u, j, _, gt]), O = C.useCallback(function() {
    if (d.current) {
      r({
        type: "openDialog"
      }), bt();
      var z = {
        multiple: x,
        types: nt
      };
      window.showOpenFilePicker(z).then(function(X) {
        return u(X);
      }).then(function(X) {
        j(X, null), r({
          type: "closeDialog"
        });
      }).catch(function(X) {
        gy(X) ? (ht(X), r({
          type: "closeDialog"
        })) : my(X) ? (d.current = !1, a.current ? (a.current.value = null, a.current.click()) : _(new Error("Cannot open the file picker because the https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API is not supported and no <input> was provided."))) : _(X);
      });
      return;
    }
    a.current && (r({
      type: "openDialog"
    }), bt(), a.current.value = null, a.current.click());
  }, [r, bt, ht, H, j, _, nt, x]), L = C.useCallback(function(z) {
    !l.current || !l.current.isEqualNode(z.target) || (z.key === " " || z.key === "Enter" || z.keyCode === 32 || z.keyCode === 13) && (z.preventDefault(), O());
  }, [l, O]), U = C.useCallback(function() {
    r({
      type: "focus"
    });
  }, []), W = C.useCallback(function() {
    r({
      type: "blur"
    });
  }, []), I = C.useCallback(function() {
    $ || (hy() ? setTimeout(O, 0) : O());
  }, [$, O]), M = function(z) {
    return o ? null : z;
  }, B = function(z) {
    return at ? null : M(z);
  }, Z = function(z) {
    return it ? null : M(z);
  }, J = function(z) {
    gt && z.stopPropagation();
  }, G = C.useMemo(function() {
    return function() {
      var z = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, X = z.refKey, et = X === void 0 ? "ref" : X, ct = z.role, ot = z.onKeyDown, mt = z.onFocus, lt = z.onBlur, dt = z.onClick, ft = z.onDragEnter, St = z.onDragOver, yt = z.onDragLeave, Ot = z.onDrop, Et = Fo(z, by);
      return Qt(Qt(Xl({
        onKeyDown: B(wn(ot, L)),
        onFocus: B(wn(mt, U)),
        onBlur: B(wn(lt, W)),
        onClick: M(wn(dt, I)),
        onDragEnter: Z(wn(ft, k)),
        onDragOver: Z(wn(St, T)),
        onDragLeave: Z(wn(yt, D)),
        onDrop: Z(wn(Ot, w)),
        role: typeof ct == "string" && ct !== "" ? ct : "presentation"
      }, et, l), !o && !at ? {
        tabIndex: 0
      } : {}), Et);
    };
  }, [l, L, U, W, I, k, T, D, w, at, it, o]), F = C.useCallback(function(z) {
    z.stopPropagation();
  }, []), q = C.useMemo(function() {
    return function() {
      var z = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, X = z.refKey, et = X === void 0 ? "ref" : X, ct = z.onChange, ot = z.onClick, mt = Fo(z, xy), lt = Xl({
        accept: P,
        multiple: x,
        type: "file",
        style: {
          border: 0,
          clip: "rect(0, 0, 0, 0)",
          clipPath: "inset(50%)",
          height: "1px",
          margin: "0 -1px -1px 0",
          overflow: "hidden",
          padding: 0,
          position: "absolute",
          width: "1px",
          whiteSpace: "nowrap"
        },
        onChange: M(wn(ct, w)),
        onClick: M(wn(ot, F)),
        tabIndex: -1
      }, et, a);
      return Qt(Qt({}, lt), mt);
    };
  }, [a, n, x, w, o]);
  return Qt(Qt({}, i), {}, {
    isFocused: s && !o,
    getRootProps: G,
    getInputProps: q,
    rootRef: l,
    inputRef: a,
    open: M(O)
  });
}
function My(t, e) {
  switch (e.type) {
    case "focus":
      return Qt(Qt({}, t), {}, {
        isFocused: !0
      });
    case "blur":
      return Qt(Qt({}, t), {}, {
        isFocused: !1
      });
    case "openDialog":
      return Qt(Qt({}, ql), {}, {
        isFileDialogActive: !0
      });
    case "closeDialog":
      return Qt(Qt({}, t), {}, {
        isFileDialogActive: !1
      });
    case "setDraggedFiles":
      return Qt(Qt({}, t), {}, {
        isDragActive: e.isDragActive,
        isDragAccept: e.isDragAccept,
        isDragReject: e.isDragReject
      });
    case "setFiles":
      return Qt(Qt({}, t), {}, {
        acceptedFiles: e.acceptedFiles,
        fileRejections: e.fileRejections,
        isDragReject: e.isDragReject
      });
    case "reset":
      return Qt({}, ql);
    default:
      return t;
  }
}
function nd() {
}
const Py = (t) => {
  C.useEffect(() => {
    if (t === "dark" || t === "light")
      document.body.setAttribute("data-theme", t);
    else if (t === "system") {
      const e = window.matchMedia("(prefers-color-scheme: dark)"), n = () => document.body.setAttribute("data-theme", e.matches ? "dark" : "light");
      return n(), e.addEventListener("change", n), () => e.removeEventListener("change", n);
    }
  }, [t]);
}, id = (t) => {
  let e;
  const n = /* @__PURE__ */ new Set(), o = (x, S) => {
    const E = typeof x == "function" ? x(e) : x;
    if (!Object.is(E, e)) {
      const A = e;
      e = S ?? (typeof E != "object" || E === null) ? E : Object.assign({}, e, E), n.forEach((Y) => Y(e, A));
    }
  }, u = () => e, g = { setState: o, getState: u, getInitialState: () => v, subscribe: (x) => (n.add(x), () => n.delete(x)) }, v = e = t(o, u, g);
  return g;
}, Ay = (t) => t ? id(t) : id, jy = (t) => t;
function Dy(t, e = jy) {
  const n = so.useSyncExternalStore(
    t.subscribe,
    () => e(t.getState()),
    () => e(t.getInitialState())
  );
  return so.useDebugValue(n), n;
}
const rd = (t) => {
  const e = Ay(t), n = (o) => Dy(e, o);
  return Object.assign(n, e), n;
}, y0 = (t) => t ? rd(t) : rd, Xc = y0((t, e) => ({
  canvasRef: { current: null },
  history: {
    undoStack: [],
    redoStack: []
  },
  allowUndo: !1,
  allowRedo: !1,
  currentTool: "Brush",
  currentMode: "NONE",
  layerList: [],
  setCanvasRef: (n) => t({ canvasRef: n }),
  setCurrentTool: (n) => t({ currentTool: n }),
  setCurrentMode: (n) => t({ currentMode: n }),
  clearLayerList: () => t({ layerList: [] }),
  updateHistoryButtonStatus: () => {
    const { history: n } = e();
    t({
      allowUndo: n.undoStack.length > 1,
      allowRedo: n.redoStack.length > 0
    });
  },
  clearHistory: () => {
    t((n) => ({
      history: {
        undoStack: [],
        redoStack: []
      }
    })), e().updateHistoryButtonStatus();
  },
  saveToHistory: () => {
    const { canvasRef: n, history: o } = e();
    if (!n.current) return;
    const u = n.current.toJSON(["enableRetinaScaling", "elementType", "brushType"]);
    t((g) => ({
      history: {
        ...g.history,
        undoStack: [...g.history.undoStack, u],
        redoStack: []
      }
    })), e().updateHistoryButtonStatus();
  },
  undo: () => {
    const { canvasRef: n, history: o } = e();
    if (o.undoStack.length <= 1) return;
    const u = o.undoStack[o.undoStack.length - 1], g = o.undoStack[o.undoStack.length - 2];
    return t((v) => ({
      history: {
        undoStack: v.history.undoStack.slice(0, -1),
        redoStack: [...v.history.redoStack, u]
      }
    })), e().updateHistoryButtonStatus(), g;
  },
  redo: () => {
    const { canvasRef: n, history: o } = e();
    if (o.redoStack.length === 0) return;
    const u = o.redoStack[o.redoStack.length - 1];
    return t((g) => ({
      history: {
        undoStack: [...g.history.undoStack, u],
        redoStack: g.history.redoStack.slice(0, -1)
      }
    })), e().updateHistoryButtonStatus(), u;
  },
  updateLayerList: () => {
    console.log("updateLayerList");
    const { canvasRef: n } = e();
    let o = [], u = !1, g = !1, v = !1, x = !1;
    const S = n.current.getObjects().map((E, A) => {
      const Y = E.elementType;
      let V;
      Y === "BRUSH" ? E.brushType === "Add Edge Brush" ? (V = "+ edge", u = !0) : E.brushType === "Remove Edge Brush" ? (V = "- edge", u = !0) : E.brushType === "Fill Brush" ? (V = "• fill", v = !0) : (V = "color", g = !0) : Y === "PROP" && (V = "prop", x = !0);
      let Q = o.filter((rt) => rt === V).length + 1;
      const tt = V + ` ${Q}`;
      return o.unshift(V), {
        name: tt,
        setActiveFunc: () => {
          n.current.discardActiveObject(), n.current.setActiveObject(E), n.current.renderAll();
        },
        setDeactiveFunc: () => {
          n.current.discardActiveObject(), n.current.renderAll();
        },
        removeFunc: (rt) => {
          n.current.remove(E), n.current.renderAll(), rt.stopPropagation();
        },
        isActive: n.current.getActiveObjects().includes(E)
      };
    });
    t(u ? {
      currentMode: "EDGE"
    } : g ? {
      currentMode: "COLOR"
    } : v ? {
      currentMode: "FILL"
    } : x ? {
      currentMode: "PROP"
    } : {
      currentMode: "NONE"
    }), t({
      layerList: S.reverse()
    });
  },
  removeMultipleObjects: (n, o = !1) => {
    const { canvasRef: u } = e();
    n.length !== 0 && (u.current.discardActiveObject(), n.forEach((g, v) => {
      (v < n.length - 1 || o) && g.set({
        notUpdateFlag: !0
      }), u.current.remove(g);
    }), u.current.renderAll());
  },
  removeAllObjects: (n = !1) => {
    const { canvasRef: o } = e();
    e().removeMultipleObjects(o.current.getObjects(), n);
  }
})), ns = y0((t, e) => ({
  propList: [],
  selectedSAMPropIdx: -1,
  addToPropList: (n) => {
    const o = {
      src: n,
      removeFunc: (g, v) => {
        const { propList: x } = e();
        t({ propList: x.filter((S, E) => E !== v) }), g.stopPropagation();
      }
    }, { propList: u } = e();
    t({ propList: [...u, o] });
  },
  getPropByIdx: (n) => {
    const { propList: o } = e();
    return o[n];
  },
  setSelectedSAMPropIdx: (n) => {
    t({ selectedSAMPropIdx: n });
  },
  replacePropByIdx: (n, o) => {
    const { propList: u } = e(), g = u.map((v, x) => x === n ? { ...v, src: o } : v);
    t({ propList: g });
  },
  handleUploadPropImage: async (n) => {
    const o = new FileReader();
    o.onload = async (u) => {
      try {
        e().addToPropList(u.target.result);
      } catch (g) {
        console.error("Error uploading background image:", g), alert("Failed to upload prop image");
      }
    }, o.readAsDataURL(n);
  },
  clearAllProps: () => t({ propList: [] })
})), Ly = "data:image/svg+xml,%3Csvg version='1.1' id='Ebene_1' x='0px' y='0px' width='595.275px' height='595.275px' viewBox='200 215 230 470' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3C/defs%3E%3Crect x='125.3' y='264.6' width='350.378' height='349.569' style='fill: rgb(237, 0, 0); stroke: rgb(197, 2, 2);' rx='58.194' ry='58.194'%3E%3C/rect%3E%3Cg%3E%3Crect x='267.162' y='307.978' transform='matrix(0.7071 -0.7071 0.7071 0.7071 -222.6202 340.6915)' style='fill:white;' width='65.545' height='262.18' rx='32.772' ry='32.772'%3E%3C/rect%3E%3Crect x='266.988' y='308.153' transform='matrix(0.7071 0.7071 -0.7071 0.7071 398.3889 -83.3116)' style='fill:white;' width='65.544' height='262.179' rx='32.772' ry='32.772'%3E%3C/rect%3E%3C/g%3E%3C/svg%3E", b0 = document.createElement("img");
b0.src = Ly;
const Ry = ({
  uploadPaintFile: t
}) => {
  const {
    canvasRef: e,
    undo: n,
    redo: o,
    saveToHistory: u,
    currentTool: g,
    setCurrentTool: v,
    updateLayerList: x,
    removeMultipleObjects: S
  } = Xc(), {
    getPropByIdx: E
  } = ns(), [A, Y] = C.useState(5), [V, Q] = C.useState("#FFFFFF"), [tt, rt] = C.useState(0.5), ut = C.useRef(g), [H, R] = C.useState({
    "Color Brush": 5,
    Erase: 5,
    "Fill Brush": 5,
    "Add Edge Brush": 5,
    "Remove Edge Brush": 5
  }), N = (P, nt) => {
    var bt = nt.target, ht = bt.canvas;
    bt._objects ? S(bt._objects) : (ht.remove(bt), ht.requestRenderAll());
  }, $ = C.useCallback((P) => {
    if (!e.current) return;
    const nt = Math.min(e.current.width, e.current.height);
    P.hasOwnProperty("controls") || (P.cornerSize = nt / 30, P.controls.removeControl = new re.Control({
      x: 0.5,
      y: -0.5,
      offsetY: -16,
      offsetX: 16,
      cursorStyle: "pointer",
      mouseUpHandler: N,
      render: A3(b0),
      cornerSize: nt / 25
    }));
  }, []), at = C.useCallback(() => {
    if (!e.current || !e.current.lowerCanvasEl) return;
    let P = e.current.freeDrawingBrush.width;
    e.current.lowerCanvasEl.clientWidth && (P = P * e.current.lowerCanvasEl.clientWidth / e.current.getWidth());
    const nt = e.current.freeDrawingBrush.color;
    let bt = ut.current === "Color Brush" ? `<svg height="${P}" viewBox="0 0 ${P * 2} ${P * 2}" 
           width="${P}" xmlns="http://www.w3.org/2000/svg">
           <circle cx="50%" cy="50%" r="${P}" fill="${nt}" 
                   opacity="0.7"/>
         </svg>` : `<svg height="${P}" viewBox="0 0 ${P * 2} ${P * 2}" 
           width="${P}" xmlns="http://www.w3.org/2000/svg">
           <circle cx="50%" cy="50%" r="${P}" fill="#ffffff" opacity="0.7"/>
           <circle cx="50%" cy="50%" r="${P * 0.9}" fill="#000000" 
                   opacity="0.7"/>
         </svg>`;
    const ht = `data:image/svg+xml;base64,${window.btoa(bt)}`;
    e.current.freeDrawingCursor = `url(${ht}) ${P / 2} 
                                          ${P / 2}, crosshair`;
  }, []), it = C.useCallback(() => {
    const P = o();
    e.current.loadFromJSON(P, () => {
      e.current.renderAll(), t(), x();
    });
  }, [o, t, x]), gt = C.useCallback(() => {
    const P = n();
    e.current.loadFromJSON(P, () => {
      e.current.renderAll(), t(), x();
    });
  }, [n, t, x]);
  C.useEffect(() => {
    !e.current || !e.current.lowerCanvasEl || g !== "Load" && (ut.current = g, g !== "Select" && (Y(H[g]), e.current.freeDrawingBrush.width = H[g], g === "Color Brush" && (e.current.freeDrawingBrush.color = Yl(
      V,
      tt
    ))));
  }, [g]);
  const b = (P) => {
    const nt = E(P), { src: bt } = nt;
    re.Image.fromURL(bt, (ht) => {
      ht.set({
        left: 0,
        top: 0,
        width: ht.width,
        height: ht.height,
        selectable: !0,
        evented: !0,
        elementType: "PROP"
      }), ht.controls && ht.controls.removeControl && delete ht.controls.removeControl, ht.controls && ht.controls.acceptControl && delete ht.controls.acceptControl, v("Select"), e.current.isDrawingMode = !1, e.current.add(ht), e.current.renderAll(), t(), u(), x();
    });
  }, Pt = C.useCallback((P, nt, bt) => {
    const ht = new re.Canvas(P, {
      isDrawingMode: !0,
      backgroundColor: "transparent",
      enablePointerEvents: !0,
      enableRetinaScaling: !1,
      fireRightClick: !0,
      fireMiddleClick: !0,
      stopContextMenu: !0
    });
    return ht.backgroundColor = "#000000", ht.on({
      "selection:created": () => {
        v("Select"), ht.isDrawingMode = !1, x();
      },
      "selection:updated": x,
      "selection:cleared": x,
      "object:modified": () => {
        console.log("object:modified"), t(), u(), x();
      },
      "object:removed": ({ target: l }) => {
        l.notUpdateFlag || (console.log("object:removed update", l), t(), u(), x());
      },
      "mouse:up": (l) => {
        ht.getActiveObjects().forEach($), ht.isDrawingMode && (t(), u());
      },
      "path:created": ({ path: l }) => {
        l.elementType = "BRUSH", l.brushType = ut.current, console.log(l), ut.current === "Remove Edge Brush" && ht.getObjects().forEach((a) => {
          a.type === "path" && a.brushType === "Remove Edge Brush" || l.sendBackwards();
        }), ut.current === "Fill Brush" && ht.getObjects().forEach((a) => {
          a.elementType === "PROP" && l.sendBackwards();
        }), console.log(ht.getObjects().length), x();
      }
    }), e.current = ht, nt && bt && (ht.setWidth(nt), ht.setHeight(bt)), ht;
  }, [$, x, t, u]);
  return C.useEffect(() => {
    if (!e.current) return;
    const P = Yl(V, tt);
    e.current.freeDrawingBrush.color = P, at();
    const nt = e.current.getActiveObjects();
    nt.length !== 0 && (nt.forEach((bt) => {
      i0(bt) && (bt.stroke ? bt.set({
        stroke: P
      }) : bt.fill && bt.set({
        fill: P
      }));
    }), e.current.requestRenderAll(), t());
  }, [V, tt, at]), C.useEffect(() => {
    e.current && (e.current.freeDrawingBrush.width = Number(A), H[g] = Number(A), R({ ...H }), at());
  }, [A, g, at]), {
    // type,
    // setType,
    currentStrokeWidth: A,
    setCurrentStrokeWidth: Y,
    currentStrokeColor: V,
    setCurrentStrokeColor: Q,
    currentStrokeColorAlpha: tt,
    setCurrentStrokeColorAlpha: rt,
    brushWidths: H,
    setBrushWidths: R,
    handleUndo: gt,
    handleRedo: it,
    setCursorStyle: at,
    initializeCanvas: Pt,
    addPropToCanvas: b
  };
}, Iy = () => {
  const [t, e] = C.useState(0), n = C.useRef(t), o = C.useCallback((u) => {
    u ? n.current++ : n.current = Math.max(0, n.current - 1), e(n.current);
  }, []);
  return {
    isLoadingCnt: t,
    setLoadingStatus: o
  };
}, Fy = ({
  updatePromptCallBack: t
}) => {
  const [e, n] = C.useState(""), o = C.useCallback(() => {
    n(""), t("");
  }, [t]), u = C.useCallback((g) => {
    n(g), t(g);
  }, [t]);
  return {
    promptInput: e,
    clearPrompt: o,
    updatePrompt: u
  };
}, By = ({
  setCanvasSize: t,
  uploadCallbacks: e,
  setLoadingStatus: n,
  clearPrompt: o
}) => {
  const {
    canvasRef: u,
    clearHistory: g,
    saveToHistory: v,
    clearLayerList: x,
    removeAllObjects: S,
    setCurrentMode: E
  } = Xc();
  ns();
  const [A, Y] = C.useState(null), [V, Q] = C.useState(!1), tt = C.useRef({
    fill: !1,
    add_edge: !1,
    remove_edge: !1,
    color: !1,
    prop: !1,
    text: !1
  }), rt = C.useCallback(() => new Promise(
    (nt) => u.current.clone(nt, ["enableRetinaScaling", "elementType", "brushType"])
  ), [u]), ut = C.useCallback(async (nt = null) => {
    const bt = await rt();
    return bt.setHeight(u.current.height), bt.setWidth(u.current.width), nt && await nt(bt), bt.renderAll(), new Promise(
      (ht) => bt.lowerCanvasEl.toBlob(ht, "image/webp")
    );
  }, [rt]), H = C.useCallback(
    () => ut((nt) => nt),
    [ut]
  ), R = C.useCallback(
    () => ut((nt) => {
      nt.remove(...nt.getObjects());
    }),
    [ut]
  ), N = C.useCallback(
    (nt = "all") => ut((bt) => {
      bt.getObjects().forEach((ht) => {
        nt === "all" ? ht.set("visible", !0) : nt === "Fill Brush" || nt === "Add Edge Brush" || nt === "Remove Edge Brush" ? ht.elementType === "BRUSH" ? ht.set("visible", ht.brushType === nt) : ht.elementType === "PROP" && ht.set("visible", !1) : nt === "prop" ? ht.elementType === "PROP" ? ht.set("visible", !0) : ht.set("visible", !1) : nt === "text" && (ht.elementType === "TEXT" ? ht.set("visible", !0) : ht.set("visible", !1)), ht.fill && ht.set("fill", "rgb(0,0,0)"), ht.stroke && ht.set("stroke", "rgb(0,0,0)"), ht.set("globalCompositeOperation", "destination-out");
      }), bt.setBackgroundImage(null), bt.setBackgroundColor("black");
    }),
    [ut]
  ), $ = C.useCallback(
    () => ut((nt) => {
      nt.remove(...nt.getObjects().filter(
        (bt) => !(bt.elementType === "BRUSH" && bt.brushType === "Color Brush")
      ));
    }),
    [ut]
  ), at = C.useCallback(() => {
    const nt = u.current.getObjects(), bt = nt.filter(
      (s) => s.elementType === "BRUSH" && s.brushType === "Fill Brush"
    ), ht = nt.filter(
      (s) => s.elementType === "BRUSH" && s.brushType === "Add Edge Brush"
    ), l = nt.filter(
      (s) => s.elementType === "BRUSH" && s.brushType === "Remove Edge Brush"
    ), a = nt.filter(
      (s) => s.elementType === "BRUSH" && s.brushType === "Color Brush"
    ), c = nt.filter(
      (s) => s.elementType === "PROP"
    ), f = nt.filter(
      (s) => s.elementType === "TEXT"
    ), i = {
      fill: bt.length > 0,
      add_edge: ht.length > 0,
      remove_edge: l.length > 0,
      color: a.length > 0,
      prop: c.length > 0,
      text: f.length > 0
    }, r = {
      fill: tt.current.fill || i.fill,
      add_edge: tt.current.add_edge || i.add_edge,
      remove_edge: tt.current.remove_edge || i.remove_edge,
      color: tt.current.color || i.color,
      prop: tt.current.prop || i.prop,
      text: tt.current.text || i.text
    };
    return tt.current = r, r;
  }, [u]), it = C.useCallback(async (nt) => {
    const bt = await new Promise(
      (ht) => re.Image.fromURL(nt, ht)
    );
    u.current && (S(!0), Y(null), g(), o(), bt.set({ erasable: !1 }), u.current.setBackgroundImage(bt, () => {
      u.current.renderAll(), b(!0);
    }), E("NONE"), tt.current = {
      fill: !1,
      add_edge: !1,
      remove_edge: !1,
      color: !1,
      prop: !1,
      text: !1
    }, x(), t(bt.width, bt.height), v());
  }, [
    u,
    g,
    o,
    t,
    v,
    Y
  ]), gt = C.useCallback(async (nt) => {
    const bt = new FileReader();
    bt.onload = async (ht) => {
      Q(!1), n(!0);
      try {
        const l = await e.background(ht.target.result);
        l && await it(l);
      } catch (l) {
        console.error("Error uploading background image:", l), alert("Failed to upload background image");
      } finally {
        n(!1);
      }
    }, bt.readAsDataURL(nt);
  }, [e.background, it, n]), b = C.useCallback(async (nt = !1) => {
    n(!0);
    try {
      const bt = await H();
      if (await e.image(bt), nt) {
        const a = await R();
        await e.originalImage(a);
      }
      const ht = at();
      if (ht.fill || nt) {
        const a = await N("Fill Brush");
        await e.fillMask(a);
      }
      if (ht.add_edge || nt) {
        const a = await N("Add Edge Brush");
        await e.addEdgeMask(a);
      }
      if (ht.text) {
        const a = await N("text");
        await e.fillMask(a);
        const c = u.current.getObjects().find((i) => i.elementType === "TEXT");
        let f = "";
        c && (f = c.text), await e.text(f);
      }
      if (ht.remove_edge || nt) {
        const a = await N("Remove Edge Brush");
        await e.removeEdgeMask(a);
      }
      if (ht.color || nt) {
        const a = await $();
        await e.coloredImage(a);
      }
      if (ht.prop || nt) {
        const a = await N("prop");
        await e.propMask(a);
      }
      const l = await N();
      e.totalMask(l);
    } catch (bt) {
      console.error("Error in uploadPaintFile:", bt), alert("An error occurred while uploading the file.");
    } finally {
      n(!1);
    }
  }, [
    H,
    R,
    N,
    $,
    at,
    e,
    o,
    n
  ]), Pt = C.useCallback(() => {
    A && it(A);
  }, [A, it]);
  C.useCallback(
    (nt = "all", bt = -1) => ut((ht) => {
      console.log("asking", bt);
      let l = 0;
      ht.getObjects().forEach((a) => {
        nt === "all" ? a.set("visible", !0) : nt === "Fill Brush" || nt === "Add Edge Brush" || nt === "Remove Edge Brush" ? a.elementType === "BRUSH" ? a.set("visible", a.brushType === nt) : a.elementType === "PROP" && a.set("visible", !1) : nt === "prop" && (a.elementType === "PROP" && l === bt ? (a.set("visible", !0), l += 1, console.log("Keeping prop idx:", bt, "current:", l)) : a.elementType === "PROP" && l !== bt ? (a.set("visible", !1), l += 1) : a.set("visible", !1));
      }), ht.setBackgroundImage(null), ht.setBackgroundColor("transparent");
    }),
    [ut]
  );
  const P = C.useCallback(async () => {
    const nt = document.createElement("a");
    A ? nt.href = A : nt.href = u.current.toDataURL({
      format: "png",
      quality: 0.8
    }), nt.download = "magicquill.png", nt.click();
  }, [A, u]);
  return {
    // States
    generatedImg: A,
    setGeneratedImg: Y,
    uploadBgReminder: V,
    setUploadBgReminder: Q,
    // Main Operations
    uploadPaintFile: b,
    handleUploadBackgroundImage: gt,
    // Generated Image Operations
    handleAcceptGeneratedImg: Pt,
    handleDownload: P
  };
}, zy = ({ initialColor: t }) => {
  const [e, n] = C.useState(t);
  return {
    tempColor: e,
    handleColorChange: (o) => {
      n(o);
    }
  };
}, Ny = ({
  isOpen: t,
  onClose: e,
  title: n,
  children: o,
  showCloseButton: u = !0,
  closeOnEscape: g = !0,
  closeOnOutsideClick: v = !0,
  className: x = "",
  size: S = "medium"
  // "small", "medium", "large", "full"
}) => {
  const E = C.useRef(null), A = C.useRef(null);
  if (C.useEffect(() => {
    const V = (Q) => {
      g && Q.key === "Escape" && e();
    };
    return t && (document.addEventListener("keydown", V), document.body.style.overflow = "hidden"), () => {
      document.removeEventListener("keydown", V), document.body.style.overflow = "unset";
    };
  }, [t, e, g]), !t) return null;
  const Y = (V) => {
    v && V.target === E.current && e();
  };
  return /* @__PURE__ */ st.jsx(
    "div",
    {
      className: `popover-overlay ${x}`,
      ref: E,
      onClick: Y,
      children: /* @__PURE__ */ st.jsxs(
        "div",
        {
          className: `popover-content popover-${S}`,
          ref: A,
          onClick: (V) => V.stopPropagation(),
          children: [
            (n || u) && /* @__PURE__ */ st.jsxs("div", { className: "popover-header", children: [
              n && /* @__PURE__ */ st.jsx("h3", { className: "popover-title", children: n }),
              u && /* @__PURE__ */ st.jsx("button", { className: "popover-close", onClick: e, children: "×" })
            ] }),
            /* @__PURE__ */ st.jsx("div", { className: "popover-body", children: o })
          ]
        }
      )
    }
  );
}, Uy = () => {
  const t = C.useRef([]), e = C.useRef([]), n = C.useRef({ width: 0, height: 0 });
  return {
    segPointsRef: t,
    segBBoxRef: e,
    addPoint: (o, u, g) => {
      const v = {
        id: Date.now(),
        x: o,
        y: u,
        type: g
        // 'positive' or 'negative'
      };
      t.current = [...t.current, v];
    },
    addBoundingBox: (o, u, g, v) => {
      const x = {
        id: Date.now(),
        startX: Math.min(o, g),
        startY: Math.min(u, v),
        endX: Math.max(o, g),
        endY: Math.max(u, v)
      };
      e.current = [...e.current, x];
    },
    clearSegmentationData: () => {
      t.current = [], e.current = [];
    },
    getSegmentationStatus: () => {
      const o = t.current, u = e.current;
      if (o.length === 0 && u.length === 0)
        return !1;
      const g = o.filter((S) => S.type === "positive").map((S) => ({ x: S.x * n.current.width, y: S.y * n.current.height })), v = o.filter((S) => S.type === "negative").map((S) => ({ x: S.x * n.current.width, y: S.y * n.current.height })), x = u.map((S) => ({
        startX: S.startX * n.current.width,
        startY: S.startY * n.current.height,
        endX: S.endX * n.current.width,
        endY: S.endY * n.current.height
      }));
      return {
        coordinates_positive: g,
        coordinates_negative: v,
        bboxes: x
      };
    },
    imageDimensions: n
  };
}, Wy = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1736741867539, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 10913, xmlnsXlink: "http://www.w3.org/1999/xlink", width: 200, height: 200, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M938.666667 955.733333h-85.333334a17.066667 17.066667 0 0 1-17.066666-17.066666v-17.066667H187.733333v17.066667a17.066667 17.066667 0 0 1-17.066666 17.066666H85.333333a17.066667 17.066667 0 0 1-17.066666-17.066666v-85.333334a17.066667 17.066667 0 0 1 17.066666-17.066666h17.066667V187.733333H85.333333a17.066667 17.066667 0 0 1-17.066666-17.066666V85.333333a17.066667 17.066667 0 0 1 17.066666-17.066666h85.333334a17.066667 17.066667 0 0 1 17.066666 17.066666v17.066667h648.533334V85.333333a17.066667 17.066667 0 0 1 17.066666-17.066666h85.333334a17.066667 17.066667 0 0 1 17.066666 17.066666v85.333334a17.066667 17.066667 0 0 1-17.066666 17.066666h-17.066667v648.533334h17.066667a17.066667 17.066667 0 0 1 17.066666 17.066666v85.333334a17.066667 17.066667 0 0 1-17.066666 17.066666z m-68.266667-34.133333h51.2v-51.2h-51.2v51.2zM102.4 921.6h51.2v-51.2H102.4v51.2z m85.333333-34.133333h648.533334v-34.133334a17.066667 17.066667 0 0 1 17.066666-17.066666h34.133334V187.733333h-34.133334a17.066667 17.066667 0 0 1-17.066666-17.066666V136.533333H187.733333v34.133334a17.066667 17.066667 0 0 1-17.066666 17.066666H136.533333v648.533334h34.133334a17.066667 17.066667 0 0 1 17.066666 17.066666v34.133334zM904.533333 153.6h17.066667V102.4h-51.2v51.2h34.133333zM119.466667 153.6h34.133333V102.4H102.4v51.2h17.066667z", "p-id": 10914 })), Yy = C.forwardRef(Wy), Vy = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1736742209119, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 3066, xmlnsXlink: "http://www.w3.org/1999/xlink", width: 200, height: 200, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M231.491817 793.770432c71.830979 71.898517 171.021072 116.415406 280.480043 116.415406l0 0 0 0c109.461017 0 208.642924-44.51689 280.482089-116.415406 71.819722-71.916936 116.300796-171.213453 116.300796-280.791128l0 0 0 0 0 0c0-109.576651-44.482097-208.873168-116.300796-280.791128C720.614783 160.851455 621.432877 116.332519 511.971859 116.332519l0 0c-109.458971 0-208.649064 44.517913-280.480043 115.855658-71.260997 71.916936-115.730815 171.213453-115.730815 280.791128S159.660838 721.852472 231.491817 793.770432L231.491817 793.770432zM292.492122 487.299435l193.820334 0L486.312456 293.246811c0-13.680581 11.410887-25.660426 25.660426-25.660426l0 0c14.240329 0 25.659403 11.979846 25.659403 25.660426l0 194.052624 193.82238 0c14.259772 0 25.65838 11.419074 25.65838 25.679869l0 0c0 14.259772-11.399631 25.679869-25.65838 25.679869L537.632285 538.659173l0 194.033182c0 14.278191-11.419074 25.678846-25.659403 25.678846l0 0c-14.249539 0-25.660426-11.400654-25.660426-25.678846L486.312456 538.659173 292.492122 538.659173c-13.68979 0-25.660426-11.420097-25.660426-25.679869l0 0C266.831696 498.718509 278.802332 487.299435 292.492122 487.299435L292.492122 487.299435zM195.001741 195.670471C276.521383 114.632807 388.262326 64.394612 511.971859 64.394612l0 0c123.701346 0 236.021481 50.238195 316.961932 131.275859 80.959893 81.615832 131.12134 193.45399 131.12134 317.309856 0 123.836423-50.161447 236.272191-131.12134 317.309856-80.941474 81.035618-193.260585 131.255393-316.961932 131.255393-123.710556 0-235.450477-50.218752-316.971142-131.255393C114.051057 749.251495 63.881424 636.815727 63.881424 512.979304 63.881424 389.123438 114.051057 277.286304 195.001741 195.670471L195.001741 195.670471z", "p-id": 3067 })), Gy = C.forwardRef(Vy), Hy = ({
  title: t,
  titleId: e,
  ...n
}, o) => /* @__PURE__ */ C.createElement("svg", { t: 1736742197782, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 2915, xmlnsXlink: "http://www.w3.org/1999/xlink", width: 200, height: 200, ref: o, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ C.createElement("title", { id: e }, t) : null, /* @__PURE__ */ C.createElement("path", { d: "M827.355853 194.58065C742.857367 110.054535 630.478903 63.523779 510.920924 63.523779c-119.55491 0-231.888348 46.530756-316.435952 131.056871C109.912807 279.084253 63.4281 391.461693 63.4281 510.973624c0 119.507838 46.530756 231.889371 131.056871 316.434929 84.503603 84.552721 196.881043 131.056871 316.435952 131.056871 119.55798 0 231.888348-46.552246 316.434929-131.056871 84.600817-84.503603 131.061988-196.880019 131.061988-316.434929C958.417841 391.414621 911.860479 279.084253 827.355853 194.58065zM510.920924 911.408689c-220.780359 0-400.389016-179.586145-400.389016-400.392086 0-220.781382 179.608657-400.389016 400.389016-400.389016 220.801848 0 400.391063 179.607634 400.391063 400.389016C911.31301 731.822544 731.723795 911.408689 510.920924 911.408689z", "p-id": 2916 }), /* @__PURE__ */ C.createElement("path", { d: "M793.550932 534.567995 228.293985 534.567995c-12.995989 0-23.552415-10.576893-23.552415-23.551392 0-12.995989 10.556427-23.552415 23.552415-23.552415l565.255924 0c12.966313 0 23.554462 10.556427 23.554462 23.552415C817.104371 523.990079 806.516222 534.567995 793.550932 534.567995z", "p-id": 2917 })), Xy = C.forwardRef(Hy), qy = ({
  isOpen: t,
  canvasImageDataURI: e,
  onClose: n,
  updateSegmentationCallBack: o,
  onAcceptMask: u
  // New callback for accepting different mask types 
}) => {
  const g = C.useRef(null), v = C.useRef(null), x = C.useRef(null), [S, E] = C.useState(null), [A, Y] = C.useState(null), [V, Q] = C.useState("positive"), [tt, rt] = C.useState(!1), ut = C.useRef(V), H = C.useRef(!1), [R, N] = C.useState({ width: 600, height: 400 }), {
    segPointsRef: $,
    segBBoxRef: at,
    addPoint: it,
    addBoundingBox: gt,
    clearSegmentationData: b,
    getSegmentationStatus: Pt,
    imageDimensions: P
  } = Uy(), {
    selectedSAMPropIdx: nt,
    setSelectedSAMPropIdx: bt,
    addToPropList: ht,
    replacePropByIdx: l
  } = ns(), a = C.useCallback((w, O) => {
    const L = w / O;
    let U, W;
    return L > 600 / 400 ? (U = Math.min(600, w), W = U / L) : (W = Math.min(400, O), U = W * L), { width: U, height: W };
  }, []);
  C.useEffect(() => (t && e && i(), () => {
    x.current && !t && (x.current.dispose(), x.current = null);
  }), [t]);
  const c = C.useCallback(() => {
    if (b(), E(null), Y(null), Q("positive"), x.current) {
      x.current.getObjects().filter(
        (O) => O.elementType === "SEGMENTATION_RESULT" || O.elementType === "SEGMENTATION_POINT" || O.elementType === "BBOX_PREVIEW"
      ).forEach((O) => x.current.remove(O));
      const w = x.current.getObjects().find((O) => O.elementType === "BACKGROUND");
      w && w.set({ opacity: 1 }), x.current.isDrawingMode = !1, x.current.renderAll();
    }
  }, [b]), f = C.useCallback(() => {
    c(), n(), x.current && (x.current.dispose(), x.current = null), nt !== -1 && bt(-1);
  }, [c, n]), i = C.useCallback(async () => {
    if (!e) return;
    const w = await new Promise(
      (B) => re.Image.fromURL(e, B)
    ), O = w.width, L = w.height;
    P.current = { width: O, height: L };
    const U = a(O, L);
    N(U);
    const W = new re.Canvas(g.current, {
      isDrawingMode: !1,
      backgroundColor: "white",
      enablePointerEvents: !0,
      enableRetinaScaling: !1,
      fireRightClick: !0,
      fireMiddleClick: !0,
      stopContextMenu: !0,
      selection: !1,
      preserveObjectStacking: !0
    });
    W.on("mouse:down", s), W.on("mouse:move", h), W.on("mouse:up", d), w.set({
      left: 0,
      top: 0,
      selectable: !1,
      evented: !1,
      erasable: !1,
      elementType: "BACKGROUND"
    }), W.add(w), W.sendToBack(w), W.setWidth(w.width), W.setHeight(w.height);
    let { width: I, height: M } = U;
    v.current.children[0].style.width = I + "px", v.current.children[0].style.height = M + "px", v.current.children[0].children[0].style.width = I + "px", v.current.children[0].children[0].style.height = M + "px", v.current.children[0].children[1].style.width = I + "px", v.current.children[0].children[1].style.height = M + "px", W.isDrawingMode = !1, W.renderAll(), x.current = W;
  }, [e, a]), r = C.useCallback((w) => {
    if (!x.current || !w) return;
    const O = x.current.getObjects().find((L) => L.elementType === "SEGMENTATION_RESULT");
    O && x.current.remove(O), re.Image.fromURL(w, (L) => {
      L.set({
        left: 0,
        top: 0,
        width: x.current.width,
        height: x.current.height,
        erasable: !0,
        elementType: "SEGMENTATION_RESULT",
        lockMovementX: !0,
        lockMovementY: !0
      }), x.current.getObjects().forEach((U) => {
        U.elementType === "BACKGROUND" && U.set({
          opacity: 0.2
          // Dim the background when segmentation is active
        });
      }), x.current.add(L), x.current.getObjects().forEach((U) => {
        (U.elementType === "SEGMENTATION_POINT" || U.elementType === "BBOX_PREVIEW") && L.sendBackwards();
      }), x.current.renderAll();
    });
  }, [R, V]), s = (w) => {
    if (!x.current) return;
    const O = x.current.getPointer(w.e), L = O.x / x.current.width, U = O.y / x.current.height;
    if (ut.current === "positive" || ut.current === "negative") {
      const W = ut.current === "positive" ? "positive" : "negative";
      it(L, U, W), p(L, U, W), k();
    } else ut.current === "bbox" && (H.current = !0, x.current.isDrawingMode = !1, x.current._startBboxX = L, x.current._startBboxY = U);
  }, h = (w) => {
    if (!(!x.current || !H.current) && ut.current === "bbox" && H.current) {
      const O = x.current.getPointer(w.e), L = O.x / x.current.width, U = O.y / x.current.height;
      m(
        x.current._startBboxX,
        x.current._startBboxY,
        L,
        U
      );
    }
  }, d = (w) => {
    if (x.current && ut.current === "bbox" && H.current) {
      const O = x.current.getPointer(w.e), L = O.x / x.current.width, U = O.y / x.current.height, W = x.current._startBboxX, I = x.current._startBboxY;
      H.current = !1, gt(W, I, L, U), k();
    }
  }, p = C.useCallback((w, O, L) => {
    if (!x.current) return;
    const U = new re.Circle({
      left: w * x.current.width - 8,
      top: O * x.current.height - 8,
      radius: 8,
      fill: L === "positive" ? "#10b981" : "#ef4444",
      stroke: "#ffffff",
      strokeWidth: 2,
      selectable: !1,
      evented: !1,
      erasable: !1,
      elementType: "SEGMENTATION_POINT"
    });
    x.current.add(U), x.current.renderAll();
  }, [R]), m = C.useCallback((w, O, L, U) => {
    if (!x.current) return;
    const W = x.current.getObjects().find((M) => M.elementType === "BBOX_PREVIEW");
    W && x.current.remove(W);
    const I = new re.Rect({
      left: Math.min(w, L) * x.current.width,
      top: Math.min(O, U) * x.current.height,
      width: Math.abs(L - w) * x.current.width,
      height: Math.abs(U - O) * x.current.height,
      fill: "rgba(59, 130, 246, 0.1)",
      stroke: "#3b82f6",
      strokeWidth: 2,
      strokeDashArray: [5, 5],
      selectable: !1,
      evented: !1,
      erasable: !1,
      elementType: "BBOX_PREVIEW"
    });
    x.current.add(I), x.current.renderAll();
  }, [R]), y = () => {
    if (!x.current) return;
    const w = new re.EraserBrush(x.current);
    w.width = 20, x.current.freeDrawingBrush = w, _(), x.current.renderAll();
  };
  C.useEffect(() => {
    ut.current = V, x.current && (V === "eraser" ? (y(), x.current.isDrawingMode = !0) : x.current.isDrawingMode = !1);
  }, [V]);
  const _ = C.useCallback(() => {
    if (!x.current || !x.current.lowerCanvasEl) return;
    let w = x.current.freeDrawingBrush.width;
    x.current.lowerCanvasEl.clientWidth && (w = w * x.current.lowerCanvasEl.clientWidth / x.current.getWidth());
    let O = `<svg height="${w}" viewBox="0 0 ${w * 2} ${w * 2}" 
           width="${w}" xmlns="http://www.w3.org/2000/svg">
           <circle cx="50%" cy="50%" r="${w}" fill="#ffffff" opacity="0.7"/>
           <circle cx="50%" cy="50%" r="${w * 0.9}" fill="#000000" 
                   opacity="0.7"/>
         </svg>`;
    const L = `data:image/svg+xml;base64,${window.btoa(O)}`;
    x.current.freeDrawingCursor = `url(${L}) ${w / 2} 
                                          ${w / 2}, crosshair`;
  }, []), k = async () => {
    if (!o || !e) return;
    const w = Pt();
    if (w) {
      w.original_image = e, rt(!0);
      try {
        const O = await o(w);
        O && O.error === !1 && (E(O.segmentation), Y(O.bbox), r(O.segmentation));
      } catch (O) {
        console.error("Segmentation failed:", O);
      } finally {
        rt(!1);
      }
    }
  }, T = C.useCallback(() => {
    if (!S || !A) return;
    const w = x.current.getObjects().find((O) => O.elementType === "SEGMENTATION_RESULT").toDataURL(
      {
        format: "webp",
        left: A.startX,
        top: A.startY,
        width: A.endX - A.startX,
        height: A.endY - A.startY
      }
    );
    ht(w), f();
  }, [S, A, ht, f]), D = C.useCallback(() => {
    if (!S || !A || nt === -1)
      return;
    const w = x.current.getObjects().find((O) => O.elementType === "SEGMENTATION_RESULT").toDataURL(
      {
        format: "webp",
        left: A.startX,
        top: A.startY,
        width: A.endX - A.startX,
        height: A.endY - A.startY
      }
    );
    l(nt, w), f();
  }, [S, A, nt, ht, f]), j = C.useCallback((w) => {
    if (!S || !u) return;
    let O;
    if (x.current) {
      const L = x.current.getObjects().find((U) => U.elementType === "SEGMENTATION_RESULT");
      L && (O = L);
    }
    O && (u(w, O), f());
  }, [S, u, f]);
  return /* @__PURE__ */ st.jsx(
    Ny,
    {
      isOpen: t,
      onClose: f,
      title: "Smart Image Segmentation",
      className: "sam-popover",
      size: "large",
      children: /* @__PURE__ */ st.jsxs("div", { className: "sam-popover-content", children: [
        /* @__PURE__ */ st.jsxs("div", { className: "sam-tool-selection", children: [
          /* @__PURE__ */ st.jsx(
            "div",
            {
              className: "painter-tool-icon",
              onClick: () => Q("positive"),
              children: /* @__PURE__ */ st.jsx(Gy, { className: V === "positive" ? "active" : "" })
            }
          ),
          /* @__PURE__ */ st.jsx(
            "div",
            {
              className: "painter-tool-icon",
              onClick: () => Q("negative"),
              children: /* @__PURE__ */ st.jsx(Xy, { className: V === "negative" ? "active" : "" })
            }
          ),
          /* @__PURE__ */ st.jsx(
            "div",
            {
              className: "painter-tool-icon",
              onClick: () => Q("bbox"),
              children: /* @__PURE__ */ st.jsx(Yy, { className: V === "bbox" ? "active" : "" })
            }
          ),
          /* @__PURE__ */ st.jsx(
            "div",
            {
              className: "painter-tool-icon" + (S ? "" : " disabled"),
              onClick: () => Q("eraser"),
              children: /* @__PURE__ */ st.jsx(n0, { className: V === "eraser" ? "active" : "" })
            }
          ),
          /* @__PURE__ */ st.jsx(
            "button",
            {
              className: "sam-button sam-button-secondary",
              onClick: c,
              disabled: $.current.length === 0 && at.current.length === 0,
              children: "reset"
            }
          ),
          /* @__PURE__ */ st.jsx("div", { id: "seg-loading-status", hidden: !tt, children: /* @__PURE__ */ st.jsx(t0, { className: "rotating" }) })
        ] }),
        e && /* @__PURE__ */ st.jsx("div", { className: "sam-canvas-wrapper " + (tt ? " disabled" : ""), ref: v, children: /* @__PURE__ */ st.jsx(
          "canvas",
          {
            ref: g,
            className: "sam-fabric-canvas",
            style: {
              border: "1px solid #e5e7eb",
              borderRadius: "8px",
              cursor: V === "bbox" || V === "eraser" ? "crosshair" : "pointer"
            }
          }
        ) }),
        /* @__PURE__ */ st.jsx("div", { className: "sam-instructions", children: /* @__PURE__ */ st.jsxs("p", { children: [
          V === "positive" && "click to add positive points",
          V === "negative" && "click to add negative points",
          V === "bbox" && "drag to draw bounding boxes",
          V === "eraser" && "erase unwanted parts"
        ] }) }),
        S && nt === -1 && /* @__PURE__ */ st.jsxs("div", { className: "sam-accept-options", children: [
          /* @__PURE__ */ st.jsx("h4", { children: "accepted as:" }),
          /* @__PURE__ */ st.jsxs("div", { className: "sam-accept-grid", children: [
            /* @__PURE__ */ st.jsx(
              "button",
              {
                className: "sam-accept-btn",
                onClick: T,
                children: "new prop"
              }
            ),
            /* @__PURE__ */ st.jsx(
              "button",
              {
                className: "sam-accept-btn",
                onClick: () => j("Fill Brush"),
                children: "local edit mask"
              }
            ),
            /* @__PURE__ */ st.jsx(
              "button",
              {
                className: "sam-accept-btn",
                onClick: () => j("Add Edge Brush"),
                children: "add mask"
              }
            ),
            /* @__PURE__ */ st.jsx(
              "button",
              {
                className: "sam-accept-btn",
                onClick: () => j("Remove Edge Brush"),
                children: "subtract mask"
              }
            ),
            /* @__PURE__ */ st.jsx(
              "button",
              {
                className: "sam-accept-btn",
                onClick: () => j("Color Brush"),
                children: "color mask"
              }
            )
          ] })
        ] }),
        S && nt >= 0 && /* @__PURE__ */ st.jsx("div", { className: "sam-accept-options", children: /* @__PURE__ */ st.jsxs("div", { className: "sam-accept-grid", children: [
          /* @__PURE__ */ st.jsx(
            "button",
            {
              className: "sam-accept-btn",
              onClick: D,
              children: "save"
            }
          ),
          /* @__PURE__ */ st.jsx(
            "button",
            {
              className: "sam-accept-btn",
              onClick: T,
              children: "save as new prop"
            }
          )
        ] }) })
      ] })
    }
  );
}, Zy = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Ky = C.forwardRef(({
  theme: t = "system",
  autoAdaptToPhone: e = !0,
  changeDimensionCallBack: n,
  uploadImgCallBack: o,
  uploadOriginalImgCallBack: u,
  uploadFillMaskCallBack: g,
  uploadAddEdgeMaskCallBack: v,
  uploadRemoveEdgeMaskCallBack: x,
  uploadColoredImgCallBack: S,
  uploadPropMaskCallBack: E,
  uploadTotalMaskCallBack: A,
  uploadBackgroundImgCallBack: Y,
  updatePromptCallBack: V,
  updateSegmentationCallBack: Q
}, tt) => {
  Py(t);
  const rt = C.useRef(0), ut = C.useRef(null), H = C.useRef(null), R = C.useRef(null), N = C.useRef(null), $ = C.useRef(null), at = C.useRef(null), it = C.useRef(null), gt = C.useRef(null), b = C.useRef(null), Pt = C.useRef(null), P = C.useRef(null), nt = C.useRef(5), [bt, ht] = C.useState(150), [l, a] = C.useState(30), [c, f] = C.useState(!1), [i, r] = C.useState(null), { isLoadingCnt: s, setLoadingStatus: h } = Iy(), [d, p] = C.useState(!1), m = C.useRef(d);
  C.useEffect(() => {
    m.current = d;
  }, [d]);
  const {
    propList: y,
    handleUploadPropImage: _,
    setSelectedSAMPropIdx: k
  } = ns(), {
    canvasRef: T,
    setCanvasRef: D,
    saveToHistory: j,
    allowUndo: w,
    allowRedo: O,
    currentTool: L,
    setCurrentTool: U,
    setCurrentMode: W,
    currentMode: I,
    layerList: M,
    removeAllObjects: B,
    updateLayerList: Z
  } = Xc(), J = (_t, wt) => {
    const Mt = ut.current.clientWidth <= 600 && e;
    at.current.style.flexDirection = Mt ? "column" : "row", Pt.current.style.width = Mt ? "100%" : "10%", P.current.style.flexDirection = Mt ? "row" : "column", P.current.style.overflow = Mt ? "scroll hidden" : "hidden scroll", nt.current = Mt ? 3 : 5, (!_t || !wt) && (_t = at.current.clientWidth, Mt || (_t /= 2), wt = _t), T.current.setWidth(_t), T.current.setHeight(wt);
    let Ft;
    Mt ? Ft = at.current.clientWidth : Ft = at.current.clientWidth * 0.9 / 2;
    const Wt = wt / _t * Ft;
    $.current.children[0].style.width = Ft + "px", $.current.children[0].style.height = Wt + "px", $.current.children[0].children[0].style.width = Ft + "px", $.current.children[0].children[0].style.height = Wt + "px", $.current.children[0].children[1].style.width = Ft + "px", $.current.children[0].children[1].style.height = Wt + "px", it.current.style.width = Ft + "px", it.current.style.height = Wt + "px", R.current.style.height = Mt ? Wt * 2 : Wt + "px";
    const Be = Wt + H.current.clientHeight, An = H.current.clientWidth;
    n({ height: Be, width: An }), G();
  }, G = () => {
    const _t = Math.min(T.current.width, T.current.height);
    if (_t === 0)
      return;
    const wt = Math.floor(_t * 0.2), Mt = Math.floor(wt / 5) * 5, Ft = Math.floor(Mt / 5 / 5) * 5, Wt = Math.max(25, Math.min(Mt, 150)), Be = Math.max(25, Math.min(Ft, 30));
    ht(Wt), a(Be);
    const An = Math.floor(Mt / 5 / 3) * 5, ya = Math.floor(Ft / 5 / 3) * 5;
    Ot(An), Object.keys(It).forEach((Di) => {
      Di === "Add Edge Brush" ? It[Di] = ya : It[Di] = An;
    }), se(It);
  }, F = () => {
    let _t = !m.current;
    T.current.discardActiveObject(), T.current.getObjects().forEach((wt) => {
      wt.set("visible", !_t);
    }), p(_t), T.current.renderAll();
  }, {
    promptInput: q,
    clearPrompt: z,
    updatePrompt: X
  } = Fy({
    updatePromptCallBack: V
  }), {
    generatedImg: et,
    setGeneratedImg: ct,
    uploadBgReminder: ot,
    setUploadBgReminder: mt,
    uploadPaintFile: lt,
    handleUploadBackgroundImage: dt,
    handleAcceptGeneratedImg: ft,
    handleDownload: St
  } = By({
    setCanvasSize: J,
    uploadCallbacks: {
      image: o,
      originalImage: u,
      fillMask: g,
      addEdgeMask: v,
      removeEdgeMask: x,
      coloredImage: S,
      propMask: E,
      totalMask: A,
      background: Y,
      segmentation: Q
    },
    setLoadingStatus: h,
    clearPrompt: z
  }), {
    currentStrokeWidth: yt,
    setCurrentStrokeWidth: Ot,
    currentStrokeColor: Et,
    setCurrentStrokeColor: Dt,
    currentStrokeColorAlpha: Zt,
    setCurrentStrokeColorAlpha: Ut,
    brushWidths: It,
    setBrushWidths: se,
    handleUndo: Nt,
    handleRedo: ne,
    setCursorStyle: hi,
    initializeCanvas: pa,
    addPropToCanvas: gr
  } = Ry({
    uploadPaintFile: lt
  }), { tempColor: mr, handleColorChange: ga } = zy({ initialColor: Et });
  C.useImperativeHandle(tt, () => ({
    updateGeneratedImg(_t) {
      ct("data:image/webp;base64," + _t);
    }
  }));
  const { getRootProps: is, getInputProps: ma } = v0({
    onDrop: (_t) => {
      !_t || _t.length < 1 || dt(_t[0]);
    },
    accept: { "image/*": [] }
  }), Ai = (_t) => {
    const wt = {
      squareWidth: 10,
      squareDistance: 5,
      get patternCanvasSize() {
        return this.squareWidth + this.squareDistance;
      }
    }, Mt = re.document.createElement("canvas");
    Mt.width = Mt.height = wt.patternCanvasSize;
    const Ft = Mt.getContext("2d");
    Ft.fillStyle = _t ? "white" : "black", Ft.fillRect(0, 0, Mt.width, Mt.height);
    const Wt = (Be = !1) => new re.Rect({
      width: Be ? wt.squareWidth / 3 : wt.squareWidth,
      height: Be ? wt.squareWidth : wt.squareWidth / 3,
      fill: _t ? "black" : "white",
      left: (wt.patternCanvasSize - (Be ? wt.squareWidth / 3 : wt.squareWidth)) / 2,
      top: (wt.patternCanvasSize - (Be ? wt.squareWidth : wt.squareWidth / 3)) / 2
    });
    return Wt().render(Ft), _t && Wt(!0).render(Ft), Mt;
  }, va = () => {
    const _t = {
      squareWidth: 15,
      squareDistance: 10,
      get patternCanvasSize() {
        return this.squareWidth + this.squareDistance;
      }
    }, wt = re.document.createElement("canvas");
    wt.width = wt.height = _t.patternCanvasSize;
    const Mt = wt.getContext("2d");
    Mt.clearRect(0, 0, wt.width, wt.height);
    const Ft = Mt.createRadialGradient(
      wt.width / 2,
      wt.height / 2,
      0,
      wt.width / 2,
      wt.height / 2,
      _t.squareWidth / 2
    );
    Ft.addColorStop(0, "rgba(255, 255, 255, 1)"), Ft.addColorStop(0.5, "rgba(255, 255, 255, 0.6)"), Ft.addColorStop(1, "rgba(255, 255, 255, 0.4)");
    const Wt = _t.squareWidth / 2, Be = _t.patternCanvasSize / 2, An = _t.patternCanvasSize / 2;
    return Mt.beginPath(), Mt.arc(Be, An, Wt, 0, Math.PI * 2, !1), Mt.fillStyle = Ft, Mt.fill(), wt;
  }, Fe = (_t) => {
    if (T.current.discardActiveObject(), _t !== "Load" && _t !== "SAM" && U(_t), _t === "Color Brush")
      T.current.freeDrawingBrush = new re.PencilBrush(T.current), T.current.isDrawingMode = !0;
    else if (_t === "Fill Brush") {
      const wt = new re.PatternBrush(T.current);
      wt.getPatternSrc = () => va(), wt.source = wt.getPatternSrc(), T.current.freeDrawingBrush = wt, T.current.isDrawingMode = !0;
    } else if (_t === "Add Edge Brush" || _t === "Remove Edge Brush") {
      const wt = _t === "Add Edge Brush", Mt = new re.PatternBrush(T.current);
      Mt.getPatternSrc = () => Ai(wt), Mt.source = Mt.getPatternSrc(), T.current.freeDrawingBrush = Mt, T.current.isDrawingMode = !0;
    } else if (_t === "Erase")
      T.current.freeDrawingBrush = new re.EraserBrush(T.current), T.current.isDrawingMode = !0;
    else if (_t === "Select")
      T.current.isDrawingMode = !1;
    else if (_t === "Load")
      gt.current.click(), W("NONE");
    else if (_t === "SAM") {
      T.current.isDrawingMode = !1, f(!0), r(T.current.toDataURL("image/webp", 1));
      return;
    }
    T.current.requestRenderAll();
  }, ji = async (_t, wt) => {
    T.current.add(wt);
    let Mt;
    switch (_t) {
      case "Add Edge Brush":
        Mt = new re.Pattern({
          source: Ai(!0),
          repeat: "repeat"
        });
        break;
      case "Remove Edge Brush":
        Mt = new re.Pattern({
          source: Ai(!1),
          repeat: "repeat"
        });
        break;
      case "Fill Brush":
        Mt = new re.Pattern({
          source: va(),
          repeat: "repeat"
        });
        break;
      case "Color Brush":
        Mt = Yl(Et, Zt);
        break;
      default:
        Mt = "transparent";
    }
    const Ft = new re.Rect({
      left: wt.left,
      top: wt.top,
      width: wt.width,
      height: wt.height,
      fill: Mt,
      opacity: 1,
      selectable: !0,
      evented: !0,
      elementType: "BRUSH",
      brushType: _t
    });
    wt.set({
      backgroundColor: "transparent",
      left: -1 * wt.width / 2,
      top: -1 * wt.height / 2
    }), Ft.controls && Ft.controls.removeControl && delete Ft.controls.removeControl, Ft.controls && Ft.controls.acceptControl && delete Ft.controls.acceptControl, Ft.clipPath = wt, T.current.add(Ft), wt.patternOverlay = Ft, wt.set({
      notUpdateFlag: !0
    }), T.current.remove(wt), lt(), Z();
  };
  return C.useEffect(() => {
    if (at.current && N.current) {
      const Mt = pa(N.current);
      D({ current: Mt }), J(null, null), mt(!0), Fe("Fill Brush"), j();
    }
    const _t = (Mt) => {
      for (let Ft of Mt) {
        let Wt = Ft.contentRect.width;
        Wt !== rt.current && (rt.current = Wt, !T.current.width || !T.current.height ? J(Wt, Wt) : J(T.current.width, T.current.height), hi());
      }
    }, wt = new ResizeObserver(_t);
    return ut.current && wt.observe(ut.current), () => {
      ut.current && wt.unobserve(ut.current), T.current && T.current.dispose();
    };
  }, []), /* @__PURE__ */ st.jsxs("div", { style: { height: "100%", width: "100%" }, ref: ut, children: [
    /* @__PURE__ */ st.jsxs("div", { className: "top-bar", ref: H, children: [
      /* @__PURE__ */ st.jsx("div", { id: "prompt-input-box", children: /* @__PURE__ */ st.jsx("input", { id: "prompt-input", placeholder: "Tell us what you'd like to create!", onChange: (_t) => X(_t.target.value), value: q }) }),
      /* @__PURE__ */ st.jsxs("div", { id: "tool-bar", children: [
        /* @__PURE__ */ st.jsxs("div", { id: "essential-tool-box", children: [
          /* @__PURE__ */ st.jsx("input", { type: "file", accept: "image/jpeg,image/png,image/webp", hidden: !0, ref: gt, onChange: (_t) => {
            dt(_t.target.files[0]), _t.target.value = null;
          } }),
          P3.map((_t) => {
            const wt = _t.icon;
            return /* @__PURE__ */ st.jsx(
              "div",
              {
                className: "painter-tool-icon" + (_t.disabledInMode.includes(I) ? " disabled" : ""),
                title: _t.title,
                onClick: () => {
                  _t.disabledInMode.includes(I) || Fe(_t.title);
                },
                children: /* @__PURE__ */ st.jsx(wt, { className: L === _t.title ? "active" : "" })
              },
              _t.title
            );
          })
        ] }),
        ["Add Edge Brush", "Remove Edge Brush", "Fill Brush", "Color Brush", "Erase"].includes(L) && /* @__PURE__ */ st.jsxs("div", { id: "stroke-size-box", children: [
          /* @__PURE__ */ st.jsx("div", { className: "separator" }),
          /* @__PURE__ */ st.jsx("input", { type: "range", id: "stroke-width-slider", min: "1", max: L === "Add Edge Brush" ? l : bt, value: yt, step: "1", title: "Stroke width", onChange: (_t) => Ot(_t.target.value) }),
          /* @__PURE__ */ st.jsx("div", { id: "stroke-width-value", children: yt })
        ] }),
        /* @__PURE__ */ st.jsxs("div", { id: "color-and-alpha-box", children: [
          (L === "Color Brush" || T.current && T.current.getActiveObjects().length > 0 && T.current.getActiveObjects().every(i0)) && /* @__PURE__ */ st.jsxs(st.Fragment, { children: [
            /* @__PURE__ */ st.jsx("div", { className: "separator" }),
            /* @__PURE__ */ st.jsx(
              "input",
              {
                id: "stroke-color",
                type: "color",
                value: mr,
                title: "Stroke color",
                onChange: (_t) => {
                  ga(_t.target.value), $.current.classList.add("canvas-locked");
                },
                onBlur: () => {
                  Dt(mr), $.current.classList.remove("canvas-locked");
                }
              }
            ),
            /* @__PURE__ */ st.jsx(
              "input",
              {
                id: "stroke-color-transparent",
                type: "number",
                max: "1.0",
                min: "0.1",
                step: "0.05",
                value: Zt,
                title: "Stroke alpha value",
                onChange: (_t) => Ut(_t.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ st.jsxs("div", { id: "painter-history-panel", children: [
            /* @__PURE__ */ st.jsx("div", { className: "separator" }),
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon" + (w ? "" : " disabled"), title: "Undo", children: /* @__PURE__ */ st.jsx(a3, { title: "Undo", onClick: () => Nt() }) }),
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon" + (O ? "" : " disabled"), title: "Redo", children: /* @__PURE__ */ st.jsx(s3, { title: "Redo", onClick: () => ne() }) })
          ] })
        ] }),
        /* @__PURE__ */ st.jsx("div", { id: "download-box", children: /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon", children: /* @__PURE__ */ st.jsx(v3, { title: "Download", onClick: () => St() }) }) })
      ] })
    ] }),
    /* @__PURE__ */ st.jsxs("div", { className: "lower-area", ref: R, children: [
      /* @__PURE__ */ st.jsxs("div", { className: "side-bar", children: [
        /* @__PURE__ */ st.jsxs("div", { className: "layer-box", children: [
          /* @__PURE__ */ st.jsxs("div", { className: "layer-operation-box", children: [
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon", title: "Remove All", id: "layer-remove-button", children: /* @__PURE__ */ st.jsx(Ns, { title: "Remove All", onClick: () => B() }) }),
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon", title: "Hide All", id: "layer-hide-button", onClick: () => F(), children: /* @__PURE__ */ st.jsx(p3, { className: d ? "active" : "", title: "Hide All" }) })
          ] }),
          /* @__PURE__ */ st.jsx("div", { className: "layer-item-list", children: M.map((_t) => /* @__PURE__ */ st.jsxs(
            "div",
            {
              className: "layer-item-container" + (_t.isActive ? " active" : ""),
              onClick: () => _t.isActive ? _t.setDeactiveFunc() : _t.setActiveFunc(),
              children: [
                /* @__PURE__ */ st.jsx("div", { className: "layer-item", children: _t.name }),
                /* @__PURE__ */ st.jsx(Ns, { className: "layer-item-remove", title: "Remove", onClick: (wt) => _t.removeFunc(wt) })
              ]
            },
            _t.name
          )) })
        ] }),
        /* @__PURE__ */ st.jsx("div", { id: "loading-status", hidden: s === 0, children: /* @__PURE__ */ st.jsx(t0, { className: "rotating" }) })
      ] }),
      /* @__PURE__ */ st.jsxs("div", { id: "output-area", ref: at, children: [
        /* @__PURE__ */ st.jsxs("div", { id: "left-box", children: [
          ot && /* @__PURE__ */ st.jsxs("div", { ...is({ id: "bg-reminder" }), children: [
            /* @__PURE__ */ st.jsx("input", { ...ma() }),
            /* @__PURE__ */ st.jsx("p", { id: "bg-reminder-text", children: "Upload or drop an image here" })
          ] }),
          /* @__PURE__ */ st.jsx("div", { id: "canvas-box", ref: $, children: /* @__PURE__ */ st.jsx("canvas", { ref: N }) })
        ] }),
        /* @__PURE__ */ st.jsx("div", { id: "prop-box", ref: Pt, children: /* @__PURE__ */ st.jsxs("div", { id: "prop-box-list", ref: P, children: [
          y.map((_t, wt) => /* @__PURE__ */ st.jsxs("div", { className: "item", onClick: (Mt) => {
            gr(wt);
          }, children: [
            /* @__PURE__ */ st.jsx(
              "img",
              {
                className: "img",
                src: _t.src
              }
            ),
            /* @__PURE__ */ st.jsx(
              "div",
              {
                className: "painter-tool-icon prop-item-remove",
                title: "Remove",
                onClick: (Mt) => _t.removeFunc(Mt, wt),
                children: /* @__PURE__ */ st.jsx(Ns, {})
              }
            ),
            /* @__PURE__ */ st.jsx(
              "div",
              {
                className: "painter-tool-icon prop-item-sam",
                title: "Remove",
                onClick: (Mt) => {
                  f(!0), r(_t.src), k(wt), Mt.stopPropagation();
                },
                children: /* @__PURE__ */ st.jsx(e0, {})
              }
            )
          ] }, wt)),
          new Array(y.length < nt.current ? nt.current - y.length : 1).fill(0).map((_t, wt) => /* @__PURE__ */ st.jsx("div", { className: "item", children: /* @__PURE__ */ st.jsx("div", { className: "placeholder", children: wt === 0 && /* @__PURE__ */ st.jsxs("div", { className: "painter-tool-icon", children: [
            /* @__PURE__ */ st.jsx("input", { type: "file", accept: "image/jpeg,image/png,image/webp", hidden: !0, ref: b, onChange: (Mt) => {
              _(Mt.target.files[0]), Mt.target.value = null;
            } }),
            /* @__PURE__ */ st.jsx($p, { onClick: () => b.current.click() })
          ] }) }) }, wt))
        ] }) }),
        /* @__PURE__ */ st.jsxs("div", { id: "output-img-box", ref: it, children: [
          et && /* @__PURE__ */ st.jsxs("div", { id: "output-operation-box", children: [
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon", title: "Accept", onClick: () => ft(), children: /* @__PURE__ */ st.jsx(c3, { title: "Accept", style: { fill: "#507B58" } }) }),
            /* @__PURE__ */ st.jsx("div", { className: "painter-tool-icon", title: "Discard", onClick: () => ct(null), children: /* @__PURE__ */ st.jsx(h3, { title: "Discard", style: { fill: "#AB3131" } }) })
          ] }),
          /* @__PURE__ */ st.jsx("img", { id: "output-img", src: et || Zy })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ st.jsx(
      qy,
      {
        isOpen: c,
        canvasImageDataURI: i,
        onClose: () => f(!1),
        updateSegmentationCallBack: Q,
        onAcceptMask: (_t, wt) => ji(_t, wt)
      }
    )
  ] });
}), Qy = (t, e) => {
  console.log(t, e, "embedMagicQuill");
  const n = Math.random().toString(36).substring(7);
  if (!t)
    throw "DOM element not found.";
  const o = so.createRef();
  return window.updateGeneratedImg || (window.updateGeneratedImg = {}), window.updateGeneratedImg[n] = (u) => {
    o.current && o.current.updateGeneratedImg(u);
  }, Iv.render(
    // <React.StrictMode>
    /* @__PURE__ */ st.jsx(Ky, { ...e, ref: o }),
    // </React.StrictMode>,
    t
  ), n;
}, {
  SvelteComponent: Jy,
  assign: $y,
  binding_callbacks: t2,
  check_outros: e2,
  create_component: x0,
  destroy_component: _0,
  detach: ad,
  element: n2,
  flush: Ga,
  get_spread_object: i2,
  get_spread_update: r2,
  group_outros: a2,
  init: o2,
  insert: od,
  mount_component: w0,
  safe_not_equal: s2,
  space: l2,
  transition_in: Vr,
  transition_out: Bo
} = window.__gradio__svelte__internal, { onMount: c2 } = window.__gradio__svelte__internal;
function sd(t) {
  let e, n;
  const o = [
    { i18n: "" },
    { autoscroll: !0 },
    { translucent: !0 },
    /*loading_status*/
    t[0]
  ];
  let u = {};
  for (let g = 0; g < o.length; g += 1)
    u = $y(u, o[g]);
  return e = new Vg({ props: u }), {
    c() {
      x0(e.$$.fragment);
    },
    m(g, v) {
      w0(e, g, v), n = !0;
    },
    p(g, v) {
      const x = v & /*loading_status*/
      1 ? r2(o, [
        o[0],
        o[1],
        o[2],
        i2(
          /*loading_status*/
          g[0]
        )
      ]) : {};
      e.$set(x);
    },
    i(g) {
      n || (Vr(e.$$.fragment, g), n = !0);
    },
    o(g) {
      Bo(e.$$.fragment, g), n = !1;
    },
    d(g) {
      _0(e, g);
    }
  };
}
function u2(t) {
  let e, n, o, u = (
    /*loading_status*/
    t[0] && sd(t)
  );
  return {
    c() {
      u && u.c(), e = l2(), n = n2("div");
    },
    m(g, v) {
      u && u.m(g, v), od(g, e, v), od(g, n, v), t[5](n), o = !0;
    },
    p(g, v) {
      /*loading_status*/
      g[0] ? u ? (u.p(g, v), v & /*loading_status*/
      1 && Vr(u, 1)) : (u = sd(g), u.c(), Vr(u, 1), u.m(e.parentNode, e)) : u && (a2(), Bo(u, 1, 1, () => {
        u = null;
      }), e2());
    },
    i(g) {
      o || (Vr(u), o = !0);
    },
    o(g) {
      Bo(u), o = !1;
    },
    d(g) {
      g && (ad(e), ad(n)), u && u.d(g), t[5](null);
    }
  };
}
function h2(t) {
  let e, n;
  return e = new z0({
    props: {
      $$slots: { default: [u2] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      x0(e.$$.fragment);
    },
    m(o, u) {
      w0(e, o, u), n = !0;
    },
    p(o, [u]) {
      const g = {};
      u & /*$$scope, el, loading_status*/
      8388611 && (g.$$scope = { dirty: u, ctx: o }), e.$set(g);
    },
    i(o) {
      n || (Vr(e.$$.fragment, o), n = !0);
    },
    o(o) {
      Bo(e.$$.fragment, o), n = !1;
    },
    d(o) {
      _0(e, o);
    }
  };
}
function d2(t, e, n) {
  var o = this && this.__awaiter || function(P, nt, bt, ht) {
    function l(a) {
      return a instanceof bt ? a : new bt(function(c) {
        c(a);
      });
    }
    return new (bt || (bt = Promise))(function(a, c) {
      function f(s) {
        try {
          r(ht.next(s));
        } catch (h) {
          c(h);
        }
      }
      function i(s) {
        try {
          r(ht.throw(s));
        } catch (h) {
          c(h);
        }
      }
      function r(s) {
        s.done ? a(s.value) : l(s.value).then(f, i);
      }
      r((ht = ht.apply(P, nt || [])).next());
    });
  };
  let { value: u = {
    from_frontend: {
      img: null,
      original_image: null,
      add_edge_mask: null,
      remove_edge_mask: null,
      add_color_image: null,
      add_prop_image: null,
      prompt_image: null,
      total_mask: null,
      fill_mask: null
    },
    from_backend: { prompt: null, generated_image: null }
  } } = e, { loading_status: g = void 0 } = e, v = null, { theme: x = "system" } = e, { url: S = void 0 } = e, E, A;
  function Y() {
    if (u.from_backend !== void 0 && u.from_backend.generated_image !== null && u.from_backend.generated_image !== v && window.updateGeneratedImg && window.updateGeneratedImg[A]) {
      const P = window.updateGeneratedImg[A];
      P(u.from_backend.generated_image), v = u.from_backend.generated_image;
    }
  }
  const V = (P) => new Promise((nt, bt) => {
    const ht = new FileReader();
    ht.onloadend = () => nt(ht.result), ht.readAsDataURL(P);
  }), Q = (P) => console.log(P), tt = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.img = nt, u);
  }), rt = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.original_image = nt, u);
  }), ut = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.add_edge_mask = nt, u);
  }), H = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.remove_edge_mask = nt, u);
  }), R = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.add_color_image = nt, u);
  }), N = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.total_mask = nt, u);
  }), $ = (P) => o(void 0, void 0, void 0, function* () {
    return yield fetch(`${S || ""}/magic_quill/process_background_img`, {
      method: "POST",
      body: JSON.stringify(P),
      headers: { "content-type": "application/json" }
    }).then((bt) => bt.json());
  }), at = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield fetch(`${S || ""}/magic_quill/segmentation`, {
      method: "POST",
      body: JSON.stringify({
        image: P.original_image,
        coordinates_positive: P.coordinates_positive,
        coordinates_negative: P.coordinates_negative,
        bboxes: P.bboxes
      }),
      headers: { "content-type": "application/json" }
    }).then((bt) => bt.json());
    return {
      error: !1,
      segmentation: nt.segmentation_image,
      bbox: nt.segmentation_bbox
    };
  }), it = (P) => {
    n(2, u.from_backend.prompt = P, u);
  }, gt = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.fill_mask = nt, u);
  }), b = (P) => o(void 0, void 0, void 0, function* () {
    const nt = yield V(P);
    n(2, u.from_frontend.add_prop_image = nt, u);
  });
  c2(() => {
    A = Qy(E, {
      theme: x,
      changeDimensionCallBack: Q,
      uploadImgCallBack: tt,
      uploadOriginalImgCallBack: rt,
      uploadAddEdgeMaskCallBack: ut,
      uploadRemoveEdgeMaskCallBack: H,
      uploadColoredImgCallBack: R,
      uploadTotalMaskCallBack: N,
      uploadBackgroundImgCallBack: $,
      updateSegmentationCallBack: at,
      updatePromptCallBack: it,
      uploadFillMaskCallBack: gt,
      uploadPropMaskCallBack: b
    });
  });
  function Pt(P) {
    t2[P ? "unshift" : "push"](() => {
      E = P, n(1, E);
    });
  }
  return t.$$set = (P) => {
    "value" in P && n(2, u = P.value), "loading_status" in P && n(0, g = P.loading_status), "theme" in P && n(3, x = P.theme), "url" in P && n(4, S = P.url);
  }, t.$$.update = () => {
    t.$$.dirty & /*value*/
    4 && u === null && n(2, u = {
      from_frontend: {
        img: null,
        original_image: null,
        add_edge_image: null,
        remove_edge_image: null,
        add_color_image: null,
        add_prop_image: null,
        prompt_image: null,
        total_mask: null,
        fill_mask: null
      },
      from_backend: { prompt: null, generated_image: null }
    }), t.$$.dirty & /*value*/
    4 && Y();
  }, [g, E, u, x, S, Pt];
}
class f2 extends Jy {
  constructor(e) {
    super(), o2(this, e, d2, h2, s2, {
      value: 2,
      loading_status: 0,
      theme: 3,
      url: 4
    });
  }
  get value() {
    return this.$$.ctx[2];
  }
  set value(e) {
    this.$$set({ value: e }), Ga();
  }
  get loading_status() {
    return this.$$.ctx[0];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), Ga();
  }
  get theme() {
    return this.$$.ctx[3];
  }
  set theme(e) {
    this.$$set({ theme: e }), Ga();
  }
  get url() {
    return this.$$.ctx[4];
  }
  set url(e) {
    this.$$set({ url: e }), Ga();
  }
}
export {
  f2 as default
};
