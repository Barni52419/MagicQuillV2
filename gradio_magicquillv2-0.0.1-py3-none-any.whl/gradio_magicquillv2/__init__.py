
from .magicquillv2 import MagicQuillV2

__all__ = ['MagicQuillV2']
